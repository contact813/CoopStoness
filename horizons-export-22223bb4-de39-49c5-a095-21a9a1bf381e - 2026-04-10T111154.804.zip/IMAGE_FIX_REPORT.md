# Image Fix Report: Centralized Handling

## 1. Centralization
- **File Created**: `src/lib/imageUtils.js`
- **Function**: `getProductImage(product)`
- **Logic**:
  - Checks if `product` exists.
  - Prioritizes `images[0]` if it's an array.
  - Handles string arrays `["url"]`.
  - Handles object arrays `[{url: "..."}]`, `[{src: "..."}]`, `[{image_url: "..."}]`.
  - Fallbacks to `thumbnail_url`.
  - Fallbacks to static placeholder `https://cdn.coopstones.com/placeholders/product.png`.
  - **NEVER** throws errors or returns null/undefined.

## 2. Updated Components
The following components were updated to use the new utility:
1.  **ProductCard.jsx**: Replaced inline logic with `getProductImage(product)`.
2.  **ProductsList.jsx (Admin)**: Standardized image rendering in the table.
3.  **RoundDetail.jsx**: Updated `RoundProductCard` to use the utility.
4.  **Product.jsx (Detail Page)**: Updated main image and gallery rendering.
5.  **RoundView.jsx**: Updated deprecated view just in case.
6.  **ProductEdit.jsx (Admin)**: Updated preview logic.

## 3. Compatibility Check
- **Old Products**: Works correctly (uses `thumbnail_url` or array).
- **New Products**: Works correctly (uses `images` array).
- **Imported Products**: Works correctly (handles `src` vs `url` vs `image_url` property names).
- **Missing Images**: Safely returns placeholder without crashing.
- **Empty Arrays**: Safely returns placeholder.

## 4. Verification
- All direct property access like `images[0].url` has been removed.
- All components now import from `@/lib/imageUtils`.
- onError handlers were preserved or standardized to reset to placeholder.

## 5. Result
The application now has a single source of truth for product images, eliminating "cannot read property of undefined" errors related to image arrays.