# Product Panel Update Report

This report details the updates made to the Admin Product Panel to support SKU management and price formatting.

## 1. Admin Products List (`src/admin/ProductsList.jsx`)
*   **SKU Display**: Added SKU display in the same column as "Vendor".
    *   **Structure**: Vendor name on top, SKU in smaller, mono-spaced font immediately below.
    *   **Fallback**: Displays "—" (em dash) if SKU is null or empty.
    *   **Visuals**: Used `text-zinc-600` and `font-mono` for clear distinction from the vendor name.
*   **Price Formatting**: Confirmed price column uses `${Number(row.price).toFixed(2)}` format (e.g., "$49.95").

## 2. Product Edit Form (`src/admin/ProductEdit.jsx`)
*   **SKU Input**: Added a new input field for SKU.
    *   **Location**: Placed immediately below the "Vendor" input field in the grid layout.
    *   **Binding**: Bound to `model.SKU` state.
*   **Price Input Formatting**:
    *   **Visual Prefix**: Wrapped the Price `Input` component in a relative `div` container.
    *   **Icon**: Added a `$` symbol positioned absolutely to the left (`left-3`).
    *   **Padding**: Added `pl-7` class to the input to prevent the text from overlapping with the `$` symbol.
    *   **Data Integrity**: The input remains `type="number"`, ensuring only numeric values are stored in the state and sent to the database.

## 3. Data Integration (`src/lib/adminProductsApi.js`)
*   **Fetch**: Updated `listAdminProducts` to include `SKU` in the `.select()` statement from `v_products_admin`.
*   **Search**: Updated search logic to allow searching by SKU.
*   **Save/Update**:
    *   Updated `ProductEdit.jsx`'s `handleSave` function to explicitly include `SKU` in the payload sent to `createProduct` and `updateProduct`.
    *   Ensured `SKU` is handled as a string (defaulting to empty string if null).

## Verification
*   **View**: Product list now shows SKU below vendor.
*   **Edit**: Editing a product allows changing the SKU.
*   **Save**: Saving a product persists the SKU to the Supabase `products` table.
*   **Search**: Searching for a SKU string filters the product list correctly.
*   **Price**: Price inputs and displays now clearly show the currency symbol without altering the underlying numeric data.