# Product System Analysis Report

This report details the current state of the product database schema, views, triggers, and logic flow to explain why some products (especially new ones) may not appear as expected.

## 1. Products Table Schema
**Table:** `public.products`

| Column | Type | Nullable | Description |
|--------|------|----------|-------------|
| `id` | `bigint` | NO | Primary Key (Identity) |
| `handle` | `text` | YES | URL slug |
| `title` | `text` | YES | Product Name |
| `vendor` | `text` | YES | Brand/Manufacturer |
| `type` | `text` | YES | Used as 'Category' in views |
| `tags` | `text` | YES | CSV string of tags |
| `price` | `double precision` | YES | Base price |
| `inventory` | `text` | YES | stored as TEXT (e.g. "100") |
| `description` | `text` | YES | HTML content |
| `images` | `jsonb` | YES | Array of image objects/urls |
| `status` | `text` | NO | 'active', 'draft', 'archived' |
| `thumbnail_url` | `text` | YES | Cover image URL |
| `SKU` | `text` | YES | Stock Keeping Unit |
| `created_at` | `timestamptz` | NO | Default: now() |
| `updated_at` | `timestamptz` | NO | Default: now() |

**Key Findings:**
*   **Inventory is Text:** The `inventory` field is stored as `text`, not `integer`. This requires casting in all views and triggers.
*   **Redundant Triggers:** There are 3 separate triggers attached to this table that perform nearly identical logic.

---

## 2. View Definitions (Reconstructed)

### A) `v_products_admin`
Used by the Admin Panel to list products.