# Product Catalog System - Technical Analysis Report

## 1. Executive Summary
The current Coop Stones application operates primarily on a **Simple Product Model**, despite the database schema containing structures for complex variants (`product_variants`, `product_options`). The frontend relies heavily on database Views (`v_products_public`, `v_products_admin`) rather than direct table access for reading data.

**Key Findings:**
*   **Abstraction Layer:** The frontend is decoupled from raw tables via `v_products_public`.
*   **Variant Status:** Partial/Legacy. The database has variant tables, and `CartContext` supports `options`/`model`, but the Admin UI (`ProductEdit.jsx`) and Product Detail Page (`Product.jsx`) currently only support simple products (1 product = 1 SKU).
*   **Categorization:** Relies on a flat string column `category` rather than a relational `collections` table.
*   **Inventory:** Handled via RPC functions and real-time subscriptions, not direct table updates from the client.

---

## 2. Screen & Flow Mapping

### A. Marketplace (`src/pages/Marketplace.jsx`)
*   **Primary Data Source:** `lib/productsApi.js` -> `fetchProducts`
*   **Secondary Data Source:** `lib/productsApi.js` -> `fetchAllCategories`
*   **Display Logic:**
    *   Grid layout using `ProductCard`.
    *   Client-side state controls Pagination (`page`, `pageSize`) and Filtering (`query`, `category`).
    *   **Crucial:** Filters are applied at the database level (via API params), not client-side.

### B. Product Detail (`src/pages/Product.jsx`)
*   **Primary Data Source:** `lib/productsApi.js` -> `fetchProductById`
*   **Inventory Source:** `utils/supabaseInventory.js` -> `getProductAvailability` (RPC) + Realtime Subscription on `inventory_reservations`.
*   **Display Logic:**
    *   Renders single price (`product.price`).
    *   Image Gallery: Uses `product.images` (JSONB).
    *   **Missing:** No variant selector (Size/Color) visible in this component.
*   **Action:** Calls `reserveStock` (RPC) before adding to cart.

### C. Admin Product Edit (`src/admin/ProductEdit.jsx`)
*   **Read Source:** `lib/adminProductsApi.js` -> `getProductById` (Direct `products` table query).
*   **Write Source:** `createProduct` / `updateProduct` (Direct `products` table write).
*   **Fields Managed:** Title, Vendor, Type (Category), Price, Inventory, Description, Images, Tags, Status, SKU.
*   **Gap:** Does not manage `product_variants` table.

### D. Rounds Detail (`src/pages/RoundDetail.jsx`)
*   **Data Source:** `lib/roundsApi.js` -> `getRoundPublic`.
*   **Aggregation:**
    1.  Fetches Round Metadata (`rounds` table).
    2.  Calls RPC `get_round_products_with_sales` to get linked product IDs and Round-specific overrides (discount, goal).
    3.  Calls `fetchProductsByIds` to get full product details.
    4.  Merges arrays in JavaScript.

---

## 3. Actual Queries Used

### Frontend Public Access (`src/lib/productsApi.js`)