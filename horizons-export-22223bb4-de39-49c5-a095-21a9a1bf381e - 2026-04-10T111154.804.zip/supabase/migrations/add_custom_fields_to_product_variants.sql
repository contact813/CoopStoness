-- Migration: Add custom_title and custom_description to product_variants

-- 1. Add Columns
ALTER TABLE public.product_variants 
ADD COLUMN IF NOT EXISTS custom_title TEXT NULL,
ADD COLUMN IF NOT EXISTS custom_description TEXT NULL;

-- 2. Add Comments for documentation
COMMENT ON COLUMN public.product_variants.custom_title IS 'Optional custom title for this specific variant. Overrides product title when selected.';
COMMENT ON COLUMN public.product_variants.custom_description IS 'Optional custom description for this specific variant. Overrides product description when selected.';

-- 3. Create Index for performance on searches involving custom titles
CREATE INDEX IF NOT EXISTS idx_product_variants_custom_title ON public.product_variants(custom_title);