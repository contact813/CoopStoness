
CREATE INDEX IF NOT EXISTS idx_round_carts_round_id_user_id_status ON round_carts(round_id, user_id, status);
CREATE INDEX IF NOT EXISTS idx_round_cart_items_round_cart_id_status ON round_cart_items(round_cart_id, status);
CREATE INDEX IF NOT EXISTS idx_round_cart_items_variant_id ON round_cart_items(variant_id);
CREATE INDEX IF NOT EXISTS idx_product_variants_product_id ON product_variants(product_id);
CREATE INDEX IF NOT EXISTS idx_rounds_status_starts_at ON rounds(status, starts_at);
