
import { serve } from "https://deno.land/std@0.168.0/http/server.ts"
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.39.3'
import Stripe from 'https://esm.sh/stripe@14.16.0'
import { corsHeaders } from '../_shared/cors.ts'

const stripe = new Stripe(Deno.env.get('STRIPE_SECRET_KEY') as string, {
  apiVersion: '2023-10-16',
})

const supabaseUrl = Deno.env.get('SUPABASE_URL') as string
const supabaseServiceRoleKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') as string

const supabase = createClient(supabaseUrl, supabaseServiceRoleKey)

serve(async (req) => {
  const signature = req.headers.get('Stripe-Signature')

  if (!signature) {
    return new Response('No signature', { status: 400 })
  }

  try {
    const body = await req.text()
    const event = stripe.webhooks.constructEvent(
      body,
      signature,
      Deno.env.get('STRIPE_WEBHOOK_SECRET') as string
    )

    if (event.type === 'checkout.session.completed') {
      const session = event.data.object
      const userId = session.metadata.userId

      // Explicitly reject marketplace orders
      if (session.metadata.type === 'marketplace') {
          console.warn(`[Marketplace Legacy] Ignored marketplace order for user ${userId}. Marketplace is disabled.`);
          return new Response(JSON.stringify({ received: true, message: 'Marketplace is disabled' }), {
              headers: { ...corsHeaders, 'Content-Type': 'application/json' },
              status: 200
          });
      }

      // Existing Round Order Logic
      if (session.metadata.type === 'round_order') {
        const roundId = session.metadata.roundId
        const { error } = await supabase
          .from('round_carts')
          .update({ 
            status: 'paid', 
            paid_at: new Date().toISOString() 
          })
          .eq('user_id', userId)
          .eq('round_id', roundId)

        if (error) console.error('Error updating round cart:', error)
      } 
      // Handle membership subscription checkout
      else if (session.metadata.type === 'membership_subscription') {
          console.log(`Processing membership subscription for user ${userId}`);
          // Membership logic goes here if needed.
          // Usually handled directly by customer.subscription.updated/deleted events from stripe.
      }
    }
    
    // Additional webhook types for memberships
    if (event.type === 'customer.subscription.updated' || event.type === 'customer.subscription.deleted') {
       // Membership webhook updates handled appropriately.
       console.log(`Received subscription event: ${event.type}`);
    }

    return new Response(JSON.stringify({ received: true }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    })
  } catch (err) {
    console.error(`Error processing webhook: ${err.message}`)
    return new Response(JSON.stringify({ error: err.message }), { status: 400 })
  }
})
