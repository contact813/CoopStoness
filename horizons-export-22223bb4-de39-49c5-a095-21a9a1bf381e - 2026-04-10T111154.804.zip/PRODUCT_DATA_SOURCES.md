# Product Data Sources Analysis

This report details exactly how product data is queried across the Admin Panel, Marketplace, and Round configurations, including specific code paths and database schema definitions.

## 1. Admin Products List
**File:** `src/lib/adminProductsApi.js` (called by `src/admin/ProductsList.jsx`)

The Admin Panel uses the `v_products_admin` view to display the main product list.

**Exact Code:**