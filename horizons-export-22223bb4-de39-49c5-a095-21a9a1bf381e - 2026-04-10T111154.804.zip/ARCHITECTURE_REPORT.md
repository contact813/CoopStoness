# Coop Stones Architecture Report

**Generated on:** 2026-01-27
**System:** Coop Stones Cooperative E-commerce Platform

## 1. VISÃO GERAL
The Coop Stones platform is a specialized e-commerce solution designed for a cooperative of stone industry experts. The system is built on a modern React frontend (Vite) and utilizes Supabase as a comprehensive Backend-as-a-Service (BaaS) provider.

The core of the system revolves around two primary purchasing models:
1.  **Marketplace:** A traditional e-commerce catalog where members can browse active products, manage carts, and purchase items directly.
2.  **Rounds (Group Purchases):** Time-limited, goal-oriented sales events where members commit to purchasing products to achieve volume discounts. This model relies on "Round Products" which are snapshots of catalog products with specific pricing and goals for that round.

The architecture emphasizes inventory accuracy through a reservation system, hierarchical product variants (Product -> Options -> Values -> Variants), and role-based access control (Admin vs. Member vs. Public).

## 2. ESTRUTURA DE BANCO DE DADOS

### Products & Catalog
*   **products**
    *   `id` (bigint): Primary Key.
    *   `handle` (text): URL-friendly slug.
    *   `title` (text): Product name.
    *   `vendor` (text): Manufacturer or supplier.
    *   `type` (text): Product category.
    *   `tags` (text): CSV or searchable tags.
    *   `price` (double precision): Base price.
    *   `inventory` (integer): Total available stock across all variants (or standalone).
    *   `description` (text): HTML content.
    *   `images` (jsonb): Array of image objects `{url, path}`.
    *   `status` (text): 'active', 'draft', 'archived'. Controlled by triggers based on inventory.
    *   `created_at`, `updated_at` (timestamp).
    *   `thumbnail_url` (text): Primary display image.
    *   `SKU`, `sku_raw` (text): Stock Keeping Unit.
    *   `published_marketplace` (boolean): Visibility toggle.

*   **product_variants**
    *   `id` (uuid): Primary Key.
    *   `product_id` (bigint): FK to products.
    *   `title` (text): Variant specific name (e.g., "Red / Large").
    *   `sku` (text): Variant SKU.
    *   `barcode` (text).
    *   `price` (numeric): Variant specific price.
    *   `compare_at_price` (numeric).
    *   `inventory_qty` (integer): Stock for this specific variant.
    *   `image_url` (text).
    *   `is_active` (boolean).
    *   `position` (integer).

*   **product_options**
    *   `id` (uuid): Primary Key.
    *   `product_id` (bigint): FK to products.
    *   `name` (text): Option name (e.g., "Color", "Size").
    *   `position` (integer).

*   **product_option_values**
    *   `id` (uuid): Primary Key.
    *   `option_id` (uuid): FK to product_options.
    *   `value` (text): Specific value (e.g., "Red", "XL").
    *   `position` (integer).

*   **variant_option_values** (Junction Table)
    *   `variant_id` (uuid): FK to product_variants.
    *   `option_value_id` (uuid): FK to product_option_values.

### Collections
*   **collections**
    *   `id` (bigint).
    *   `handle`, `title`.
*   **product_collections**
    *   `product_id` (bigint), `collection_id` (bigint).

### Rounds (Group Buys)
*   **rounds**
    *   `id` (uuid).
    *   `slug`, `title`, `subtitle`, `description`.
    *   `cover_image_url`, `cover_path`.
    *   `starts_at`, `ends_at` (timestamp).
    *   `status` (text): 'active', 'closed', etc.
    *   `goal_amount`, `committed_amount` (numeric): Financial tracking.
    *   `discount_pct` (numeric): Global round discount.
    *   `order_index` (integer).

*   **round_products**
    *   `round_id` (uuid).
    *   `product_id` (bigint), `product_id_bigint`.
    *   `variant_id` (uuid): Optional FK. If present, this row represents a specific variant in the round.
    *   `special_price` (numeric): Overridden price for this round.
    *   `discount_pct` (numeric): Specific item discount.
    *   `stock_override` (integer): Limit specifically for this round.
    *   `goal_qty` (integer), `goal_unit` (text): Sales target.
    *   `is_featured` (boolean).
    *   `position` (integer).

### Carts & Commerce
*   **round_carts**
    *   `id` (uuid).
    *   `user_id` (uuid).
    *   `round_id` (uuid).
    *   `status` (text): 'reserved', 'eligible_to_pay', 'paid'.
    *   `expires_at` (timestamp).

*   **round_cart_items**
    *   `id` (uuid).
    *   `round_cart_id` (uuid).
    *   `product_id` (bigint).
    *   `qty` (integer).
    *   `unit_price` (numeric).

*   **marketplace_carts**
    *   `id` (uuid).
    *   `user_id` (uuid).
    *   `status` (text).
    *   `session_id` (text).

*   **marketplace_cart_items**
    *   `id` (uuid).
    *   `cart_id` (uuid).
    *   `product_id` (bigint).
    *   `qty` (integer).
    *   `unit_price` (numeric).

### Orders & Sales
*   **orders**
    *   `id` (uuid).
    *   `user_id` (uuid).
    *   `status` (text).
    *   `total_amount` (numeric).
    *   `stripe_payment_intent_id`, `stripe_session_id`.

*   **order_items**
    *   `id` (bigint).
    *   `order_id` (uuid).
    *   `product_id` (bigint).
    *   `qty`, `unit_price`, `total_price`.

*   **sales_events** (Analytics Log)
    *   `id` (bigint).
    *   `order_id`, `user_id`, `product_id`, `round_id`.
    *   `qty`, `price_paid`.

*   **inventory_reservations** (Concurrency Control)
    *   `id` (uuid).
    *   `product_id` (bigint).
    *   `qty` (integer).
    *   `session_id` (uuid).
    *   `status`: 'active', 'purchased', 'expired', 'released'.
    *   `expires_at`.

## 3. ROTAS DO FRONTEND

### Public
*   `/` - Landing Page
*   `/marketplace` - Product Catalog & Filtering
*   `/product/:id` - Detailed Product View
*   `/rounds` - Active Group Buys List
*   `/rounds/:slug` - Round Detail View
*   `/login` - Authentication
*   `/about`, `/contact`, `/blog`, `/membership` - Content Pages

### Member Protected (Requires Authentication)
*   `/cart` - Unified Cart Management (Rounds & Marketplace)
*   `/checkout` - Stripe Integration Wrapper
*   `/payment-success` - Post-purchase confirmation
*   `/account` - User Profile & Order History

### Admin Protected (Requires Role='admin')
*   `/admin` - Dashboard
*   `/admin/products` - Product List
*   `/admin/products/new` - Create Product
*   `/admin/products/:id` - Edit Product System
*   `/admin/rounds` - Round Management
*   `/admin/rounds/:id` - Edit Round & Linked Products
*   `/admin/categories`, `/admin/users`, `/admin/orders` - Other management resources

## 4. COMPONENTES E PÁGINAS

### Key Pages
*   **Marketplace.jsx:** Handles fetching products with pagination, search, category filtering, and display logic.
*   **Product.jsx (Detail):** Fetches comprehensive product data including variants and options. Manages the variant selection logic to determine active price/image/stock.
*   **CartPage.jsx:** Complex state manager. Splits view into "Marketplace Items" and "Round Reservations". Handles expiration timers and checkout initialization.
*   **RoundEditPage.jsx:** Admin tool. Allows linking products to rounds, setting special prices, managing goals, and hierarchically adding variants as sub-rows.

### Key Components
*   **ProductCard.jsx:** Universal card. Handles stock badges, price ranges, and "Add to Cart" vs "Select Options" logic.
*   **ProductGallery.jsx:** Interactive image viewer with zoom and thumbnail navigation.
*   **VariantSelectorShopify.jsx:** UI for selecting options (Color, Size, etc.) and visualizing out-of-stock states.
*   **RoundProductCard.jsx:** Specialized card for rounds showing discount percentages, goals, and round-specific context.
*   **VariantsSection.jsx (Admin):** Table for managing existing variants (SKU, Price, Inventory) and creating new ones.
*   **OptionsSection.jsx (Admin):** Defines the dimensions of the product (e.g., defining "Size" has values "S, M, L").

## 5. FLUXO DE DADOS

### Product Creation
1.  Admin defines **Title** & **Base Info**.
2.  Admin defines **Options** (e.g., Color: Red, Blue).
3.  System generates combinatorial **Variants**.
4.  Admin inputs SKUs, Inventory, and Prices for each Variant.
5.  **Save:** Atomic transaction recreates options/values and syncs variants to DB.

### Round Workflow
1.  **Create Round:** Admin sets dates and metadata.
2.  **Link Products:** Admin searches catalog. Adds a product.
3.  **Variant Selection:** If product has variants, Admin expands row and selects specific variants to include in the round.
4.  **Pricing:** Admin sets `special_price` for the round context.
5.  **User View:** Members see special pricing. Adding to cart creates a `round_cart_item`.
6.  **Checkout:** Round carts are processed separately via `createRoundCheckout`.

### Inventory & Reservations
1.  **Add to Cart:** Triggers `reserve_stock` RPC function in Postgres.
2.  **Lock:** An `inventory_reservation` row is created; product inventory is effectively reduced by calculating `total - reserved`.
3.  **Timer:** Frontend counts down.
4.  **Checkout:** On success, reservation status -> 'purchased', and actual `products.inventory` is decremented.
5.  **Expiration:** Background job or lazy check marks old reservations 'expired'.

## 6. LÓGICA DE NEGÓCIO

*   **Product Status:**
    *   Trigger `trg_products_status` automatically sets status to 'draft' if `inventory <= 0`.
    *   Ensures out-of-stock items don't clutter the marketplace unless desired.
*   **Variant Resolution:**
    *   Frontend finds the specific `product_variant` ID by matching all selected `option_value`s.
    *   If no match found, "Unavailable" is shown.
*   **Round Discounts:**
    *   Hierarchy: `special_price` > `round_item.discount_pct` > `round.discount_pct` > `product.price`.
*   **Cart Cleanup:**
    *   Separate logic for Marketplace carts (immediate purchase) vs Round Carts (reservation/commitment model).

## 7. RELACIONAMENTOS (ERD Simplificado)