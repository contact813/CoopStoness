
# Relatório de Auditoria Arquitetural: Rounds e Pedidos (COOPSTONES)

Este documento apresenta uma análise detalhada da arquitetura de rodadas (Rounds) e pedidos (Orders) da plataforma Coop Stones, identificando fluxos de dados, inconsistências estruturais e bugs críticos.

═══════════════════════════════════════════════════════════════

## SEÇÃO 1: ESTRUTURA DE PEDIDOS DO SITE

### 1. Tabelas de pedidos existentes

**Tabela `orders`**
| Coluna | Tipo | Constraints / Detalhes |
|--------|------|------------------------|
| `id` | uuid | NOT NULL, Primary Key |
| `user_id` | uuid | NOT NULL, Foreign Key (profiles.id) |
| `status` | text | NOT NULL |
| `total_amount` | numeric | NOT NULL |
| `stripe_payment_intent_id` | text | - |
| `stripe_session_id` | text | - |
| `created_at` | timestamp with time zone | - |
| `updated_at` | timestamp with time zone | - |

**Tabela `order_items`**
| Coluna | Tipo | Constraints / Detalhes |
|--------|------|------------------------|
| `id` | bigint | NOT NULL, Primary Key |
| `order_id` | uuid | NOT NULL, Foreign Key (orders.id) |
| `product_id` | bigint | - |
| `product_title` | text | - |
| `qty` | integer | NOT NULL |
| `unit_price` | numeric | NOT NULL |
| `total_price` | numeric | NOT NULL |
| `discount_amount` | numeric | - |
| `created_at` | timestamp with time zone | - |

*   **Existe campo `source_type` ou similar para rastrear origem (rounds vs marketplace)?** NÃO EXISTE.
*   **Existe campo `round_id` em `orders` ou `order_items`?** NÃO EXISTE.

### 2. Arquivo que alimenta "My Orders"

*   **Arquivo exato:** `src/components/account/AccountOrders.jsx`
*   **Função/API usada:** Acesso direto via cliente Supabase (`supabase.from('round_carts').select(...)`)
*   **Como filtra pedidos do usuário:** Usa `.eq('user_id', user.id)` e filtra apenas status confirmados `.in('status', ['confirmed', 'eligible_to_pay', 'paid', 'completed'])`.

**Código exato da função:**
