# Product Data Flow Documentation

This document outlines the complete lifecycle and data flow of Products within the application, including storage locations, relationships, system interactions, and data persistence mechanisms.

---

## 1. Product Storage Location

The central source of truth for all product records is the **`public.products`** table in the Supabase PostgreSQL database. 

- **Primary Key:** `id` (bigint)
- **Core Fields:** `title`, `handle`, `description`, `price`, `inventory`, `status`, `images` (jsonb), `created_at`, `updated_at`.
- **Access:** Governed strictly by Row Level Security (RLS) policies.

---

## 2. Related Product Tables

Products rarely exist in isolation. They are linked to multiple auxiliary tables that define their complete taxonomy, variations, and history.

| Table Name | Purpose / Relationship to `products` |
| :--- | :--- |
| `public.products` | The core product entity containing base fields. |
| `public.product_variants` | Holds different variations of a product (e.g., sizes, colors), linked by `product_id`. |
| `public.product_options` | Defines the types of options a product has (e.g., "Color", "Size"). |
| `public.product_option_values` | Defines the specific values for those options (e.g., "Red", "Large"). |
| `public.variant_option_values` | Mapping table joining `product_variants` to `product_option_values`. |
| `public.product_collections` | Many-to-many join table mapping `products` to `collections`. |
| `public.collections` | Categories or groupings that products belong to. |
| `public.round_products` | Join table defining which products are available in specific sales "Rounds". |

*(Note: `product_images` are primarily stored as a `jsonb` array directly on the `products` table in this schema, referencing objects in the Supabase Storage `product-images` bucket).*

---

## 3. Complete Data Flow Diagrams (Text-Based)

### A. New Product Creation Flow