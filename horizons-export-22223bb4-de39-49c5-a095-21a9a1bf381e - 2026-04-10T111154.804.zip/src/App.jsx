
/**
 * FILENAME: src/App.jsx
 * PURPOSE: Application Router Config.
 */
import React, { useEffect, useState } from 'react';
import { Routes, Route, Outlet, Navigate } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import { AlertCircle } from 'lucide-react';

// Context
import { ProductsProvider } from '@/contexts/ProductsContext';

// Pages
import HomePage from '@/pages/HomePage';
import AboutPage from '@/pages/AboutPage';
import MembershipPage from '@/pages/MembershipPage';
import MembershipGoldPage from '@/pages/MembershipGoldPage';
import MembershipPlatinumPage from '@/pages/MembershipPlatinumPage';
import BlogPage from '@/pages/BlogPage';
import BlogPostPage from '@/pages/BlogPostPage';
import ContactPage from '@/pages/ContactPage';
import Marketplace from '@/pages/Marketplace';
import ProductPage from '@/pages/Product';
import CartPage from '@/pages/CartPage';
import LoginPage from '@/pages/Login';
import SetPassword from '@/pages/SetPassword';
import ResetPasswordPage from '@/pages/ResetPasswordPage';
import RoundsPage from '@/pages/Rounds';
import RoundDetailPage from '@/pages/RoundDetail';
import RoundProduct from '@/pages/RoundProduct'; 
import RoundCartPage from '@/pages/RoundCartPage';
import AccountPage from '@/pages/Account';
import Checkout from '@/pages/Checkout';
import PaymentSuccess from '@/pages/payment-success';

// Legal Pages
import TermsAndConditions from '@/pages/TermsAndConditions';
import PrivacyPolicy from '@/pages/PrivacyPolicy';
import RefundPolicy from '@/pages/RefundPolicy';
import CompanyInformation from '@/pages/CompanyInformation';

// Admin Imports
import AdminLayout from '@/admin/AdminLayout';
import Dashboard from '@/pages/admin/Dashboard';
import RoundsList from '@/admin/RoundsList';
import RoundEdit from '@/admin/RoundEdit';
import ProductsPage from '@/pages/admin/ProductsPage'; 
import ProductEditPage from '@/pages/admin/ProductEditPage'; 
import VariantEditPage from '@/pages/admin/VariantEditPage';
import AdminBlogList from '@/pages/admin/blog/index.jsx';
import AdminBlogEdit from '@/pages/admin/blog/[id].jsx';
import UsersPage from '@/pages/admin/Users.jsx';
import UserDetails from '@/pages/admin/users/UserDetails.jsx';
import UserEdit from '@/pages/admin/users/UserEdit.jsx';
import UserCreate from '@/pages/admin/users/UserCreate.jsx';
import AdminOrdersPage from '@/pages/admin/Orders.jsx';
import OrderDetailPage from '@/pages/admin/OrderDetail.jsx';
import MembershipApplicationsPage from '@/pages/admin/MembershipApplicationsPage';
import SystemAudit from '@/pages/admin/SystemAudit.jsx';

// Components & Gates
import { Toaster } from "@/components/ui/toaster";
import ProtectedRoute from '@/components/ProtectedRoute';
import AdminGate from '@/components/AdminGate';
import AdminErrorBoundary from '@/components/admin/AdminErrorBoundary';
import SubscriptionWarningModal from '@/components/SubscriptionWarningModal';

// Diagnostics
import { generateDiagnosticReport } from '@/lib/diagnosticReport';

const Layout = () => {
  return (
    <div className="min-h-screen flex flex-col bg-black">
      <Header />
      <SubscriptionWarningModal />
      <main className="flex-1 pt-16">
        <div className="section-bg min-h-full">
          <Outlet />
        </div>
      </main>
      <Footer />
    </div>
  );
};

function App() {
  const [globalError, setGlobalError] = useState(null);

  useEffect(() => {
    console.log('[App] Component mounted. Initiating diagnostic report...');
    
    const runDiagnostics = async () => {
      try {
        const report = await generateDiagnosticReport();
        if (report.supabase.connectionStatus === 'failed') {
          console.error('[App] Diagnostic reported a Supabase connection failure.');
          setGlobalError(`Database Connection Error: ${report.supabase.error}`);
        }
      } catch (err) {
        console.error('[App] Failed to run diagnostics:', err);
      }
    };

    runDiagnostics();
  }, []);

  if (globalError) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center text-white px-4">
        <div className="max-w-md w-full bg-red-950/30 border border-red-900 rounded-xl p-8 text-center flex flex-col items-center">
          <AlertCircle className="w-16 h-16 text-red-500 mb-6" />
          <h1 className="text-2xl font-bold mb-4 text-red-500">System Initialization Error</h1>
          <p className="text-zinc-400 mb-6">{globalError}</p>
          <p className="text-sm text-zinc-500">Please check your environment configuration or network connectivity.</p>
        </div>
      </div>
    );
  }

  return (
    <>
      <Helmet>
        <title>Coop Stones - Exclusive Cooperative for Stone Industry Experts</title>
        <meta name="description" content="Join Coop Stones, an exclusive cooperative built by and for stone industry experts." />
      </Helmet>
      <Toaster />
      <Routes>
        <Route element={<Layout />}>
          {/* Legacy Marketplace Redirects */}
          <Route path="/marketplace" element={<Navigate to="/rounds" replace />} />
          <Route path="/marketplace/*" element={<Navigate to="/rounds" replace />} />
          <Route path="/cart" element={<Navigate to="/rounds" replace />} />
          <Route path="/checkout" element={<Navigate to="/rounds" replace />} />
          <Route path="/payment-success" element={<Navigate to="/rounds" replace />} />

          {/* Public Routes */}
          <Route path="/" element={<HomePage />} />
          <Route path="/about" element={<AboutPage />} />
          <Route path="/membership" element={<MembershipPage />} />
          <Route path="/membership/gold" element={<MembershipGoldPage />} />
          <Route path="/membership/platinum" element={<MembershipPlatinumPage />} />
          <Route path="/blog" element={<BlogPage />} />
          <Route path="/blog/:slug" element={<BlogPostPage />} />
          <Route path="/contact" element={<ContactPage />} />
          <Route path="/login" element={<LoginPage />} />
          
          <Route path="/set-password" element={<SetPassword />} />
          <Route path="/auth/set-password" element={<SetPassword />} />
          <Route path="/reset-password" element={<ResetPasswordPage />} />
          
          {/* Legal Pages */}
          <Route path="/terms-and-conditions" element={<TermsAndConditions />} />
          <Route path="/privacy-policy" element={<PrivacyPolicy />} />
          <Route path="/refund-policy" element={<RefundPolicy />} />
          <Route path="/company-information" element={<CompanyInformation />} />

          {/* Protected Routes */}
          <Route element={<ProtectedRoute />}>
            <Route path="/rounds/:slug/product/:productId" element={<RoundProduct />} />
            <Route path="/rounds/:slug/cart" element={<RoundCartPage />} />
            <Route path="/rounds" element={<RoundsPage />} />
            <Route path="/rounds/:slug" element={<RoundDetailPage />} />
            <Route path="/product/:id" element={<ProductPage />} />
            <Route path="/account" element={<AccountPage />} />
          </Route>
          
          {/* Admin Routes wrapped in ProductsProvider */}
          <Route path="/admin" element={
            <AdminGate>
              <AdminErrorBoundary>
                <ProductsProvider>
                  <AdminLayout />
                </ProductsProvider>
              </AdminErrorBoundary>
            </AdminGate>
          }>
            <Route index element={<Dashboard />} />
            <Route path="analytics" element={<Navigate to="/admin" replace />} />
            <Route path="audit" element={<SystemAudit />} />
            <Route path="rounds" element={<RoundsList />} />
            <Route path="rounds/:id" element={<RoundEdit />} />
            
            <Route path="products/new" element={<ProductEditPage />} />
            <Route path="products/:productId/variants/new" element={<VariantEditPage />} />
            <Route path="products/:productId/variants/:variantId" element={<VariantEditPage />} />
            <Route path="products/:id" element={<ProductEditPage />} />
            <Route path="products" element={<ProductsPage />} />
            
            <Route path="blog" element={<AdminBlogList />} />
            <Route path="blog/:id" element={<AdminBlogEdit />} />
            
            <Route path="users/new" element={<UserCreate />} />
            <Route path="users/edit/:id" element={<UserEdit />} />
            <Route path="users/:id" element={<UserDetails />} />
            <Route path="users" element={<UsersPage />} />
            
            <Route path="orders/:id" element={<OrderDetailPage />} />
            <Route path="orders" element={<AdminOrdersPage />} />
            <Route path="membership-applications" element={<MembershipApplicationsPage />} />
            
            {/* Legacy redirect */}
            <Route path="standard-orders" element={<Navigate to="/admin/orders" replace />} />
            <Route path="round-orders" element={<Navigate to="/admin/orders" replace />} />
          </Route>
        </Route>
      </Routes>
    </>
  );
}

export default App;
