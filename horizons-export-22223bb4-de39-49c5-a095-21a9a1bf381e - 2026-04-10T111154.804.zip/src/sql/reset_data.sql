
-- SQL Reset Script for Development/Testing
-- Use this to clear all data to test fresh flows.

-- 1. Clear Round Carts and Orders
TRUNCATE TABLE round_cart_items CASCADE;
TRUNCATE TABLE round_carts CASCADE;

-- 2. Clear Orders
TRUNCATE TABLE order_items CASCADE;
TRUNCATE TABLE orders CASCADE;

-- 3. Clear Sales Events (Analytics)
TRUNCATE TABLE sales_events CASCADE;

-- 4. Clear Rounds
TRUNCATE TABLE rounds CASCADE;

-- 5. Clear Products and Variants
TRUNCATE TABLE product_variants CASCADE;
TRUNCATE TABLE products CASCADE;

-- Reset Sequences if they exist
ALTER SEQUENCE IF EXISTS products_id_seq RESTART WITH 1;
