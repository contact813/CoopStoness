import React from 'react';
import { Helmet } from 'react-helmet';
import { Building2, MapPin, Mail, Phone, ShieldCheck } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

const CompanyInformation = () => {
  return (
    <div className="container mx-auto px-4 py-16 md:px-8 max-w-4xl">
      <Helmet>
        <title>Company Information – COOPSTONES</title>
        <meta name="description" content="Official company information for COOPSTONES LLC. Legal address, contact details, and compliance information." />
        <meta property="og:title" content="Company Information – COOPSTONES" />
        <link rel="canonical" href="https://coopstones.com/company-information" />
      </Helmet>

      <h1 className="text-4xl font-bold text-white mb-8">Company Information</h1>

      <div className="grid gap-6 md:grid-cols-2">
        <Card className="bg-zinc-900 border-zinc-800 text-zinc-100">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-yellow-500">
              <Building2 className="h-6 w-6" />
              Legal Identity
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3 text-zinc-300">
            <div className="flex flex-col">
              <span className="text-sm text-zinc-500 uppercase font-bold">Company Name</span>
              <span className="text-lg">COOPSTONES LLC</span>
            </div>
            <div className="flex flex-col">
              <span className="text-sm text-zinc-500 uppercase font-bold">Company Type</span>
              <span>Limited Liability Company (LLC)</span>
            </div>
            <div className="flex flex-col">
              <span className="text-sm text-zinc-500 uppercase font-bold">EIN / Tax ID</span>
              <span>(Available upon request for B2B partners)</span>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-zinc-900 border-zinc-800 text-zinc-100">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-yellow-500">
              <MapPin className="h-6 w-6" />
              Physical Address
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3 text-zinc-300">
            <p>
              W St Conrad St<br />
              Massachusetts, USA
            </p>
            <p className="text-sm text-zinc-500 italic mt-4">
              Note: This address is for administrative and legal correspondence only. We do not hold physical inventory at this location.
            </p>
          </CardContent>
        </Card>

        <Card className="bg-zinc-900 border-zinc-800 text-zinc-100">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-yellow-500">
              <Mail className="h-6 w-6" />
              Contact Channels
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4 text-zinc-300">
            <div className="flex items-center gap-3">
              <Mail className="h-5 w-5 text-zinc-500" />
              <a href="mailto:contact@coopstones.com" className="hover:text-yellow-400 transition-colors">contact@coopstones.com</a>
            </div>
            <div className="flex items-center gap-3">
              <Phone className="h-5 w-5 text-zinc-500" />
              <span>+1 (555) 123-4567 (Support)</span>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-zinc-900 border-zinc-800 text-zinc-100">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-yellow-500">
              <ShieldCheck className="h-6 w-6" />
              Legal & Compliance
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-2 text-zinc-300">
            <p className="text-sm mb-4">
              We are fully compliant with U.S. business regulations and consumer protection laws.
            </p>
            <a href="/terms-and-conditions" className="block text-yellow-500 hover:underline">Terms & Conditions</a>
            <a href="/privacy-policy" className="block text-yellow-500 hover:underline">Privacy Policy</a>
            <a href="/refund-policy" className="block text-yellow-500 hover:underline">Refund Policy</a>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default CompanyInformation;