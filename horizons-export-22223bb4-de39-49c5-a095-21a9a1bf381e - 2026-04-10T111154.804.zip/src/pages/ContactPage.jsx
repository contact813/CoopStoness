import React from 'react';
import { Helmet } from 'react-helmet';
import ContactForm from '@/components/ContactForm';

const ContactPage = () => {
  return (
    <>
      <Helmet>
        <title>Contact Us - Coop Stones</title>
        <meta name="description" content="Get in touch with Coop Stones. Submit your application to join our exclusive cooperative." />
      </Helmet>
      <div className="min-h-screen text-white flex flex-col">
        <main className="flex-grow">
          <ContactForm className="section-bg" />
        </main>
      </div>
    </>
  );
};

export default ContactPage;