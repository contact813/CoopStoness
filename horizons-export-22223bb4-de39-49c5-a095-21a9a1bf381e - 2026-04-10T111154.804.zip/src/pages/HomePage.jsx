
import React from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import Hero from '@/components/Hero';
import AboutSection from '@/components/AboutSection';
import Benefits from '@/components/Benefits';
import MembershipPlans from '@/components/MembershipPlans';
import TrustedPartners from '@/components/TrustedPartners';
import ContactForm from '@/components/ContactForm';
import BlogPreview from '@/components/BlogPreview';
import FeaturedProducts from '@/components/FeaturedProducts';
import { useAuth } from '@/contexts/AuthContext';
import { Loader2 } from 'lucide-react';

const HomePage = () => {
  const { user, isAuthInitialized } = useAuth();

  return (
    <>
      <Helmet>
        <title>Coop Stones - Stronger Together</title>
        <meta name="description" content="Uniting stone professionals to leverage collective power, reduce costs, and grow stronger together." />
      </Helmet>
      <main className="text-white bg-black">
        <Hero className="pb-16" />
        
        {!isAuthInitialized ? (
          <div className="flex flex-col items-center justify-center py-20">
             <Loader2 className="w-10 h-10 animate-spin text-yellow-500 mb-4" />
             <p className="text-zinc-400">Loading catalog...</p>
          </div>
        ) : !user ? (
          <section className="py-20 px-4 max-w-4xl mx-auto text-center border border-zinc-800 bg-zinc-950 rounded-3xl my-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-6 text-white">Unlock Exclusive Pricing</h2>
            <p className="text-zinc-400 mb-8 text-lg">
              Our full product catalog and group purchase rounds are exclusively available to authenticated members.
            </p>
            <div className="flex flex-col sm:flex-row justify-center gap-4">
              <Link to="/login" className="px-8 py-4 rounded-xl bg-zinc-800 text-white font-bold hover:bg-zinc-700 transition-colors border border-zinc-700">
                Sign In
              </Link>
              <Link to="/membership" className="px-8 py-4 rounded-xl bg-yellow-500 text-black font-bold hover:bg-yellow-400 transition-colors">
                Join Membership
              </Link>
            </div>
          </section>
        ) : (
          <FeaturedProducts />
        )}

        <AboutSection />
        <Benefits />
        <MembershipPlans />
        <BlogPreview />
        <TrustedPartners />
        <ContactForm />
      </main>
    </>
  );
};

export default HomePage;
