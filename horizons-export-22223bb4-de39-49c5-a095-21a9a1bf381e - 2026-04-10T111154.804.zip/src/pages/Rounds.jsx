
import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import { useNavigate, Navigate } from 'react-router-dom';
import { getRounds } from '@/lib/roundsApi';
import { Loader2, Calendar, Package } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { useAuth } from '@/contexts/AuthContext';

export default function RoundsPage() {
  const { user, isAuthInitialized } = useAuth();
  const [rounds, setRounds] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    if (!isAuthInitialized || !user) return;

    async function fetchRounds() {
      console.log('[RoundsPage] Fetching rounds for authenticated user...');
      setLoading(true);
      setError(null);
      try {
        const data = await getRounds();
        setRounds(data || []);
        console.log(`[RoundsPage] Loaded ${data?.length || 0} rounds`);
      } catch (err) {
        console.error("[RoundsPage] Failed to load rounds:", err);
        setError("Could not load purchase rounds. Please try again later.");
      } finally {
        setLoading(false);
      }
    }
    fetchRounds();
  }, [isAuthInitialized, user]);

  if (!isAuthInitialized) {
    return (
      <div className="min-h-screen bg-black flex flex-col items-center justify-center">
        <Loader2 className="w-10 h-10 animate-spin text-yellow-500 mb-4" />
        <p className="text-zinc-400">Verifying access...</p>
      </div>
    );
  }

  if (!user) {
    console.log('[RoundsPage] Access denied. Redirecting to login.');
    return <Navigate to="/login" replace />;
  }

  return (
    <>
      <Helmet>
        <title>Group Purchase Rounds - Coop Stones</title>
        <meta name="description" content="Join our group purchase rounds to get exclusive pricing." />
      </Helmet>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="text-center mb-12">
          <h1 className="text-4xl md:text-5xl font-extrabold text-white tracking-tight">
            Group Purchase Rounds
          </h1>
          <p className="mt-4 max-w-2xl mx-auto text-lg text-zinc-400">
            Leverage our collective power to get the best prices.
          </p>
        </div>

        <AnimatePresence>
          {loading ? (
            <motion.div
              key="loader"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="flex justify-center items-center py-20 text-zinc-400"
            >
              <Loader2 className="w-8 h-8 animate-spin mr-3" />
              <span>Loading Rounds...</span>
            </motion.div>
          ) : error ? (
            <motion.div
              key="error"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="text-center py-20 text-red-400"
            >
              <p>Oops! Something went wrong.</p>
              <p>{error}</p>
            </motion.div>
          ) : rounds.length > 0 ? (
            <motion.div key="rounds-grid" className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {rounds.map((round, index) => (
                <motion.div
                  key={round.slug || index}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.4, delay: index * 0.1 }}
                  className="bg-zinc-900 border border-zinc-800 rounded-2xl overflow-hidden hover:border-yellow-500 transition-all cursor-pointer group flex flex-col"
                  onClick={() => navigate(`/rounds/${round.slug}`)}
                >
                  <div className="aspect-[16/9] relative overflow-hidden bg-zinc-950">
                    {round.cover_image_url || round.cover_url ? (
                      <img 
                        src={round.cover_url || round.cover_image_url} 
                        alt={round.title} 
                        className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105" 
                      />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center text-zinc-600">
                        <Package className="w-12 h-12 opacity-50" />
                      </div>
                    )}
                    <div className="absolute top-4 right-4 flex flex-col gap-2 items-end">
                      <span className={`px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wide shadow-lg ${round.status === 'active' || round.status === 'open' ? 'bg-green-500 text-black' : 'bg-zinc-800 text-zinc-400'}`}>
                        {round.status || 'Active'}
                      </span>
                    </div>
                  </div>
                  <div className="p-6 flex flex-col flex-1">
                    <h2 className="text-2xl font-bold text-white mb-2 group-hover:text-yellow-500 transition-colors">{round.title}</h2>
                    {round.description && (
                      <p className="text-zinc-400 text-sm line-clamp-2 mb-4 flex-1">{round.description}</p>
                    )}
                    <div className="flex items-center justify-between text-sm mt-auto pt-4 border-t border-zinc-800/50">
                      <div className="flex items-center text-zinc-500">
                        <Calendar className="w-4 h-4 mr-2" />
                        {new Date(round.starts_at).toLocaleDateString()}
                      </div>
                      <Button variant="ghost" className="text-yellow-500 hover:text-yellow-400 hover:bg-yellow-500/10 p-0">View Details &rarr;</Button>
                    </div>
                  </div>
                </motion.div>
              ))}
            </motion.div>
          ) : (
            <motion.div
              key="no-rounds"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="text-center py-20"
            >
              <h3 className="text-2xl font-semibold text-white">No Rounds Found</h3>
              <p className="mt-2 text-zinc-400">
                There are currently no purchase rounds available.
              </p>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </>
  );
}
