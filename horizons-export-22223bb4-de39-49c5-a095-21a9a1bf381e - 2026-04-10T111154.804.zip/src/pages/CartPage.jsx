
import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { ShoppingBag, ArrowLeft, Trash2, Plus, Minus } from 'lucide-react';
import { getCart, removeFromCart, updateCartItem } from '@/lib/cartApi';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';

export default function CartPage() {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [cart, setCart] = useState({ items: [] });
  const [loading, setLoading] = useState(true);

  const loadCart = () => {
    console.log('[CartPage] Loading cart');
    const result = getCart();
    
    if (result.success && result.cart && Array.isArray(result.cart.items)) {
      console.log('[CartPage] Cart loaded:', result.cart);
      console.log('[CartPage] Items count:', result.cart.items.length);
      setCart(result.cart);
    } else {
      console.log('[CartPage] Cart loaded (fallback):', result);
      setCart({ items: [] });
    }
    setLoading(false);
  };

  useEffect(() => {
    loadCart();
    
    const handleCartUpdate = () => {
      loadCart();
    };
    
    window.addEventListener('cart_updated', handleCartUpdate);
    return () => {
      window.removeEventListener('cart_updated', handleCartUpdate);
    };
  }, []);

  const handleUpdateQuantity = (productId, variantId, newQuantity) => {
    if (newQuantity < 1) return;
    const result = updateCartItem(productId, variantId, newQuantity);
    if (result.success) {
      setCart(result.cart);
    } else {
      toast({ variant: "destructive", title: "Error", description: result.error });
    }
  };

  const handleRemoveItem = (productId, variantId) => {
    console.log('[CartPage] Removing item:', { productId, variantId });
    
    if (!productId) {
      console.error('[CartPage] Invalid product ID for removal');
      return;
    }

    const result = removeFromCart(productId, variantId);
    
    if (result.success) {
      console.log('[CartPage] Item removed successfully');
      setCart(result.cart);
      window.dispatchEvent(new Event('cart_updated'));
      toast({ title: "Item removed", description: "The item has been removed from your cart." });
    } else {
      toast({ variant: "destructive", title: "Error", description: result.error });
    }
  };

  const subtotal = cart.items.reduce((total, item) => {
    return total + (item.price || 0) * item.quantity;
  }, 0);

  if (loading) {
    return (
      <div className="min-h-screen py-12 flex items-center justify-center">
        <p className="text-zinc-500">Loading cart...</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen py-12">
      <Helmet>
        <title>Your Cart | Coop Stones</title>
      </Helmet>

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between mb-8 pb-4 border-b border-zinc-800">
          <h1 className="text-3xl font-bold text-white flex items-center gap-3">
            <ShoppingBag className="w-8 h-8 text-yellow-500" />
            Your Cart
          </h1>
          <Button onClick={() => navigate('/rounds')} variant="ghost" className="text-zinc-400 hover:text-white">
            <ArrowLeft className="w-4 h-4 mr-2" /> Continue Shopping
          </Button>
        </div>

        {cart.items.length === 0 ? (
          <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-12 text-center">
            <ShoppingBag className="w-16 h-16 text-zinc-700 mx-auto mb-4" />
            <h2 className="text-xl font-bold text-white mb-2">Your cart is empty</h2>
            <p className="text-zinc-500 mb-6">Looks like you haven't added any products to your cart yet.</p>
            <Button onClick={() => navigate('/rounds')} className="bg-yellow-500 hover:bg-yellow-400 text-black font-bold">
              Browse Products
            </Button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="md:col-span-2 space-y-4">
              {cart.items.map((item) => (
                <div key={`${item.productId}-${item.variantId}`} className="bg-zinc-900 border border-zinc-800 p-4 rounded-xl">
                  <div className="flex justify-between items-center w-full flex-wrap sm:flex-nowrap gap-4">
                    
                    {/* LEFT: Image + Info */}
                    <div className="flex gap-4 items-center flex-1 min-w-[200px]">
                      <div className="w-24 h-24 bg-zinc-950 rounded-lg overflow-hidden flex-shrink-0 flex items-center justify-center border border-zinc-800">
                        <img 
                          src={item.image_url || '/images/placeholder-product.svg'} 
                          alt={item.title || 'Product'} 
                          className="w-full h-full object-contain"
                          onError={(e) => { e.currentTarget.src = '/images/placeholder-product.svg'; }}
                        />
                      </div>
                      
                      <div>
                        <h3 className="font-bold text-white text-lg line-clamp-2">{item.title}</h3>
                        <p className="text-zinc-400 text-sm mb-3">{item.variantTitle}</p>
                        
                        <div className="flex items-center border border-zinc-700 rounded-md overflow-hidden bg-zinc-950 w-fit">
                          <button 
                            onClick={() => handleUpdateQuantity(item.productId, item.variantId, item.quantity - 1)}
                            className="px-3 py-1 hover:bg-zinc-800 text-zinc-400 transition-colors"
                            aria-label="Decrease quantity"
                          >
                            <Minus className="w-4 h-4" />
                          </button>
                          <span className="w-10 text-center text-sm font-medium text-white">{item.quantity}</span>
                          <button 
                            onClick={() => handleUpdateQuantity(item.productId, item.variantId, item.quantity + 1)}
                            className="px-3 py-1 hover:bg-zinc-800 text-zinc-400 transition-colors"
                            aria-label="Increase quantity"
                          >
                            <Plus className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    </div>

                    {/* RIGHT: Price + Remove Button */}
                    <div className="flex flex-col items-end gap-2">
                      <p className="text-yellow-500 font-bold text-lg">
                        ${((item.price || 0) * item.quantity).toFixed(2)}
                      </p>
                      {item.quantity > 1 && (
                        <p className="text-xs text-zinc-500">
                          ${Number(item.price || 0).toFixed(2)} each
                        </p>
                      )}
                      <button
                        onClick={() => handleRemoveItem(item.productId, item.variantId)}
                        className="text-red-500 hover:text-red-400 transition-colors min-w-fit whitespace-nowrap mt-2 flex items-center"
                        title="Remove item"
                        aria-label="Remove item"
                      >
                        <Trash2 className="w-5 h-5 mr-1" />
                        Remove
                      </button>
                    </div>
                    
                  </div>
                </div>
              ))}
            </div>
            
            <div className="md:col-span-1">
              <div className="bg-zinc-900 border border-zinc-800 p-6 rounded-xl sticky top-24">
                <h3 className="text-lg font-bold text-white mb-4 pb-4 border-b border-zinc-800">Order Summary</h3>
                
                <div className="space-y-3 mb-6">
                  <div className="flex justify-between text-zinc-400">
                    <span>Subtotal</span>
                    <span className="text-white">${subtotal.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between text-zinc-400">
                    <span>Shipping</span>
                    <span className="text-sm">Calculated at checkout</span>
                  </div>
                  <div className="flex justify-between text-zinc-400">
                    <span>Taxes</span>
                    <span className="text-sm">Calculated at checkout</span>
                  </div>
                </div>
                
                <div className="pt-4 border-t border-zinc-800 mb-6">
                  <div className="flex justify-between font-bold">
                    <span className="text-white text-lg">Total</span>
                    <span className="text-yellow-500 text-xl">${subtotal.toFixed(2)}</span>
                  </div>
                </div>
                
                <Button 
                  className="w-full h-12 bg-yellow-500 hover:bg-yellow-400 text-black font-bold uppercase tracking-wide"
                  onClick={() => toast({ title: "Checkout", description: "Checkout functionality coming soon!" })}
                >
                  Proceed to Checkout
                </Button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
