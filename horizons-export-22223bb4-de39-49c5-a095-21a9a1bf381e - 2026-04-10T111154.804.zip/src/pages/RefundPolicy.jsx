
import React from 'react';
import { Helmet } from 'react-helmet';

const RefundPolicy = () => {
  return (
    <div className="container mx-auto px-4 py-16 md:px-8 max-w-4xl">
      <Helmet>
        <title>Refund Policy – COOPSTONES</title>
        <meta name="description" content="COOPSTONES Refund Policy. Information on returns, cancellations, and refund eligibility for round orders and subscriptions." />
        <meta property="og:title" content="Refund Policy – COOPSTONES" />
        <meta property="og:description" content="Our policy on refunds and returns." />
        <link rel="canonical" href="https://coopstones.com/refund-policy" />
      </Helmet>

      <h1 className="text-4xl font-bold text-white mb-2">Refund Policy</h1>
      <p className="text-zinc-400 mb-8">Last Updated: December 2, 2025</p>

      <div className="space-y-8 text-zinc-300 leading-relaxed">
        <section>
          <h2 className="text-2xl font-semibold text-yellow-500 mb-4">1. General Refund Rules</h2>
          <p>
            At COOPSTONES, we strive to ensure customer satisfaction. However, due to the nature of our cooperative buying model and the specific logistics of stone products, certain restrictions apply. Refunds are generally processed to the original method of payment within 5-10 business days of approval.
          </p>
        </section>

        <section>
          <h2 className="text-2xl font-semibold text-yellow-500 mb-4">2. Round Orders</h2>
          <p className="mb-4">
            <strong>Damaged or Defective Goods:</strong> If you receive a product that is damaged or defective, you must notify us within 48 hours of delivery. Please provide photographic evidence. Upon verification, we will arrange for a replacement or a full refund.
          </p>
          <p>
            <strong>Change of Mind:</strong> Returns for "change of mind" are subject to a 20% restocking fee and the customer is responsible for return shipping costs. Items must be in their original, unused condition.
          </p>
        </section>

        <section>
          <h2 className="text-2xl font-semibold text-yellow-500 mb-4">3. Membership Subscriptions</h2>
          <p>
            <strong>Monthly Subscriptions:</strong> You may cancel your monthly subscription at any time. Refunds are not provided for partial months. Access continues until the end of the current billing cycle.
          </p>
          <p className="mt-2">
            <strong>Annual Subscriptions:</strong> If you cancel an annual subscription within 14 days of initial purchase, you are eligible for a full refund. After 14 days, no refunds will be issued, but you will retain access until the end of the year term.
          </p>
        </section>

        <section>
          <h2 className="text-2xl font-semibold text-yellow-500 mb-4">4. Non-Eligible Items</h2>
          <p>
            The following items are final sale and not eligible for return or refund unless defective:
          </p>
          <ul className="list-disc pl-6 mt-2 space-y-2">
            <li>Custom-ordered stone slabs.</li>
            <li>Clearance or "Final Sale" items.</li>
            <li>Digital products or services once accessed/downloaded.</li>
          </ul>
        </section>

        <section>
          <h2 className="text-2xl font-semibold text-yellow-500 mb-4">5. How to Request a Refund</h2>
          <p>
            To initiate a return or request a refund, please contact our support team with your Order ID and reason for the request.
          </p>
          <div className="mt-4 p-4 bg-zinc-900 rounded-lg border border-zinc-800">
            <p><strong>Refund Contact</strong></p>
            <p>Email: <a href="mailto:contact@coopstones.com" className="text-yellow-500 hover:underline">contact@coopstones.com</a></p>
            <p>Subject Line: Refund Request - [Your Order ID]</p>
          </div>
        </section>
      </div>
    </div>
  );
};

export default RefundPolicy;
