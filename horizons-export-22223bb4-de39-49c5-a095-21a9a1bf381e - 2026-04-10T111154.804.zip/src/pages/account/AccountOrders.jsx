
import React, { useEffect, useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { useNavigate } from 'react-router-dom';
import { supabase } from '@/lib/supabaseClient';
import { Loader2, Package, AlertCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { cancelOrder } from '@/lib/roundsApi';
import { useToast } from '@/components/ui/use-toast';

export default function AccountOrders() {
  const { user, isAuthInitialized } = useAuth();
  const navigate = useNavigate();
  const { toast } = useToast();
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [cancellingOrderId, setCancellingOrderId] = useState(null);

  useEffect(() => {
    if (!isAuthInitialized) return;
    
    if (!user) {
      console.log("[AccountOrders] No authenticated user, redirecting to login.");
      navigate('/login');
      return;
    }

    loadOrders();
  }, [isAuthInitialized, user, navigate]);

  async function loadOrders() {
    setLoading(true);
    setError(null);
    try {
      console.log(`[AccountOrders] Fetching public.orders for user: ${user.id}`);
      
      const { data, error: fetchErr } = await supabase
        .from('orders')
        .select(`
          id, status, total_amount, created_at, updated_at,
          order_items (
            id, product_id, variant_id, quantity, unit_price,
            products (title),
            product_variants (title)
          )
        `)
        .eq('user_id', user.id)
        .order('created_at', { ascending: false });

      if (fetchErr) throw fetchErr;
      
      console.log(`[AccountOrders] Successfully loaded ${data?.length || 0} orders:`, data);
      setOrders(data || []);
    } catch (err) {
      console.error('[AccountOrders] Failed to fetch orders:', err);
      setError(err.message || 'Failed to load your orders.');
    } finally {
      setLoading(false);
    }
  }

  const handleCancelOrder = async (orderId) => {
    if (!window.confirm("Are you sure you want to cancel this order?")) {
      return;
    }
    
    console.log(`[AccountOrders] Proceeding to cancel order: ${orderId}`);
    setCancellingOrderId(orderId);
    
    try {
      await cancelOrder(orderId, user.id);
      console.log(`[AccountOrders] Order ${orderId} successfully cancelled.`);
      
      // Update local state
      setOrders(prevOrders => 
        prevOrders.map(order => 
          order.id === orderId 
            ? { ...order, status: 'cancelled', updated_at: new Date().toISOString() } 
            : order
        )
      );
      
      toast({
        title: "Order Cancelled",
        description: "Your order has been successfully cancelled.",
      });
    } catch (err) {
      console.error('[AccountOrders] Failed to cancel order:', err);
      toast({
        variant: "destructive",
        title: "Cancellation Failed",
        description: err.message || "An error occurred while cancelling your order.",
      });
    } finally {
      setCancellingOrderId(null);
    }
  };

  if (!isAuthInitialized || loading) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[40vh] text-zinc-400">
        <Loader2 className="w-8 h-8 animate-spin text-yellow-500 mb-4" />
        <p>Loading your orders...</p>
      </div>
    );
  }

  if (error) {
    return (
      <div className="text-center p-8 bg-zinc-900 border border-zinc-800 rounded-xl max-w-2xl mx-auto">
        <AlertCircle className="w-12 h-12 text-red-500 mx-auto mb-4" />
        <h2 className="text-xl font-bold text-white mb-2">Error Loading Orders</h2>
        <p className="text-zinc-400 mb-6">{error}</p>
        <Button onClick={loadOrders} className="bg-yellow-500 text-black hover:bg-yellow-400">
          Try Again
        </Button>
      </div>
    );
  }

  if (orders.length === 0) {
    return (
      <div className="text-center p-12 bg-zinc-950 border border-zinc-800 rounded-xl">
        <Package className="w-16 h-16 text-zinc-700 mx-auto mb-4" />
        <h2 className="text-2xl font-bold text-white mb-2">No Orders Yet</h2>
        <p className="text-zinc-400 mb-8">When you place orders from a round, they will appear here.</p>
        <Button onClick={() => navigate('/rounds')} className="bg-yellow-500 text-black hover:bg-yellow-400 font-bold">
          View Active Rounds
        </Button>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold text-white mb-8">Your Orders</h1>
      
      <div className="grid gap-6">
        {orders.map((order) => {
          const dbTotal = Number(order.total_amount).toFixed(2);
          const orderDate = new Date(order.created_at).toLocaleDateString(undefined, { 
            year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit'
          });
          const isCancelling = cancellingOrderId === order.id;

          // ✅ order_items usa APENAS quantity
          const totalItems = order.order_items?.reduce((sum, item) => {
            const itemQuantity = item.quantity ?? 0;
            return sum + itemQuantity;
          }, 0) ?? 0;

          console.log('[AccountOrders] Order total items:', totalItems);

          const calculatedTotal = order.order_items?.reduce((sum, item) => {
            const itemQuantity = item.quantity ?? 0;
            return sum + (itemQuantity * (item.unit_price ?? 0));
          }, 0) || 0;

          console.log(`[AccountOrders] Order ${order.id} | Status: ${order.status} | DB Total: ${order.total_amount} | Match: ${Number(order.total_amount) === Number(calculatedTotal)}`);
          
          return (
            <div key={order.id} className="bg-zinc-950 border border-zinc-800 rounded-xl overflow-hidden">
              <div className="bg-zinc-900 p-4 border-b border-zinc-800 flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div>
                  <p className="text-xs text-zinc-500 font-mono mb-1">Order #{String(order.id).substring(0, 8).toUpperCase()}</p>
                  <p className="text-sm text-zinc-300">{orderDate}</p>
                </div>
                <div className="flex items-center gap-6">
                  <div className="text-right">
                    <p className="text-xs text-zinc-500 mb-1">Total</p>
                    <p className="text-lg font-bold text-yellow-500">${dbTotal}</p>
                  </div>
                  <div className={`order-status status-${order.status.toLowerCase()}`}>
                    {order.status}
                  </div>
                </div>
              </div>
              
              <div className="p-4">
                <div className="space-y-4">
                  {order.order_items?.map((item) => {
                    const title = item.product_variants?.title || item.products?.title || 'Unknown Product';
                    
                    // ✅ order_items usa APENAS quantity
                    const itemQuantity = item.quantity ?? 0;
                    const itemUnitPrice = item.unit_price ?? 0;
                    const itemSubtotal = itemQuantity * itemUnitPrice;

                    console.log('[AccountOrders] Rendering order item:', {
                      id: item.id,
                      quantity: itemQuantity,
                      unit_price: itemUnitPrice,
                      subtotal: itemSubtotal
                    });
                    
                    return (
                      <div key={item.id} className="flex items-center justify-between gap-4">
                        <div className="flex-1">
                          <p className="text-zinc-200 font-medium">{title}</p>
                          <p className="text-zinc-500 text-xs">Qty: {itemQuantity} × ${Number(itemUnitPrice).toFixed(2)} = ${itemSubtotal.toFixed(2)}</p>
                        </div>
                        <p className="text-zinc-300 font-bold whitespace-nowrap">
                          ${itemSubtotal.toFixed(2)}
                        </p>
                      </div>
                    );
                  })}
                </div>

                {order.status === 'cancelled' && (
                  <div className="order-cancelled-notice">
                    <p><strong>This order has been cancelled.</strong> No further action is required.</p>
                  </div>
                )}

                {order.status === 'confirmed' && (
                  <div className="order-actions">
                    <button 
                      className="btn-danger"
                      onClick={() => handleCancelOrder(order.id)}
                      disabled={isCancelling}
                    >
                      {isCancelling ? (
                        <span className="flex items-center gap-2">
                          <Loader2 className="w-4 h-4 animate-spin" />
                          Cancelling...
                        </span>
                      ) : (
                        "Cancel Order"
                      )}
                    </button>
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
