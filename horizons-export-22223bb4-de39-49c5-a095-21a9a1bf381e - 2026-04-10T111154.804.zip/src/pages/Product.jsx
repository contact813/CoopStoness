
import React, { useState, useEffect } from "react";
import { useParams, useNavigate, Navigate } from "react-router-dom";
import { Helmet } from "react-helmet";
import { useCart } from "@/contexts/CartContext";
import { useAuth } from "@/contexts/AuthContext";
import RelatedProducts from "@/components/product/RelatedProducts";
import FrequentlyBoughtTogether from "@/components/product/FrequentlyBoughtTogether";
import QuantitySelector from "@/components/QuantitySelector";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Label } from "@/components/ui/label";
import { toast } from "@/components/ui/use-toast";
import { Loader2 } from "lucide-react";
import { PLACEHOLDER_IMAGE } from "@/lib/imageUtils";
import { getProductById } from "@/lib/productsApi";
import ProductVariantSelector from "@/components/ProductVariantSelector";
import { getVariantDisplayTitle } from "@/utils/variantUtils";
import ProductGallery from "@/components/product/ProductGallery";

export default function Product() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { addItem } = useCart();
  const { user, isAuthInitialized } = useAuth();
  
  const [product, setProduct] = useState(null);
  const [activeVariant, setActiveVariant] = useState(null);
  const [quantity, setQuantity] = useState(1);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!isAuthInitialized || !user) return;

    async function load() {
      setLoading(true);
      console.log(`[ProductPage] Loading product details for ID: ${id}`);
      try {
        const productData = await getProductById(id);
        
        if (!productData || !productData.validVariants || productData.validVariants.length === 0) {
            toast({ variant: "destructive", title: "Product not found or unavailable" });
            navigate('/');
            return;
        }
        
        setProduct(productData);

        if (!productData.hasOptions && productData.validVariants.length > 0) {
            setActiveVariant(productData.validVariants[0]);
        }
      } catch (err) {
        console.error("[ProductPage] Error loading product:", err);
        toast({ variant: "destructive", title: "Error loading product details" });
        navigate('/');
      } finally {
        setLoading(false);
      }
    }
    load();
  }, [id, navigate, isAuthInitialized, user]);

  const handleAddToCart = () => {
    if (!activeVariant) {
        toast({ variant: "destructive", title: "Please select a variant" });
        return;
    }

    const itemToAdd = {
        id: product.id,
        title: displayTitle,
        price: displayPrice,
        original_price: product.price || displayPrice,
        image_url: displayImage,
        thumbnail_url: displayImage,
        variant_id: activeVariant.id,
        variant_title: activeVariant.title || null,
        variant_sku: activeVariant.sku || null,
        quantity: quantity,
        sku: activeVariant.sku || null,
    };
    
    addItem(itemToAdd);
    toast({ title: "Added to Cart", description: "Item added to your shopping cart." });
    setQuantity(1);
  };
  
  const handleBuyNow = () => {
    handleAddToCart();
    navigate('/cart');
  };

  if (!isAuthInitialized) {
    return (
      <div className="h-screen flex items-center justify-center bg-black">
        <Loader2 className="w-10 h-10 animate-spin text-yellow-500" />
      </div>
    );
  }

  if (!user) {
    console.log('[ProductPage] Access denied. Redirecting to login.');
    return <Navigate to="/login" replace />;
  }

  if (loading) return <div className="h-screen flex items-center justify-center bg-black"><Loader2 className="w-10 h-10 animate-spin text-yellow-500" /></div>;
  if (!product) return null;

  const displayTitle = getVariantDisplayTitle(activeVariant, product.title);
  const displayDescription = activeVariant?.custom_description || product.description || '';
  const displayImage = activeVariant?.image_url || product?.thumbnail_url || product?.images?.[0]?.url || PLACEHOLDER_IMAGE;
  const displayPrice = activeVariant?.price ? Number(activeVariant.price) : (product.min_price || 0);
  const displayCompareAtPrice = activeVariant?.compare_at_price ? Number(activeVariant.compare_at_price) : null;
  const displayInventory = activeVariant?.inventory_qty !== undefined ? activeVariant.inventory_qty : product.inventory;
  const isOutOfStock = displayInventory <= 0;
  const displaySku = activeVariant?.sku || 'N/A';
  const isVariantSelectionValid = !!activeVariant;

  return (
    <div className="min-h-screen bg-black text-white py-12">
        <Helmet>
            <title>{displayTitle} | Coop Stones</title>
        </Helmet>
        
        <div className="container max-w-7xl mx-auto px-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-16">
                
                <div className="flex-1 h-[420px] md:h-[520px] relative">
                    <ProductGallery 
                        images={product.images?.length ? product.images : (product.thumbnail_url ? [product.thumbnail_url] : [])} 
                        selectedVariantImage={activeVariant?.image_url || product?.thumbnail_url} 
                    />
                     {isOutOfStock && (
                        <div className="absolute top-4 left-4 bg-red-500/90 text-white px-3 py-1 rounded-full text-sm font-bold shadow-lg z-10">
                            Sold Out
                        </div>
                    )}
                </div>

                <div className="flex flex-col h-full">
                    <div className="mb-6">
                        {product.vendor && (
                            <div className="text-zinc-500 text-xs font-bold uppercase tracking-widest mb-2">
                                {product.vendor}
                            </div>
                        )}
                        <h1 className="text-3xl md:text-4xl font-bold mb-4 leading-tight text-white">{displayTitle}</h1>
                        
                        <div className="flex items-center gap-3 mb-4">
                            <span className="text-3xl font-bold tracking-tight text-yellow-500">
                                ${displayPrice.toFixed(2)}
                            </span>
                            {displayCompareAtPrice && displayCompareAtPrice > displayPrice && (
                                <span className="text-lg text-zinc-500 line-through">
                                    ${displayCompareAtPrice.toFixed(2)}
                                </span>
                            )}
                            
                            {isOutOfStock ? (
                                <Badge variant="destructive" className="bg-red-500/10 text-red-500 border-red-500/20 ml-auto">
                                    Out of Stock
                                </Badge>
                            ) : (
                                <Badge className="bg-green-500/10 text-green-500 border-green-500/20 ml-auto">
                                    In Stock ({displayInventory} units)
                                </Badge>
                            )}
                        </div>
                        
                        <div className="flex items-center gap-4 text-sm text-zinc-500">
                             <p>SKU: {displaySku}</p>
                             {product.variants_count > 1 && (
                                <p>• {product.variants_count} Variants Available</p>
                             )}
                        </div>
                    </div>

                    <div className="h-px bg-zinc-800 mb-6" />

                    <div className="space-y-6 flex-1">
                        
                        <ProductVariantSelector 
                            product={product} 
                            onVariantSelect={setActiveVariant} 
                        />

                        <div>
                            <Label className="text-zinc-400 mb-2 block text-xs uppercase tracking-wider font-bold">Quantity</Label>
                            <QuantitySelector 
                                quantity={quantity} 
                                onQuantityChange={setQuantity}
                                max={displayInventory > 0 ? displayInventory : 1} 
                                disabled={isOutOfStock}
                            />
                        </div>

                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-4">
                            <Button 
                                size="lg" 
                                onClick={handleAddToCart}
                                disabled={isOutOfStock || !isVariantSelectionValid}
                                className="h-12 bg-zinc-800 hover:bg-zinc-700 text-white font-semibold border border-zinc-700"
                            >
                                Add to Cart
                            </Button>
                            <Button 
                                size="lg"
                                onClick={handleBuyNow}
                                disabled={isOutOfStock || !isVariantSelectionValid}
                                className="h-12 bg-yellow-500 hover:bg-yellow-400 text-black font-bold"
                            >
                                Buy it Now
                            </Button>
                        </div>
                    </div>
                </div>
            </div>
            
            {displayDescription && (
                <div className="max-w-4xl mx-auto mt-16 mb-20 bg-zinc-950 p-8 rounded-2xl border border-zinc-800">
                    <h3 className="text-xl font-bold text-white mb-6 border-b border-zinc-800 pb-4">Product Description</h3>
                    <div 
                        className="prose prose-invert prose-lg max-w-none text-zinc-300"
                        dangerouslySetInnerHTML={{ __html: displayDescription }} 
                    />
                </div>
            )}
            
            <FrequentlyBoughtTogether currentProductId={product.id} currentProductPrice={String(displayPrice)} />
            
            <div className="mt-20">
                <RelatedProducts productId={product.id} vendor={product.vendor} category={product.type} />
            </div>
        </div>
    </div>
  );
}
