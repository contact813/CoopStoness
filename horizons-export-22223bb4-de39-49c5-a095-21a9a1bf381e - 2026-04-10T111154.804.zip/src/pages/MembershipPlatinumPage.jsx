
import React, { useEffect } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Check, Star, Truck, BarChart2, Headphones, Wallet, Zap, Layers } from 'lucide-react';
import MembershipApplicationForm from '@/components/MembershipApplicationForm';
import { Badge } from "@/components/ui/badge";

const benefits = [
  {
    icon: Star,
    title: "All Gold Benefits",
    description: "Includes everything in the Gold tier, plus exclusive premium advantages."
  },
  {
    icon: BarChart2,
    title: "Reputation Management",
    description: "Access to premium software to manage reviews and online presence automatically."
  },
  {
    icon: Truck,
    title: "Equipment Discounts",
    description: "Special negotiated rates on heavy machinery and tooling equipment."
  },
  {
    icon: Layers,
    title: "Cabinet Program",
    description: "Exclusive 36% discount program on premium cabinetry lines."
  },
  {
    icon: Headphones,
    title: "Premium Support",
    description: "Dedicated account manager and priority support channel."
  },
  {
    icon: Zap,
    title: "Priority Access",
    description: "First dibs on new product launches and limited-quantity round buys."
  },
  {
    icon: Wallet,
    title: "Capital Funds",
    description: "Access to business capital and funding options for expansion.",
    badge: "Coming Soon"
  }
];

export default function MembershipPlatinumPage() {
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  return (
    <>
      <Helmet>
        <title>Platinum Membership - Coop Stones</title>
        <meta name="description" content="Elite status for established businesses. Join Coop Stones Platinum Membership for maximum savings and strategic growth tools." />
      </Helmet>
      
      <div className="min-h-screen bg-black text-white">
        {/* Hero Section */}
        <section className="relative h-[80vh] min-h-[600px] flex items-center justify-center overflow-hidden">
          <div 
            className="absolute inset-0 z-0 bg-cover bg-center"
            style={{ 
              backgroundImage: 'url(https://horizons-cdn.hostinger.com/22223bb4-de39-49c5-a095-21a9a1bf381e/6797c64454b05265587c4a2db4cc8e2f.png)',
              backgroundSize: 'cover',
              backgroundPosition: 'center',
              backgroundAttachment: 'fixed'
            }}
          >
             <div className="absolute inset-0 bg-black bg-opacity-40" />
          </div>

          <div className="relative z-10 max-w-4xl mx-auto px-6 text-center">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
            >
              <Badge className="bg-yellow-400/20 text-yellow-400 border-yellow-400 mb-6 px-4 py-1.5 text-sm uppercase tracking-widest font-bold">
                Elite Tier
              </Badge>
              <h1 className="text-5xl md:text-7xl font-bold mb-6 tracking-tight text-white">
                Platinum <span className="text-yellow-400">Membership</span>
              </h1>
              <p className="text-xl md:text-2xl text-zinc-300 max-w-2xl mx-auto mb-10 leading-relaxed">
                Premium partnership with exclusive advantages for high-volume businesses.
              </p>
              <a 
                href="#apply" 
                className="inline-block bg-yellow-400 text-black font-bold text-lg px-8 py-4 rounded-full hover:bg-yellow-300 transition-all hover:scale-105 shadow-lg shadow-yellow-400/20"
              >
                Apply for Membership
              </a>
            </motion.div>
          </div>
        </section>

        {/* Benefits Section */}
        <section className="py-24 bg-zinc-950">
          <div className="max-w-7xl mx-auto px-6">
            <div className="text-center mb-16">
              <h2 className="text-3xl md:text-4xl font-bold mb-4 text-white">
                The Platinum <span className="text-yellow-400">Advantage</span>
              </h2>
              <p className="text-zinc-400 max-w-2xl mx-auto">Designed for businesses ready to dominate their local market.</p>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {benefits.map((benefit, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, scale: 0.95 }}
                  whileInView={{ opacity: 1, scale: 1 }}
                  viewport={{ once: true }}
                  transition={{ delay: index * 0.05 }}
                  className={`bg-zinc-900/50 border border-zinc-800 p-6 rounded-2xl hover:bg-zinc-900 transition-colors ${index === 0 ? 'lg:col-span-2 md:col-span-2 border-yellow-400/30 bg-yellow-900/10' : ''}`}
                >
                  <div className="flex justify-between items-start mb-4">
                    <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${index === 0 ? 'bg-yellow-400/20' : 'bg-white/10'}`}>
                      <benefit.icon className={`w-6 h-6 ${index === 0 ? 'text-yellow-400' : 'text-white'}`} />
                    </div>
                    {benefit.badge && (
                      <span className="text-[10px] font-bold uppercase tracking-wider bg-zinc-800 text-zinc-400 px-2 py-1 rounded-full">
                        {benefit.badge}
                      </span>
                    )}
                  </div>
                  <h3 className="text-lg font-bold mb-2 text-white">{benefit.title}</h3>
                  <p className="text-sm text-zinc-400 leading-relaxed">{benefit.description}</p>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* Visual / Info Section */}
        <section className="py-24 bg-black overflow-hidden">
          <div className="max-w-7xl mx-auto px-6">
            <div className="grid lg:grid-cols-2 gap-16 items-center">
               <div className="relative order-2 lg:order-1">
                <div className="absolute -inset-4 bg-white/10 blur-3xl rounded-full opacity-20" />
                <div className="grid grid-cols-2 gap-4 relative z-10">
                  <img 
                    src="https://images.unsplash.com/photo-1696424137853-7084343b76b4?q=80&w=2070&auto=format&fit=crop" 
                    alt="Luxury Kitchen" 
                    className="rounded-2xl object-cover h-64 w-full shadow-2xl"
                  />
                  <img 
                    src="https://images.unsplash.com/photo-1577962917302-cd874c4e31d2?q=80&w=2070&auto=format&fit=" 
                    alt="Showroom" 
                    className="rounded-2xl object-cover h-64 w-full shadow-2xl translate-y-8"
                  />
                </div>
              </div>
              <div className="space-y-8 order-1 lg:order-2">
                <h2 className="text-3xl md:text-4xl font-bold leading-tight text-white">
                  Maximize Your <br />
                  <span className="text-yellow-400">Business Potential</span>
                </h2>
                <p className="text-zinc-400 text-lg">
                  Platinum members are our top-tier partners. We work directly with you to implement systems and savings that can add 5-10% to your bottom line immediately.
                </p>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="bg-zinc-900 p-4 rounded-lg border border-zinc-800">
                        <h4 className="font-bold text-white mb-1">Dedicated Support</h4>
                        <p className="text-xs text-zinc-400">Direct line to our expert team.</p>
                    </div>
                    <div className="bg-zinc-900 p-4 rounded-lg border border-zinc-800">
                        <h4 className="font-bold text-white mb-1">Max Savings</h4>
                        <p className="text-xs text-zinc-400">Highest tier discounts available.</p>
                    </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Application Form */}
        <section id="apply" className="py-24 bg-zinc-950 border-t border-zinc-900">
          <div className="max-w-3xl mx-auto px-6">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold mb-4 text-white">
                Apply for <span className="text-yellow-400">Platinum Membership</span>
              </h2>
              <p className="text-zinc-400">Join the elite tier of stone industry professionals.</p>
            </div>
            
            <div className="bg-zinc-900/50 border border-zinc-800 p-8 md:p-12 rounded-2xl shadow-xl">
              <MembershipApplicationForm plan="Platinum" />
            </div>
          </div>
        </section>
      </div>
    </>
  );
}
