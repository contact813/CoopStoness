
import React, { useState, useEffect } from "react";
import { useParams, useNavigate, Link, Navigate } from "react-router-dom";
import { Helmet } from "react-helmet";
import { getRoundBySlug, getRoundProductDetail } from "@/lib/roundsApi";
import { useCart } from "@/contexts/CartContext";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { useToast } from "@/components/ui/use-toast";
import ProductVariantSelector from "@/components/ProductVariantSelector";
import QuantitySelector from "@/components/QuantitySelector";
import { Loader2, ArrowLeft, ShoppingCart, AlertCircle, ShoppingBag } from "lucide-react";

export default function RoundProduct() {
  const { slug, productId } = useParams();
  const navigate = useNavigate();
  const { user, isAuthInitialized } = useAuth();
  const { addToRoundCart } = useCart();
  const { toast } = useToast();

  const [loading, setLoading] = useState(true);
  const [errorState, setErrorState] = useState(null);
  const [addingToCart, setAddingToCart] = useState(false);
  const [round, setRound] = useState(null);
  const [product, setProduct] = useState(null);
  const [selectedVariant, setSelectedVariant] = useState(null);
  const [quantity, setQuantity] = useState(1);

  useEffect(() => {
    if (!isAuthInitialized || !user) return;

    async function loadData() {
      if (!slug || !productId) {
        setErrorState('Invalid parameters.');
        setLoading(false);
        return;
      }

      setLoading(true);
      setErrorState(null);
      
      try {
        console.log(`[RoundProduct] Loading product ID: ${productId}`);
        const { data: roundData, error: roundError } = await getRoundBySlug(slug);
        
        if (roundError) throw new Error(roundError.message || 'Round not found.');
        if (!roundData) throw new Error('Round not found.');
        
        setRound(roundData);

        const { data: prodData, error: pErr } = await getRoundProductDetail(roundData.id, productId);
        if (pErr) throw pErr;

        if (!prodData) {
          setErrorState('This product is not available in this round.');
          return;
        }
        
        setProduct(prodData);

        const variantsToUse = prodData.validVariants || prodData.product_variants || [];
        if (variantsToUse.length > 0) {
          setSelectedVariant(variantsToUse[0]);
        }
      } catch (err) {
        console.error("[RoundProduct] Error loading data exception:", err);
        setErrorState(err.message || 'An error occurred while loading data.');
      } finally {
        setLoading(false);
      }
    }
    loadData();
  }, [slug, productId, isAuthInitialized, user]);

  useEffect(() => {
    if (selectedVariant?.id) {
      setQuantity(1);
    }
  }, [selectedVariant?.id]);

  const handleAddToCart = async () => {
    console.log("[RoundProduct] handleAddToCart started");
    
    if (!isAuthInitialized || !user) {
      console.log("[RoundProduct] User not authenticated.");
      toast({ variant: "destructive", title: "Authentication Required", description: "You must be logged in to add items." });
      return;
    }

    if (!selectedVariant || !selectedVariant.id) {
      console.log("[RoundProduct] No selectedVariant or missing variant id.");
      toast({ variant: "destructive", title: "Selection Required", description: "Please select a variant." });
      return;
    }

    if (!quantity || quantity < 1) {
      console.log("[RoundProduct] Invalid quantity:", quantity);
      toast({ variant: "destructive", title: "Warning", description: "Quantity must be at least 1." });
      return;
    }

    const availableStock = selectedVariant.stock_quantity ?? selectedVariant.inventory_qty ?? 0;
    if (quantity > availableStock) {
      toast({ variant: "destructive", title: "Insufficient Stock", description: `Only ${availableStock} available.` });
      return;
    }

    setAddingToCart(true);
    try {
      console.log("[RoundProduct] BEFORE add - roundId:", round.id, "userId:", user.id, "variantId:", selectedVariant.id, "quantity:", quantity, "variantName:", selectedVariant.title, "variantPrice:", selectedVariant.price);
      
      const payload = { 
        roundId: round.id, 
        userId: user.id, 
        variantId: selectedVariant.id, 
        quantity 
      };
      
      const result = await addToRoundCart(payload);
      console.log("[RoundProduct] AFTER add - result:", result);
      
      if (result && result.success) {
        toast({ title: "Added to Cart", description: `Successfully added ${quantity}x to your cart.` });
        navigate(`/rounds/${round.slug || round.id}/cart`);
      }
    } catch (err) {
      console.error("[RoundProduct] Add to cart exception:", err);
      toast({ variant: "destructive", title: "Error", description: err?.message || "Error adding to cart." });
    } finally {
      setAddingToCart(false);
    }
  };

  const handleViewCart = () => navigate(`/rounds/${round?.slug || round?.id}/cart`);

  if (!isAuthInitialized) {
    return (
      <div className="min-h-[70vh] flex flex-col items-center justify-center text-zinc-400">
        <Loader2 className="w-10 h-10 animate-spin text-yellow-500 mb-4" />
        <p>Verifying access...</p>
      </div>
    );
  }

  if (!user) {
    console.log('[RoundProduct] Access denied. Redirecting to login.');
    return <Navigate to="/login" replace />;
  }

  if (loading) {
    return (
      <div className="min-h-[70vh] flex flex-col items-center justify-center text-zinc-400">
        <Loader2 className="w-10 h-10 animate-spin text-yellow-500 mb-4" />
        <p>Loading product...</p>
      </div>
    );
  }

  if (errorState || !product || !round) {
    return (
      <div className="min-h-[60vh] flex flex-col items-center justify-center text-white px-4 text-center">
        <AlertCircle className="w-16 h-16 text-red-500 mb-6" />
        <h1 className="text-3xl font-bold mb-4 text-red-500">Error</h1>
        <p className="text-zinc-400 max-w-md mb-8">{errorState || 'Product not found'}</p>
        <Button onClick={() => navigate(`/rounds/${slug}`)} className="bg-yellow-500 hover:bg-yellow-400 text-black font-bold">
          <ArrowLeft className="w-4 h-4 mr-2" /> Back to Round
        </Button>
      </div>
    );
  }

  const formatVariantOptionsLocal = (options) => {
    if (!options) return '';
    if (Array.isArray(options)) return options.map(opt => `${opt.optionName}: ${opt.value}`).join(', ');
    return String(options);
  };

  const displayTitle = selectedVariant?.title || product.title;
  const displayDescription = selectedVariant?.custom_description || product.description || '';
  const displayImage = selectedVariant?.image_url || product.thumbnail_url || product.images?.[0]?.url || '/images/placeholder-product.svg';
  const displayPrice = selectedVariant?.price || product.price || 0;
  const displayCompareAtPrice = selectedVariant?.compare_at_price || product.compare_at_price || 0;
  const displaySku = selectedVariant?.sku || 'N/A';
  
  const displayOptions = selectedVariant?.optionValues && selectedVariant.optionValues.length > 0
    ? formatVariantOptionsLocal(selectedVariant.optionValues) 
    : selectedVariant?.option_value 
      ? formatVariantOptionsLocal([{ optionName: selectedVariant.option_name || 'Opção', value: selectedVariant.option_value }]) 
      : '';

  const isRoundOpen = round.status === 'open' || round.status === 'active';
  const maxQuantity = selectedVariant?.stock_quantity || selectedVariant?.inventory_qty || 1;
  const variantsToUse = product.validVariants || product.product_variants || [];

  return (
    <div className="min-h-screen py-12">
      <Helmet>
        <title>{displayTitle} | {round.title}</title>
      </Helmet>

      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center gap-2 text-sm text-zinc-500 mb-8 pb-4 border-b border-zinc-800">
          <Link to="/rounds" className="hover:text-yellow-500 transition-colors">Rounds</Link>
          <span>/</span>
          <Link to={`/rounds/${round.slug || round.id}`} className="hover:text-yellow-500 transition-colors">{round.title}</Link>
          <span>/</span>
          <span className="text-zinc-300 truncate">{displayTitle}</span>
        </div>

        <Button onClick={() => navigate(`/rounds/${round.slug || round.id}`)} variant="ghost" className="mb-6 text-zinc-400 hover:text-white">
          <ArrowLeft className="w-4 h-4 mr-2" /> Back to Catalog
        </Button>

        {!isRoundOpen && (
          <div className="mb-6 p-4 bg-yellow-500/10 border border-yellow-500/50 rounded-lg text-yellow-500 flex items-center gap-2">
            <AlertCircle className="w-5 h-5" />
            <p>This round is currently closed.</p>
          </div>
        )}

        <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
          <div className="bg-zinc-950 border border-zinc-800 rounded-2xl p-6 flex items-center justify-center sticky top-24 h-fit">
            <img 
              src={displayImage} 
              alt={displayTitle} 
              className="w-full max-w-md aspect-square object-contain"
              onError={(e) => { e.currentTarget.onerror = null; e.currentTarget.src = '/images/placeholder-product.svg'; }}
            />
          </div>

          <div className="flex flex-col">
            {product.vendor && (
              <span className="text-zinc-500 text-xs font-bold uppercase tracking-widest mb-2">{product.vendor}</span>
            )}
            <h1 className="text-3xl md:text-4xl font-bold text-white mb-2 leading-tight">{displayTitle}</h1>
            
            {displayOptions && displayOptions !== '-' && (
              <p className="text-zinc-400 mb-4">{displayOptions}</p>
            )}
            
            <div className="flex items-center gap-4 mb-6 pb-6 border-b border-zinc-800">
              <div className="price-with-compare">
                {displayCompareAtPrice > displayPrice && (
                  <span className="compare-at-price">${Number(displayCompareAtPrice).toFixed(2)}</span>
                )}
                <span className="text-3xl font-bold text-yellow-500">${Number(displayPrice).toFixed(2)}</span>
              </div>
              <span className="text-sm font-mono text-zinc-500 bg-zinc-900 px-2 py-1 rounded border border-zinc-800 ml-auto">SKU: {displaySku}</span>
            </div>

            {variantsToUse.length > 0 ? (
              <div className="mb-8">
                <ProductVariantSelector 
                  product={product}
                  variants={variantsToUse}
                  selectedVariant={selectedVariant}
                  onSelectVariant={setSelectedVariant} 
                />
              </div>
            ) : (
              <p className="text-zinc-500 mb-8 italic">Sem opções disponíveis</p>
            )}

            <div className="bg-zinc-900/50 border border-zinc-800 p-6 rounded-xl mb-8">
              <div className="flex justify-between items-end mb-3">
                <Label className="text-zinc-400 text-xs uppercase tracking-wider font-bold">Quantity</Label>
                {selectedVariant && (
                  <span className="text-xs text-zinc-500">Available: {maxQuantity}</span>
                )}
              </div>
              <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-4">
                <div className="w-full sm:w-1/3">
                  <QuantitySelector 
                    quantity={quantity} 
                    onQuantityChange={setQuantity} 
                    max={maxQuantity || 1}
                    disabled={addingToCart || !isRoundOpen || maxQuantity <= 0}
                  />
                </div>
                <div className="flex-1 flex gap-2">
                  <Button 
                    onClick={handleAddToCart}
                    disabled={addingToCart || !isRoundOpen || !selectedVariant || maxQuantity <= 0}
                    className="flex-1 h-12 bg-yellow-500 hover:bg-yellow-400 text-black font-bold uppercase tracking-wide flex items-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    {addingToCart ? <Loader2 className="w-5 h-5 animate-spin" /> : <ShoppingCart className="w-5 h-5" />}
                    Add
                  </Button>
                  <Button
                    onClick={handleViewCart}
                    variant="outline"
                    className="h-12 border-zinc-700 text-white hover:bg-zinc-800 flex items-center gap-2"
                  >
                    <ShoppingBag className="w-5 h-5" />
                    Cart
                  </Button>
                </div>
              </div>
            </div>

            {displayDescription && (
              <div className="mt-8">
                <h3 className="text-lg font-bold text-white mb-4 pb-2 border-b border-zinc-800">Description</h3>
                <div 
                  className="prose prose-invert prose-zinc max-w-none text-zinc-400 text-sm leading-relaxed"
                  dangerouslySetInnerHTML={{ __html: displayDescription }} 
                />
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
