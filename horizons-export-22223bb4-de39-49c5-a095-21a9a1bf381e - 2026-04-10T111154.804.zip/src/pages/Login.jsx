
import React, { useState, useEffect } from "react";
import { useNavigate, Link } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/lib/supabaseClient";
import { Helmet } from "react-helmet";
import { useToast } from "@/components/ui/use-toast";
import { Loader2, AlertCircle } from "lucide-react";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";

export default function LoginPage() {
  const [email, setEmail] = useState("");
  const [pass, setPass] = useState("");
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState(null);
  const [forgotPasswordMode, setForgotPasswordMode] = useState(false);
  
  const { user, profile } = useAuth();
  const navigate = useNavigate();
  const { toast } = useToast();

  useEffect(() => {
    if (user && !forgotPasswordMode) {
      const isAdmin = profile?.is_admin || profile?.role === 'admin' || user?.app_metadata?.role === 'admin';
      navigate(isAdmin ? "/admin" : "/rounds");
    }
  }, [user, profile, navigate, forgotPasswordMode]);

  const handleLoginSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setErrorMsg(null);

    try {
      const { data, error } = await supabase.auth.signInWithPassword({
        email: email,
        password: pass,
      });

      if (error) throw error;
      
      toast({
        title: "Welcome back!",
        description: "You have successfully logged in.",
      });
      
      // Check role for redirect
      let isAdmin = false;
      if (data.user) {
         const { data: userProfile } = await supabase.from('profiles').select('is_admin, role').eq('id', data.user.id).single();
         isAdmin = userProfile?.is_admin || userProfile?.role === 'admin' || data.user?.app_metadata?.role === 'admin';
      }
      
      navigate(isAdmin ? "/admin" : "/rounds");

    } catch (error) {
      let displayMessage = "An unexpected error occurred. Please try again.";
      if (error.message === "Invalid login credentials") {
        displayMessage = "Invalid email or password. Please check your credentials.";
      } else if (error.message) {
        displayMessage = error.message;
      }
      setErrorMsg(displayMessage);
      toast({ variant: "destructive", title: "Login failed", description: displayMessage });
    } finally {
      setLoading(false);
    }
  };

  const handleResetPasswordSubmit = async (e) => {
    e.preventDefault();
    if (!email) {
      setErrorMsg("Please enter your email address.");
      return;
    }
    
    setLoading(true);
    setErrorMsg(null);

    try {
      const { error } = await supabase.auth.resetPasswordForEmail(email, {
        redirectTo: `${window.location.origin}/reset-password`,
      });

      if (error) throw error;
      
      toast({
        title: "Reset link sent",
        description: "Check your email for a link to reset your password.",
      });
      setForgotPasswordMode(false);
      setPass("");
    } catch (error) {
      setErrorMsg(error.message || "An unexpected error occurred.");
      toast({ variant: "destructive", title: "Failed to send reset link", description: error.message });
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      <Helmet>
        <title>{forgotPasswordMode ? 'Reset Password' : 'Login'} - Coop Stones</title>
        <meta name="description" content="Login to your Coop Stones account to access exclusive group purchasing rounds and member benefits." />
      </Helmet>
      <div className="min-h-[70vh] grid place-items-center px-4 py-12">
        <div className="w-full max-w-lg rounded-2xl bg-zinc-900 border border-zinc-800 p-8 shadow-2xl">
          <h1 className="text-3xl font-semibold text-zinc-100">
            {forgotPasswordMode ? 'Reset Password' : 'Join the Community'}
          </h1>
          <p className="text-zinc-400 mt-2">
            {forgotPasswordMode ? (
              "Enter your email address and we'll send you a link to reset your password."
            ) : (
              <>
                Log in to unlock <span className="text-yellow-400">collective purchase rounds</span>,
                exclusive prices, and a complete experience in the COOP STONES platform.
              </>
            )}
          </p>

          {errorMsg && (
            <Alert variant="destructive" className="mt-6 border-red-900/50 bg-red-900/20 text-red-200">
              <AlertCircle className="h-4 w-4" />
              <AlertTitle>Error</AlertTitle>
              <AlertDescription>
                {errorMsg}
              </AlertDescription>
            </Alert>
          )}

          {forgotPasswordMode ? (
            <form onSubmit={handleResetPasswordSubmit} className="mt-6 space-y-4">
              <div>
                <label className="text-sm text-zinc-300" htmlFor="reset-email">Email</label>
                <input
                  id="reset-email"
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="you@example.com"
                  className="mt-1 w-full px-3 py-2 rounded-xl bg-zinc-950 border border-zinc-800 outline-none focus:border-yellow-500 text-zinc-100 placeholder:text-zinc-600 transition-colors"
                />
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full flex items-center justify-center px-4 py-3 rounded-xl bg-yellow-500 text-black font-medium hover:bg-yellow-400 disabled:opacity-60 disabled:cursor-not-allowed transition-all shadow-lg hover:shadow-yellow-500/20"
              >
                {loading ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Sending...
                  </>
                ) : (
                  "Send Reset Link"
                )}
              </button>

              <div className="mt-4 text-sm text-center">
                <button 
                  type="button"
                  onClick={() => {
                    setForgotPasswordMode(false);
                    setErrorMsg(null);
                  }} 
                  className="text-zinc-400 hover:text-yellow-400 transition-colors"
                >
                  Back to login
                </button>
              </div>
            </form>
          ) : (
            <form onSubmit={handleLoginSubmit} className="mt-6 space-y-4">
              <div>
                <label className="text-sm text-zinc-300" htmlFor="email">Email</label>
                <input
                  id="email"
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="you@example.com"
                  className="mt-1 w-full px-3 py-2 rounded-xl bg-zinc-950 border border-zinc-800 outline-none focus:border-yellow-500 text-zinc-100 placeholder:text-zinc-600 transition-colors"
                />
              </div>
              <div>
                <label className="text-sm text-zinc-300" htmlFor="password">Password</label>
                <input
                  id="password"
                  type="password"
                  required
                  value={pass}
                  onChange={(e) => setPass(e.target.value)}
                  placeholder="••••••••"
                  className="mt-1 w-full px-3 py-2 rounded-xl bg-zinc-950 border border-zinc-800 outline-none focus:border-yellow-500 text-zinc-100 placeholder:text-zinc-600 transition-colors"
                />
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full flex items-center justify-center px-4 py-3 rounded-xl bg-yellow-500 text-black font-medium hover:bg-yellow-400 disabled:opacity-60 disabled:cursor-not-allowed transition-all shadow-lg hover:shadow-yellow-500/20"
              >
                {loading ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Logging in...
                  </>
                ) : (
                  "Login"
                )}
              </button>
              
              <div className="mt-4 text-sm text-zinc-400 text-center">
                Forgot your password?{" "}
                <button 
                  type="button" 
                  onClick={() => {
                    setForgotPasswordMode(true);
                    setErrorMsg(null);
                  }}
                  className="text-yellow-400 hover:underline"
                >
                  Recover access
                </button>
              </div>
            </form>
          )}

          {!forgotPasswordMode && (
            <div className="mt-8 rounded-xl bg-zinc-950 border border-zinc-800 p-4">
              <h2 className="text-zinc-100 font-medium">Not a member yet?</h2>
              <p className="text-zinc-400 text-sm mt-1">
                Join our platform and start ordering from our rounds to reduce costs and gain purchasing power.
              </p>
              <Link to="/membership" className="mt-3 inline-block px-4 py-2 rounded-xl bg-zinc-800 border border-zinc-700 hover:border-yellow-500 text-zinc-300 hover:text-yellow-400 transition-all">
                Learn about Membership
              </Link>
            </div>
          )}
        </div>
      </div>
    </>
  );
}
