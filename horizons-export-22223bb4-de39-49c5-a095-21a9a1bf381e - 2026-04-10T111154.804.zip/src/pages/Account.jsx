
import React, { useEffect, useState } from 'react';
import { Helmet } from 'react-helmet';
import { useAuth } from '@/contexts/AuthContext';
import { useSearchParams, useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { LogOut, User, Package, Settings, Loader2 } from 'lucide-react';
import { cn } from '@/lib/utils';

// Tab Components
import AccountOverview from '@/components/account/AccountOverview';
import AccountOrders from '@/pages/account/AccountOrders';
import AccountSettings from '@/components/account/AccountSettings';

const TABS = [
  { id: 'overview', label: 'Overview', icon: User, component: AccountOverview },
  { id: 'orders', label: 'My Orders', icon: Package, component: AccountOrders },
  { id: 'settings', label: 'Settings', icon: Settings, component: AccountSettings },
];

export default function AccountPage() {
  const { user, signOut, isAuthInitialized } = useAuth();
  const [searchParams, setSearchParams] = useSearchParams();
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState('overview');

  useEffect(() => {
    // Redirect logic using isAuthInitialized to ensure auth state is confirmed
    if (isAuthInitialized && !user) {
      console.log("[AccountPage] No authenticated user found after initialization, redirecting to login.");
      navigate('/login', { replace: true });
    }
  }, [user, isAuthInitialized, navigate]);

  useEffect(() => {
    const tab = searchParams.get('tab');
    if (tab && TABS.some(t => t.id === tab)) {
      setActiveTab(tab);
    } else if (!tab) {
      setSearchParams({ tab: 'overview' }, { replace: true });
    }
  }, [searchParams, setSearchParams]);

  // Loading state using isAuthInitialized
  if (!isAuthInitialized) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center">
        <Loader2 className="w-10 h-10 animate-spin text-yellow-500" />
      </div>
    );
  }

  // Prevent flash of content if user is missing but check passed
  if (!user) return null;

  const handleTabChange = (tabId) => {
    console.log(`[AccountPage] Changing tab to: ${tabId}`);
    setActiveTab(tabId);
    setSearchParams({ tab: tabId });
  };

  const handleSignOut = async () => {
    console.log("[AccountPage] User sign out initiated.");
    await signOut();
    navigate('/');
  };

  const ActiveComponent = TABS.find(t => t.id === activeTab)?.component || AccountOverview;

  return (
    <div className="min-h-screen bg-black py-24 px-4 sm:px-6 lg:px-8">
      <Helmet>
        <title>My Account | Coop Stones</title>
      </Helmet>

      <div className="max-w-6xl mx-auto">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-8 gap-4">
          <div>
            <h1 className="text-3xl font-bold text-white">My Account</h1>
            <p className="text-zinc-400 mt-1">Logged in as <span className="text-white font-medium">{user.email}</span></p>
          </div>
          <Button 
            variant="outline" 
            onClick={handleSignOut}
            className="border-zinc-800 text-zinc-300 hover:text-white hover:bg-zinc-900"
          >
            <LogOut className="mr-2 h-4 w-4" /> Sign Out
          </Button>
        </div>

        <div className="flex flex-col md:flex-row gap-8">
          <aside className="w-full md:w-64 shrink-0">
            <nav className="sticky top-24 flex flex-row md:flex-col gap-2 overflow-x-auto md:overflow-visible pb-2 md:pb-0 scrollbar-none z-10 bg-black md:bg-transparent">
              {TABS.map((tab) => {
                const Icon = tab.icon;
                const isActive = activeTab === tab.id;
                return (
                  <button
                    key={tab.id}
                    onClick={() => handleTabChange(tab.id)}
                    className={cn(
                      "flex items-center gap-3 px-4 py-3 rounded-lg text-sm font-medium transition-all whitespace-nowrap",
                      isActive 
                        ? "bg-yellow-400 text-black shadow-lg shadow-yellow-400/20" 
                        : "text-zinc-400 hover:text-white bg-zinc-950 hover:bg-zinc-900 border border-transparent hover:border-zinc-800"
                    )}
                  >
                    <Icon className="h-5 w-5" />
                    {tab.label}
                  </button>
                );
              })}
            </nav>
          </aside>

          <main className="flex-1 min-w-0">
            <div className="bg-zinc-950 rounded-2xl border border-zinc-900 p-4 sm:p-6 lg:p-8 min-h-[500px]">
              <ActiveComponent user={user} />
            </div>
          </main>
        </div>
      </div>
    </div>
  );
}
