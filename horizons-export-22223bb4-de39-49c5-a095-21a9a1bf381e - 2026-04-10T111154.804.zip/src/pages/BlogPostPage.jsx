import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { supabase } from '@/lib/supabaseClient';
import { motion } from 'framer-motion';
import { Calendar, User, ArrowLeft } from 'lucide-react';

const BlogPostPage = () => {
    const [post, setPost] = useState(null);
    const [loading, setLoading] = useState(true);
    const { slug } = useParams();

    useEffect(() => {
        const fetchPost = async () => {
            setLoading(true);
            const { data, error } = await supabase
                .from('v_post_by_slug')
                .select('*')
                .eq('slug', slug)
                .single();

            if (error) {
                console.error('Error fetching post:', error);
                setPost(null);
            } else {
                setPost(data);
            }
            setLoading(false);
        };

        fetchPost();
    }, [slug]);

    if (loading) {
        return (
            <div className="flex justify-center items-center h-screen bg-black">
                <div className="text-white text-2xl">Loading Post...</div>
            </div>
        );
    }

    if (!post) {
        return (
            <div className="flex flex-col justify-center items-center h-screen bg-black text-white">
                <h1 className="text-4xl font-bold mb-4">Post Not Found</h1>
                <p className="mb-8">Sorry, we couldn't find the post you're looking for.</p>
                <Link to="/blog" className="flex items-center gap-2 px-4 py-2 bg-yellow-500 text-black rounded-lg hover:bg-yellow-400">
                    <ArrowLeft size={18} />
                    Back to Blog
                </Link>
            </div>
        );
    }

    return (
        <>
            <Helmet>
                <title>{`${post.title} - Coop Stones Blog`}</title>
                <meta name="description" content={post.description || 'Read this article on the Coop Stones blog.'} />
            </Helmet>
            <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ duration: 0.8 }}
                className="bg-black text-white min-h-screen"
            >
                <div className="relative h-[50vh] min-h-[400px]">
                    <img src={post.cover_url} alt={post.title} className="absolute inset-0 w-full h-full object-cover" />
                    <div className="absolute inset-0 bg-gradient-to-t from-black via-black/70 to-transparent"></div>
                    <div className="relative max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 h-full flex flex-col justify-end pb-12">
                        <motion.h1
                            initial={{ opacity: 0, y: 20 }}
                            animate={{ opacity: 1, y: 0 }}
                            transition={{ duration: 0.6, delay: 0.2 }}
                            className="text-4xl md:text-6xl font-extrabold leading-tight text-shadow-lg"
                        >
                            {post.title}
                        </motion.h1>
                        <motion.div
                            initial={{ opacity: 0, y: 20 }}
                            animate={{ opacity: 1, y: 0 }}
                            transition={{ duration: 0.6, delay: 0.4 }}
                            className="flex items-center gap-6 mt-4 text-zinc-300"
                        >
                            <div className="flex items-center gap-2">
                                <Calendar size={16} className="text-yellow-400" />
                                <span>{new Date(post.published_at).toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' })}</span>
                            </div>
                        </motion.div>
                    </div>
                </div>

                <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
                    <motion.div
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.6, delay: 0.6 }}
                        className="prose prose-invert prose-lg max-w-none text-zinc-300 prose-headings:text-white prose-a:text-yellow-400 hover:prose-a:text-yellow-300 prose-strong:text-white"
                    >
                        <p className="lead text-xl text-zinc-200">{post.description}</p>
                        <div dangerouslySetInnerHTML={{ __html: post.content }} />
                    </motion.div>
                     <motion.div
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.6, delay: 0.8 }}
                        className="mt-12 pt-8 border-t border-zinc-800"
                    >
                        <Link to="/blog" className="inline-flex items-center gap-2 text-yellow-400 hover:text-yellow-300 font-semibold">
                            <ArrowLeft size={18} />
                            Back to All Posts
                        </Link>
                    </motion.div>
                </div>
            </motion.div>
        </>
    );
};

export default BlogPostPage;