import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import CallToAction from '@/components/CallToAction';
import { ShieldCheck, Target, Users } from 'lucide-react';

const AboutPage = () => {
  return (
    <>
      <Helmet>
        <title>About Coop Stones - Our Mission & Vision</title>
        <meta name="description" content="Learn about Coop Stones, an exclusive cooperative built by and for stone industry experts, and our mission to empower our members." />
      </Helmet>
      <div className="min-h-screen text-white flex flex-col">
        <main className="flex-grow">
          <section className="section-bg py-24">
            <div className="max-w-screen-xl mx-auto px-4 sm:px-6 lg:px-8">
              <div className="grid md:grid-cols-2 gap-16 items-center">
                <motion.div
                  initial={{ opacity: 0, x: -30 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.6 }}
                >
                  <h1 className="text-3xl sm:text-4xl md:text-5xl font-bold text-white mb-6">
                    About <span className="text-yellow-400">Coop Stones</span>
                  </h1>
                  <p className="text-gray-300 text-lg mb-6 leading-relaxed">
                    Coop Stones is an exclusive cooperative built by and for stone industry
                    experts. We unite fabricators, installers, and suppliers, creating a powerful
                    network to share resources, negotiate superior pricing on materials and
                    tools, and unlock new revenue streams.
                  </p>
                  <p className="text-gray-300 text-lg leading-relaxed">
                    Our model ensures that members benefit directly from our collective success, all
                    while upholding the highest standards of quality and ethics. Join us to transform
                    your business and the industry.
                  </p>
                </motion.div>
                <motion.div
                  initial={{ opacity: 0, scale: 0.9 }}
                  whileInView={{ opacity: 1, scale: 1 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.6, delay: 0.2 }}
                  className="relative"
                >
                  <div className="aspect-w-4 aspect-h-3 rounded-lg overflow-hidden shadow-2xl shadow-yellow-400/10">
                    <img 
                      className="w-full h-full object-cover" 
                      alt="Modern office with stone industry professionals collaborating"
                      src="https://images.unsplash.com/photo-1634715022648-13d43a4e9fe8" 
                    />
                  </div>
                </motion.div>
              </div>
            </div>
          </section>
          <section className="section-bg py-24">
            <div className="max-w-screen-xl mx-auto px-4 sm:px-6 lg:px-8">
              <div className="grid md:grid-cols-3 gap-12 text-center">
                <motion.div 
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.5, delay: 0.1 }}
                >
                  <Target className="w-16 h-16 mx-auto text-yellow-400 mb-6" />
                  <h2 className="text-2xl font-bold text-white mb-4">Our Mission</h2>
                  <p className="text-gray-400">To empower stone professionals by providing collective bargaining power, shared resources, and a collaborative network to foster growth and profitability.</p>
                </motion.div>
                <motion.div 
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.5, delay: 0.2 }}
                >
                  <Users className="w-16 h-16 mx-auto text-yellow-400 mb-6" />
                  <h2 className="text-2xl font-bold text-white mb-4">Our Vision</h2>
                  <p className="text-gray-400">To be the leading cooperative in the stone industry, recognized for our commitment to member success, innovation, and the highest ethical standards.</p>
                </motion.div>
                <motion.div 
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.5, delay: 0.3 }}
                >
                  <ShieldCheck className="w-16 h-16 mx-auto text-yellow-400 mb-6" />
                  <h2 className="text-2xl font-bold text-white mb-4">Our Values</h2>
                  <p className="text-gray-400">Integrity, collaboration, quality, and a member-first approach guide every decision we make as a cooperative.</p>
                </motion.div>
              </div>
            </div>
          </section>
          
          <CallToAction />
        </main>
      </div>
    </>
  );
};

export default AboutPage;