import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import Benefits from '@/components/Benefits';
import MembershipPlans from '@/components/MembershipPlans';
import { 
  FileText, 
  Search, 
  CheckCircle, 
  Briefcase, 
  CheckCircle2, 
  XCircle,
  Clock,
  Ban,
  FileSignature
} from 'lucide-react';

// Shared Divider Component
const SectionDivider = () => (
  <div className="h-px w-full max-w-7xl mx-auto bg-gradient-to-r from-transparent via-yellow-400/50 to-transparent opacity-50" />
);

const MembershipPage = () => {
  return (
    <>
      <Helmet>
        <title>Membership - Coop Stones</title>
        <meta name="description" content="Discover exclusive member benefits including group purchasing, premium materials, and marketing tools. Choose a plan and join us today." />
      </Helmet>
      
      <div className="min-h-screen bg-black text-white flex flex-col font-sans">
        <main className="flex-grow">
          
          {/* 1. Hero Section */}
          <section className="relative h-screen flex items-center justify-center overflow-hidden">
            <div className="absolute inset-0 z-0">
               <img 
                 src="https://images.unsplash.com/photo-1656658385993-2ab29848b080?q=80&w=2070&auto=format&fit=crop" 
                 alt="Stone Texture Background" 
                 className="w-full h-full object-cover"
               />
               <div className="absolute inset-0 bg-gradient-to-b from-black/80 via-black/60 to-black" />
            </div>

            <div className="relative z-10 max-w-5xl mx-auto px-6 text-center">
              <motion.div
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8 }}
              >
                <h1 className="text-4xl md:text-6xl lg:text-7xl font-bold mb-6 tracking-tight leading-tight">
                  A Cooperative Built to Elevate the <span className="text-yellow-400">Stone Industry</span>
                </h1>
                <p className="text-lg md:text-2xl text-zinc-300 max-w-3xl mx-auto mb-8 leading-relaxed font-light">
                  Coop Stones is a trade-focused cooperative association created for stone fabricators and industry professionals who want leverage, scale, and long-term growth through collective power.
                </p>
                <div className="inline-block bg-zinc-900/60 backdrop-blur-sm border border-zinc-800 rounded-full px-6 py-2 text-sm text-zinc-400">
                  Membership is selective and approval-based to ensure alignment with cooperative standards.
                </div>
              </motion.div>
            </div>
          </section>

          {/* 2. Exclusive Member Benefits */}
          <Benefits />
          
          <SectionDivider />

          {/* 3. How Membership Works (Premium Timeline) */}
          <section className="py-24 relative overflow-hidden">
            <div className="absolute inset-0 z-0 marble-bg opacity-20 pointer-events-none mix-blend-overlay"></div>
            <div className="absolute inset-0 bg-gradient-to-b from-black via-zinc-950/90 to-black z-0"></div>
            
            <div className="relative z-10 max-w-7xl mx-auto px-6">
              <div className="text-center mb-20">
                <h2 className="text-3xl md:text-5xl font-bold mb-6 tracking-tight text-white">
                  How <span className="text-yellow-400">Membership Works</span>
                </h2>
                <p className="text-zinc-400 max-w-2xl mx-auto text-lg">
                  A streamlined path to partnership and growth.
                </p>
              </div>

              {/* Desktop Connector Line */}
              <div className="hidden lg:block relative mb-12">
                <div className="absolute top-8 left-0 w-full h-0.5 bg-gradient-to-r from-transparent via-yellow-400/30 to-transparent"></div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 lg:gap-6">
                {[
                  {
                    icon: FileText,
                    title: "Apply",
                    subtitle: "Submit Application",
                    desc: "Membership is approval-based to ensure quality."
                  },
                  {
                    icon: Search,
                    title: "Review",
                    subtitle: "Profile Alignment",
                    desc: "We verify your business goals align with the coop."
                  },
                  {
                    icon: CheckCircle,
                    title: "Select",
                    subtitle: "Choose Plan",
                    desc: "Pick the tier that fits your operational scale."
                  },
                  {
                    icon: Briefcase,
                    title: "Operate",
                    subtitle: "Access Benefits",
                    desc: "Leverage collective power for your business."
                  }
                ].map((step, idx) => (
                  <motion.div
                    key={idx}
                    initial={{ opacity: 0, y: 30 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ delay: idx * 0.15 }}
                    whileHover={{ scale: 1.05 }}
                    className="relative group flex flex-col items-center text-center p-8 rounded-xl border border-yellow-400/30 bg-zinc-900/40 backdrop-blur-sm transition-all duration-300 gold-glow-hover hover:border-yellow-400/50"
                  >
                     {/* Step Number Badge */}
                     <div className="w-16 h-16 rounded-full bg-zinc-900 border-2 border-yellow-400 text-yellow-400 font-bold text-xl flex items-center justify-center mb-6 z-10 gold-glow group-hover:bg-yellow-400 group-hover:text-black transition-colors duration-300">
                       {idx + 1}
                     </div>
                     
                     <h3 className="text-2xl font-bold text-white mb-1">{step.title}</h3>
                     <p className="text-yellow-400 text-sm font-medium uppercase tracking-wider mb-4">{step.subtitle}</p>
                     <p className="text-zinc-400 text-sm leading-relaxed">{step.desc}</p>
                  </motion.div>
                ))}
              </div>
              <div className="text-center mt-16">
                <p className="text-zinc-500 text-sm italic border-t border-zinc-800 inline-block px-8 py-2">
                  *Membership requires a minimum 12-month commitment.
                </p>
              </div>
            </div>
          </section>

          <SectionDivider />

          {/* 4. Who This Is For (Glassmorphism) */}
          <section className="py-24 bg-zinc-900/20 relative">
             <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/dark-matter.png')] opacity-10"></div>
             <div className="max-w-7xl mx-auto px-6 relative z-10">
               <h2 className="text-3xl md:text-5xl font-bold text-center mb-20 text-white">
                 Is Coop Stones <span className="text-yellow-400">For You?</span>
               </h2>
               
               <div className="grid lg:grid-cols-2 gap-12 max-w-6xl mx-auto">
                  {/* Ideal For */}
                  <motion.div 
                    initial={{ opacity: 0, x: -30 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    viewport={{ once: true }}
                    className="backdrop-blur-md bg-white/5 border-l-4 border-green-500/30 p-8 md:p-12 rounded-2xl shadow-2xl transition-all duration-300 hover:bg-green-500/5 hover:border-green-500"
                  >
                     <div className="flex items-center gap-4 mb-8 border-b border-white/10 pb-6">
                       <div className="p-3 bg-green-500/10 rounded-full">
                         <CheckCircle2 className="w-8 h-8 text-green-500" />
                       </div>
                       <h3 className="text-2xl font-bold text-white">Ideal For</h3>
                     </div>
                     <ul className="space-y-6">
                       {[
                         "Stone fabricators and countertop shops",
                         "Granite, quartz, & porcelain professionals",
                         "Trade businesses seeking purchasing leverage",
                         "Operators focused on long-term growth"
                       ].map((item, i) => (
                         <li key={i} className="flex items-start gap-4 group">
                            <span className="mt-1 w-5 h-5 rounded-full border border-green-500/50 flex items-center justify-center group-hover:bg-green-500/20 transition-colors">
                              <CheckCircle2 className="w-3 h-3 text-green-500" />
                            </span>
                            <span className="text-zinc-300 text-lg group-hover:text-white transition-colors">{item}</span>
                         </li>
                       ))}
                     </ul>
                  </motion.div>

                  {/* Not For */}
                  <motion.div 
                    initial={{ opacity: 0, x: 30 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    viewport={{ once: true }}
                    className="backdrop-blur-md bg-white/5 border-l-4 border-red-500/30 p-8 md:p-12 rounded-2xl shadow-2xl transition-all duration-300 hover:bg-red-500/5 hover:border-red-500"
                  >
                     <div className="flex items-center gap-4 mb-8 border-b border-white/10 pb-6">
                       <div className="p-3 bg-red-500/10 rounded-full">
                         <XCircle className="w-8 h-8 text-red-500" />
                       </div>
                       <h3 className="text-2xl font-bold text-white">Not Designed For</h3>
                     </div>
                     <ul className="space-y-6">
                       {[
                         "One-time retail buyers",
                         "Price-only transaction shoppers",
                         "Short-term or non-committed businesses",
                         "Hobbyists or DIY enthusiasts"
                       ].map((item, i) => (
                         <li key={i} className="flex items-start gap-4 group">
                            <span className="mt-1 w-5 h-5 rounded-full border border-red-500/50 flex items-center justify-center group-hover:bg-red-500/20 transition-colors">
                              <XCircle className="w-3 h-3 text-red-500" />
                            </span>
                            <span className="text-zinc-400 text-lg group-hover:text-zinc-200 transition-colors">{item}</span>
                         </li>
                       ))}
                     </ul>
                  </motion.div>
               </div>
             </div>
          </section>

          <SectionDivider />

          {/* 5. Commitment & Transparency (Micro-section) */}
          <section className="py-24 bg-zinc-950/80">
             <div className="max-w-6xl mx-auto px-6">
                <div className="text-center mb-16">
                  <h2 className="text-3xl md:text-5xl font-bold mb-6 tracking-tight text-white">
                    Commitment & <span className="text-yellow-400">Transparency</span>
                  </h2>
                </div>
                <div className="grid md:grid-cols-3 gap-12 text-center">
                   {[
                     {
                       icon: Clock,
                       text: "12-month minimum commitment required."
                     },
                     {
                       icon: Ban,
                       text: "Fees are non-refundable & non-transferable."
                     },
                     {
                       icon: FileSignature,
                       text: "Applications reviewed for cooperative alignment."
                     }
                   ].map((item, i) => (
                     <motion.div 
                       key={i} 
                       initial={{ opacity: 0, y: 20 }}
                       whileInView={{ opacity: 1, y: 0 }}
                       viewport={{ once: true }}
                       transition={{ delay: i * 0.1 }}
                       className="flex flex-col items-center gap-6 p-6 rounded-lg hover:bg-zinc-900/50 transition-colors"
                     >
                       <div className="p-4 rounded-full border border-yellow-400/30 text-yellow-400 bg-yellow-950/10">
                         <item.icon className="w-8 h-8 stroke-[1.5]" />
                       </div>
                       <p className="text-zinc-400 font-medium text-sm max-w-xs leading-relaxed border-t border-zinc-800 pt-4 w-full">
                         {item.text}
                       </p>
                     </motion.div>
                   ))}
                </div>
             </div>
          </section>

          <SectionDivider />

          {/* 6. Membership Plans */}
          <MembershipPlans />
          
        </main>
      </div>
    </>
  );
};

export default MembershipPage;