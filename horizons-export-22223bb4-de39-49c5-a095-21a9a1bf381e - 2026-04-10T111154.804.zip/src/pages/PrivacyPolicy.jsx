import React from 'react';
import { Helmet } from 'react-helmet';

const PrivacyPolicy = () => {
  return (
    <div className="container mx-auto px-4 py-16 md:px-8 max-w-4xl">
      <Helmet>
        <title>Privacy Policy – COOPSTONES</title>
        <meta name="description" content="COOPSTONES Privacy Policy. Learn how we collect, use, and protect your personal data." />
        <meta property="og:title" content="Privacy Policy – COOPSTONES" />
        <meta property="og:description" content="Learn how we protect your data." />
        <link rel="canonical" href="https://coopstones.com/privacy-policy" />
      </Helmet>

      <h1 className="text-4xl font-bold text-white mb-2">Privacy Policy</h1>
      <p className="text-zinc-400 mb-8">Last Updated: December 2, 2025</p>

      <div className="space-y-8 text-zinc-300 leading-relaxed">
        <section>
          <h2 className="text-2xl font-semibold text-yellow-500 mb-4">1. Information We Collect</h2>
          <p>
            We collect information you provide directly to us, such as when you create an account, make a purchase, or communicate with us. This may include:
          </p>
          <ul className="list-disc pl-6 mt-2 space-y-2">
            <li>Identity Data: Name, company name, job title.</li>
            <li>Contact Data: Email address, phone number, billing address, shipping address.</li>
            <li>Financial Data: Payment card details (processed securely by Stripe; we do not store full card numbers).</li>
            <li>Transaction Data: Details about payments to and from you and other details of products you have purchased from us.</li>
          </ul>
        </section>

        <section>
          <h2 className="text-2xl font-semibold text-yellow-500 mb-4">2. How We Use Your Information</h2>
          <p>
            We use the information we collect to:
          </p>
          <ul className="list-disc pl-6 mt-2 space-y-2">
            <li>Provide, maintain, and improve our services.</li>
            <li>Process transactions and send related information, including confirmations and invoices.</li>
            <li>Send you technical notices, updates, security alerts, and support and administrative messages.</li>
            <li>Respond to your comments, questions, and requests.</li>
            <li>Comply with legal obligations.</li>
          </ul>
        </section>

        <section>
          <h2 className="text-2xl font-semibold text-yellow-500 mb-4">3. Cookies and Tracking Technologies</h2>
          <p>
            We use cookies and similar tracking technologies to track the activity on our Service and hold certain information. You can instruct your browser to refuse all cookies or to indicate when a cookie is being sent. However, if you do not accept cookies, you may not be able to use some portions of our Service.
          </p>
        </section>

        <section>
          <h2 className="text-2xl font-semibold text-yellow-500 mb-4">4. Payment Data Security</h2>
          <p>
            All payment transactions are processed through our third-party payment processor, Stripe. Stripe uses best-in-class security tools and practices to maintain a high level of security. We do not store your credit card information on our servers.
          </p>
        </section>

        <section>
          <h2 className="text-2xl font-semibold text-yellow-500 mb-4">5. GDPR & CCPA Compliance</h2>
          <p>
            <strong>GDPR (General Data Protection Regulation):</strong> If you are a resident of the European Economic Area (EEA), you have certain data protection rights, including the right to access, correct, update, or delete your personal information.
          </p>
          <p className="mt-2">
            <strong>CCPA (California Consumer Privacy Act):</strong> If you are a resident of California, you have the right to request disclosure of what personal information we collect, use, disclose, and sell. We do not sell your personal information.
          </p>
        </section>

        <section>
          <h2 className="text-2xl font-semibold text-yellow-500 mb-4">6. Data Retention</h2>
          <p>
            We will retain your Personal Data only for as long as is necessary for the purposes set out in this Privacy Policy. We will retain and use your Personal Data to the extent necessary to comply with our legal obligations, resolve disputes, and enforce our legal agreements and policies.
          </p>
        </section>

        <section>
          <h2 className="text-2xl font-semibold text-yellow-500 mb-4">7. Contact Us Regarding Privacy</h2>
          <p>
            If you have any questions about this Privacy Policy or wish to exercise your rights, please contact our Data Privacy Officer at:
          </p>
          <div className="mt-4 p-4 bg-zinc-900 rounded-lg border border-zinc-800">
            <p><strong>COOPSTONES LLC</strong></p>
            <p>Attn: Privacy Officer</p>
            <p>Email: <a href="mailto:contact@coopstones.com" className="text-yellow-500 hover:underline">contact@coopstones.com</a></p>
          </div>
        </section>
      </div>
    </div>
  );
};

export default PrivacyPolicy;