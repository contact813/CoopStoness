
import React, { useState, useEffect } from "react";
import { useNavigate, Link } from "react-router-dom";
import { supabase } from "@/lib/supabaseClient";
import { Helmet } from "react-helmet";
import { useToast } from "@/components/ui/use-toast";
import { Loader2, AlertCircle, CheckCircle } from "lucide-react";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";

export default function ResetPasswordPage() {
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState(null);
  const [success, setSuccess] = useState(false);
  
  const navigate = useNavigate();
  const { toast } = useToast();

  useEffect(() => {
    // Supabase automatically parses the URL hash containing the access_token 
    // and logs the user in temporarily so we can update their password.
    const checkSession = async () => {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) {
        // If there's no session, the token might be missing or expired
        // But we won't strictly block them here as they might just be typing it in
        // or the auth state change hasn't fired yet.
      }
    };
    checkSession();

    const { data: authListener } = supabase.auth.onAuthStateChange((event, session) => {
      if (event === 'PASSWORD_RECOVERY') {
        // Ready to reset password
        setErrorMsg(null);
      }
    });

    return () => {
      authListener.subscription.unsubscribe();
    };
  }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setErrorMsg(null);

    if (password !== confirmPassword) {
      setErrorMsg("Passwords do not match.");
      setLoading(false);
      return;
    }

    if (password.length < 6) {
      setErrorMsg("Password must be at least 6 characters.");
      setLoading(false);
      return;
    }

    try {
      const { error } = await supabase.auth.updateUser({
        password: password
      });

      if (error) throw error;
      
      setSuccess(true);
      toast({
        title: "Password Updated",
        description: "Your password has been successfully reset. Redirecting to login...",
      });
      
      // Sign out to clear the temporary recovery session
      await supabase.auth.signOut();
      
      setTimeout(() => {
        navigate("/login");
      }, 2000);

    } catch (error) {
      let displayMessage = "An unexpected error occurred. Please try again.";
      if (error.message) {
        displayMessage = error.message;
      }
      setErrorMsg(displayMessage);
      toast({ variant: "destructive", title: "Update failed", description: displayMessage });
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      <Helmet>
        <title>Reset Password - Coop Stones</title>
        <meta name="description" content="Set a new password for your Coop Stones account." />
      </Helmet>
      <div className="min-h-[70vh] grid place-items-center px-4 py-12">
        <div className="w-full max-w-lg rounded-2xl bg-zinc-900 border border-zinc-800 p-8 shadow-2xl">
          <h1 className="text-3xl font-semibold text-zinc-100">Set New Password</h1>
          <p className="text-zinc-400 mt-2">
            Please enter your new password below.
          </p>

          {errorMsg && (
            <Alert variant="destructive" className="mt-6 border-red-900/50 bg-red-900/20 text-red-200">
              <AlertCircle className="h-4 w-4" />
              <AlertTitle>Error</AlertTitle>
              <AlertDescription>
                {errorMsg}
              </AlertDescription>
            </Alert>
          )}

          {success ? (
            <div className="mt-6 p-6 bg-green-950/30 border border-green-900/50 rounded-xl text-center">
              <CheckCircle className="h-12 w-12 text-green-500 mx-auto mb-4" />
              <h3 className="text-xl font-medium text-zinc-100 mb-2">Password Reset Successful</h3>
              <p className="text-zinc-400 mb-6">You can now log in with your new password.</p>
              <Link 
                to="/login"
                className="inline-flex items-center justify-center px-6 py-3 rounded-xl bg-yellow-500 text-black font-medium hover:bg-yellow-400 transition-all"
              >
                Go to Login
              </Link>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="mt-6 space-y-4">
              <div>
                <label className="text-sm text-zinc-300" htmlFor="password">New Password</label>
                <input
                  id="password"
                  type="password"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="mt-1 w-full px-3 py-2 rounded-xl bg-zinc-950 border border-zinc-800 outline-none focus:border-yellow-500 text-zinc-100 placeholder:text-zinc-600 transition-colors"
                />
              </div>
              <div>
                <label className="text-sm text-zinc-300" htmlFor="confirmPassword">Confirm Password</label>
                <input
                  id="confirmPassword"
                  type="password"
                  required
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  placeholder="••••••••"
                  className="mt-1 w-full px-3 py-2 rounded-xl bg-zinc-950 border border-zinc-800 outline-none focus:border-yellow-500 text-zinc-100 placeholder:text-zinc-600 transition-colors"
                />
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full flex items-center justify-center px-4 py-3 rounded-xl bg-yellow-500 text-black font-medium hover:bg-yellow-400 disabled:opacity-60 disabled:cursor-not-allowed transition-all shadow-lg hover:shadow-yellow-500/20 mt-6"
              >
                {loading ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Updating Password...
                  </>
                ) : (
                  "Reset Password"
                )}
              </button>
            </form>
          )}

          {!success && (
            <div className="mt-6 text-sm text-center">
              <Link to="/login" className="text-zinc-400 hover:text-yellow-400 transition-colors">
                Back to Login
              </Link>
            </div>
          )}
        </div>
      </div>
    </>
  );
}
