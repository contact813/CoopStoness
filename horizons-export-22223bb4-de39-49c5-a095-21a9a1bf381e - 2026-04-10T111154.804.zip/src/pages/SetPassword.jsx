
import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/lib/supabaseClient";
import { Helmet } from "react-helmet";
import { useToast } from "@/components/ui/use-toast";
import { Loader2, AlertCircle } from "lucide-react";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";

export default function SetPassword() {
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState(null);
  const [hasSession, setHasSession] = useState(false);
  const [checkingSession, setCheckingSession] = useState(true);
  
  const navigate = useNavigate();
  const { toast } = useToast();

  useEffect(() => {
    const checkSession = async () => {
      try {
        const { data: { session }, error } = await supabase.auth.getSession();
        if (error) throw error;
        if (session) setHasSession(true);
        else setHasSession(false);
      } catch (err) {
        setHasSession(false);
      } finally {
        setCheckingSession(false);
      }
    };
    checkSession();
  }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setErrorMsg(null);

    if (password.length < 8) {
      setErrorMsg("Password must be at least 8 characters long.");
      setLoading(false);
      return;
    }

    if (password !== confirmPassword) {
      setErrorMsg("Passwords do not match.");
      setLoading(false);
      return;
    }

    try {
      const { error } = await supabase.auth.updateUser({ password });
      if (error) throw error;

      toast({ title: "Success!", description: "Your password has been set successfully." });
      
      let isAdmin = false;
      const { data: { user } } = await supabase.auth.getUser();
      if (user) {
          const { data: profile } = await supabase.from('profiles').select('is_admin, role').eq('id', user.id).single();
          isAdmin = profile?.is_admin || profile?.role === 'admin' || user?.app_metadata?.role === 'admin';
      }
      
      navigate(isAdmin ? "/admin" : "/rounds");

    } catch (error) {
      setErrorMsg(error.message || "Failed to set password. Your link may have expired.");
    } finally {
      setLoading(false);
    }
  };

  if (checkingSession) {
    return (
      <div className="min-h-[70vh] flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-yellow-500" />
      </div>
    );
  }

  if (!hasSession) {
    return (
      <div className="min-h-[70vh] grid place-items-center px-4 py-12">
        <div className="w-full max-w-lg rounded-2xl bg-zinc-900 border border-zinc-800 p-8 shadow-2xl text-center">
          <AlertCircle className="h-12 w-12 text-red-500 mx-auto mb-4" />
          <h1 className="text-2xl font-semibold text-zinc-100 mb-2">Invalid or Expired Link</h1>
          <p className="text-zinc-400 mb-6">
            Your password setup link is invalid or has expired. For security reasons, these links expire after 24 hours.
          </p>
          <div className="space-y-4">
            <button 
              onClick={() => navigate('/login')}
              className="w-full px-4 py-3 rounded-xl bg-yellow-500 text-black font-medium hover:bg-yellow-400 transition-all"
            >
              Go to Login
            </button>
            <p className="text-sm text-zinc-500">
              Need help? <a href="/contact" className="text-yellow-500 hover:underline">Contact Support</a>
            </p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <>
      <Helmet><title>Set Password - Coop Stones</title></Helmet>
      <div className="min-h-[70vh] grid place-items-center px-4 py-12">
        <div className="w-full max-w-lg rounded-2xl bg-zinc-900 border border-zinc-800 p-8 shadow-2xl">
          <h1 className="text-3xl font-semibold text-zinc-100">Set Your Password</h1>
          <p className="text-zinc-400 mt-2">
            Please create a secure password for your new account to access the platform.
          </p>

          {errorMsg && (
            <Alert variant="destructive" className="mt-6 border-red-900/50 bg-red-900/20 text-red-200">
              <AlertCircle className="h-4 w-4" />
              <AlertTitle>Error</AlertTitle>
              <AlertDescription>{errorMsg}</AlertDescription>
            </Alert>
          )}

          <form onSubmit={handleSubmit} className="mt-6 space-y-4">
            <div>
              <label className="text-sm text-zinc-300" htmlFor="password">New Password</label>
              <input
                id="password"
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Minimum 8 characters"
                className="mt-1 w-full px-3 py-2 rounded-xl bg-zinc-950 border border-zinc-800 outline-none focus:border-yellow-500 text-zinc-100 placeholder:text-zinc-600 transition-colors"
              />
            </div>
            <div>
              <label className="text-sm text-zinc-300" htmlFor="confirmPassword">Confirm Password</label>
              <input
                id="confirmPassword"
                type="password"
                required
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                placeholder="Confirm your new password"
                className="mt-1 w-full px-3 py-2 rounded-xl bg-zinc-950 border border-zinc-800 outline-none focus:border-yellow-500 text-zinc-100 placeholder:text-zinc-600 transition-colors"
              />
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full flex items-center justify-center px-4 py-3 mt-4 rounded-xl bg-yellow-500 text-black font-medium hover:bg-yellow-400 disabled:opacity-60 disabled:cursor-not-allowed transition-all shadow-lg hover:shadow-yellow-500/20"
            >
              {loading ? (
                <><Loader2 className="mr-2 h-4 w-4 animate-spin" />Updating...</>
              ) : ("Save Password")}
            </button>
          </form>
        </div>
      </div>
    </>
  );
}
