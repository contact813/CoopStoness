
import React, { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';

const StandardOrdersPage = () => {
    const navigate = useNavigate();

    useEffect(() => {
        // Automatically redirect to the new primary Round Orders flow
        navigate('/admin/orders', { replace: true });
    }, [navigate]);

    return null;
};

export default StandardOrdersPage;
