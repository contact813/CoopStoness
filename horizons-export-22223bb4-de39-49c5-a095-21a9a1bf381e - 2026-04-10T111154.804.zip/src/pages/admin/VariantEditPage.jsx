
import React, { useState, useEffect } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { getProductById } from '@/lib/adminProductsApi';
import { getVariant, updateVariant, createVariant, deleteVariant, getProductVariants } from '@/lib/adminVariantsApi';
import { useToast } from '@/components/ui/use-toast';
import { Loader2, Menu, ChevronRight, Save, X, Trash2 } from 'lucide-react';
import { normalizeImages } from '@/lib/adminDataNormalizers';
import { Button } from '@/components/ui/button';
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { sanitizeUuid } from '@/lib/idUtils';

import VariantSidebar from '@/components/admin/VariantSidebar';
import VariantForm from '@/components/admin/VariantForm';

export default function VariantEditPage() {
  const { productId, variantId } = useParams();
  const navigate = useNavigate();
  const { toast } = useToast();
  const isCreate = !variantId || variantId === 'new';

  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [deleting, setDeleting] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  
  const [product, setProduct] = useState(null);
  const [options, setOptions] = useState([]);
  const [variants, setVariants] = useState([]);
  const [formState, setFormState] = useState({
    price: 0,
    compare_at_price: '',
    cost: '',
    inventory_qty: 0,
    sku: '',
    barcode: '',
    image_url: '',
    optionValues: [],
    title: '',
    custom_description: '',
    is_active: true
  });

  const loadVariantData = async (cleanProductId, cleanVariantId) => {
    try {
      console.log(`[VariantEditPage] Loading variant data...`);
      const { data: productData, error: productError } = await getProductById(cleanProductId);
      if (productError || !productData) throw new Error(productError?.message || "Product not found");
      
      const safeOpts = Array.isArray(productData.options) ? productData.options : (productData.product_options || []);
      
      const { data: varsData, error: varsError } = await getProductVariants(cleanProductId);
      if (varsError) console.error(`[VariantEditPage] Error loading variants:`, varsError);
      
      const safeVars = Array.isArray(varsData) ? varsData : [];

      setProduct({
          ...productData,
          images: normalizeImages(productData.images)
      });
      setOptions(safeOpts);
      setVariants(safeVars);

      if (!isCreate) {
         const { data: targetVariant, error: varError } = await getVariant(cleanVariantId);
         if (varError) throw varError;
         
         if (targetVariant) {
           console.log(`[VariantEditPage] Successfully loaded variant: ${cleanVariantId}`, targetVariant);
           console.log('[VariantEditPage] Loaded variant image_url:', targetVariant?.image_url);
           
           const imageUrl = targetVariant.image_url || targetVariant.image || null;
           const variantPrice = (targetVariant.price && targetVariant.price > 0) 
              ? targetVariant.price 
              : productData.price;

           setFormState(prev => ({
               ...prev,
               ...targetVariant,
               id: targetVariant.id,
               product_id: targetVariant.product_id,
               title: targetVariant.title || '',
               price: variantPrice || 0,
               compare_at_price: targetVariant.compare_at_price || '',
               cost: targetVariant.cost || '',
               inventory_qty: targetVariant.inventory_qty || 0,
               sku: targetVariant.sku || '',
               barcode: targetVariant.barcode || '',
               image_url: imageUrl || '',
               optionValues: Array.isArray(targetVariant.optionValues) ? targetVariant.optionValues : [],
               position: targetVariant.position,
               custom_description: targetVariant.custom_description || '',
               is_active: targetVariant.is_active !== false
           }));
         } else {
           toast({ variant: "destructive", title: "Variant not found" });
           navigate(`/admin/products/${cleanProductId}`);
         }
      } else {
         console.log(`[VariantEditPage] Initializing new variant form`);
         const defaultOptionValues = safeOpts.map(o => ({
           optionId: o.id,
           option_id: o.id,
           optionName: o.name,
           valueId: o.values?.[0]?.id || null,
           option_value_id: o.values?.[0]?.id || null, 
           value: o.values?.[0]?.value || ''
         }));
         
         setFormState({
           id: 'new',
           product_id: cleanProductId,
           price: productData.price || 0, 
           compare_at_price: '',
           cost: '',
           inventory_qty: 0,
           sku: '',
           barcode: '',
           image_url: '',
           optionValues: defaultOptionValues,
           title: defaultOptionValues.map(ov => ov.value).join(' / ') || 'New Variant',
           custom_description: '',
           is_active: true
         });
      }
    } catch (error) {
      console.error("[VariantEditPage] Initialization error:", error);
      toast({ variant: "destructive", title: "Error loading data", description: error.message });
      navigate('/admin/products');
    }
  };

  useEffect(() => {
    const cleanProductId = sanitizeUuid(productId);
    const cleanVariantId = !isCreate ? sanitizeUuid(variantId) : 'new';

    if (!cleanProductId) {
        toast({ variant: "destructive", title: "Error", description: "Invalid Product ID" });
        navigate('/admin/products');
        return;
    }

    if (!isCreate && !cleanVariantId) {
        toast({ variant: "destructive", title: "Error", description: "Invalid Variant ID" });
        navigate(`/admin/products/${cleanProductId}`);
        return;
    }

    async function load() {
      setLoading(true);
      await loadVariantData(cleanProductId, cleanVariantId);
      setLoading(false);
    }
    load();
  }, [productId, variantId, isCreate, navigate, toast]);

  const handleSave = async () => {
    setSaving(true);
    console.log('[VariantEditPage] Saving variant');
    console.log('[VariantEditPage] Form image_url:', formState.image_url);
    
    try {
        const cleanProductId = sanitizeUuid(productId);
        
        if (!formState.title) throw new Error("Title is required");
        if (!formState.sku) throw new Error("SKU is required");
        if (formState.price <= 0) throw new Error("Price must be greater than 0");

        const payload = {
            ...formState,
            product_id: cleanProductId,
            title: formState.title,
            price: formState.price,
            compare_at_price: formState.compare_at_price || null,
            cost: formState.cost || null,
            inventory_qty: formState.inventory_qty,
            sku: formState.sku,
            barcode: formState.barcode,
            image_url: formState.image_url || '',
            optionValues: Array.isArray(formState.optionValues) ? formState.optionValues : [],
            custom_description: formState.custom_description || null,
            is_active: formState.is_active,
            ...(formState.position !== undefined ? { position: formState.position } : {})
        };
        
        console.log('[VariantEditPage] Payload being sent:', payload);

        let savedData;
        if (isCreate || formState.id === 'new') {
            const { data, error } = await createVariant(cleanProductId, payload);
            if (error) {
              console.error('[VariantEditPage] Save error:', error.message);
              throw error;
            }
            savedData = data;
            console.log(`[VariantEditPage] Variant saved successfully (Created)`, savedData);
            
            toast({ title: "Variant created", className: "bg-green-500 text-white" });
            navigate(`/admin/products/${cleanProductId}/variants/${savedData.id}`, { replace: true });
        } else {
            const { data, error } = await updateVariant(formState.id, payload);
            if (error) {
              console.error('[VariantEditPage] Save error:', error.message);
              throw error;
            }
            savedData = data;
            console.log(`[VariantEditPage] Variant saved successfully (Updated)`, savedData);
            
            console.log('[VariantEditPage] Variant saved, reloading');
            await loadVariantData(cleanProductId, formState.id);
            toast({ title: "Variant updated", className: "bg-green-500 text-white" });
        }
    } catch (error) {
        console.error("[VariantEditPage] Save error:", error);
        toast({ variant: "destructive", title: "Save failed", description: error.message });
    } finally {
        setSaving(false);
    }
  };

  const handleDelete = async () => {
      if (!confirm("Are you sure you want to delete this variant? This cannot be undone.")) return;
      
      setDeleting(true);
      const cleanVariantId = sanitizeUuid(variantId);
      console.log(`[VariantEditPage] Deleting variant: ${cleanVariantId}`);
      
      try {
          const { error } = await deleteVariant(cleanVariantId);
          if (error) throw error;
          
          console.log(`[VariantEditPage] Successfully deleted variant: ${cleanVariantId}`);
          toast({ title: "Variant deleted" });
          navigate(`/admin/products/${productId}`);
      } catch (error) {
          console.error("[VariantEditPage] Delete failed:", error);
          toast({ variant: "destructive", title: "Delete failed", description: error.message });
          setDeleting(false);
      }
  };

  if (loading) {
      return (
        <div className="flex h-screen items-center justify-center bg-zinc-950">
          <div className="flex flex-col items-center gap-4">
             <Loader2 className="w-10 h-10 animate-spin text-yellow-500" />
             <p className="text-zinc-500 animate-pulse">Loading editor...</p>
          </div>
        </div>
      );
  }

  if (!product) return null;

  return (
    <div className="flex h-screen overflow-hidden bg-black text-white">
       <div className="hidden lg:block w-[320px] h-full flex-shrink-0 border-r border-zinc-800 overflow-y-auto no-scrollbar">
          <VariantSidebar 
              product={product} 
              variants={variants} 
              options={options}
              activeVariantId={isCreate ? 'new' : variantId}
              productId={productId}
              className="h-full"
          />
       </div>
       
       <div className="flex-1 flex flex-col h-full overflow-y-auto relative bg-black no-scrollbar" id="main-scroll-container">
          <div className="sticky top-0 z-10 px-6 py-4 border-b border-zinc-800 bg-zinc-950/95 backdrop-blur shadow-sm">
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 max-w-7xl mx-auto w-full">
                  <div className="flex flex-col gap-1">
                     <div className="flex items-center text-sm text-zinc-500 gap-1">
                         <Link to="/admin/products" className="hover:text-yellow-500 transition-colors">Products</Link>
                         <ChevronRight className="w-3 h-3" />
                         <Link to={`/admin/products/${productId}`} className="hover:text-yellow-500 transition-colors max-w-[150px] truncate">{product.title}</Link>
                         <ChevronRight className="w-3 h-3" />
                         <span className="text-zinc-300">Variants</span>
                     </div>
                     <div className="flex items-center gap-3">
                         <Sheet open={mobileMenuOpen} onOpenChange={setMobileMenuOpen}>
                            <SheetTrigger asChild>
                              <Button variant="ghost" size="icon" className="lg:hidden text-white hover:bg-white/10 -ml-2">
                                  <Menu className="w-5 h-5" />
                              </Button>
                            </SheetTrigger>
                            <SheetContent side="left" className="w-[300px] p-0 border-r border-white/10 bg-zinc-950">
                                <VariantSidebar 
                                    product={product} 
                                    variants={variants} 
                                    options={options}
                                    activeVariantId={isCreate ? 'new' : variantId}
                                    productId={productId}
                                    className="h-full"
                                    onCloseMobile={() => setMobileMenuOpen(false)}
                                />
                            </SheetContent>
                         </Sheet>
                         <h1 className="text-xl font-bold text-white flex items-center gap-3">
                            {isCreate ? 'Add Variant' : formState.title || 'Untitled Variant'}
                            {!isCreate && formState.sku && (
                               <span className="text-sm font-normal text-zinc-500 bg-white/5 px-2 py-0.5 rounded border border-white/5">{formState.sku}</span>
                            )}
                         </h1>
                     </div>
                  </div>
                  
                  <div className="flex items-center gap-3">
                      {!isCreate && (
                          <Button 
                              variant="outline" 
                              className="border-red-900/50 text-red-500 hover:bg-red-500/10 hover:text-red-400" 
                              onClick={handleDelete} 
                              disabled={saving || deleting}
                          >
                              {deleting ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Trash2 className="w-4 h-4 mr-2" />}
                              Delete
                          </Button>
                      )}
                      <Button 
                          variant="ghost" 
                          onClick={() => navigate(`/admin/products/${productId}`)} 
                          disabled={saving || deleting}
                      >
                          <X className="w-4 h-4 mr-2" /> Cancel
                      </Button>
                      <Button 
                          className="bg-yellow-500 text-black hover:bg-yellow-400" 
                          onClick={handleSave} 
                          disabled={saving || deleting}
                      >
                          {saving ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Save className="w-4 h-4 mr-2" />}
                          Save Variant
                      </Button>
                  </div>
              </div>
          </div>

          <div className="p-6 max-w-7xl mx-auto w-full space-y-6">
              <VariantForm 
                formState={formState}
                onChange={setFormState}
                productImages={product?.images || []}
                options={options}
              />
          </div>
       </div>
    </div>
  );
}
