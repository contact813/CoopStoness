
import React, { useEffect, useState, useMemo, useCallback, useRef } from 'react';
import { Helmet } from 'react-helmet';
import { 
  Calendar as CalendarIcon, 
  RefreshCw, 
  Download, 
  Filter,
  Smartphone,
  Globe,
  Activity,
  MousePointerClick
} from 'lucide-react';
import { format, subDays, startOfYear } from 'date-fns';

import { supabase } from '@/lib/supabaseClient';
import { getDashboardData, aggregateDailyData, downloadCSV } from '@/lib/analyticsApi';
import { getAdminOrders } from '@/api/stripeApi';
import { cn } from "@/lib/utils";

// UI Components
import { Button } from "@/components/ui/button";
import { Calendar } from "@/components/ui/calendar";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

// Analytics Components
import KPISection from '@/components/admin/analytics/KPISection';
import TrendChart from '@/components/admin/analytics/TrendChart';
import RoundsAnalysis from '@/components/admin/analytics/RoundsAnalysis';
import SalesFunnel from '@/components/admin/analytics/FunnelChart'; 
import AlertsList from '@/components/admin/analytics/AlertsList';
import Insights from '@/components/admin/analytics/Insights';
import RecentOrders from '@/components/admin/analytics/RecentOrders';
import EmptyState from '@/components/admin/analytics/EmptyState';

const TrafficCards = ({ funnelData, metrics, conversion }) => {
  const visits = funnelData?.find(s => s.step === 'Visits')?.value || 0;
  
  if (!funnelData || funnelData.length === 0) {
     return <div className="h-[150px] bg-zinc-950 border border-zinc-800 rounded-xl"><EmptyState message="No traffic data available" /></div>;
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
      <Card className="bg-zinc-950 border-zinc-800 shadow-sm">
        <CardContent className="pt-6">
          <div className="flex items-center gap-2 mb-2">
            <Globe className="w-4 h-4 text-blue-500" />
            <span className="text-xs font-medium text-zinc-400 uppercase">Sessions</span>
          </div>
          <div className="text-2xl font-bold text-white">{visits.toLocaleString()}</div>
        </CardContent>
      </Card>
      
      <Card className="bg-zinc-950 border-zinc-800 shadow-sm">
        <CardContent className="pt-6">
           <div className="flex items-center gap-2 mb-2">
            <Activity className="w-4 h-4 text-purple-500" />
            <span className="text-xs font-medium text-zinc-400 uppercase">Active Users</span>
          </div>
          <div className="text-2xl font-bold text-white">{(metrics?.activeMembers || 0).toLocaleString()}</div>
        </CardContent>
      </Card>

      <Card className="bg-zinc-950 border-zinc-800 shadow-sm">
        <CardContent className="pt-6">
           <div className="flex items-center gap-2 mb-2">
            <MousePointerClick className="w-4 h-4 text-emerald-500" />
            <span className="text-xs font-medium text-zinc-400 uppercase">Conversion Rate</span>
          </div>
          <div className="text-2xl font-bold text-white">{conversion || '0%'}</div>
        </CardContent>
      </Card>

       <Card className="bg-zinc-950 border-zinc-800 shadow-sm">
        <CardContent className="pt-6">
           <div className="flex items-center gap-2 mb-2">
            <Smartphone className="w-4 h-4 text-yellow-500" />
            <span className="text-xs font-medium text-zinc-400 uppercase">Mobile Share</span>
          </div>
          <div className="text-2xl font-bold text-white">--</div> 
        </CardContent>
      </Card>
    </div>
  );
};

const DeviceChart = ({ deviceData }) => {
  const total = deviceData?.reduce((acc, curr) => acc + curr.visits, 0) || 1;

  return (
    <Card className="bg-zinc-950 border-zinc-800 h-full shadow-sm">
      <CardHeader>
        <CardTitle className="text-white flex items-center gap-2">
          <Smartphone className="text-zinc-400" size={20} />
          Device Distribution
        </CardTitle>
      </CardHeader>
      <CardContent className="h-[250px]">
        {(!deviceData || deviceData.length === 0) ? (
           <EmptyState message="No device data available" />
        ) : (
          <div className="space-y-4 pt-4">
            {deviceData.map((item, i) => {
              const pct = Math.round((item.visits / total) * 100);
              return (
                <div key={i} className="space-y-1">
                  <div className="flex justify-between text-sm">
                    <span className="text-zinc-300">{item.device || 'Unknown'}</span>
                    <span className="text-zinc-500">{pct}% ({item.visits})</span>
                  </div>
                  <div className="h-2 w-full bg-zinc-900 rounded-full overflow-hidden">
                    <div 
                      className="h-full bg-yellow-500 rounded-full" 
                      style={{ width: `${pct}%` }} 
                    />
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </CardContent>
    </Card>
  );
};

const HeatmapTable = ({ heatmapData }) => {
  const daysIso = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
  const maxOrders = heatmapData?.reduce((max, d) => Math.max(max, d.orders), 0) || 1;

  const getIntensity = (dayIsoIndex, hour) => {
    const entry = heatmapData?.find(d => d.day_of_week === (dayIsoIndex + 1) && d.hour_of_day === hour);
    const val = entry ? entry.orders : 0;
    const opacity = val / maxOrders;
    return { val, opacity };
  };

  return (
    <Card className="bg-zinc-950 border-zinc-800 h-full shadow-sm">
      <CardHeader>
        <CardTitle className="text-white flex items-center gap-2">
          <Activity className="text-zinc-400" size={20} />
          Order Heatmap
        </CardTitle>
      </CardHeader>
      <CardContent className="overflow-x-auto h-[250px] flex flex-col justify-center">
        {(!heatmapData || heatmapData.length === 0) ? (
            <EmptyState message="No heatmap data available" />
        ) : (
            <>
                <div className="min-w-[600px]">
                <div className="flex mb-2">
                    <div className="w-10"></div>
                    {Array.from({ length: 24 }).map((_, h) => (
                    <div key={h} className="flex-1 text-[10px] text-zinc-500 text-center">
                        {h % 3 === 0 ? h : ''}
                    </div>
                    ))}
                </div>
                {daysIso.map((day, dIdx) => (
                    <div key={day} className="flex items-center mb-1">
                    <div className="w-10 text-[10px] text-zinc-400 font-medium">{day}</div>
                    {Array.from({ length: 24 }).map((_, h) => {
                        const { val, opacity } = getIntensity(dIdx, h);
                        return (
                        <div 
                            key={h} 
                            className="flex-1 aspect-square mx-[1px] rounded-sm relative group"
                            style={{ 
                            backgroundColor: `rgba(234, 179, 8, ${Math.max(0.1, opacity)})`, 
                            opacity: val > 0 ? 1 : 0.1
                            }}
                        >
                            {val > 0 && (
                            <div className="hidden group-hover:block absolute bottom-full left-1/2 -translate-x-1/2 mb-1 z-10 bg-zinc-800 text-white text-[10px] px-1.5 py-0.5 rounded border border-zinc-700 whitespace-nowrap">
                                {val} orders
                            </div>
                            )}
                        </div>
                        );
                    })}
                    </div>
                ))}
                </div>
                <div className="mt-4 flex items-center justify-end gap-2 text-[10px] text-zinc-500">
                <span>Less</span>
                <div className="w-16 h-2 bg-gradient-to-r from-yellow-900/20 to-yellow-500 rounded-full"></div>
                <span>More</span>
                </div>
            </>
        )}
      </CardContent>
    </Card>
  );
};

export default function Dashboard() {
  const [dateRange, setDateRange] = useState({
    from: subDays(new Date(), 30),
    to: new Date()
  });
  const [vendorFilter, setVendorFilter] = useState("all");
  const [categoryFilter, setCategoryFilter] = useState("all");
  
  const [rawData, setRawData] = useState(null);
  const [recentOrders, setRecentOrders] = useState([]);
  
  const [isLoading, setIsLoading] = useState(true);
  const [isRefreshing, setIsRefreshing] = useState(false);

  const rtTimerRef = useRef(null);
  const rtCooldownRef = useRef(false);
  const rtPendingRef = useRef(false);
  const lastRefreshRef = useRef(Date.now());
  const rtCooldownTimerRef = useRef(null);
  const isMountedRef = useRef(false);

  useEffect(() => {
    isMountedRef.current = true;
    return () => {
      isMountedRef.current = false;
    };
  }, []);

  const calculateMetrics = useCallback((sales) => {
    if (!sales || sales.length === 0) {
      return { revenue: 0, items: 0, orders: 0, activeMembers: 0, activeSuppliers: 0, savings: 0, avgTicket: 0, avgDiscount: 0 };
    }
    const revenue = sales.reduce((sum, s) => sum + (Number(s.price_paid) * Number(s.qty)), 0);
    const items = sales.reduce((sum, s) => sum + Number(s.qty), 0);
    const uniqueOrders = new Set(sales.map(s => s.order_id)).size;
    const uniqueMembers = new Set(sales.map(s => s.user_id)).size;
    const uniqueSuppliers = new Set(sales.map(s => s.products?.vendor).filter(Boolean)).size;
    const savings = sales.reduce((sum, s) => {
      const retail = Number(s.products?.price || 0);
      const paid = Number(s.price_paid || 0);
      return sum + ((retail - paid) * Number(s.qty));
    }, 0);
    const avgTicket = uniqueOrders ? revenue / uniqueOrders : 0;
    const avgDiscount = (revenue + savings) > 0 ? (savings / (revenue + savings)) * 100 : 0;
    return { revenue, items, orders: uniqueOrders, activeMembers: uniqueMembers, activeSuppliers: uniqueSuppliers, savings, avgTicket, avgDiscount };
  }, []);

  const refreshData = useCallback(async () => {
    if (!isMountedRef.current) return;
    if (!dateRange.from || !dateRange.to) return;
    setIsRefreshing(true);
    try {
      const analyticsData = await getDashboardData(dateRange.from.toISOString(), dateRange.to.toISOString());
      if (isMountedRef.current) setRawData(analyticsData);
      const { orders } = await getAdminOrders({ page: 1, perPage: 5 });
      if (isMountedRef.current) setRecentOrders(orders || []);
      lastRefreshRef.current = Date.now();
    } catch (error) {
      console.error("Dashboard refresh error:", error);
    } finally {
      if (isMountedRef.current) {
        setIsRefreshing(false);
        setIsLoading(false);
      }
    }
  }, [dateRange]);

  const scheduleRealtimeRefresh = useCallback(() => {
    if (rtTimerRef.current) clearTimeout(rtTimerRef.current);
    rtTimerRef.current = setTimeout(() => {
      if (!isMountedRef.current) return;
      if (rtCooldownRef.current) {
        rtPendingRef.current = true;
        return;
      }
      refreshData();
      rtCooldownRef.current = true;
      if (rtCooldownTimerRef.current) clearTimeout(rtCooldownTimerRef.current);
      rtCooldownTimerRef.current = setTimeout(() => {
        if (!isMountedRef.current) return;
        rtCooldownRef.current = false;
        if (rtPendingRef.current) {
          rtPendingRef.current = false;
          scheduleRealtimeRefresh();
        }
      }, 5000);
    }, 800);
  }, [refreshData]);

  useEffect(() => {
    const handler = setTimeout(refreshData, 800);
    return () => clearTimeout(handler);
  }, [refreshData]); 

  useEffect(() => {
    const channel = supabase.channel('dashboard-realtime')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'sales_events' }, () => scheduleRealtimeRefresh())
      .on('postgres_changes', { event: '*', schema: 'public', table: 'orders' }, () => scheduleRealtimeRefresh())
      .on('postgres_changes', { event: '*', schema: 'public', table: 'products' }, () => scheduleRealtimeRefresh())
      .subscribe();
    return () => {
      supabase.removeChannel(channel);
      if (rtTimerRef.current) clearTimeout(rtTimerRef.current);
      if (rtCooldownTimerRef.current) clearTimeout(rtCooldownTimerRef.current);
    };
  }, [scheduleRealtimeRefresh]);

  const filteredData = useMemo(() => {
    if (!rawData) return null;
    let current = rawData.currentSales || [];
    let prev = rawData.prevSales || [];
    if (vendorFilter !== 'all') {
      const filterFn = (s) => s.products?.vendor === vendorFilter;
      current = current.filter(filterFn);
      prev = prev.filter(filterFn);
    }
    if (categoryFilter !== 'all') {
      const filterFn = (s) => s.products?.type === categoryFilter;
      current = current.filter(filterFn);
      prev = prev.filter(filterFn);
    }
    return { currentSales: current, prevSales: prev, funnel: rawData.funnel, heatmap: rawData.heatmap, lowStock: rawData.lowStock, traffic: rawData.traffic, devices: rawData.devices };
  }, [rawData, vendorFilter, categoryFilter]);

  const { vendors, categories } = useMemo(() => {
    if (!rawData?.currentSales) return { vendors: [], categories: [] };
    const v = new Set();
    const c = new Set();
    rawData.currentSales.forEach(s => {
      if (s.products?.vendor) v.add(s.products.vendor);
      if (s.products?.type) c.add(s.products.type);
    });
    return { vendors: Array.from(v).sort(), categories: Array.from(c).sort() };
  }, [rawData]);

  const metrics = useMemo(() => calculateMetrics(filteredData?.currentSales), [filteredData, calculateMetrics]);
  const prevMetrics = useMemo(() => calculateMetrics(filteredData?.prevSales), [filteredData, calculateMetrics]);

  const trendData = useMemo(() => {
    if (!filteredData) return { current: [], prev: [] };
    return { current: aggregateDailyData(filteredData.currentSales), prev: aggregateDailyData(filteredData.prevSales) };
  }, [filteredData]);

  const categoryPieData = useMemo(() => {
    if (!filteredData?.currentSales) return [];
    const map = {};
    filteredData.currentSales.forEach(s => {
      const cat = s.products?.type || 'Uncategorized';
      map[cat] = (map[cat] || 0) + (s.price_paid * s.qty);
    });
    return Object.entries(map).map(([name, value]) => ({ name, value }));
  }, [filteredData]);

  const roundsData = useMemo(() => {
    if (!filteredData?.currentSales) return [];
    const roundsMap = {};
    filteredData.currentSales.forEach(s => {
      if (!s.round_id) return;
      if (!roundsMap[s.round_id]) {
        roundsMap[s.round_id] = { id: s.round_id, title: s.rounds?.title || 'Unknown Round', status: s.rounds?.status || 'active', orders: new Set(), revenue: 0, savings: 0 };
      }
      const r = roundsMap[s.round_id];
      r.orders.add(s.order_id);
      r.revenue += (s.price_paid * s.qty);
      const retail = s.products?.price || 0;
      r.savings += ((retail - s.price_paid) * s.qty);
    });
    return Object.values(roundsMap).map(r => ({ ...r, orders: r.orders.size }));
  }, [filteredData]);

  const insightsData = useMemo(() => {
    if (!trendData.current.length) return { bestDay: null, topCategory: null, conversion: '0%' };
    const bestDayObj = [...trendData.current].sort((a,b) => b.revenue - a.revenue)[0];
    const bestDay = bestDayObj ? format(new Date(bestDayObj.day), 'MMM dd') : null;
    const topCatObj = [...categoryPieData].sort((a,b) => b.value - a.value)[0];
    const topCategory = topCatObj ? topCatObj.name : null;
    const visits = filteredData?.funnel?.find(s => s.step === 'Visits')?.value || 0;
    const purchases = filteredData?.funnel?.find(s => s.step === 'Purchases')?.value || 0;
    const conversion = visits > 0 ? ((purchases / visits) * 100).toFixed(1) + '%' : '0%';
    return { bestDay, topCategory, conversion };
  }, [trendData, categoryPieData, filteredData]);

  const applyPreset = (days) => {
    if (days === 'ytd') {
      setDateRange({ from: startOfYear(new Date()), to: new Date() });
    } else {
      setDateRange({ from: subDays(new Date(), days), to: new Date() });
    }
  };

  return (
    <div className="space-y-6">
      <Helmet>
        <title>Dashboard - Coop Stones Admin</title>
      </Helmet>

      {/* Title & Global Controls */}
      <div className="flex flex-col xl:flex-row gap-4 items-start xl:items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-white tracking-tight">Dashboard</h1>
          <p className="text-zinc-400 mt-1">
             Real-time performance metrics and sales analytics.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2 w-full xl:w-auto">
          <div className="flex items-center bg-zinc-900 rounded-md border border-zinc-800 p-1">
            <Button variant="ghost" size="sm" onClick={() => applyPreset(7)} className="h-7 text-xs hover:bg-zinc-800 text-zinc-400 hover:text-white">7D</Button>
            <Separator orientation="vertical" className="h-4 mx-1 bg-zinc-800" />
            <Button variant="ghost" size="sm" onClick={() => applyPreset(30)} className="h-7 text-xs hover:bg-zinc-800 text-zinc-400 hover:text-white">30D</Button>
            <Separator orientation="vertical" className="h-4 mx-1 bg-zinc-800" />
            <Button variant="ghost" size="sm" onClick={() => applyPreset('ytd')} className="h-7 text-xs hover:bg-zinc-800 text-zinc-400 hover:text-white">YTD</Button>
          </div>

          <Popover>
            <PopoverTrigger asChild>
              <Button variant={"outline"} className={cn("w-[240px] justify-start text-left font-normal border-zinc-800 bg-zinc-900 hover:bg-zinc-800 text-zinc-300", !dateRange && "text-muted-foreground")}>
                <CalendarIcon className="mr-2 h-4 w-4" />
                {dateRange?.from ? (dateRange.to ? <>{format(dateRange.from, "LLL dd, y")} - {format(dateRange.to, "LLL dd, y")}</> : format(dateRange.from, "LLL dd, y")) : <span>Pick a date</span>}
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-auto p-0 bg-zinc-900 border-zinc-800" align="end">
              <Calendar initialFocus mode="range" defaultMonth={dateRange?.from} selected={dateRange} onSelect={setDateRange} numberOfMonths={2} className="bg-zinc-950 text-white" />
            </PopoverContent>
          </Popover>

          <Button variant="outline" size="icon" onClick={refreshData} disabled={isRefreshing} className="border-zinc-800 bg-zinc-900 hover:bg-zinc-800 text-zinc-400">
            <RefreshCw className={cn("h-4 w-4", isRefreshing && "animate-spin")} />
          </Button>
          <Button variant="outline" size="icon" onClick={() => downloadCSV(filteredData?.currentSales, 'sales-export.csv')} className="border-zinc-800 bg-zinc-900 hover:bg-zinc-800 text-zinc-400">
            <Download className="h-4 w-4" />
          </Button>
        </div>
      </div>

      {/* Quick Insights Row */}
      <Insights 
        bestDay={insightsData.bestDay} 
        topCategory={insightsData.topCategory} 
        conversion={insightsData.conversion} 
      />
      
      {/* Filtering Row */}
      <div className="flex flex-wrap gap-4 items-center bg-zinc-900/30 p-3 rounded-xl border border-zinc-800/50">
        <div className="flex items-center gap-2 text-sm text-zinc-500">
            <Filter size={14} />
            <span className="font-medium">Filters:</span>
        </div>
        
        <Select value={vendorFilter} onValueChange={setVendorFilter}>
            <SelectTrigger className="w-[180px] h-8 text-xs bg-zinc-950 border-zinc-800 focus:ring-0">
                <SelectValue placeholder="All Vendors" />
            </SelectTrigger>
            <SelectContent>
                <SelectItem value="all">All Vendors</SelectItem>
                {vendors.map(v => <SelectItem key={v} value={v}>{v}</SelectItem>)}
            </SelectContent>
        </Select>

        <Select value={categoryFilter} onValueChange={setCategoryFilter}>
            <SelectTrigger className="w-[180px] h-8 text-xs bg-zinc-950 border-zinc-800 focus:ring-0">
                <SelectValue placeholder="All Categories" />
            </SelectTrigger>
            <SelectContent>
                <SelectItem value="all">All Categories</SelectItem>
                {categories.map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)}
            </SelectContent>
        </Select>

        {(vendorFilter !== 'all' || categoryFilter !== 'all') && (
            <Button variant="ghost" size="sm" className="h-8 text-xs text-red-400 hover:text-red-300 hover:bg-red-950/20" onClick={() => { setVendorFilter('all'); setCategoryFilter('all'); }}>Clear Filters</Button>
        )}
      </div>

      <TrafficCards funnelData={filteredData?.funnel} metrics={metrics} conversion={insightsData.conversion} />
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <HeatmapTable heatmapData={filteredData?.heatmap} />
        <DeviceChart deviceData={filteredData?.devices} />
      </div>

      <KPISection currentMetrics={metrics} prevMetrics={prevMetrics} isLoading={isLoading} />

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-3">
            <TrendChart currentData={trendData.current} prevData={trendData.prev} isLoading={isLoading} />
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
            <RoundsAnalysis roundsData={roundsData} isLoading={isLoading} />
        </div>
        <div className="space-y-6">
             <AlertsList lowStock={filteredData?.lowStock} isLoading={isLoading} />
             <SalesFunnel data={filteredData?.funnel || []} isLoading={isLoading} />
             <RecentOrders orders={recentOrders} isLoading={isLoading} />
        </div>
      </div>
    </div>
  );
}
