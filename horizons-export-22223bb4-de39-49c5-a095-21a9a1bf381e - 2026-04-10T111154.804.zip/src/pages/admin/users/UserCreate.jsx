import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { adminCreateUser } from "@/api/adminUsers";
import { ArrowLeft, Save, Loader2, AlertTriangle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { useToast } from "@/components/ui/use-toast";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";

export default function UserCreate() {
  const navigate = useNavigate();
  const { toast } = useToast();
  
  const [saving, setSaving] = useState(false);
  
  const [formData, setFormData] = useState({
      email: '',
      full_name: '',
      phone: '',
      company_name: '',
      address_street: '',
      address_city: '',
      address_state: '',
      address_zip: '',
      role: 'member',
      membership_tier: 'Standard',
      membership_status: 'active'
  });

  const handleChange = (e) => {
      const { name, value } = e.target;
      setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSelectChange = (name, value) => {
      setFormData(prev => ({ ...prev, [name]: value }));
  }

  const handleSubmit = async (e) => {
      e.preventDefault();
      setSaving(true);
      try {
          await adminCreateUser(formData);
          toast({ title: "User Created", description: "New user has been added successfully." });
          navigate("/admin/users");
      } catch (error) {
          console.error(error);
          toast({ 
              variant: "destructive", 
              title: "Creation Failed", 
              description: error.message || "Ensure the admin-user-actions edge function is deployed." 
          });
      } finally {
          setSaving(false);
      }
  };

  return (
      <div className="max-w-3xl mx-auto p-6">
          <div className="flex items-center justify-between mb-8">
            <div className="flex items-center gap-4">
                <Link to="/admin/users">
                    <Button variant="ghost" size="icon"><ArrowLeft size={20}/></Button>
                </Link>
                <h1 className="text-2xl font-bold text-white">Create New User</h1>
            </div>
          </div>
        
          <Alert className="mb-6 border-yellow-500/50 bg-yellow-500/10 text-yellow-200">
              <AlertTriangle className="h-4 w-4" />
              <AlertTitle>Admin Creation</AlertTitle>
              <AlertDescription>
                  This action uses a secure Edge Function to create the user in Auth and automatically generate their profile.
                  A temporary password will be assigned.
              </AlertDescription>
          </Alert>

          <form onSubmit={handleSubmit} className="space-y-8 bg-zinc-900/50 p-6 rounded-xl border border-zinc-800">
              {/* Account Info */}
              <div className="space-y-4">
                  <h3 className="text-lg font-medium text-white border-b border-zinc-800 pb-2">Account Information</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                          <Label htmlFor="email">Email Address</Label>
                          <Input id="email" name="email" type="email" value={formData.email} onChange={handleChange} required placeholder="user@example.com" />
                      </div>
                      <div className="space-y-2">
                          <Label htmlFor="full_name">Full Name</Label>
                          <Input id="full_name" name="full_name" value={formData.full_name} onChange={handleChange} required placeholder="John Doe" />
                      </div>
                  </div>
              </div>

              {/* Personal Info */}
              <div className="space-y-4">
                  <h3 className="text-lg font-medium text-white border-b border-zinc-800 pb-2">Contact Details</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                          <Label htmlFor="phone">Phone</Label>
                          <Input id="phone" name="phone" value={formData.phone} onChange={handleChange} placeholder="+1 (555) 000-0000" />
                      </div>
                      <div className="space-y-2">
                          <Label htmlFor="company_name">Company Name</Label>
                          <Input id="company_name" name="company_name" value={formData.company_name} onChange={handleChange} placeholder="Acme Stone Co." />
                      </div>
                  </div>
              </div>

              {/* Address */}
              <div className="space-y-4">
                  <h3 className="text-lg font-medium text-white border-b border-zinc-800 pb-2">Address</h3>
                  <div className="space-y-2">
                      <Label htmlFor="address_street">Street Address</Label>
                      <Input id="address_street" name="address_street" value={formData.address_street} onChange={handleChange} />
                  </div>
                  <div className="grid grid-cols-3 gap-4">
                      <div className="space-y-2">
                          <Label htmlFor="address_city">City</Label>
                          <Input id="address_city" name="address_city" value={formData.address_city} onChange={handleChange} />
                      </div>
                      <div className="space-y-2">
                          <Label htmlFor="address_state">State</Label>
                          <Input id="address_state" name="address_state" value={formData.address_state} onChange={handleChange} />
                      </div>
                      <div className="space-y-2">
                          <Label htmlFor="address_zip">ZIP Code</Label>
                          <Input id="address_zip" name="address_zip" value={formData.address_zip} onChange={handleChange} />
                      </div>
                  </div>
              </div>

              {/* Status & Role */}
              <div className="space-y-4">
                  <h3 className="text-lg font-medium text-white border-b border-zinc-800 pb-2">Status & Role</h3>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <div className="space-y-2">
                          <Label>Role</Label>
                          <Select value={formData.role} onValueChange={(v) => handleSelectChange('role', v)}>
                              <SelectTrigger><SelectValue /></SelectTrigger>
                              <SelectContent>
                                  <SelectItem value="member">Member</SelectItem>
                                  <SelectItem value="admin">Admin</SelectItem>
                              </SelectContent>
                          </Select>
                      </div>
                      <div className="space-y-2">
                          <Label>Membership Tier</Label>
                          <Select value={formData.membership_tier} onValueChange={(v) => handleSelectChange('membership_tier', v)}>
                              <SelectTrigger><SelectValue /></SelectTrigger>
                              <SelectContent>
                                  <SelectItem value="Standard">Standard</SelectItem>
                                  <SelectItem value="Premium">Premium</SelectItem>
                                  <SelectItem value="Elite">Elite</SelectItem>
                              </SelectContent>
                          </Select>
                      </div>
                      <div className="space-y-2">
                          <Label>Status</Label>
                          <Select value={formData.membership_status} onValueChange={(v) => handleSelectChange('membership_status', v)}>
                              <SelectTrigger><SelectValue /></SelectTrigger>
                              <SelectContent>
                                  <SelectItem value="active">Active</SelectItem>
                                  <SelectItem value="late">Late</SelectItem>
                                  <SelectItem value="suspended">Suspended</SelectItem>
                                  <SelectItem value="canceled">Canceled</SelectItem>
                              </SelectContent>
                          </Select>
                      </div>
                  </div>
              </div>

              <div className="flex justify-end gap-4 pt-4">
                  <Link to="/admin/users">
                      <Button type="button" variant="ghost">Cancel</Button>
                  </Link>
                  <Button type="submit" disabled={saving} className="bg-yellow-500 text-black hover:bg-yellow-400">
                      {saving ? <Loader2 className="animate-spin mr-2" size={16}/> : <Save className="mr-2" size={16}/>}
                      Create User
                  </Button>
              </div>
          </form>
      </div>
  );
}