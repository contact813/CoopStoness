import React, { useEffect, useState } from "react";
import { useParams, Link, useNavigate } from "react-router-dom";
import { adminGetUserDetails, adminUpdateUser } from "@/api/adminUsers";
import { ArrowLeft, Save, Loader2, AlertCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { useToast } from "@/components/ui/use-toast";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";

export default function UserEdit() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { toast } = useToast();
  
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState(null);
  
  const [formData, setFormData] = useState({
      full_name: '',
      phone: '',
      company_name: '',
      address_street: '',
      address_city: '',
      address_state: '',
      address_zip: '',
      role: 'member',
      membership_tier: 'Standard',
      membership_status: 'active'
  });

  useEffect(() => {
      async function load() {
          setLoading(true);
          setError(null);
          try {
              const result = await adminGetUserDetails(id);
              if (!result || !result.profile) {
                  throw new Error("User not found");
              }
              const { profile } = result;
              setFormData({
                  full_name: profile.full_name || profile.name || '',
                  phone: profile.phone || '',
                  company_name: profile.company_name || '',
                  address_street: profile.address_street || '',
                  address_city: profile.address_city || '',
                  address_state: profile.address_state || '',
                  address_zip: profile.address_zip || '',
                  role: profile.role || 'member',
                  membership_tier: profile.membership_tier || 'Standard',
                  membership_status: profile.membership_status || 'active'
              });
          } catch (e) {
              console.error("Load error:", e);
              setError(e.message || "Could not load user.");
              toast({ variant: "destructive", title: "Error", description: "Could not load user." });
          } finally {
              setLoading(false);
          }
      }
      load();
  }, [id, toast]);

  const handleChange = (e) => {
      const { name, value } = e.target;
      setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSelectChange = (name, value) => {
      setFormData(prev => ({ ...prev, [name]: value }));
  }

  const handleSubmit = async (e) => {
      e.preventDefault();
      setSaving(true);
      try {
          // Mapping full_name to both fields if schema is inconsistent
          const updates = {
              ...formData,
              name: formData.full_name 
          };
          await adminUpdateUser(id, updates);
          toast({ title: "Saved", description: "User profile updated successfully." });
          navigate("/admin/users");
      } catch (error) {
          toast({ variant: "destructive", title: "Error", description: error.message });
      } finally {
          setSaving(false);
      }
  };

  if (loading) return <div className="p-10 text-center"><Loader2 className="animate-spin mx-auto text-yellow-500"/></div>;

  if (error) {
      return (
          <div className="p-6 max-w-3xl mx-auto">
              <Alert variant="destructive" className="bg-red-900/20 border-red-900 text-red-200">
                  <AlertCircle className="h-4 w-4" />
                  <AlertTitle>Error</AlertTitle>
                  <AlertDescription className="flex flex-col gap-4 mt-2">
                      <p>{error}</p>
                      <div className="flex gap-2">
                          <Button variant="outline" size="sm" onClick={() => navigate("/admin/users")} className="border-red-800 hover:bg-red-900/50">
                              <ArrowLeft className="mr-2 h-3 w-3" /> Back to Users
                          </Button>
                      </div>
                  </AlertDescription>
              </Alert>
          </div>
      );
  }

  return (
      <div className="max-w-3xl mx-auto p-6">
          <div className="flex items-center justify-between mb-8">
            <div className="flex items-center gap-4">
                <Link to="/admin/users">
                    <Button variant="ghost" size="icon"><ArrowLeft size={20}/></Button>
                </Link>
                <h1 className="text-2xl font-bold text-white">Edit User Profile</h1>
            </div>
          </div>

          <form onSubmit={handleSubmit} className="space-y-8 bg-zinc-900/50 p-6 rounded-xl border border-zinc-800">
              {/* Personal Info */}
              <div className="space-y-4">
                  <h3 className="text-lg font-medium text-white border-b border-zinc-800 pb-2">Personal Information</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                          <Label htmlFor="full_name">Full Name</Label>
                          <Input id="full_name" name="full_name" value={formData.full_name} onChange={handleChange} required />
                      </div>
                      <div className="space-y-2">
                          <Label htmlFor="phone">Phone</Label>
                          <Input id="phone" name="phone" value={formData.phone} onChange={handleChange} />
                      </div>
                      <div className="space-y-2 md:col-span-2">
                          <Label htmlFor="company_name">Company Name</Label>
                          <Input id="company_name" name="company_name" value={formData.company_name} onChange={handleChange} />
                      </div>
                  </div>
              </div>

              {/* Address */}
              <div className="space-y-4">
                  <h3 className="text-lg font-medium text-white border-b border-zinc-800 pb-2">Address</h3>
                  <div className="space-y-2">
                      <Label htmlFor="address_street">Street Address</Label>
                      <Input id="address_street" name="address_street" value={formData.address_street} onChange={handleChange} />
                  </div>
                  <div className="grid grid-cols-3 gap-4">
                      <div className="space-y-2">
                          <Label htmlFor="address_city">City</Label>
                          <Input id="address_city" name="address_city" value={formData.address_city} onChange={handleChange} />
                      </div>
                      <div className="space-y-2">
                          <Label htmlFor="address_state">State</Label>
                          <Input id="address_state" name="address_state" value={formData.address_state} onChange={handleChange} />
                      </div>
                      <div className="space-y-2">
                          <Label htmlFor="address_zip">ZIP Code</Label>
                          <Input id="address_zip" name="address_zip" value={formData.address_zip} onChange={handleChange} />
                      </div>
                  </div>
              </div>

              {/* Status & Role */}
              <div className="space-y-4">
                  <h3 className="text-lg font-medium text-white border-b border-zinc-800 pb-2">Status & Role</h3>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <div className="space-y-2">
                          <Label>Role</Label>
                          <Select value={formData.role} onValueChange={(v) => handleSelectChange('role', v)}>
                              <SelectTrigger><SelectValue /></SelectTrigger>
                              <SelectContent>
                                  <SelectItem value="member">Member</SelectItem>
                                  <SelectItem value="admin">Admin</SelectItem>
                              </SelectContent>
                          </Select>
                      </div>
                      <div className="space-y-2">
                          <Label>Membership Tier</Label>
                          <Select value={formData.membership_tier} onValueChange={(v) => handleSelectChange('membership_tier', v)}>
                              <SelectTrigger><SelectValue /></SelectTrigger>
                              <SelectContent>
                                  <SelectItem value="Standard">Standard</SelectItem>
                                  <SelectItem value="Premium">Premium</SelectItem>
                                  <SelectItem value="Elite">Elite</SelectItem>
                              </SelectContent>
                          </Select>
                      </div>
                      <div className="space-y-2">
                          <Label>Status</Label>
                          <Select value={formData.membership_status} onValueChange={(v) => handleSelectChange('membership_status', v)}>
                              <SelectTrigger><SelectValue /></SelectTrigger>
                              <SelectContent>
                                  <SelectItem value="active">Active</SelectItem>
                                  <SelectItem value="late">Late</SelectItem>
                                  <SelectItem value="suspended">Suspended</SelectItem>
                                  <SelectItem value="canceled">Canceled</SelectItem>
                              </SelectContent>
                          </Select>
                      </div>
                  </div>
              </div>

              <div className="flex justify-end gap-4 pt-4">
                  <Link to="/admin/users">
                      <Button type="button" variant="ghost">Cancel</Button>
                  </Link>
                  <Button type="submit" disabled={saving} className="bg-yellow-500 text-black hover:bg-yellow-400">
                      {saving ? <Loader2 className="animate-spin mr-2" size={16}/> : <Save className="mr-2" size={16}/>}
                      Save Changes
                  </Button>
              </div>
          </form>
      </div>
  );
}