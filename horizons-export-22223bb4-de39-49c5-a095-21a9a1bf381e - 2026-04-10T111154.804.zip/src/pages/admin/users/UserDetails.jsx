import React, { useEffect, useState } from "react";
import { useParams, Link, useNavigate } from "react-router-dom";
import { adminGetUserDetails, adminDeleteUser } from "@/api/adminUsers";
import { 
    ArrowLeft, Mail, Phone, Building2, MapPin, Calendar, DollarSign, 
    TrendingUp, Package, Edit, Trash2, Crown, BadgeCheck, Shield, AlertCircle
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useToast } from "@/components/ui/use-toast";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import {
    AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, 
    AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger
} from "@/components/ui/alert-dialog";

export default function UserDetails() {
    const { id } = useParams();
    const navigate = useNavigate();
    const { toast } = useToast();
    const [data, setData] = useState(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);

    useEffect(() => {
        loadData();
    }, [id]);

    async function loadData() {
        setLoading(true);
        setError(null);
        try {
            const result = await adminGetUserDetails(id);
            if (!result || !result.profile) {
                throw new Error("User not found");
            }
            setData(result);
        } catch (error) {
            console.error("Failed to load user details", error);
            setError(error.message || "Could not load user details.");
        } finally {
            setLoading(false);
        }
    }

    // --- Helpers for Date Formatting ---
    const getContractEndDate = (createdAt) => {
        if (!createdAt) return null;
        const date = new Date(createdAt);
        date.setFullYear(date.getFullYear() + 1);
        return date;
    };

    const formatDate = (date) => {
        if (!date) return "—";
        return new Date(date).toLocaleDateString("en-US", {
            year: 'numeric',
            month: 'long',
            day: 'numeric'
        });
    };

    const handleDelete = async () => {
        try {
            const result = await adminDeleteUser(id);
            
            if (result && result.success === true) {
                toast({ title: "Success", description: "User deleted successfully." });
                navigate("/admin/users");
            } else {
                throw new Error("Delete failed");
            }
        } catch (error) {
            toast({ variant: "destructive", title: "Error", description: error.message || "Failed to delete user" });
        }
    };

    if (loading) return <div className="p-8 text-center text-zinc-500">Loading user data...</div>;
    
    if (error) {
        return (
            <div className="p-6 max-w-6xl mx-auto">
                <Alert variant="destructive" className="bg-red-900/20 border-red-900 text-red-200">
                    <AlertCircle className="h-4 w-4" />
                    <AlertTitle>Error</AlertTitle>
                    <AlertDescription className="flex flex-col gap-4 mt-2">
                        <p>{error}</p>
                        <div className="flex gap-2">
                            <Button variant="outline" size="sm" onClick={() => navigate("/admin/users")} className="border-red-800 hover:bg-red-900/50">
                                <ArrowLeft className="mr-2 h-3 w-3" /> Back to Users
                            </Button>
                        </div>
                    </AlertDescription>
                </Alert>
            </div>
        );
    }

    if (!data || !data.profile) return null;

    const { profile, stats } = data;

    return (
        <div className="p-6 max-w-6xl mx-auto space-y-8">
            {/* Header */}
            <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                    <Link to="/admin/users">
                        <Button variant="outline" size="icon" className="rounded-full border-zinc-700 bg-zinc-900 hover:bg-zinc-800">
                            <ArrowLeft size={20} />
                        </Button>
                    </Link>
                    <div>
                        <h1 className="text-3xl font-bold text-white">{profile.full_name || profile.name}</h1>
                        <div className="flex items-center gap-2 text-sm text-zinc-400 mt-1">
                            <span className="font-mono text-xs bg-zinc-800 px-1.5 py-0.5 rounded">{profile.id}</span>
                            <span className="w-1 h-1 rounded-full bg-zinc-600"></span>
                            <span>Joined {new Date(profile.created_at).toLocaleDateString()}</span>
                        </div>
                    </div>
                </div>
                <div className="flex gap-2">
                    <Link to={`/admin/users/edit/${id}`}>
                        <Button variant="outline" className="border-zinc-700 hover:bg-zinc-800">
                            <Edit size={16} className="mr-2"/> Edit User
                        </Button>
                    </Link>
                    
                    <AlertDialog>
                        <AlertDialogTrigger asChild>
                            <Button variant="destructive" className="bg-red-900/50 hover:bg-red-900 text-red-200 border border-red-900">
                                <Trash2 size={16} className="mr-2"/> Delete
                            </Button>
                        </AlertDialogTrigger>
                        <AlertDialogContent className="bg-zinc-950 border-zinc-800">
                            <AlertDialogHeader>
                                <AlertDialogTitle>Confirm Deletion</AlertDialogTitle>
                                <AlertDialogDescription>
                                    Are you sure you want to delete this user? This action cannot be undone.
                                </AlertDialogDescription>
                            </AlertDialogHeader>
                            <AlertDialogFooter>
                                <AlertDialogCancel className="bg-transparent border-zinc-700 text-white hover:bg-zinc-800">Cancel</AlertDialogCancel>
                                <AlertDialogAction onClick={handleDelete} className="bg-red-600 hover:bg-red-700">Delete</AlertDialogAction>
                            </AlertDialogFooter>
                        </AlertDialogContent>
                    </AlertDialog>
                </div>
            </div>

            <div className="grid gap-6 lg:grid-cols-3">
                {/* Panel 1: Personal Data */}
                <Card className="bg-zinc-900/50 border-zinc-800">
                    <CardHeader>
                        <CardTitle className="flex items-center gap-2 text-white">
                            <Building2 className="text-yellow-500" size={20} />
                            Personal Information
                        </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                        <div className="grid grid-cols-[24px_1fr] gap-3">
                            <Mail className="text-zinc-500 mt-1" size={16} />
                            <div>
                                <p className="text-xs text-zinc-500 uppercase tracking-wider font-bold">Email</p>
                                <p className="text-zinc-200">{profile.email}</p>
                            </div>
                        </div>
                        <div className="grid grid-cols-[24px_1fr] gap-3">
                            <Phone className="text-zinc-500 mt-1" size={16} />
                            <div>
                                <p className="text-xs text-zinc-500 uppercase tracking-wider font-bold">Phone</p>
                                <p className="text-zinc-200">{profile.phone || "—"}</p>
                            </div>
                        </div>
                        <div className="grid grid-cols-[24px_1fr] gap-3">
                            <Building2 className="text-zinc-500 mt-1" size={16} />
                            <div>
                                <p className="text-xs text-zinc-500 uppercase tracking-wider font-bold">Company</p>
                                <p className="text-zinc-200">{profile.company_name || "—"}</p>
                            </div>
                        </div>
                        <div className="grid grid-cols-[24px_1fr] gap-3">
                            <MapPin className="text-zinc-500 mt-1" size={16} />
                            <div>
                                <p className="text-xs text-zinc-500 uppercase tracking-wider font-bold">Address</p>
                                <p className="text-zinc-200">{profile.address_street || "—"}</p>
                                <p className="text-zinc-200">
                                    {profile.address_city}{profile.address_state ? `, ${profile.address_state}` : ''} {profile.address_zip}
                                </p>
                            </div>
                        </div>
                    </CardContent>
                </Card>

                {/* Panel 2: Membership Status */}
                <Card className="bg-zinc-900/50 border-zinc-800">
                    <CardHeader>
                        <CardTitle className="flex items-center gap-2 text-white">
                            <Crown className="text-amber-500" size={20} />
                            Membership
                        </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-6">
                        <div className="grid grid-cols-2 gap-4">
                            <div className="p-3 bg-zinc-950 rounded-lg border border-zinc-800">
                                <p className="text-xs text-zinc-500 mb-1">Current Tier</p>
                                <div className="flex items-center gap-2 font-bold text-amber-400">
                                    <Crown size={14} /> {profile.membership_tier || 'Standard'}
                                </div>
                            </div>
                            <div className="p-3 bg-zinc-950 rounded-lg border border-zinc-800">
                                <p className="text-xs text-zinc-500 mb-1">Status</p>
                                <div className="flex items-center gap-2 font-bold text-emerald-400 capitalize">
                                    <BadgeCheck size={14} /> {profile.membership_status || 'Active'}
                                </div>
                            </div>
                        </div>

                        <div className="space-y-2">
                            <div className="flex justify-between text-sm border-b border-zinc-800 pb-2">
                                <span className="text-zinc-400">Role</span>
                                <span className="text-white capitalize flex items-center gap-1"><Shield size={12}/> {profile.role || 'Member'}</span>
                            </div>
                            <div className="flex justify-between text-sm border-b border-zinc-800 pb-2">
                                <span className="text-zinc-400">Start Date</span>
                                <span className="text-white">{new Date(profile.created_at).toLocaleDateString()}</span>
                            </div>
                            <div className="flex justify-between text-sm border-b border-zinc-800 pb-2">
                                <span className="text-zinc-400">Contract End</span>
                                <span className="text-white">{formatDate(getContractEndDate(profile.created_at))}</span>
                            </div>
                        </div>
                    </CardContent>
                </Card>

                {/* Panel 3: Financials */}
                <Card className="bg-zinc-900/50 border-zinc-800">
                    <CardHeader>
                        <CardTitle className="flex items-center gap-2 text-white">
                            <TrendingUp className="text-emerald-500" size={20} />
                            Financial Overview
                        </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-6">
                         <div className="grid grid-cols-2 gap-4">
                             <div className="space-y-1">
                                 <p className="text-xs text-zinc-500">Total Spent</p>
                                 <p className="text-2xl font-bold text-white flex items-baseline">
                                    <span className="text-sm text-zinc-500 mr-1">$</span>
                                    {stats.total_spent.toLocaleString()}
                                 </p>
                             </div>
                             <div className="space-y-1">
                                 <p className="text-xs text-zinc-500">Est. Savings</p>
                                 <p className="text-2xl font-bold text-emerald-400 flex items-baseline">
                                    <span className="text-sm text-emerald-600 mr-1">$</span>
                                    {stats.estimated_savings.toLocaleString()}
                                 </p>
                             </div>
                         </div>

                         <div className="p-4 bg-zinc-950/50 rounded-lg border border-zinc-800 flex items-center justify-between">
                            <div className="flex items-center gap-3">
                                <div className="w-8 h-8 rounded-full bg-blue-500/10 flex items-center justify-center text-blue-500">
                                    <Package size={16} />
                                </div>
                                <span className="text-sm text-zinc-300">Total Orders</span>
                            </div>
                            <span className="font-bold text-white">{stats.total_orders_count}</span>
                         </div>
                    </CardContent>
                </Card>
            </div>
        </div>
    );
}