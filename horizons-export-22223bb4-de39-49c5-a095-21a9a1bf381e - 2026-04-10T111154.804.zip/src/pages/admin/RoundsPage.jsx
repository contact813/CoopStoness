
import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { getAllRounds, reorderRounds, normalizeRoundsOrder } from '@/lib/roundsApi';
import { Loader2, AlertCircle, Plus, ArrowUp, ArrowDown, Settings2, Edit } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { useToast } from '@/components/ui/use-toast';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';

export default function RoundsPage() {
  const navigate = useNavigate();
  const { toast } = useToast();
  
  const [rounds, setRounds] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [reorderingId, setReorderingId] = useState(null);
  const [normalizing, setNormalizing] = useState(false);

  useEffect(() => {
    loadRounds();
  }, []);

  async function loadRounds() {
    setLoading(true);
    setError(null);
    
    try {
      console.log('[RoundsPage] Loading all rounds');
      const { data, error: apiError } = await getAllRounds();
      
      if (apiError) {
        setError('Erro ao carregar lista de rounds');
        console.error('[RoundsPage] Error fetching all rounds:', apiError);
      } else {
        setRounds(data || []);
      }
    } catch (err) {
      console.error('[RoundsPage] Catch block error:', err);
      setError('Erro inesperado ao carregar dados');
    } finally {
      setLoading(false);
    }
  }

  async function handleReorder(roundId, direction) {
    if (reorderingId) return;
    
    console.log(`[RoundsPage] handleReorder: ${roundId} ${direction}`);
    setReorderingId(roundId);
    
    try {
      const { success, error } = await reorderRounds(roundId, direction);
      
      if (!success) {
        throw error || new Error('Failed to reorder');
      }
      
      await loadRounds(); // Refresh list to get new order
      
      toast({
        title: "Sucesso",
        description: "Ordem atualizada com sucesso.",
      });
    } catch (err) {
      console.error('[RoundsPage] Error reordering:', err);
      toast({
        variant: "destructive",
        title: "Erro ao reordenar",
        description: err.message || "Ocorreu um erro ao tentar mudar a ordem.",
      });
    } finally {
      setReorderingId(null);
    }
  }

  async function handleNormalize() {
    if (normalizing) return;
    
    console.log('[RoundsPage] handleNormalize');
    setNormalizing(true);
    
    try {
      const { success, error } = await normalizeRoundsOrder();
      
      if (!success) {
        throw error || new Error('Failed to normalize');
      }
      
      await loadRounds();
      
      toast({
        title: "Sucesso",
        description: "Ordem normalizada com sucesso.",
      });
    } catch (err) {
      console.error('[RoundsPage] Error normalizing:', err);
      toast({
        variant: "destructive",
        title: "Erro ao normalizar",
        description: err.message || "Ocorreu um erro ao tentar normalizar a ordem.",
      });
    } finally {
      setNormalizing(false);
    }
  }

  if (loading && rounds.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[400px] text-zinc-400">
        <Loader2 className="w-8 h-8 animate-spin mb-4" />
        <p>Carregando rounds...</p>
      </div>
    );
  }

  if (error && rounds.length === 0) {
    return (
      <div className="p-6">
        <Card className="bg-red-950/20 border-red-900/50">
          <CardContent className="flex flex-col items-center justify-center py-10">
            <AlertCircle className="w-12 h-12 text-red-500 mb-4" />
            <h2 className="text-xl font-bold text-red-500 mb-2">{error}</h2>
            <Button variant="outline" className="mt-4" onClick={loadRounds}>
              Tentar novamente
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6 max-w-6xl mx-auto">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-white mb-2">Gerenciar Rounds</h1>
          <p className="text-zinc-400">Gerencie todos os rounds de compras coletivas e sua ordem de exibição.</p>
        </div>
        <div className="flex items-center gap-3">
          <Button 
            variant="outline" 
            onClick={handleNormalize}
            disabled={normalizing || loading}
          >
            {normalizing ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Settings2 className="w-4 h-4 mr-2" />}
            Normalizar Ordem
          </Button>
          <Button onClick={() => {
              toast({
                title: "Não implementado",
                description: "🚧 This feature isn't implemented yet—but don't worry! You can request it in your next prompt! 🚀",
              });
          }}>
            <Plus className="w-4 h-4 mr-2" /> Novo Round
          </Button>
        </div>
      </div>

      <Card className="bg-zinc-900 border-zinc-800">
        <div className="rounded-md border border-zinc-800">
          <Table>
            <TableHeader>
              <TableRow className="border-zinc-800 hover:bg-transparent">
                <TableHead className="w-[100px] text-center">Ordem</TableHead>
                <TableHead>Título</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Início</TableHead>
                <TableHead>Fim</TableHead>
                <TableHead className="text-right">Ações</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {rounds.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={6} className="h-24 text-center text-zinc-500">
                    Nenhum round encontrado.
                  </TableCell>
                </TableRow>
              ) : (
                rounds.map((round, index) => (
                  <TableRow key={round.id} className="border-zinc-800 hover:bg-zinc-800/50">
                    <TableCell className="text-center font-medium">
                      {round.order_index || index + 1}
                    </TableCell>
                    <TableCell>
                      <div className="font-medium text-zinc-200">{round.title}</div>
                      <div className="text-sm text-zinc-500">{round.slug}</div>
                    </TableCell>
                    <TableCell>
                      <Badge 
                        variant={round.status === 'active' ? 'default' : (round.status === 'draft' ? 'secondary' : 'outline')}
                        className={
                          round.status === 'active' ? 'bg-green-500/10 text-green-500 hover:bg-green-500/20 border-green-500/20' :
                          round.status === 'draft' ? 'bg-yellow-500/10 text-yellow-500 hover:bg-yellow-500/20 border-yellow-500/20' : ''
                        }
                      >
                        {round.status}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-zinc-400">
                      {round.starts_at ? new Date(round.starts_at).toLocaleDateString('pt-BR') : '-'}
                    </TableCell>
                    <TableCell className="text-zinc-400">
                      {round.ends_at ? new Date(round.ends_at).toLocaleDateString('pt-BR') : '-'}
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex items-center justify-end gap-2">
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-8 w-8 text-zinc-400 hover:text-white"
                          disabled={!!reorderingId || loading}
                          onClick={() => handleReorder(round.id, 'up')}
                          title="Mover para cima"
                        >
                          <ArrowUp className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-8 w-8 text-zinc-400 hover:text-white"
                          disabled={!!reorderingId || loading}
                          onClick={() => handleReorder(round.id, 'down')}
                          title="Mover para baixo"
                        >
                          <ArrowDown className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          className="ml-2"
                          onClick={() => navigate(`/admin/rounds/${round.id}`)}
                        >
                          <Edit className="h-4 w-4 mr-2" /> Editar
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </div>
      </Card>
    </div>
  );
}
