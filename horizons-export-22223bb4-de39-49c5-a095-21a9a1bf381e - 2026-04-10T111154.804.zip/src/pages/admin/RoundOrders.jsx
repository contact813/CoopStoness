import React from 'react';
import { Helmet } from 'react-helmet';
import RoundOrdersList from '@/components/admin/RoundOrdersList';
import AdminHeader from '@/components/admin/AdminHeader';
import AdminErrorBoundary from '@/components/admin/AdminErrorBoundary';

const RoundOrdersPage = () => {
    return (
        <div className="min-h-screen bg-zinc-950 text-white">
            <Helmet>
                <title>Round Orders | Admin</title>
            </Helmet>
            
            <div className="p-8 max-w-[1600px] mx-auto">
                <div className="mb-8">
                    <h1 className="text-3xl font-bold text-yellow-500">Round Orders</h1>
                    <p className="text-zinc-400 mt-2">Manage all round orders, reservations, and sales.</p>
                </div>

                <div className="bg-zinc-900/30 border border-zinc-800/50 rounded-xl p-6">
                    <AdminErrorBoundary>
                        <RoundOrdersList />
                    </AdminErrorBoundary>
                </div>
            </div>
        </div>
    );
};

export default RoundOrdersPage;