
import React, { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';

/**
 * FILENAME: src/pages/admin/Categories.jsx
 * PURPOSE: Legacy page redirect.
 * NOTE: Categories (product types) are dynamically generated from the "Type" field 
 * in products and do not require a separate management interface.
 * This file redirects any users landing here to the main products page.
 */
const CategoriesPage = () => {
  const navigate = useNavigate();

  useEffect(() => {
    // Redirect to products page as categories are managed within the product entity
    navigate('/admin/products', { replace: true });
  }, [navigate]);

  return null;
};

export default CategoriesPage;

