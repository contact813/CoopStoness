import React, { useState, useEffect, useMemo } from 'react';
import { Helmet } from 'react-helmet';
import { format, subDays, startOfYear } from 'date-fns';
import { Download, Calendar as CalendarIcon } from 'lucide-react';

import { getDashboardData } from '@/lib/analyticsApi';
import { aggregateDailyData, downloadCSV } from '@/lib/analyticsUtils';

import { Button } from '@/components/ui/button';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Calendar } from '@/components/ui/calendar';
import { cn } from '@/lib/utils';

// Subcomponents
import KPISection from '@/components/admin/analytics/KPISection';
import TrendChart from '@/components/admin/analytics/TrendChart';
import CategoryPies from '@/components/admin/analytics/CategoryPies';
import RoundsAnalysis from '@/components/admin/analytics/RoundsAnalysis';
import SalesFunnel from '@/components/admin/analytics/FunnelChart';
import AlertsList from '@/components/admin/analytics/AlertsList';
import Insights from '@/components/admin/analytics/Insights';

const AnalyticsPage = () => {
  // 1. State
  const [dateRange, setDateRange] = useState({
    from: subDays(new Date(), 30),
    to: new Date(),
  });
  const [isLoading, setIsLoading] = useState(true);
  const [rawData, setRawData] = useState({
    currentSales: [],
    prevSales: [],
    funnel: [],
    heatmap: [],
    traffic: [],
    devices: [],
    lowStock: []
  });

  // 2. Fetch Data
  useEffect(() => {
    const load = async () => {
      if (!dateRange.from || !dateRange.to) return;
      
      setIsLoading(true);
      try {
        const data = await getDashboardData(dateRange.from.toISOString(), dateRange.to.toISOString());
        setRawData(data);
      } catch (err) {
        console.error("Failed to load analytics", err);
      } finally {
        setIsLoading(false);
      }
    };
    load();
  }, [dateRange]);

  // 3. Process Data for Visualization (Memoized)
  const metrics = useMemo(() => {
    const processSales = (sales) => {
      if (!sales) return { revenue: 0, items: 0, orders: 0, activeMembers: 0, activeSuppliers: 0, savings: 0, avgTicket: 0, avgDiscount: 0 };
      const revenue = sales.reduce((sum, s) => sum + (s.price_paid * s.qty), 0);
      const items = sales.reduce((sum, s) => sum + s.qty, 0);
      const uniqueOrders = new Set(sales.map(s => s.order_id)).size;
      const uniqueMembers = new Set(sales.map(s => s.user_id)).size;
      const uniqueSuppliers = new Set(sales.map(s => s.products?.vendor).filter(Boolean)).size;
      
      // Calculate savings: (Retail - Paid) * Qty
      const savings = sales.reduce((sum, s) => {
        const retail = s.products?.price || 0;
        return sum + ((retail - s.price_paid) * s.qty);
      }, 0);

      const avgTicket = uniqueOrders ? revenue / uniqueOrders : 0;
      const avgDiscount = sales.length ? (savings / (revenue + savings)) * 100 : 0;

      return { revenue, items, orders: uniqueOrders, activeMembers: uniqueMembers, activeSuppliers: uniqueSuppliers, savings, avgTicket, avgDiscount };
    };

    return {
      current: processSales(rawData.currentSales),
      prev: processSales(rawData.prevSales)
    };
  }, [rawData]);

  const trendData = useMemo(() => {
      if (!rawData.currentSales || !rawData.prevSales) return { current: [], prev: [] };
      return {
        current: aggregateDailyData(rawData.currentSales),
        prev: aggregateDailyData(rawData.prevSales)
      };
  }, [rawData.currentSales, rawData.prevSales]);

  const pieData = useMemo(() => {
      if (!rawData.currentSales) return { categories: [], vendors: [], topCategory: null };
      const catMap = {};
      const vendorMap = {};
      rawData.currentSales.forEach(s => {
          const rev = s.price_paid * s.qty;
          const cat = s.products?.type || 'Uncategorized';
          const vend = s.products?.vendor || 'Unknown';
          catMap[cat] = (catMap[cat] || 0) + rev;
          vendorMap[vend] = (vendorMap[vend] || 0) + rev;
      });
      
      const toChartData = (map) => Object.entries(map)
        .map(([name, value]) => ({ name, value }))
        .sort((a, b) => b.value - a.value)
        .slice(0, 5); // Top 5

      return {
          categories: toChartData(catMap),
          vendors: toChartData(vendorMap),
          topCategory: toChartData(catMap)[0]?.name,
      };
  }, [rawData.currentSales]);

  const roundsData = useMemo(() => {
      if (!rawData.currentSales) return [];
      const map = {};
      rawData.currentSales.forEach(s => {
          if(!s.rounds) return;
          const rid = s.rounds.id;
          if(!map[rid]) {
              map[rid] = { 
                  id: rid, 
                  title: s.rounds.title, 
                  status: s.rounds.status, 
                  revenue: 0, 
                  orders: new Set(), 
                  savings: 0 
              };
          }
          map[rid].revenue += (s.price_paid * s.qty);
          map[rid].orders.add(s.order_id);
          const retail = s.products?.price || 0;
          map[rid].savings += ((retail - s.price_paid) * s.qty);
      });
      return Object.values(map).map(r => ({ ...r, orders: r.orders.size }));
  }, [rawData.currentSales]);

  const funnelChartData = useMemo(() => {
     if (!rawData.funnel || !Array.isArray(rawData.funnel)) return [];
     const steps = ['Visits', 'Add to Cart', 'Checkout', 'Purchases'];
     return steps.map(step => {
         const found = rawData.funnel.find(f => f.step === step);
         return { name: step, value: found ? parseInt(found.value, 10) : 0 };
     });
  }, [rawData.funnel]);


  // 4. Handlers
  const handleExport = () => {
      if (!rawData.currentSales) return;
      downloadCSV(rawData.currentSales.map(s => ({
          date: s.created_at,
          order_id: s.order_id,
          product: s.products?.title,
          qty: s.qty,
          revenue: s.price_paid * s.qty
      })), 'sales_data');
  };

  // 5. Render
  return (
    <div className="min-h-screen bg-black pb-20">
      <Helmet>
        <title>Analytics Dashboard - Coop Stones Admin</title>
      </Helmet>

      {/* Header */}
      <div className="bg-zinc-950 border-b border-zinc-800 sticky top-16 z-30 backdrop-blur-md bg-opacity-80">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
              <h1 className="text-2xl font-bold text-white">Analytics Dashboard</h1>
              <p className="text-zinc-400 text-sm">Real-time insights and performance metrics</p>
            </div>
            
            <div className="flex items-center gap-2">
               <Popover>
                <PopoverTrigger asChild>
                  <Button variant="outline" className={cn("justify-start text-left font-normal w-[240px]", !dateRange && "text-zinc-500")}>
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {dateRange?.from ? (
                      dateRange.to ? (
                        <>
                          {format(dateRange.from, "LLL dd")} - {format(dateRange.to, "LLL dd, y")}
                        </>
                      ) : (
                        format(dateRange.from, "LLL dd, y")
                      )
                    ) : (
                      <span>Pick a date</span>
                    )}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0" align="end">
                  <Calendar
                    initialFocus
                    mode="range"
                    defaultMonth={dateRange?.from}
                    selected={dateRange}
                    onSelect={setDateRange}
                    numberOfMonths={2}
                  />
                </PopoverContent>
              </Popover>

              <div className="hidden md:flex bg-zinc-900 rounded-md border border-zinc-800 p-1">
                 <button onClick={() => setDateRange({ from: subDays(new Date(), 7), to: new Date() })} className="px-3 py-1 text-xs font-medium text-zinc-400 hover:text-white hover:bg-zinc-800 rounded">7D</button>
                 <button onClick={() => setDateRange({ from: subDays(new Date(), 30), to: new Date() })} className="px-3 py-1 text-xs font-medium text-zinc-400 hover:text-white hover:bg-zinc-800 rounded">30D</button>
                 <button onClick={() => setDateRange({ from: startOfYear(new Date()), to: new Date() })} className="px-3 py-1 text-xs font-medium text-zinc-400 hover:text-white hover:bg-zinc-800 rounded">YTD</button>
              </div>

              <Button onClick={handleExport} variant="outline" size="icon" title="Export CSV">
                <Download className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
        
        {/* Insights Pills */}
        <Insights 
            bestDay={trendData.current.sort((a,b) => b.revenue - a.revenue)[0]?.day}
            topCategory={pieData.topCategory}
            conversion={metrics.current.orders > 0 && funnelChartData[0]?.value > 0 ? `${((metrics.current.orders / funnelChartData[0].value) * 100).toFixed(1)}%` : '0%'}
        />

        {/* KPIs */}
        <KPISection 
            currentMetrics={metrics.current} 
            prevMetrics={metrics.prev} 
            isLoading={isLoading} 
        />

        {/* Main Trend Chart */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
           <TrendChart 
             currentData={trendData.current} 
             prevData={trendData.prev} 
             isLoading={isLoading} 
           />
        </div>

        {/* Middle Section: Funnel & Category Pies */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
           <div className="lg:col-span-1">
              <SalesFunnel data={funnelChartData} isLoading={isLoading} />
           </div>
           <div className="lg:col-span-2">
              <CategoryPies 
                categoryData={pieData.categories} 
                vendorData={pieData.vendors} 
                isLoading={isLoading} 
              />
           </div>
        </div>

        {/* Bottom Section: Rounds & Alerts */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
           <RoundsAnalysis roundsData={roundsData} isLoading={isLoading} />
           <div className="lg:col-span-1 h-full">
             <AlertsList lowStock={rawData.lowStock} isLoading={isLoading} />
           </div>
        </div>

      </div>
    </div>
  );
};

export default AnalyticsPage;