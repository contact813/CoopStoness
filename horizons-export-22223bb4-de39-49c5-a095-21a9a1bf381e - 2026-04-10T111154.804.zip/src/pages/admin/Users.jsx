import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { adminGetAllUsers, adminDeleteUser } from "@/api/adminUsers";
import { useAuth } from "@/contexts/AuthContext";
import { 
  Search, Plus, Eye, Edit, Trash2, MoreVertical, 
  Building2, Mail, Phone, Calendar, Shield, Crown, AlertCircle, RefreshCw
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from "@/components/ui/table";
import {
    DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger
} from "@/components/ui/dropdown-menu";
import { useToast } from "@/components/ui/use-toast";
import { 
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, 
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle 
} from "@/components/ui/alert-dialog";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";

export default function UsersPage() {
  const { user, isAuthLoading } = useAuth();
  const [users, setUsers] = useState([]);
  const [filteredUsers, setFilteredUsers] = useState([]);
  const [search, setSearch] = useState("");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const { toast } = useToast();

  // Delete State
  const [deleteOpen, setDeleteOpen] = useState(false);
  const [userToDelete, setUserToDelete] = useState(null);

  useEffect(() => {
    if (!isAuthLoading && user) {
      loadUsers();
    }
  }, [isAuthLoading, user]);

  useEffect(() => {
    if (!search.trim()) {
      setFilteredUsers(users);
    } else {
      const lower = search.toLowerCase();
      setFilteredUsers(users.filter(u => 
        (u.full_name || u.name || "").toLowerCase().includes(lower) ||
        (u.email || "").toLowerCase().includes(lower) ||
        (u.company_name || "").toLowerCase().includes(lower)
      ));
    }
  }, [search, users]);

  async function loadUsers() {
    if (!user) return [];
    
    setLoading(true);
    setError(null);
    try {
      const data = await adminGetAllUsers();
      setUsers(data);
      setFilteredUsers(data);
      return data;
    } catch (error) {
      console.error(error);
      setError("Failed to load users. Please try again later.");
      toast({ variant: "destructive", title: "Error", description: "Failed to load users." });
      return [];
    } finally {
      setLoading(false);
    }
  }

  // --- Helpers for Date Formatting ---
  const getContractEndDate = (createdAt) => {
    if (!createdAt) return null;
    const date = new Date(createdAt);
    date.setFullYear(date.getFullYear() + 1);
    return date;
  };

  const formatDate = (date) => {
    if (!date) return "—";
    return new Date(date).toLocaleDateString("en-US", {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  const confirmDelete = (user) => {
      setUserToDelete(user);
      setDeleteOpen(true);
  }

  const handleDelete = async () => {
      if(!userToDelete) return;

      // 1. Optimistic update: immediately remove from UI
      const previousUsers = [...users];
      setUsers(prev => prev.filter(u => u.id !== userToDelete.id));
      
      try {
          // 2. Call adminDeleteUser (includes fallback logic)
          const result = await adminDeleteUser(userToDelete.id);
          
          if (result && result.success === true) {
             // 3. Reload users to ensure sync with server
             await loadUsers();
             
             toast({ title: "User Deleted", description: "Profile has been removed successfully." });

          } else {
             throw new Error("Delete operation did not report success.");
          }
      } catch (error) {
          console.error("Delete failed:", error);
          // 5. On error - restore optimistic update and show error toast
          toast({ variant: "destructive", title: "Failed to delete", description: error.message || "Unknown error occurred" });
          setUsers(previousUsers); 
          loadUsers(); // Refresh to be safe
      } finally {
          setDeleteOpen(false);
          setUserToDelete(null);
      }
  }

  const getStatusBadge = (status) => {
      const s = (status || 'inactive').toLowerCase();
      let classes = "bg-zinc-800 text-zinc-400";
      if (s === 'active') classes = "bg-emerald-500/10 text-emerald-500 border-emerald-500/20";
      if (s === 'late') classes = "bg-yellow-500/10 text-yellow-500 border-yellow-500/20";
      if (s === 'suspended') classes = "bg-red-500/10 text-red-500 border-red-500/20";
      
      return <Badge variant="outline" className={`${classes} capitalize border`}>{s}</Badge>;
  };

  if (error) {
      return (
          <div className="p-6">
              <Alert variant="destructive" className="bg-red-900/20 border-red-900 text-red-200">
                  <AlertCircle className="h-4 w-4" />
                  <AlertTitle>Error</AlertTitle>
                  <AlertDescription className="flex items-center gap-4 mt-2">
                      {error}
                      <Button variant="outline" size="sm" onClick={loadUsers} className="border-red-800 hover:bg-red-900/50">
                          <RefreshCw className="mr-2 h-3 w-3" /> Retry
                      </Button>
                  </AlertDescription>
              </Alert>
          </div>
      );
  }

  return (
    <div className="space-y-6 p-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
           <h1 className="text-2xl font-bold tracking-tight text-white">Manage Users</h1>
           <p className="text-zinc-400">View and manage registered members</p>
        </div>
        <div className="flex items-center gap-3 w-full sm:w-auto">
            <div className="relative w-full sm:w-64">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-zinc-500 h-4 w-4" />
                <Input 
                    placeholder="Search users..." 
                    className="pl-9 bg-zinc-900/50 border-zinc-800 text-white"
                    value={search}
                    onChange={(e) => setSearch(e.target.value)}
                />
            </div>
            <Link to="/admin/users/new">
                <Button className="bg-yellow-500 text-black hover:bg-yellow-400 whitespace-nowrap">
                    <Plus size={16} className="mr-2"/> New User
                </Button>
            </Link>
        </div>
      </div>

      <div className="rounded-xl border border-zinc-800 bg-zinc-900/50 overflow-hidden">
        <Table>
          <TableHeader className="bg-zinc-900">
            <TableRow className="hover:bg-zinc-900 border-zinc-800">
              <TableHead className="text-zinc-400">Name / Company</TableHead>
              <TableHead className="text-zinc-400">Contact</TableHead>
              <TableHead className="text-zinc-400">Membership</TableHead>
              <TableHead className="text-zinc-400">Role</TableHead>
              <TableHead className="text-zinc-400">Joined</TableHead>
              <TableHead className="text-zinc-400">Contract End</TableHead>
              <TableHead className="text-zinc-400 text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {loading ? (
              Array.from({ length: 5 }).map((_, i) => (
                <TableRow key={i} className="border-zinc-800">
                  <TableCell colSpan={7}><div className="h-8 bg-zinc-800 rounded animate-pulse" /></TableCell>
                </TableRow>
              ))
            ) : filteredUsers.length === 0 ? (
              <TableRow>
                <TableCell colSpan={7} className="h-32 text-center text-zinc-500">
                  No users found.
                </TableCell>
              </TableRow>
            ) : (
              filteredUsers.map((user) => (
                <TableRow key={user.id} className="border-zinc-800 hover:bg-zinc-800/30">
                  <TableCell className="font-medium text-white">
                    <div>
                        <div className="font-semibold text-base">{user.full_name || user.name || 'No Name'}</div>
                        {user.company_name && (
                            <div className="text-xs text-zinc-400 flex items-center gap-1 mt-0.5">
                                <Building2 size={10} /> {user.company_name}
                            </div>
                        )}
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="flex flex-col gap-1 text-sm">
                        <div className="flex items-center gap-2 text-zinc-300">
                            <Mail size={12} className="text-zinc-500" /> {user.email}
                        </div>
                        {user.phone && (
                            <div className="flex items-center gap-2 text-zinc-400">
                                <Phone size={12} className="text-zinc-500" /> {user.phone}
                            </div>
                        )}
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="flex flex-col gap-1">
                         {getStatusBadge(user.membership_status)}
                         {user.membership_tier && (
                             <span className="text-xs text-amber-500 flex items-center gap-1">
                                <Crown size={10} /> {user.membership_tier}
                             </span>
                         )}
                    </div>
                  </TableCell>
                  <TableCell>
                      <div className="flex items-center gap-1 text-xs bg-zinc-800 w-fit px-2 py-1 rounded text-zinc-300 capitalize">
                          <Shield size={10} /> {user.role || 'member'}
                      </div>
                  </TableCell>
                  <TableCell className="text-zinc-400 text-sm">
                    <div className="flex items-center gap-2">
                        <Calendar size={12} />
                        {user.created_at ? new Date(user.created_at).toLocaleDateString() : '—'}
                    </div>
                  </TableCell>
                  <TableCell className="text-zinc-400 text-sm">
                    <div className="flex items-center gap-2">
                         {formatDate(getContractEndDate(user.created_at))}
                    </div>
                  </TableCell>
                  <TableCell className="text-right">
                      <div className="flex items-center justify-end gap-1">
                        <Link to={`/admin/users/${user.id}`}>
                            <Button variant="ghost" size="icon" className="h-8 w-8 hover:text-yellow-400">
                                <Eye size={16} />
                            </Button>
                        </Link>
                        <Link to={`/admin/users/edit/${user.id}`}>
                            <Button variant="ghost" size="icon" className="h-8 w-8 hover:text-blue-400">
                                <Edit size={16} />
                            </Button>
                        </Link>
                        <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                                <Button variant="ghost" size="icon" className="h-8 w-8 hover:bg-zinc-800">
                                    <MoreVertical size={16} />
                                </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end" className="bg-zinc-900 border-zinc-800">
                                <DropdownMenuItem className="text-red-500 focus:text-red-400 focus:bg-zinc-800 cursor-pointer" onClick={() => confirmDelete(user)}>
                                    <Trash2 size={14} className="mr-2"/> Delete User
                                </DropdownMenuItem>
                            </DropdownMenuContent>
                        </DropdownMenu>
                      </div>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>

      <AlertDialog open={deleteOpen} onOpenChange={setDeleteOpen}>
        <AlertDialogContent className="bg-zinc-950 border-zinc-800 text-white">
            <AlertDialogHeader>
                <AlertDialogTitle>Delete User Profile?</AlertDialogTitle>
                <AlertDialogDescription className="text-zinc-400">
                    This will permanently delete the user profile data. This action cannot be undone.
                </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
                <AlertDialogCancel className="bg-transparent border-zinc-700 text-zinc-300 hover:bg-zinc-800 hover:text-white">Cancel</AlertDialogCancel>
                <AlertDialogAction onClick={handleDelete} className="bg-red-600 hover:bg-red-700 text-white">Delete User</AlertDialogAction>
            </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}