
import React, { useEffect, useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { useNavigate } from 'react-router-dom';
import { supabase } from '@/lib/supabaseClient';
import { Loader2, Package, AlertCircle, ShoppingBag } from 'lucide-react';
import { Helmet } from 'react-helmet';

export default function AdminOrders() {
  const { user, profile, isAuthInitialized } = useAuth();
  const navigate = useNavigate();
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    if (!isAuthInitialized) return;
    
    const isAdmin = profile?.is_admin || profile?.role === 'admin';
    if (!user || !isAdmin) {
      console.log("[AdminOrders] Unauthorized access attempt, redirecting.");
      navigate('/');
      return;
    }

    loadOrders();
  }, [isAuthInitialized, user, profile, navigate]);

  async function loadOrders() {
    setLoading(true);
    setError(null);
    try {
      console.log(`[AdminOrders] Fetching all from public.orders...`);
      
      const { data, error: fetchErr } = await supabase
        .from('orders')
        .select(`
          id, status, user_id, round_id, total_amount, created_at, updated_at,
          order_items (
            id, product_id, variant_id, quantity, unit_price,
            products (title),
            product_variants (title)
          )
        `)
        .order('created_at', { ascending: false });

      if (fetchErr) throw fetchErr;
      
      console.log(`[AdminOrders] Successfully loaded ${data?.length || 0} orders:`, data);
      setOrders(data || []);
    } catch (err) {
      console.error('[AdminOrders] Failed to fetch orders:', err);
      setError(err.message || 'Failed to load orders.');
    } finally {
      setLoading(false);
    }
  }

  if (!isAuthInitialized || loading) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh] text-zinc-400">
        <Loader2 className="w-10 h-10 animate-spin text-yellow-500 mb-4" />
        <p>Loading all orders...</p>
      </div>
    );
  }

  if (error) {
    return (
      <div className="text-center p-8 bg-zinc-900 border border-zinc-800 rounded-xl max-w-2xl mx-auto mt-12">
        <AlertCircle className="w-12 h-12 text-red-500 mx-auto mb-4" />
        <h2 className="text-xl font-bold text-white mb-2">Error Loading Orders</h2>
        <p className="text-zinc-400 mb-6">{error}</p>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6 max-w-[1600px] mx-auto">
      <Helmet>
        <title>All Orders | Coop Stones Admin</title>
      </Helmet>

      <div className="flex justify-between items-center mb-6 border-b border-zinc-800 pb-4">
        <div>
          <h1 className="text-3xl font-bold text-yellow-500 flex items-center gap-3">
            <ShoppingBag className="w-8 h-8" />
            Orders Management
          </h1>
          <p className="text-zinc-400 mt-2">
            Showing {orders.length} total orders from public.orders
          </p>
        </div>
      </div>

      {orders.length === 0 ? (
        <div className="text-center p-12 bg-zinc-950 border border-zinc-800 rounded-xl">
          <Package className="w-16 h-16 text-zinc-700 mx-auto mb-4" />
          <h2 className="text-2xl font-bold text-white mb-2">No Orders Found</h2>
          <p className="text-zinc-400">There are no orders submitted in the database yet.</p>
        </div>
      ) : (
        <div className="grid gap-6">
          {orders.map((order) => {
            const dbTotal = Number(order.total_amount).toFixed(2);
            const orderDate = new Date(order.created_at).toLocaleDateString(undefined, { 
              year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit'
            });
            const updateDate = order.updated_at ? new Date(order.updated_at).toLocaleDateString(undefined, { 
              year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit'
            }) : null;

            const shortOrderId = String(order.id).substring(0, 8).toUpperCase();
            const shortRoundId = order.round_id ? String(order.round_id).substring(0, 8).toUpperCase() : 'N/A';
            const shortUserId = String(order.user_id).substring(0, 8).toUpperCase();
            
            // ✅ order_items usa APENAS quantity
            const totalItems = order.order_items?.reduce((sum, item) => {
              const itemQuantity = item.quantity ?? 0;
              return sum + itemQuantity;
            }, 0) ?? 0;

            console.log('[AdminOrders] Order total items:', totalItems);

            const calculatedTotal = order.order_items?.reduce((sum, item) => {
              const itemQuantity = item.quantity ?? 0;
              return sum + (itemQuantity * (item.unit_price ?? 0));
            }, 0) || 0;
            
            console.log(`[AdminOrders] Order ${order.id} | Status: ${order.status} | DB Total: ${order.total_amount} | Calculated Total: ${calculatedTotal}`);

            return (
              <div key={order.id} className="bg-zinc-950 border border-zinc-800 rounded-xl overflow-hidden shadow-sm">
                <div className="bg-zinc-900 p-5 border-b border-zinc-800 grid grid-cols-1 md:grid-cols-4 gap-4">
                  <div>
                    <p className="text-xs text-zinc-500 font-bold uppercase tracking-wider mb-1">Order Details</p>
                    <p className="text-sm font-mono text-white mb-1">#{shortOrderId}</p>
                    <p className="text-xs text-zinc-400">Created: {orderDate}</p>
                    {updateDate && <p className="text-xs text-zinc-400 mt-1">Updated: {updateDate}</p>}
                  </div>
                  <div>
                    <p className="text-xs text-zinc-500 font-bold uppercase tracking-wider mb-1">Customer / Round</p>
                    <p className="text-sm text-zinc-300 font-mono mb-1">User: {shortUserId}</p>
                    <p className="text-xs text-zinc-400 font-mono">Round: {shortRoundId}</p>
                  </div>
                  <div>
                    <p className="text-xs text-zinc-500 font-bold uppercase tracking-wider mb-1">Status</p>
                    <span className={`order-status status-${order.status.toLowerCase()} mt-1`}>
                      {order.status}
                    </span>
                  </div>
                  <div className="md:text-right">
                    <p className="text-xs text-zinc-500 font-bold uppercase tracking-wider mb-1">Total</p>
                    <p className="text-xl font-bold text-yellow-500">${dbTotal}</p>
                  </div>
                </div>
                
                <div className="p-5">
                  <h4 className="text-sm font-bold text-white mb-4 border-b border-zinc-800 pb-2">Order Items</h4>
                  <div className="space-y-3">
                    {order.order_items?.map((item) => {
                      const title = item.product_variants?.title || item.products?.title || 'Unknown Product';
                      
                      // ✅ order_items usa APENAS quantity
                      const itemQuantity = item.quantity ?? 0;
                      const itemSubtotal = itemQuantity * (item.unit_price ?? 0);

                      console.log('[AdminOrders] Rendering order item:', {
                        id: item.id,
                        quantity: itemQuantity,
                        unit_price: item.unit_price,
                        subtotal: itemSubtotal
                      });
                      
                      return (
                        <div key={item.id} className="flex items-center justify-between gap-4 bg-zinc-900/50 p-3 rounded-lg border border-zinc-800/50">
                          <div className="flex-1">
                            <p className="text-zinc-200 font-medium">{title}</p>
                            <p className="text-zinc-500 text-xs mt-1">Qty: {itemQuantity} × ${Number(item.unit_price ?? 0).toFixed(2)} = ${itemSubtotal.toFixed(2)}</p>
                          </div>
                          <p className="text-zinc-300 font-bold whitespace-nowrap bg-zinc-900 px-3 py-1 rounded border border-zinc-800">
                            ${itemSubtotal.toFixed(2)}
                          </p>
                        </div>
                      );
                    })}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
