
import React, { useState, useEffect, useCallback, useMemo } from "react";
import { useNavigate } from "react-router-dom";
import { isValidCatalogProduct, getOrphanReason } from "@/lib/productsApi";
import { getAllProducts } from "@/lib/adminProductsApi";
import { useProductsRefresh } from "@/contexts/ProductsContext";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/components/ui/use-toast";
import {
  Loader2,
  Edit,
  Search,
  Plus,
  Package,
  AlertTriangle,
  AlertCircle
} from "lucide-react";
import { PLACEHOLDER_IMAGE, getProductImage } from "@/lib/imageUtils";

function useDebounce(value, delay) {
  const [debouncedValue, setDebouncedValue] = useState(value);
  useEffect(() => {
    const handler = setTimeout(() => {
      setDebouncedValue(value);
    }, delay);
    return () => clearTimeout(handler);
  }, [value, delay]);
  return debouncedValue;
}

export default function ProductsPage() {
  const navigate = useNavigate();
  const { toast } = useToast();
  const { refreshTrigger } = useProductsRefresh() || {};

  const [allProducts, setAllProducts] = useState([]);
  const [tab, setTab] = useState('valid'); // Catalog (valid) tab by default
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const [q, setQ] = useState('');
  const debouncedQ = useDebounce(q, 500);

  const loadProducts = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      console.log(`[ProductsPage] Fetching all products...`);
      
      const { rows, error: fetchErr } = await getAllProducts({ limit: 5000 }); 
      
      if (fetchErr) {
        throw fetchErr;
      }

      if (!Array.isArray(rows)) {
        throw new Error("Invalid response format. Expected an array of products.");
      }

      console.log(`[ProductsPage] Data loaded successfully. Length: ${rows.length}`);
      setAllProducts(rows);
      
    } catch (err) {
      console.error("[ProductsPage] Error loading products:", err);
      setAllProducts([]);
      setError(err.message || "Failed to load products. Please try again.");
      toast({ variant: "destructive", title: "Error", description: err.message });
    } finally {
      setLoading(false);
    }
  }, [toast]);

  // Load when mounted or when context refresh triggered
  useEffect(() => { 
    loadProducts(); 
  }, [loadProducts, refreshTrigger]);

  // Listener for custom event dispatched from edit page
  useEffect(() => {
    const handleProductSaved = (e) => {
      console.log('[ProductsPage] Received custom event "productSaved", reloading products...', e.detail);
      loadProducts();
    };

    window.addEventListener('productSaved', handleProductSaved);
    return () => {
      window.removeEventListener('productSaved', handleProductSaved);
    };
  }, [loadProducts]);

  // Split products into valid and orphan categories
  const { validProducts, orphanProducts } = useMemo(() => {
    if (!Array.isArray(allProducts)) return { validProducts: [], orphanProducts: [] };

    const valid = allProducts.filter(p => {
      // Valid = Has ID and status is active or draft
      return p && p.id && (p.status === 'active' || p.status === 'draft');
    });

    const orphan = allProducts.filter(p => {
      // Orphan = Missing ID OR status is NOT active/draft
      return !p || !p.id || (p.status !== 'active' && p.status !== 'draft');
    });

    return { validProducts: valid, orphanProducts: orphan };
  }, [allProducts]);

  // Apply search filtering to the active tab's list
  const filteredProducts = useMemo(() => {
    const activeList = tab === 'valid' ? validProducts : orphanProducts;
    
    if (!debouncedQ) return activeList;

    const lowerQ = debouncedQ.toLowerCase();
    return activeList.filter(p => 
      (p.title?.toLowerCase().includes(lowerQ)) || 
      (p.vendor?.toLowerCase().includes(lowerQ))
    );
  }, [validProducts, orphanProducts, tab, debouncedQ]);

  const handleSearchChange = (e) => {
    setQ(e.target.value);
  };

  const handleViewProduct = (productId) => {
    if (!productId) return;
    navigate(`/admin/products/${productId}`);
  };

  const renderSkeletons = () => {
    return Array.from({ length: 5 }).map((_, idx) => (
      <tr key={`skel-${idx}`} className="animate-pulse">
        <td className="p-4 flex items-center gap-3">
          <div className="h-10 w-10 bg-zinc-800 rounded"></div>
          <div className="space-y-2">
            <div className="h-3 bg-zinc-800 rounded w-32"></div>
            <div className="h-2 bg-zinc-800 rounded w-16"></div>
          </div>
        </td>
        <td className="p-4"><div className="h-3 bg-zinc-800 rounded w-20"></div></td>
        <td className="p-4"><div className="h-3 bg-zinc-800 rounded w-12 ml-auto"></div></td>
        <td className="p-4"><div className="h-5 bg-zinc-800 rounded w-16 mx-auto"></div></td>
        <td className="p-4"><div className="h-6 bg-zinc-800 rounded w-8 ml-auto"></div></td>
      </tr>
    ));
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-6 border-b border-zinc-800">
        <div className="space-y-1">
          <h1 className="text-3xl font-bold text-white tracking-tight">Products</h1>
          <p className="text-zinc-400">
            Manage your catalog. <span className="text-white font-medium">{validProducts.length}</span> valid, <span className="text-yellow-500 font-medium">{orphanProducts.length}</span> orphans.
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-3">
          <div className="flex items-center bg-zinc-900 border border-zinc-800 rounded-md p-1 mr-2">
            <Button
              variant={tab === 'valid' ? "secondary" : "ghost"}
              onClick={() => { setTab('valid'); }}
              className={`h-8 px-4 text-sm font-medium ${tab === 'valid' ? 'bg-zinc-800 text-white active' : 'text-zinc-400 hover:text-white'}`}
            >
              Ver Catálogo ({validProducts.length})
            </Button>
            <Button
              variant={tab === 'orphan' ? "secondary" : "ghost"}
              onClick={() => { setTab('orphan'); }}
              className={`h-8 px-4 text-sm font-medium ${tab === 'orphan' ? 'bg-yellow-500/20 text-yellow-500 hover:bg-yellow-500/30 active' : 'text-zinc-400 hover:text-yellow-500 hover:bg-yellow-500/10'}`}
            >
              <AlertTriangle className="w-3 h-3 mr-2" />
              Ver Órfãos ({orphanProducts.length})
            </Button>
          </div>
          <Button
            onClick={() => navigate("/admin/products/new")}
            className="bg-yellow-400 hover:bg-yellow-500 text-zinc-900 font-semibold shadow-lg shadow-yellow-400/10 transition-all h-10 px-4"
          >
            <Plus className="w-4 h-4 mr-2" /> New Product
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-12 gap-4 bg-zinc-950 p-1 rounded-xl">
        <div className="md:col-span-12 relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-zinc-500" />
          <Input 
            placeholder="Search products by title or vendor..." 
            value={q} 
            onChange={handleSearchChange} 
            className="pl-9 bg-zinc-950 border-zinc-800 text-white placeholder:text-zinc-600 focus:ring-yellow-500/50 focus:border-yellow-500/50 h-10" 
          />
        </div>
      </div>

      {error ? (
        <div className="p-8 text-center bg-red-950/20 border border-red-900/50 rounded-xl">
           <AlertTriangle className="h-8 w-8 text-red-500 mx-auto mb-3" />
           <h3 className="text-lg font-medium text-red-400 mb-1">Error Loading Products</h3>
           <p className="text-zinc-400 max-w-md mx-auto">{error}</p>
           <Button variant="outline" className="mt-4 border-red-900/50 hover:bg-red-900/30 text-red-400" onClick={loadProducts}>Try Again</Button>
        </div>
      ) : (
      <div className={`rounded-xl border overflow-hidden ${tab === 'orphan' ? 'border-yellow-500/30 bg-yellow-950/10' : 'border-zinc-800 bg-zinc-950/50'}`}>
        <div className="overflow-x-auto">
          <table className="w-full text-sm text-left">
            <thead className={`uppercase tracking-wider text-[11px] font-semibold sticky top-0 z-10 border-b ${tab === 'orphan' ? 'bg-yellow-950/30 text-yellow-500 border-yellow-500/20' : 'bg-zinc-950 text-zinc-500 border-zinc-800'}`}>
              <tr>
                <th className="p-4">Product</th>
                {tab === 'valid' && <th className="p-4">Vendor</th>}
                <th className="p-4 text-right">Price</th>
                {tab === 'valid' && <th className="p-4 text-center">Status</th>}
                {tab === 'orphan' && <th className="p-4">Orphan Reason</th>}
                <th className="p-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className={`divide-y ${tab === 'orphan' ? 'divide-yellow-900/20' : 'divide-zinc-800'}`}>
              {loading ? (
                renderSkeletons()
              ) : filteredProducts.length === 0 ? (
                <tr>
                  <td colSpan={tab === 'orphan' ? 4 : 5} className="p-12 text-center">
                    <div className={`mx-auto h-12 w-12 rounded-full flex items-center justify-center mb-3 border ${tab === 'orphan' ? 'bg-yellow-950/30 border-yellow-500/30 text-yellow-500' : 'bg-zinc-900 border-zinc-800 text-zinc-500'}`}>
                      {tab === 'orphan' ? <AlertCircle className="h-6 w-6" /> : <Package className="h-6 w-6" />}
                    </div>
                    <h3 className="text-lg font-medium text-white mb-1">
                      {tab === 'orphan' ? 'No orphan products found' : 'No products found'}
                    </h3>
                    <p className="text-zinc-500 max-w-sm mx-auto mb-4">{q ? "Try adjusting your search." : "Your catalog is currently empty."}</p>
                    {q && (<Button variant="outline" onClick={() => setQ('')}>Clear Search</Button>)}
                  </td>
                </tr>
              ) : (
                filteredProducts.map((row) => {
                  const imgUrl = getProductImage(row);
                  const key = row.id || `orphan-${row.title}-${Math.random()}`;
                  return (
                    <tr key={key} className={`group transition-colors duration-200 hover:bg-zinc-900/40 bg-transparent`}>
                      <td className="p-4">
                         <div className="flex items-center gap-3">
                           <div className="h-10 w-10 rounded bg-zinc-900 border border-zinc-800 overflow-hidden flex-shrink-0">
                             <img 
                               src={imgUrl} 
                               alt={row.title} 
                               loading="lazy" 
                               decoding="async" 
                               className="h-full w-full object-cover" 
                               onError={(e) => { 
                                 console.warn(`[ProductsPage] Failed to load image for product ${row.id}, falling back.`);
                                 e.currentTarget.src = PLACEHOLDER_IMAGE; 
                               }} 
                             />
                           </div>
                           <div className="min-w-0">
                             <div className="font-medium text-zinc-200 truncate max-w-[200px] md:max-w-[300px]" title={row.title}>{row.title || 'Untitled'}</div>
                             <div className="text-[10px] text-zinc-600 font-mono truncate">{row.id ? row.id.split('-')[0] + '...' : 'NO-ID'}</div>
                           </div>
                         </div>
                      </td>
                      {tab === 'valid' && <td className="p-4 text-zinc-400 text-sm">{row.vendor || '—'}</td>}
                      <td className="p-4 font-medium text-zinc-200 text-sm text-right">${Number(row.min_price || row.price || 0).toFixed(2)}</td>
                      {tab === 'valid' && (
                        <td className="p-4 text-center">
                          <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-medium border uppercase tracking-wide ${row.status === 'active' ? 'bg-green-500/10 text-green-400 border-green-500/20' : row.status === 'archived' ? 'bg-red-500/10 text-red-400 border-red-500/20' : 'bg-zinc-500/10 text-zinc-400 border-zinc-500/20'}`}>
                            {row.status || 'draft'}
                          </span>
                        </td>
                      )}
                      {tab === 'orphan' && (
                        <td className="p-4 text-xs font-medium text-yellow-500">
                          {getOrphanReason(row) || "Invalid Status/Missing ID"}
                        </td>
                      )}
                      <td className="p-4 text-right">
                         <div className="flex justify-end items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                            <Button 
                              variant="ghost" 
                              size="sm" 
                              onClick={() => handleViewProduct(row.id)} 
                              className="h-8 w-8 p-0 text-zinc-400 hover:text-white hover:bg-zinc-800" 
                              title="Edit"
                              disabled={!row.id}
                            >
                              <Edit className="h-4 w-4" />
                            </Button>
                         </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>
      )}
    </div>
  );
}
