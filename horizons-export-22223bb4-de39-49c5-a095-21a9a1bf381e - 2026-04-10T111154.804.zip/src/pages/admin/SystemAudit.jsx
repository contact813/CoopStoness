import React, { useState, useEffect } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/lib/supabaseClient';
import { getClientFileManifest } from '@/admin/auditManifest';
import { 
    CheckCircle, 
    XCircle, 
    AlertTriangle, 
    Shield, 
    FileCode, 
    Database, 
    Play, 
    Clock, 
    ChevronDown, 
    ChevronUp,
    RefreshCw,
    Lock,
    Info,
    Activity
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/components/ui/use-toast';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { cn } from '@/lib/utils';

// Helper to format date safely
const formatDate = (dateString) => {
    if (!dateString) return '--';
    try {
        const date = new Date(dateString);
        if (isNaN(date.getTime())) return '--';
        return new Intl.DateTimeFormat('en-US', {
            year: 'numeric',
            month: 'short',
            day: 'numeric',
            hour: '2-digit',
            minute: '2-digit'
        }).format(date);
    } catch (e) {
        return '--';
    }
};

const AuditResultRow = ({ result }) => {
  const [expanded, setExpanded] = useState(false);
  
  // Custom colors for Advisor "Info" status which comes as 'pass' but serves as Info
  const isAdvisor = result.category === 'Supabase Advisor';
  
  let Icon = CheckCircle;
  let color = 'text-emerald-500';
  let bgColor = 'bg-emerald-500/10';
  let borderColor = 'border-emerald-500/20';

  if (result.status === 'fail') {
      Icon = XCircle;
      color = 'text-red-500';
      bgColor = 'bg-red-500/10';
      borderColor = 'border-red-500/20';
  } else if (result.status === 'warn') {
      Icon = AlertTriangle;
      color = 'text-amber-500';
      bgColor = 'bg-amber-500/10';
      borderColor = 'border-amber-500/20';
  } else if (result.status === 'pass' && isAdvisor) {
      Icon = Info;
      color = 'text-blue-500';
      bgColor = 'bg-blue-500/10';
      borderColor = 'border-blue-500/20';
  }

  return (
    <div className={cn("rounded-lg border transition-all", borderColor, expanded ? "bg-zinc-900" : "bg-zinc-900/50")}>
      <div 
        className="flex items-center gap-3 p-4 cursor-pointer hover:bg-zinc-800/50 transition-colors rounded-t-lg"
        onClick={() => setExpanded(!expanded)}
      >
        <Icon className={cn("w-5 h-5 flex-shrink-0", color)} />
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2">
            <h4 className="text-sm font-medium text-zinc-200">{result.title}</h4>
            <Badge variant="outline" className={cn("text-[10px] h-5 px-1.5 uppercase tracking-wider border-0", bgColor, color)}>
              {result.status === 'pass' && isAdvisor ? 'INFO' : result.status}
            </Badge>
          </div>
          <p className="text-xs text-zinc-500 truncate mt-0.5">{result.description}</p>
        </div>
        <Button variant="ghost" size="sm" className="h-8 w-8 p-0 text-zinc-500">
           {expanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
        </Button>
      </div>
      
      {expanded && (
        <div className="px-4 pb-4 pt-0 text-sm border-t border-zinc-800/50 mt-2">
            <div className="mt-3 space-y-3">
                <div className="grid grid-cols-[100px_1fr] gap-2">
                    <span className="text-zinc-500 text-xs uppercase font-bold tracking-wider">Details</span>
                    <span className="text-zinc-300 font-mono text-xs break-all whitespace-pre-wrap">
                        {typeof result.details === 'object' ? JSON.stringify(result.details, null, 2) : result.details || "No details provided."}
                    </span>
                </div>
                {result.fix_hint && (
                    <div className="grid grid-cols-[100px_1fr] gap-2">
                        <span className="text-zinc-500 text-xs uppercase font-bold tracking-wider">Remedy</span>
                        <span className="text-amber-500/80 text-xs">{result.fix_hint}</span>
                    </div>
                )}
                <div className="grid grid-cols-[100px_1fr] gap-2">
                    <span className="text-zinc-500 text-xs uppercase font-bold tracking-wider">Code</span>
                    <span className="text-zinc-600 font-mono text-xs">{result.key}</span>
                </div>
            </div>
        </div>
      )}
    </div>
  );
};

const SupabaseAdvisor = ({ results }) => {
    const advisorResults = results.filter(r => r.category === 'Supabase Advisor');
    if (advisorResults.length === 0) return null;

    const errors = advisorResults.filter(r => r.status === 'fail');
    const warnings = advisorResults.filter(r => r.status === 'warn');
    const infos = advisorResults.filter(r => r.status === 'pass');

    return (
        <Card className="bg-zinc-950 border-zinc-800 overflow-hidden">
            <CardHeader className="bg-zinc-900/50 border-b border-zinc-800 pb-4">
                <div className="flex items-center gap-2">
                    <Shield className="w-5 h-5 text-indigo-400" />
                    <CardTitle className="text-lg font-semibold text-zinc-100">Supabase Advisor</CardTitle>
                    <Badge variant="outline" className="ml-2 bg-indigo-500/10 text-indigo-400 border-indigo-500/20">BETA</Badge>
                </div>
            </CardHeader>
            <CardContent className="p-0">
                <Tabs defaultValue="all" className="w-full">
                    <div className="border-b border-zinc-800 px-4 bg-zinc-900/20">
                        <TabsList className="bg-transparent h-12 p-0 gap-6 w-full justify-start">
                            <TabsTrigger 
                                value="all" 
                                className="data-[state=active]:bg-transparent data-[state=active]:shadow-none data-[state=active]:border-b-2 data-[state=active]:border-indigo-500 rounded-none h-full px-0 font-normal text-zinc-400 data-[state=active]:text-indigo-400 transition-all"
                            >
                                All Issues
                                <span className="ml-2 bg-zinc-800 text-zinc-400 text-[10px] px-1.5 py-0.5 rounded-full">{advisorResults.length}</span>
                            </TabsTrigger>
                            <TabsTrigger 
                                value="errors" 
                                className="data-[state=active]:bg-transparent data-[state=active]:shadow-none data-[state=active]:border-b-2 data-[state=active]:border-red-500 rounded-none h-full px-0 font-normal text-zinc-400 data-[state=active]:text-red-400 transition-all"
                            >
                                Errors
                                <span className="ml-2 bg-red-500/10 text-red-500 text-[10px] px-1.5 py-0.5 rounded-full">{errors.length}</span>
                            </TabsTrigger>
                            <TabsTrigger 
                                value="warnings" 
                                className="data-[state=active]:bg-transparent data-[state=active]:shadow-none data-[state=active]:border-b-2 data-[state=active]:border-amber-500 rounded-none h-full px-0 font-normal text-zinc-400 data-[state=active]:text-amber-400 transition-all"
                            >
                                Warnings
                                <span className="ml-2 bg-amber-500/10 text-amber-500 text-[10px] px-1.5 py-0.5 rounded-full">{warnings.length}</span>
                            </TabsTrigger>
                            <TabsTrigger 
                                value="infos" 
                                className="data-[state=active]:bg-transparent data-[state=active]:shadow-none data-[state=active]:border-b-2 data-[state=active]:border-blue-500 rounded-none h-full px-0 font-normal text-zinc-400 data-[state=active]:text-blue-400 transition-all"
                            >
                                Info
                                <span className="ml-2 bg-blue-500/10 text-blue-500 text-[10px] px-1.5 py-0.5 rounded-full">{infos.length}</span>
                            </TabsTrigger>
                        </TabsList>
                    </div>
                    
                    <div className="p-4 bg-zinc-950 min-h-[200px]">
                        <TabsContent value="all" className="mt-0 space-y-3">
                            {advisorResults.map((r, i) => <AuditResultRow key={i} result={r} />)}
                        </TabsContent>
                        <TabsContent value="errors" className="mt-0 space-y-3">
                            {errors.length === 0 ? <div className="p-8 text-center text-zinc-500 text-sm">No critical errors found. Great job!</div> : errors.map((r, i) => <AuditResultRow key={i} result={r} />)}
                        </TabsContent>
                        <TabsContent value="warnings" className="mt-0 space-y-3">
                             {warnings.length === 0 ? <div className="p-8 text-center text-zinc-500 text-sm">No warnings found.</div> : warnings.map((r, i) => <AuditResultRow key={i} result={r} />)}
                        </TabsContent>
                        <TabsContent value="infos" className="mt-0 space-y-3">
                             {infos.length === 0 ? <div className="p-8 text-center text-zinc-500 text-sm">No informational items.</div> : infos.map((r, i) => <AuditResultRow key={i} result={r} />)}
                        </TabsContent>
                    </div>
                </Tabs>
            </CardContent>
        </Card>
    );
};

export default function SystemAudit() {
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const [auditData, setAuditData] = useState(null);

  const fetchLastRun = async () => {
    try {
        const { data, error } = await supabase
            .from('system_audit_runs')
            .select('*')
            .order('created_at', { ascending: false })
            .limit(1);
            
        if (data && data.length > 0) {
            setAuditData(data[0]);
        }
    } catch (e) {
        console.error("No previous run found or error", e);
    }
  };

  useEffect(() => {
    fetchLastRun();
  }, []);

  const handleRunAudit = async () => {
    setLoading(true);
    try {
        const clientFiles = getClientFileManifest();
        
        // Invoke the audit
        const { error } = await supabase.functions.invoke('system-audit', {
            body: { clientFiles }
        });

        if (error) throw error;
        
        // CRITICAL: Fetch the ACTUAL created record from DB
        await fetchLastRun();

        toast({
            title: "Audit Completed",
            description: "System analysis finished successfully.",
            variant: "success"
        });
        
    } catch (error) {
        console.error("Audit failed:", error);
        toast({
            title: "Audit Failed",
            description: error.message || "Could not complete system scan.",
            variant: "destructive"
        });
    } finally {
        setLoading(false);
    }
  };

  // Exclude Supabase Advisor from generic list as it has its own section
  const categories = [
    { id: 'Routes & Front', icon: FileCode, label: 'Frontend & Routes' },
    { id: 'Supabase Security', icon: Shield, label: 'Access Control' },
    { id: 'Data Integrity', icon: Database, label: 'Data Health' },
  ];

  return (
    <div className="space-y-8 text-white max-w-5xl mx-auto pb-20">
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <h2 className="text-3xl font-bold text-zinc-100 tracking-tight">System Integrity Audit</h2>
          <p className="text-zinc-400 text-sm mt-1">Deep diagnostic scan using direct database connection and frontend analysis.</p>
        </div>
        
        <div className="flex items-center gap-3">
             <div className="text-right hidden sm:block mr-2">
                <div className="text-xs text-zinc-500 uppercase tracking-wider font-bold">Last Run</div>
                <div className="text-sm font-mono text-zinc-300">
                    {auditData ? formatDate(auditData.created_at) : '--'}
                </div>
             </div>
             <Button 
                onClick={handleRunAudit} 
                disabled={loading}
                className="bg-amber-500 hover:bg-amber-400 text-black font-bold min-w-[140px]"
            >
                {loading ? <RefreshCw className="w-4 h-4 animate-spin mr-2" /> : <Play className="w-4 h-4 mr-2 fill-current" />}
                {loading ? 'Scanning...' : 'Run Audit'}
             </Button>
        </div>
      </div>

      {auditData ? (
        <>
            <div className="grid grid-cols-3 gap-4">
                <Card className="bg-zinc-950 border-zinc-800">
                    <CardContent className="p-6 flex flex-col items-center justify-center">
                        <span className="text-4xl font-bold text-emerald-500">{auditData.summary?.pass || 0}</span>
                        <span className="text-xs text-zinc-500 uppercase tracking-widest font-bold mt-1">Passed</span>
                    </CardContent>
                </Card>
                <Card className="bg-zinc-950 border-zinc-800">
                    <CardContent className="p-6 flex flex-col items-center justify-center">
                        <span className="text-4xl font-bold text-amber-500">{auditData.summary?.warn || 0}</span>
                        <span className="text-xs text-zinc-500 uppercase tracking-widest font-bold mt-1">Warnings</span>
                    </CardContent>
                </Card>
                <Card className="bg-zinc-950 border-zinc-800">
                    <CardContent className="p-6 flex flex-col items-center justify-center">
                        <span className="text-4xl font-bold text-red-500">{auditData.summary?.fail || 0}</span>
                        <span className="text-xs text-zinc-500 uppercase tracking-widest font-bold mt-1">Failed</span>
                    </CardContent>
                </Card>
            </div>

            {/* NEW: Supabase Advisor Section */}
            <SupabaseAdvisor results={auditData.results || []} />

            {/* Standard Categories */}
            <div className="space-y-8">
                {categories.map(cat => {
                    const catResults = (auditData.results || []).filter(r => r.category === cat.id);
                    if (catResults.length === 0) return null;

                    return (
                        <div key={cat.id} className="space-y-4">
                            <h3 className="flex items-center gap-2 text-lg font-semibold text-zinc-200">
                                <cat.icon className="w-5 h-5 text-zinc-500" />
                                {cat.label}
                            </h3>
                            <div className="grid gap-3">
                                {catResults.map((result, idx) => (
                                    <AuditResultRow key={idx} result={result} />
                                ))}
                            </div>
                        </div>
                    );
                })}
            </div>
        </>
      ) : (
          <div className="min-h-[400px] flex flex-col items-center justify-center border-2 border-dashed border-zinc-800 rounded-2xl bg-zinc-900/20">
              <Clock className="w-12 h-12 text-zinc-700 mb-4" />
              <h3 className="text-xl font-medium text-zinc-400">No audit history found</h3>
              <p className="text-zinc-500 mt-2 mb-6 max-w-md text-center">Run a system audit to verify the integrity of your database, security policies, and frontend routes.</p>
              <Button onClick={handleRunAudit} variant="secondary">Start First Scan</Button>
          </div>
      )}
    </div>
  );
}