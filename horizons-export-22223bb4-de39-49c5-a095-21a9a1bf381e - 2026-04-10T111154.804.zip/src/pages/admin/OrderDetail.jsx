
import React, { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { supabase } from "@/lib/supabaseClient";
import { ArrowLeft, Mail, Package, DollarSign, Calendar, Clock, Loader2, AlertTriangle, Tag } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/components/ui/use-toast";
import { Helmet } from 'react-helmet';
import { format } from 'date-fns';

export default function OrderDetailPage() {
    const { id } = useParams();
    const navigate = useNavigate();
    const { toast } = useToast();
    const [cartInfo, setCartInfo] = useState(null);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        async function fetchOrderDetails() {
            setLoading(true);
            try {
                const { data, error } = await supabase
                    .from('round_carts')
                    .select(`
                        id, status, created_at, updated_at, user_id, round_id,
                        rounds (title),
                        profiles!round_carts_user_id_fkey (name, full_name, email),
                        round_cart_items (
                            id, qty, unit_price, original_unit_price, status, product_id, variant_id,
                            products (title, SKU, thumbnail_url),
                            product_variants (title, sku)
                        )
                    `)
                    .eq('id', id)
                    .single();

                if (error) throw error;
                
                if (!data) {
                    toast({ variant: "destructive", title: "Not Found", description: "Could not find Order details." });
                    setCartInfo(null);
                    return;
                }
                
                setCartInfo(data);
            } catch (error) {
                console.error("Error fetching order details:", error);
                toast({ variant: "destructive", title: "Error", description: "Failed to load order details." });
            } finally {
                setLoading(false);
            }
        }
        
        if (id) fetchOrderDetails();
    }, [id, toast]);

    const getStatusBadge = (status) => {
        const normalized = (status || '').toLowerCase();
        const styles = {
            paid: 'bg-emerald-500/10 text-emerald-500 border-emerald-500/20',
            completed: 'bg-blue-500/10 text-blue-500 border-blue-500/20',
            cancelled: 'bg-red-500/10 text-red-500 border-red-500/20',
            canceled: 'bg-red-500/10 text-red-500 border-red-500/20',
            failed_round: 'bg-red-500/10 text-red-500 border-red-500/20',
            expired: 'bg-zinc-800 text-zinc-500 border-zinc-700',
            pending: 'bg-yellow-500/10 text-yellow-500 border-yellow-500/20',
            confirmed: 'bg-yellow-500/10 text-yellow-500 border-yellow-500/20',
            eligible_to_pay: 'bg-blue-500/10 text-blue-400 border-blue-500/20',
            reserved: 'bg-yellow-500/10 text-yellow-500 border-yellow-500/20',
            active: 'bg-blue-500/10 text-blue-400 border-blue-500/20'
        };
        const defaultStyle = 'bg-zinc-800 text-zinc-400 border-zinc-700';
        return (
            <Badge variant="outline" className={`px-3 py-1 uppercase tracking-wider text-xs font-bold ${styles[normalized] || defaultStyle}`}>
                {normalized.replace(/_/g, ' ') || 'UNKNOWN'}
            </Badge>
        );
    };

    if (loading) {
        return (
            <div className="flex flex-col items-center justify-center min-h-[60vh] bg-black">
                <Loader2 className="h-10 w-10 animate-spin text-yellow-500 mb-4" />
                <p className="text-zinc-500 font-medium">Loading order details...</p>
            </div>
        );
    }

    if (!cartInfo) {
        return (
            <div className="max-w-[1200px] mx-auto p-8">
                <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-12 text-center">
                    <AlertTriangle className="h-12 w-12 text-red-500 mx-auto mb-4" />
                    <h2 className="text-xl font-bold text-white mb-2">Order Not Found</h2>
                    <p className="text-zinc-400 mb-6">The order you are looking for does not exist.</p>
                    <Button onClick={() => navigate('/admin/orders')} className="bg-yellow-500 text-black hover:bg-yellow-400">
                        Back to Orders
                    </Button>
                </div>
            </div>
        );
    }

    const items = cartInfo.round_cart_items || [];
    let totalItems = 0;
    let totalAmount = 0;
    let totalSavings = 0;

    items.forEach(item => {
        const qty = item.qty || 1;
        const price = Number(item.unit_price || 0);
        const originalPrice = Number(item.original_unit_price || price);
        
        totalItems += qty;
        totalAmount += qty * price;
        
        if (originalPrice > price) {
            totalSavings += (originalPrice - price) * qty;
        }
    });

    const customerName = cartInfo.profiles?.name || cartInfo.profiles?.full_name || 'Unknown User';
    const customerEmail = cartInfo.profiles?.email || 'No email provided';

    return (
        <div className="max-w-[1400px] mx-auto p-6 space-y-8">
            <Helmet>
                <title>Order Details | Coop Stones Admin</title>
            </Helmet>

            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-zinc-800 pb-6">
                <div className="flex items-center gap-4">
                    <Button 
                        variant="outline" 
                        size="icon" 
                        onClick={() => navigate('/admin/orders')}
                        className="rounded-full border-zinc-700 bg-zinc-900 hover:bg-zinc-800 text-zinc-300"
                    >
                        <ArrowLeft size={20} />
                    </Button>
                    <div>
                        <div className="flex items-center gap-3">
                            <h1 className="text-2xl md:text-3xl font-bold text-white">Order Details</h1>
                            {getStatusBadge(cartInfo.status)}
                        </div>
                        <p className="text-sm font-mono text-zinc-500 mt-1">ID: {cartInfo.id}</p>
                    </div>
                </div>
                <div className="bg-zinc-900 px-4 py-2 rounded-lg border border-zinc-800 flex flex-col items-end">
                     <span className="text-xs text-zinc-500 font-semibold uppercase tracking-wider">Order Type</span>
                     <span className="text-sm text-zinc-200 font-medium flex items-center gap-1.5">
                         <Package className="w-3.5 h-3.5 text-blue-400" /> Round Order
                     </span>
                </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <div className="lg:col-span-1 space-y-6">
                    <Card className="border-zinc-800 bg-zinc-900/50 shadow-sm">
                        <CardHeader className="pb-3 border-b border-zinc-800/50">
                            <CardTitle className="flex items-center gap-2 text-white text-base">
                                <Package className="text-yellow-500 w-5 h-5"/> Round Information
                            </CardTitle>
                        </CardHeader>
                        <CardContent className="pt-4 space-y-4">
                            <div>
                                <p className="text-xs text-zinc-500 uppercase tracking-wider font-bold mb-1">Round Name</p>
                                <p className="text-zinc-200 font-medium">{cartInfo.rounds?.title || 'N/A'}</p>
                            </div>
                            <div>
                                <p className="text-xs text-zinc-500 uppercase tracking-wider font-bold mb-1">Created At</p>
                                <div className="flex items-center text-zinc-300 text-sm">
                                    <Calendar className="w-4 h-4 mr-2 text-zinc-500" />
                                    {format(new Date(cartInfo.created_at), 'MMMM dd, yyyy')}
                                </div>
                            </div>
                            <div>
                                <p className="text-xs text-zinc-500 uppercase tracking-wider font-bold mb-1">Last Updated</p>
                                <div className="flex items-center text-zinc-400 text-sm">
                                    <Clock className="w-4 h-4 mr-2 text-zinc-600" />
                                    {cartInfo.updated_at ? format(new Date(cartInfo.updated_at), 'MMM dd, yyyy hh:mm:ss a') : 'N/A'}
                                </div>
                            </div>
                        </CardContent>
                    </Card>

                    <Card className="border-zinc-800 bg-zinc-900/50 shadow-sm">
                        <CardHeader className="pb-3 border-b border-zinc-800/50">
                            <CardTitle className="flex items-center gap-2 text-white text-base">
                                <Mail className="text-blue-400 w-5 h-5"/> Customer
                            </CardTitle>
                        </CardHeader>
                        <CardContent className="pt-4 space-y-4">
                            <div>
                                <p className="text-xs text-zinc-500 uppercase tracking-wider font-bold mb-1">Name</p>
                                <p className="text-zinc-200 font-medium">{customerName}</p>
                            </div>
                            <div>
                                <p className="text-xs text-zinc-500 uppercase tracking-wider font-bold mb-1">Email</p>
                                <a href={`mailto:${customerEmail}`} className="text-yellow-500 hover:underline font-medium break-all">
                                    {customerEmail}
                                </a>
                            </div>
                            <div>
                                <p className="text-xs text-zinc-500 uppercase tracking-wider font-bold mb-1">User ID</p>
                                <p className="text-zinc-500 text-xs font-mono break-all">{cartInfo.user_id}</p>
                            </div>
                        </CardContent>
                    </Card>

                    <Card className="border-zinc-800 bg-zinc-900 shadow-sm">
                        <CardHeader className="pb-3 border-b border-zinc-800/50">
                            <CardTitle className="flex items-center gap-2 text-white text-base">
                                <DollarSign className="text-emerald-500 w-5 h-5"/> Summary
                            </CardTitle>
                        </CardHeader>
                        <CardContent className="pt-4 space-y-4">
                            <div className="flex justify-between items-center text-sm">
                                <span className="text-zinc-400">Total Items</span>
                                <span className="text-zinc-200 font-mono">{totalItems}</span>
                            </div>
                            {totalSavings > 0 && (
                                <div className="flex justify-between items-center text-sm text-green-400">
                                    <span className="flex items-center gap-1"><Tag className="w-3 h-3"/> Total Savings</span>
                                    <span className="font-bold">+${totalSavings.toFixed(2)}</span>
                                </div>
                            )}
                            <div className="flex justify-between items-center text-lg font-bold pt-2 border-t border-zinc-800">
                                <span className="text-white">Total Amount</span>
                                <span className="text-emerald-400">${totalAmount.toFixed(2)}</span>
                            </div>
                        </CardContent>
                    </Card>
                </div>

                <div className="lg:col-span-2">
                    <Card className="border-zinc-800 bg-zinc-900/50 shadow-sm h-full">
                        <CardHeader className="pb-4 border-b border-zinc-800/50">
                            <CardTitle className="text-white">Order Items</CardTitle>
                        </CardHeader>
                        <CardContent className="p-0">
                            <div className="overflow-x-auto">
                                <table className="w-full text-sm text-left">
                                    <thead className="bg-zinc-950/50 text-zinc-400 font-medium border-b border-zinc-800">
                                        <tr>
                                            <th className="px-6 py-4">Product</th>
                                            <th className="px-4 py-4">SKU / Variant</th>
                                            <th className="px-4 py-4 text-center">Qty</th>
                                            <th className="px-4 py-4 text-right">Price</th>
                                            <th className="px-6 py-4 text-right">Subtotal</th>
                                        </tr>
                                    </thead>
                                    <tbody className="divide-y divide-zinc-800/50">
                                        {items.map((item) => {
                                            const productTitle = item.products?.title || 'Unknown Product';
                                            const variantTitle = item.product_variants?.title;
                                            const displaySku = item.product_variants?.sku || item.products?.SKU || 'N/A';
                                            const imgUrl = item.products?.thumbnail_url;
                                            const price = Number(item.unit_price || 0);
                                            const originalPrice = Number(item.original_unit_price || price);
                                            const hasDiscount = originalPrice > price;
                                            const savings = hasDiscount ? (originalPrice - price) * item.qty : 0;
                                            const subtotal = price * item.qty;

                                            return (
                                                <tr key={item.id} className="hover:bg-zinc-800/20 transition-colors">
                                                    <td className="px-6 py-4">
                                                        <div className="flex items-center gap-3">
                                                            {imgUrl ? (
                                                                <div className="h-10 w-10 rounded border border-zinc-700 overflow-hidden flex-shrink-0 bg-white">
                                                                    <img src={imgUrl} alt={productTitle} className="h-full w-full object-contain" />
                                                                </div>
                                                            ) : (
                                                                <div className="h-10 w-10 rounded border border-zinc-700 bg-zinc-800 flex items-center justify-center flex-shrink-0">
                                                                    <Package className="h-5 w-5 text-zinc-500" />
                                                                </div>
                                                            )}
                                                            <span className="font-medium text-zinc-200 line-clamp-2">{productTitle}</span>
                                                        </div>
                                                    </td>
                                                    <td className="px-4 py-4">
                                                        <div className="flex flex-col gap-1">
                                                            <span className="font-mono text-xs text-zinc-400">{displaySku}</span>
                                                            {variantTitle && (
                                                                <Badge variant="secondary" className="bg-zinc-800 text-zinc-300 border-none w-fit text-[10px] py-0">
                                                                    {variantTitle}
                                                                </Badge>
                                                            )}
                                                        </div>
                                                    </td>
                                                    <td className="px-4 py-4 text-center font-medium text-zinc-300">{item.qty}</td>
                                                    <td className="px-4 py-4 text-right">
                                                        <div className="flex flex-col items-end">
                                                            <span className="text-zinc-200">${price.toFixed(2)}</span>
                                                            {hasDiscount && (
                                                                <span className="text-xs text-zinc-500 line-through">${originalPrice.toFixed(2)}</span>
                                                            )}
                                                        </div>
                                                    </td>
                                                    <td className="px-6 py-4 text-right">
                                                        <div className="flex flex-col items-end">
                                                            <span className="font-bold text-emerald-400">${subtotal.toFixed(2)}</span>
                                                            {savings > 0 && (
                                                                <span className="text-[10px] text-green-500 uppercase font-semibold tracking-wide">
                                                                    Saved ${savings.toFixed(2)}
                                                                </span>
                                                            )}
                                                        </div>
                                                    </td>
                                                </tr>
                                            );
                                        })}
                                    </tbody>
                                </table>
                            </div>
                        </CardContent>
                    </Card>
                </div>
            </div>
        </div>
    );
}
