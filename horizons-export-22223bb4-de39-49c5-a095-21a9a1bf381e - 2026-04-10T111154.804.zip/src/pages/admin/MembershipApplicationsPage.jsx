import React, { useEffect, useState } from 'react';
import { DragDropContext, Droppable } from "@hello-pangea/dnd";
import { supabase } from '@/lib/supabaseClient';
import { useAuth } from '@/contexts/AuthContext';
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Label } from "@/components/ui/label";
import { useToast } from "@/components/ui/use-toast";
import { Textarea } from "@/components/ui/textarea";
import { Search, Loader2, LayoutList, Calendar as CalendarIcon, XCircle, Plus, Settings } from "lucide-react";
import ApplicationCard from '@/admin/components/ApplicationCard';
import { format, isSameDay } from 'date-fns';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { Calendar } from "@/components/ui/calendar";
import { cn } from "@/lib/utils";
import { 
  DEFAULT_COLUMNS, 
  normalizeColumnName, 
  getCanonicalStatus, 
  getStatusColor, 
  sortColumns 
} from '@/lib/membershipStatusUtils';
import { membershipAutomation } from '@/lib/membershipAutomation';

import ColumnEditModal from '@/components/admin/ColumnEditModal';
import ApplicationDetailsModal from '@/components/admin/ApplicationDetailsModal';

export default function MembershipApplicationsPage() {
  const { user } = useAuth();
  const { toast } = useToast();
  
  // Data State
  const [columns, setColumns] = useState([]);
  const [applications, setApplications] = useState([]);
  const [loading, setLoading] = useState(true);

  // Filter State
  const [search, setSearch] = useState("");
  const [filterPlan, setFilterPlan] = useState("all");
  const [filterStatus, setFilterStatus] = useState("all");
  const [filterDate, setFilterDate] = useState(null);

  // Interaction State
  const [selectedApplicationId, setSelectedApplicationId] = useState(null);
  const [selectedAppModal, setSelectedAppModal] = useState(null);
  const [editingColumn, setEditingColumn] = useState(null);

  // Add Column State
  const [showAddColumnModal, setShowAddColumnModal] = useState(false);
  const [newColumnName, setNewColumnName] = useState("");
  const [creatingColumn, setCreatingColumn] = useState(false);

  // Approve/Reject Modals
  const [approveConfirmOpen, setApproveConfirmOpen] = useState(false);
  const [showRejectDialog, setShowRejectDialog] = useState(false);
  const [rejectReason, setRejectReason] = useState("");
  const [isProcessing, setIsProcessing] = useState(false);

  const fetchColumns = async () => {
    try {
      const { data: cols, error: colsError } = await supabase
        .from('crm_columns')
        .select('*')
        .order('order', { ascending: true });
        
      if (colsError) throw colsError;

      let currentCols = cols || [];
      
      if (currentCols.length === 0) {
          const defaultsToInsert = DEFAULT_COLUMNS.map((name, i) => ({
             name,
             order: i + 1,
             is_default: true
          }));
          const { data: insertedCols, error: insertError } = await supabase
            .from('crm_columns')
            .insert(defaultsToInsert)
            .select('*');
            
          if (!insertError && insertedCols) currentCols = insertedCols;
      }

      const uniqueColsMap = new Map();
      currentCols.forEach(c => {
         const normName = normalizeColumnName(c.name);
         if (!uniqueColsMap.has(normName)) {
            uniqueColsMap.set(normName, { ...c, name: normName });
         }
      });

      const uniqueCols = Array.from(uniqueColsMap.values());
      const sortedCols = sortColumns(uniqueCols);
      
      setColumns(sortedCols);
      return sortedCols;
    } catch (error) {
      console.error("Columns fetch error:", error);
      toast({ variant: "destructive", title: "Error", description: "Failed to load pipeline columns." });
      setColumns([]);
      return [];
    }
  };

  const fetchApplications = async () => {
    try {
      const { data: apps, error: appsError } = await supabase
        .from('membership_applications')
        .select('*')
        .order('created_at', { ascending: false });
        
      if (appsError) throw appsError;

      const uniqueAppsMap = new Map();
      (apps || []).forEach(app => {
         if (!uniqueAppsMap.has(app.id)) {
            uniqueAppsMap.set(app.id, {
                ...app,
                status: getCanonicalStatus(app.status)
            });
         }
      });
      
      const uniqueApps = Array.from(uniqueAppsMap.values());
      setApplications(uniqueApps);
    } catch (error) {
      console.error("Applications fetch error:", error);
      toast({ variant: "destructive", title: "Error", description: "Failed to load pipeline applications." });
      setApplications([]);
    }
  };

  const fetchData = async () => {
    if (columns.length === 0 && applications.length === 0) setLoading(true);
    await Promise.all([fetchColumns(), fetchApplications()]);
    setLoading(false);
  };

  useEffect(() => {
    fetchData();
  }, []);

  useEffect(() => {
    const appsChannel = supabase.channel('crm-apps')
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'membership_applications' }, (payload) => {
         setApplications(prev => {
            const map = new Map(prev.map(p => [p.id, p]));
            if (!map.has(payload.new.id)) {
               map.set(payload.new.id, { ...payload.new, status: getCanonicalStatus(payload.new.status) });
            }
            return Array.from(map.values()).sort((a, b) => new Date(b.created_at) - new Date(a.created_at));
         });
      })
      .on('postgres_changes', { event: 'UPDATE', schema: 'public', table: 'membership_applications' }, (payload) => {
         setApplications(prev => {
            const map = new Map(prev.map(p => [p.id, p]));
            map.set(payload.new.id, { ...payload.new, status: getCanonicalStatus(payload.new.status) });
            return Array.from(map.values()).sort((a, b) => new Date(b.created_at) - new Date(a.created_at));
         });
      })
      .on('postgres_changes', { event: 'DELETE', schema: 'public', table: 'membership_applications' }, (payload) => {
         setApplications(prev => prev.filter(p => p.id !== payload.old.id));
      })
      .subscribe();

    const colsChannel = supabase.channel('crm-cols')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'crm_columns' }, () => {
         fetchColumns();
      })
      .subscribe();

    return () => {
      supabase.removeChannel(appsChannel);
      supabase.removeChannel(colsChannel);
    };
  }, []);

  const uniqueApplications = Array.from(new Map(applications.map(app => [app.id, app])).values());
  
  const filteredApps = uniqueApplications.filter(app => {
    const matchesSearch = 
      app.company_name?.toLowerCase().includes(search.toLowerCase()) ||
      app.applicant_name?.toLowerCase().includes(search.toLowerCase()) ||
      app.email?.toLowerCase().includes(search.toLowerCase());

    const matchesPlan = filterPlan === 'all' || app.plan?.toLowerCase() === filterPlan.toLowerCase();
    const appStatus = getCanonicalStatus(app.status);
    const matchesStatus = filterStatus === 'all' || appStatus === filterStatus;
    const matchesDate = !filterDate || (app.created_at && isSameDay(new Date(app.created_at), filterDate));

    return matchesSearch && matchesPlan && matchesStatus && matchesDate;
  });

  const appsByColumn = columns.reduce((acc, col) => {
    acc[col.id] = filteredApps.filter(app => app.column_id === col.id);
    return acc;
  }, {});

  const clearFilters = () => {
    setSearch("");
    setFilterPlan("all");
    setFilterStatus("all");
    setFilterDate(null);
  };

  const hasActiveFilters = search || filterPlan !== 'all' || filterStatus !== 'all' || filterDate;

  const onDragEnd = async (result) => {
    const { destination, source, draggableId } = result;

    if (!destination) return;
    if (destination.droppableId === source.droppableId && destination.index === source.index) return;

    const targetCol = columns.find(c => c.id === destination.droppableId);
    if (!targetCol) return;

    const canonicalStatus = getCanonicalStatus(targetCol.name);
    const originalApps = [...applications];
    
    if (canonicalStatus === 'CONTRACT SIGNED') {
       toast({ variant: "destructive", title: "Action Not Allowed", description: "CONTRACT SIGNED must be triggered by contract-signature automation or explicit backend action" });
       setApplications(originalApps);
       return;
    }

    // Optimistic Update
    setApplications(prev => {
      const map = new Map(prev.map(p => [p.id, p]));
      const existing = map.get(draggableId);
      if (existing) {
         map.set(draggableId, { ...existing, column_id: targetCol.id, status: canonicalStatus });
      }
      return Array.from(map.values());
    });

    try {
      if (canonicalStatus === 'APPROVED / CONTRACT SENT') {
         // Open confirmation dialog without auto-processing instantly
         setSelectedApplicationId(draggableId);
         setApproveConfirmOpen(true);
         setApplications(originalApps); // Revert optimistic update until user confirms in the dialog
         return;
      } 
      
      if (canonicalStatus === 'REJECTED') {
         setSelectedApplicationId(draggableId);
         setShowRejectDialog(true);
         setApplications(originalApps); // Revert optimistic until rejected
         return;
      }

      const { error } = await supabase
        .from('membership_applications')
        .update({ column_id: targetCol.id, status: canonicalStatus })
        .eq('id', draggableId);

      if (error) throw error;
    } catch (error) {
      toast({ variant: "destructive", title: "Move Failed", description: error.message });
      setApplications(originalApps);
    }
  };

  const handleApproveConfirm = async () => {
    if (!selectedApplicationId) return;
    setIsProcessing(true);

    try {
       const result = await membershipAutomation.handleApproveApplication(selectedApplicationId);
       
       // Update local state with returned column ID and status without needing a full refresh
       setApplications(prev => {
          const map = new Map(prev.map(p => [p.id, p]));
          const existing = map.get(selectedApplicationId);
          if (existing) {
             const newStatus = result.status || 'APPROVED / CONTRACT SENT';
             const newColId = columns.find(c => c.name === newStatus)?.id || existing.column_id;
             
             map.set(selectedApplicationId, { 
               ...existing, 
               status: newStatus, 
               column_id: newColId,
               contract_url: result.contractUrl || existing.contract_url,
               approved_at: new Date().toISOString()
             });
          }
          return Array.from(map.values());
       });

       toast({ title: "Application Approved", description: result.message });
       setApproveConfirmOpen(false);
       setSelectedApplicationId(null);
       fetchApplications(); // Ensure sync with backend properly
    } catch (err) {
       toast({ variant: "destructive", title: "Approval Error", description: err.message });
       fetchApplications(); 
    } finally {
       setIsProcessing(false);
    }
  };

  const handleReject = async () => {
    if (!selectedApplicationId) return;
    setIsProcessing(true);

    try {
       const result = await membershipAutomation.handleRejectApplication(selectedApplicationId, rejectReason);
       
       // Update local state with returned column ID and status
       setApplications(prev => {
          const map = new Map(prev.map(p => [p.id, p]));
          const existing = map.get(selectedApplicationId);
          if (existing) {
             map.set(selectedApplicationId, { ...existing, status: result.status, column_id: result.columnId });
          }
          return Array.from(map.values());
       });

       toast({ title: "Application Rejected", description: result.message });
       setShowRejectDialog(false);
       setRejectReason("");
       setSelectedApplicationId(null);
       fetchApplications();
    } catch (err) {
       toast({ variant: "destructive", title: "Rejection Error", description: err.message });
       fetchApplications();
    } finally {
       setIsProcessing(false);
    }
  };

  const handleAddColumn = async (e) => {
    e.preventDefault();
    const name = normalizeColumnName(newColumnName);
    if (!name) return;

    if (columns.some(c => c.name === name)) {
        toast({ variant: "destructive", title: "Error", description: "Column already exists." });
        return;
    }

    setCreatingColumn(true);
    try {
      const maxOrder = columns.length > 0 ? Math.max(...columns.map(c => c.order || 0)) : 0;
      const { error } = await supabase.from('crm_columns').insert([{ name, order: maxOrder + 1, is_default: false }]);
      if (error) throw error;

      toast({ title: "Success", description: `Column "${name}" created successfully.` });
      setShowAddColumnModal(false);
      setNewColumnName("");
      fetchColumns(); 
    } catch (error) {
      toast({ variant: "destructive", title: "Error", description: error.message });
    } finally {
      setCreatingColumn(false);
    }
  };

  const authorName = user?.user_metadata?.full_name || user?.email || 'Admin';
  const renderedColumns = new Set();

  return (
    <div className="w-full max-w-none min-h-[80vh] flex flex-col">
      <div className="flex flex-col gap-6 mb-6">
         <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center">
            <div>
              <h2 className="text-2xl font-bold text-white flex items-center gap-2">
                <LayoutList className="text-yellow-500" /> Membership Pipeline
              </h2>
              <p className="text-sm text-zinc-400">Manage incoming applications and track their status.</p>
            </div>
            <Button
              onClick={() => setShowAddColumnModal(true)}
              className="mt-4 sm:mt-0 bg-yellow-500/15 border border-yellow-400/30 text-yellow-200 hover:bg-yellow-500/25 hover:text-yellow-100 transition-colors"
            >
              <Plus className="w-4 h-4 mr-2" /> Add Column
            </Button>
         </div>
         
         <div className="bg-zinc-900/50 border border-zinc-800 p-4 rounded-xl flex flex-col lg:flex-row gap-4">
            <div className="flex-1 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
               <div className="relative">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-zinc-500 w-4 h-4" />
                  <Input 
                    placeholder="Search applications..." 
                    value={search}
                    onChange={(e) => setSearch(e.target.value)}
                    className="pl-9 bg-zinc-950 border-zinc-800 focus:ring-yellow-500 h-10"
                  />
               </div>

               <Select value={filterPlan} onValueChange={setFilterPlan}>
                  <SelectTrigger className="h-10 bg-zinc-950 border-zinc-800">
                    <SelectValue placeholder="Filter by Plan" />
                  </SelectTrigger>
                  <SelectContent className="bg-zinc-950 border-zinc-800 text-white">
                    <SelectItem value="all">All Plans</SelectItem>
                    <SelectItem value="gold">Gold</SelectItem>
                    <SelectItem value="platinum">Platinum</SelectItem>
                  </SelectContent>
               </Select>

               <Select value={filterStatus} onValueChange={setFilterStatus}>
                  <SelectTrigger className="h-10 bg-zinc-950 border-zinc-800">
                    <SelectValue placeholder="Filter by Status" />
                  </SelectTrigger>
                  <SelectContent className="bg-zinc-950 border-zinc-800 text-white">
                    <SelectItem value="all">All Statuses</SelectItem>
                    {columns.map(col => {
                       if (renderedColumns.has(col.name)) return null;
                       return <SelectItem key={col.id} value={col.name}>{col.name}</SelectItem>;
                    })}
                  </SelectContent>
               </Select>

               <Popover>
                  <PopoverTrigger asChild>
                    <Button
                      variant="outline"
                      className={cn(
                        "h-10 justify-start text-left font-normal bg-zinc-950 border-zinc-800 hover:bg-zinc-900 hover:text-white",
                        !filterDate && "text-muted-foreground"
                      )}
                    >
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {filterDate ? format(filterDate, "PPP") : <span>Filter by date</span>}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0 bg-zinc-950 border-zinc-800" align="start">
                    <Calendar
                      mode="single"
                      selected={filterDate}
                      onSelect={setFilterDate}
                      initialFocus
                      className="text-white"
                    />
                  </PopoverContent>
                </Popover>
            </div>

            {hasActiveFilters && (
               <Button 
                  variant="ghost" 
                  onClick={clearFilters}
                  className="shrink-0 h-10 text-zinc-400 hover:text-white hover:bg-zinc-800"
               >
                  <XCircle className="w-4 h-4 mr-2" />
                  Clear Filters
               </Button>
            )}
         </div>
      </div>

      {loading ? (
        <div className="flex-1 flex items-center justify-center">
          <Loader2 className="w-8 h-8 animate-spin text-yellow-500" />
        </div>
      ) : columns.length === 0 ? (
        <div className="flex-1 flex flex-col items-center justify-center border border-zinc-800 border-dashed rounded-xl bg-zinc-900/30 p-8">
           <LayoutList className="w-12 h-12 text-zinc-600 mb-4" />
           <p className="text-zinc-400 text-lg">No pipeline columns found.</p>
           <p className="text-zinc-500 text-sm mb-6">Create your first column to start managing applications.</p>
           <Button onClick={() => setShowAddColumnModal(true)} className="bg-yellow-500 text-black hover:bg-yellow-400">
             <Plus className="w-4 h-4 mr-2" /> Add Column
           </Button>
        </div>
      ) : (
        <DragDropContext onDragEnd={onDragEnd}>
          <div className="flex-1 pb-4 overflow-x-auto custom-scrollbar">
            <div className="flex gap-4 h-full min-w-max pb-4" style={{ minWidth: columns.length * 340 }}>
              {columns.map((col) => {
                if (renderedColumns.has(col.name)) return null;
                renderedColumns.add(col.name);
                
                const columnApps = appsByColumn[col.id] || [];
                const uniqueColumnApps = Array.from(new Map(columnApps.map(a => [a.id, a])).values());
                const count = uniqueColumnApps.length;
                
                return (
                  <div 
                    key={col.id} 
                    className="w-[320px] shrink-0 bg-gradient-to-b from-zinc-900/50 to-zinc-950/80 border border-zinc-800 rounded-xl flex flex-col h-full max-h-[calc(100vh-280px)] shadow-lg"
                  >
                    <div className="p-3 border-b border-zinc-800 flex justify-between items-center sticky top-0 bg-zinc-950/90 backdrop-blur rounded-t-xl z-10">
                      <div className="flex items-center gap-2 overflow-hidden flex-1">
                        <h3 className="font-semibold text-zinc-200 text-xs uppercase tracking-wider truncate" title={col.name}>{col.name}</h3>
                        <Badge variant="secondary" className="bg-zinc-800 text-zinc-400 text-[10px] px-2 py-0.5 rounded-full">{count}</Badge>
                      </div>
                      <Button 
                        variant="ghost" 
                        size="icon" 
                        className="h-7 w-7 text-zinc-400 hover:text-white hover:bg-zinc-800 shrink-0"
                        onClick={() => setEditingColumn(col)}
                      >
                        <Settings className="w-4 h-4" />
                      </Button>
                    </div>
                    <Droppable droppableId={col.id}>
                      {(provided, snapshot) => (
                        <div
                          {...provided.droppableProps}
                          ref={provided.innerRef}
                          className={cn(
                            "flex-1 p-3 overflow-y-auto custom-scrollbar transition-colors duration-200",
                            snapshot.isDraggingOver ? "bg-zinc-800/30" : ""
                          )}
                        >
                          {uniqueColumnApps.map((app, index) => (
                            <ApplicationCard 
                              key={app.id} 
                              application={app} 
                              index={index} 
                              onClick={() => setSelectedAppModal(app)}
                              badgeClassName={getStatusColor(col.name)}
                            />
                          ))}
                          {provided.placeholder}
                        </div>
                      )}
                    </Droppable>
                  </div>
                )
              })}
            </div>
          </div>
        </DragDropContext>
      )}

      <Dialog open={approveConfirmOpen} onOpenChange={setApproveConfirmOpen}>
        <DialogContent className="bg-zinc-950 border-zinc-800 text-white">
          <DialogHeader>
            <DialogTitle>Approve Application</DialogTitle>
            <DialogDescription>Are you sure you want to approve this application? This will move the application to Approved and send the contract email automatically.</DialogDescription>
          </DialogHeader>
          <DialogFooter>
             <Button variant="ghost" onClick={() => setApproveConfirmOpen(false)}>Cancel</Button>
             <Button className="bg-green-600 hover:bg-green-500 text-white" onClick={handleApproveConfirm} disabled={isProcessing}>
                {isProcessing ? <Loader2 className="w-4 h-4 mr-2 animate-spin"/> : null} Confirm Approval
             </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={showRejectDialog} onOpenChange={setShowRejectDialog}>
        <DialogContent className="bg-zinc-950 border-zinc-800 text-white">
          <DialogHeader>
            <DialogTitle>Reject Application</DialogTitle>
            <DialogDescription>Provide a reason. The applicant will receive a rejection email.</DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
             <Textarea 
                placeholder="Reason for rejection..." 
                value={rejectReason}
                onChange={e => setRejectReason(e.target.value)}
                className="bg-zinc-900 border-zinc-800 min-h-[100px]"
             />
          </div>
          <DialogFooter>
             <Button variant="ghost" onClick={() => setShowRejectDialog(false)}>Cancel</Button>
             <Button variant="destructive" onClick={handleReject} disabled={isProcessing || !rejectReason.trim()}>
                {isProcessing ? <Loader2 className="w-4 h-4 mr-2 animate-spin"/> : null} Reject & Notify
             </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <ColumnEditModal 
        isOpen={!!editingColumn}
        onClose={() => setEditingColumn(null)}
        column={editingColumn}
        applications={applications}
        onSaved={() => { setEditingColumn(null); fetchColumns(); }}
      />

      <ApplicationDetailsModal
        isOpen={!!selectedAppModal && !approveConfirmOpen && !showRejectDialog}
        onClose={() => setSelectedAppModal(null)}
        application={selectedAppModal}
        columns={columns}
        onUpdated={fetchApplications}
        authorName={authorName}
      />

      <Dialog open={showAddColumnModal} onOpenChange={setShowAddColumnModal}>
        <DialogContent className="bg-zinc-950 border-zinc-800 text-white">
          <DialogHeader>
            <DialogTitle>Add New Column</DialogTitle>
            <DialogDescription>Create a new column for your pipeline.</DialogDescription>
          </DialogHeader>
          <form onSubmit={handleAddColumn} className="space-y-4 pt-4">
            <div className="space-y-2">
              <Label htmlFor="columnName">Column Name</Label>
              <Input
                id="columnName"
                placeholder="e.g. Follow Up"
                value={newColumnName}
                onChange={(e) => setNewColumnName(e.target.value)}
                className="bg-zinc-900 border-zinc-800 uppercase"
                maxLength={50}
              />
            </div>
            <DialogFooter>
              <Button type="button" variant="ghost" onClick={() => setShowAddColumnModal(false)}>Cancel</Button>
              <Button 
                type="submit" 
                disabled={!newColumnName.trim() || creatingColumn}
                className="bg-yellow-500 text-black hover:bg-yellow-400"
              >
                {creatingColumn ? <><Loader2 className="w-4 h-4 mr-2 animate-spin" /> Creating...</> : "Create Column"}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}