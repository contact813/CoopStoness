
import React, { useState, useEffect, useCallback, useRef } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { 
  createProduct, 
  getProductById, 
  updateProduct, 
  getProductCollections,
  saveProductVariantsSystem, 
  updateProductCollections,
  getUniqueTypes,
  getUniqueVendors,
  getAllCollections,
  updateProductPriceRange,
  cleanProductData
} from '@/lib/adminProductsApi';
import { normalizeTags } from '@/lib/adminDataNormalizers';
import { sanitizeUuid } from '@/lib/idUtils';
import { invalidateProductsCache } from '@/lib/productsCache';
import { useProductsRefresh } from '@/contexts/ProductsContext';

import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import ImageGalleryManager from '@/admin/ImageGalleryManager';
import Toast from '@/components/Toast';
import { useToast } from '@/components/ui/use-toast';
import { Loader2, ArrowLeft, Save, AlertCircle, RefreshCw, Bug, Info } from 'lucide-react';
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";

import VendorCombobox from '@/components/admin/VendorCombobox';
import TypeCombobox from '@/components/admin/TypeCombobox';
import StatusSelect from '@/components/admin/StatusSelect';
import TagsMultiSelect from '@/components/admin/TagsMultiSelect';
import CollectionsMultiSelect from '@/components/admin/CollectionsMultiSelect';

import MatrixVariantBuilder from '@/components/admin/MatrixVariantBuilder.jsx';
import MatrixVariantsTable from '@/components/admin/MatrixVariantsTable.jsx';

const emptyModel = {
  title: "",
  vendor: "",
  type: "",
  price: 0,
  inventory: "0",
  description: "",
  images: [],
  tags: [], 
  status: "active",
  thumbnail_url: "",
  seo_description: "",
  collectionIds: [],
};

export default function ProductEditPage() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { toast: uiToast } = useToast();
  const { triggerRefresh } = useProductsRefresh() || {};
  
  console.log('[ProductEditPage] Product ID from params:', id);
  
  const isCreateMode = !id || id === 'new';
  const cleanId = !isCreateMode ? sanitizeUuid(id) : null;

  const [model, setModel] = useState(emptyModel);
  const [options, setOptions] = useState([]);
  const [variants, setVariants] = useState([]);

  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [pageError, setPageError] = useState(null);
  const [retryCount, setRetryCount] = useState(0);
  
  const [toast, setToast] = useState(null);
  const [validationErrors, setValidationErrors] = useState([]);
  const [showErrors, setShowErrors] = useState(false);
  
  const [typeOptions, setTypeOptions] = useState([]);
  const [vendorOptions, setVendorOptions] = useState([]);
  const [collectionOptions, setCollectionOptions] = useState([]);
  
  const [showDebug, setShowDebug] = useState(false);

  const titleRef = useRef(null);
  const priceRef = useRef(null);
  const imagesRef = useRef(null);

  const fetchProductData = async (productId) => {
    try {
        console.log('[ProductEditPage] Loading product:', productId);
        const { data: loadedProduct, error: fetchError } = await getProductById(productId);
        
        if (fetchError) {
          console.error('[ProductEditPage] Exception:', fetchError);
          throw new Error(fetchError.message || 'Failed to fetch product');
        }

        if (!loadedProduct) {
          throw new Error(`Product not found for ID: ${productId}`);
        }

        console.log('[ProductEditPage] Loaded product:', loadedProduct.id, 'thumbnail_url:', loadedProduct.thumbnail_url);

        const prodCollectionsRes = await getProductCollections(productId).catch(() => []);
        const normalizedTags = normalizeTags(loadedProduct.tags);

        const restoredImages = loadedProduct.thumbnail_url
          ? [{
              id: 'cover-image',
              url: loadedProduct.thumbnail_url,
              alt: loadedProduct.title || 'Product image',
              is_cover: true
            }]
          : [];

        console.log('[ProductEditPage] Restored images length:', restoredImages.length);

        const finalModel = {
           ...emptyModel,
           ...loadedProduct,
           inventory: String(loadedProduct.inventory ?? 0),
           price: Number(loadedProduct.price ?? 0), 
           images: restoredImages,
           tags: normalizedTags,
           description: loadedProduct.description || "",
           seo_description: loadedProduct.seo_description || "",
           thumbnail_url: loadedProduct.thumbnail_url || "",
           collectionIds: Array.isArray(prodCollectionsRes) ? prodCollectionsRes : []
        };

        console.log('[ProductEditPage] Final model structure:', { imagesCount: finalModel.images.length, thumbnail_url: finalModel.thumbnail_url });
        setModel(finalModel);
        
        const loadedOptions = Array.isArray(loadedProduct.options) ? loadedProduct.options : [];
        const loadedVariants = Array.isArray(loadedProduct.product_variants) ? loadedProduct.product_variants : [];
        
        setOptions(loadedOptions);
        setVariants(loadedVariants);
        
        setPageError(null);
        return loadedProduct;
    } catch (err) {
        console.error("[ProductEditPage] Fetch error:", err);
        setPageError(err.message || "Failed to load product data");
        throw err;
    }
  };

  useEffect(() => {
    let isMounted = true;
    
    if (!isCreateMode && !cleanId) {
        console.error('[ProductEditPage] Invalid ID detected:', id);
        setPageError(`Invalid Product ID detected: ${id}`);
        setLoading(false);
        return;
    }

    async function loadAllData() {
      setLoading(true);
      setPageError(null);
      setValidationErrors([]);
      setShowErrors(false);

      try {
        const [typesRes, vendorsRes, collectionsRes] = await Promise.allSettled([
          getUniqueTypes(),
          getUniqueVendors(),
          getAllCollections()
        ]);
        
        if (isMounted) {
            setTypeOptions(typesRes.status === 'fulfilled' && Array.isArray(typesRes.value) ? typesRes.value : []);
            setVendorOptions(vendorsRes.status === 'fulfilled' && Array.isArray(vendorsRes.value) ? vendorsRes.value : []);
            setCollectionOptions(collectionsRes.status === 'fulfilled' && Array.isArray(collectionsRes.value) ? collectionsRes.value : []);
        }

        if (isCreateMode) {
           if (isMounted) {
             setModel({ ...emptyModel });
             setLoading(false);
           }
           return;
        }

        if (isMounted) {
            await fetchProductData(cleanId);
        }
        
      } catch (error) {
        console.error("[ProductEditPage] Error loading product data:", error);
      } finally {
        if (isMounted) setLoading(false);
      }
    }

    loadAllData();
    return () => { isMounted = false; };
  }, [cleanId, isCreateMode, retryCount, id]);

  const handleRetry = () => {
    setRetryCount(prev => prev + 1);
  };

  const handleModelChange = useCallback((field, value) => {
    console.log(`[ProductEditPage] handleModelChange - Field: ${field}, Value:`, value);
    setModel(prev => ({ ...prev, [field]: value }));
  }, []);

  const handleVariantsChange = useCallback((updatedVariants) => {
    setVariants(Array.isArray(updatedVariants) ? updatedVariants : []);
  }, []);

  const handleOptionsChange = useCallback((updatedOptions) => {
      setOptions(Array.isArray(updatedOptions) ? updatedOptions : []);
  }, []);

  const validateForm = (data, vList, opts) => {
    const errors = [];
    if (!data.title || !data.title.trim()) errors.push("Product Name is required.");
    
    if (vList.length === 0 && (!opts || opts.length === 0)) {
        if (data.price <= 0) errors.push("Price must be greater than 0.");
    } else {
        if (vList.length === 0) errors.push("Variants must be generated before saving.");
        
        let invalidPriceCount = 0;
        vList.forEach(v => {
            if (parseFloat(v.price) <= 0 || isNaN(parseFloat(v.price))) invalidPriceCount++;
        });

        if (invalidPriceCount > 0) {
            errors.push(`Found ${invalidPriceCount} variant(s) with invalid pricing (must be > 0).`);
        }
    }
    
    return errors;
  };

  const scrollToError = (errors) => {
      if (!errors || errors.length === 0) return;
      const firstError = errors[0].toLowerCase();
      let targetRef = null;
      if (firstError.includes("name") || firstError.includes("title")) targetRef = titleRef;
      else if (firstError.includes("price") || firstError.includes("sku")) targetRef = priceRef;
      else if (firstError.includes("image")) targetRef = imagesRef;
      
      if (targetRef && targetRef.current) targetRef.current.scrollIntoView({ behavior: 'smooth', block: 'center' });
  };
  
  const handleSave = useCallback(async (e) => {
    if (e) { e.preventDefault(); e.stopPropagation(); }
    if (saving) return;

    setToast(null);
    setValidationErrors([]);
    setSaving(true);
    
    try {
        const safeVariants = Array.isArray(variants) ? variants : [];
        const safeOptions = Array.isArray(options) ? options : [];
        
        const frontendErrors = validateForm(model, safeVariants, safeOptions);
        if (frontendErrors.length > 0) {
            console.log('[ProductEditPage] Validation failed', frontendErrors);
            setValidationErrors(frontendErrors);
            setShowErrors(true);
            setToast({ type: 'warning', message: '⚠️ Please fix validation errors to save this product' });
            scrollToError(frontendErrors);
            setSaving(false);
            return;
        }

        const cleanModel = cleanProductData(model);
        const tagsCSV = Array.isArray(cleanModel.tags) ? cleanModel.tags.join(', ') : '';

        const coverUrl = model.thumbnail_url || (Array.isArray(model.images) && model.images.length > 0 ? model.images[0]?.url || model.images[0]?.path : '') || '';
        console.log('[ProductEditPage] Final Cover URL calculation:', coverUrl);

        const productPayload = {
          title: cleanModel.title,
          description: cleanModel.description,
          seo_description: cleanModel.seo_description,
          price: cleanModel.price,
          thumbnail_url: coverUrl,
          vendor: cleanModel.vendor,
          type: cleanModel.type,
          inventory: cleanModel.inventory,
          tags: tagsCSV,
          status: cleanModel.status || 'draft'
        };

        console.log('[ProductEditPage] Product payload:', { title: productPayload.title, thumbnail_url: productPayload.thumbnail_url });

        let targetId = cleanId;

        if (isCreateMode) {
            console.log('[ProductEditPage] Creating new product:', productPayload);
            const { data: newProduct, error: createErr } = await createProduct(productPayload);
            if (createErr) throw createErr;
            targetId = newProduct.id;
            console.log('[ProductEditPage] Created product:', targetId);
        } else {
            console.log('[ProductEditPage] Saving product:', targetId);
            const { error: updateErr } = await updateProduct(targetId, productPayload);
            if (updateErr) {
                 console.error('[ProductEditPage] Failed to update product:', updateErr);
                 throw updateErr;
            }
        }
        
        console.log('[ProductEditPage] Product saved successfully');

        try {
            const { error: colErr, skipped } = await updateProductCollections(targetId, model.collectionIds || []);
            if (skipped) {
                console.log("[ProductEditPage] Skipped collections update due to schema format rules.");
            } else if (colErr) {
                console.error("[ProductEditPage] Error updating collections:", colErr);
            }
        } catch (colErr) {
            console.error("[ProductEditPage] Collections error ignored:", colErr);
        }

        try {
            const finalVariants = safeVariants.map(v => ({
                ...v,
                image_url: v.image_url || v.image || null,
                image: v.image_url || v.image || null
            }));

            const { error: variantsErr } = await saveProductVariantsSystem(targetId, safeOptions, finalVariants);
            if (variantsErr) throw variantsErr;
            console.log('[ProductEditPage] Variants saved successfully');
            
            const { error: priceErr } = await updateProductPriceRange(targetId);
            if (priceErr) throw priceErr;
            console.log('[ProductEditPage] Price updated successfully');

            invalidateProductsCache();

            // Trigger global refresh context and dispatch custom event
            if (triggerRefresh) {
              triggerRefresh();
            }
            console.log('[ProductEditPage] Dispatching productSaved event for ID:', targetId);
            window.dispatchEvent(new CustomEvent('productSaved', { detail: { id: targetId } }));

            setToast({ type: 'success', message: '✅ Product saved successfully!' });
            setShowErrors(false);
            
            await fetchProductData(targetId);
            
            if (isCreateMode) {
                setTimeout(() => {
                     navigate(`/admin/products/${targetId}`, { replace: true });
                }, 500);
            }
            
        } catch (relError) {
            console.error('[ProductEditPage] Error saving variants/options:', relError);
            setPageError(`Saved partial data. Variants/options failed: ${relError.message}`);
            setToast({ type: 'error', message: `Saved partial data. Variants/options failed: ${relError.message}` });
        }

    } catch (error) {
        console.error('[ProductEditPage] Save Error:', error);
        setPageError(error.message || "An unexpected error occurred.");
        setToast({ type: 'error', message: error.message || "An unexpected error occurred." });
    } finally {
      setSaving(false);
    }
  }, [model, variants, options, isCreateMode, cleanId, navigate, uiToast, triggerRefresh]);

  if (loading) {
    return (
      <div className="flex flex-col justify-center items-center h-[60vh] text-zinc-400 gap-3">
        <Loader2 className="h-10 w-10 animate-spin text-yellow-500" />
        <p>Loading Product Data...</p>
      </div>
    );
  }

  if (pageError) {
      return (
          <div className="p-8 flex flex-col items-center justify-center min-h-[50vh] text-center">
              <Alert variant="destructive" className="max-w-md mb-6 border-red-900 bg-red-950/20 text-left">
                  <AlertCircle className="h-4 w-4" />
                  <AlertTitle>Error</AlertTitle>
                  <AlertDescription className="mt-2 text-red-200">
                    <p>{pageError}</p>
                    <p className="text-xs opacity-75 mt-2">Attempted ID: {id}</p>
                  </AlertDescription>
              </Alert>
              <div className="flex gap-4">
                 <Button onClick={() => navigate('/admin/products')} variant="ghost">
                   <ArrowLeft className="mr-2 h-4 w-4" /> Go Back
                 </Button>
                 <Button onClick={handleRetry} variant="outline">
                   <RefreshCw className="mr-2 h-4 w-4" /> Retry
                 </Button>
              </div>
          </div>
      );
  }

  const hasVariants = Array.isArray(variants) && variants.length > 0;
  const currentProductId = cleanId || 'new';

  return (
    <div className="container mx-auto max-w-7xl px-4 py-8 text-white relative">
      <Toast toast={toast} onClose={() => setToast(null)} />

      <div className="absolute top-0 right-0 p-2">
         <Button type="button" variant="ghost" size="icon" className="text-zinc-800 hover:text-zinc-600" onClick={() => setShowDebug(!showDebug)}>
           <Bug className="h-4 w-4" />
         </Button>
      </div>
      
      {showDebug && (
        <div className="mb-4 p-4 bg-zinc-900 border border-zinc-800 rounded text-xs font-mono text-zinc-400 overflow-x-auto z-50 relative">
          <strong>DEBUG PANEL:</strong>
          <div>ID: {id} ({cleanId}) | Mode: {isCreateMode ? 'Create' : 'Edit'}</div>
          <div>Loading: {String(loading)}</div>
          <div>Images: {model.images?.length} | Variants: {variants?.length} | Options: {options?.length}</div>
        </div>
      )}

      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between mb-8 gap-4">
        <div>
           <Button type="button" variant="ghost" onClick={() => navigate('/admin/products')} className="mb-2 pl-0 text-zinc-400 hover:text-white">
             <ArrowLeft className="w-4 h-4 mr-2" /> Back to Products
           </Button>
           <h1 className="text-3xl font-bold">{isCreateMode ? 'New Product' : `Edit: ${model.title}`}</h1>
        </div>
        
        <div className="flex items-center gap-3">
            <Button type="button" variant="outline" onClick={() => navigate('/admin/products')}>Cancel</Button>
            <Button type="button" onClick={handleSave} disabled={saving} className="bg-yellow-500 text-black hover:bg-yellow-400 min-w-[120px]">
                {saving ? (
                    <>
                        <Loader2 className="h-4 w-4 animate-spin mr-2" />
                        Saving...
                    </>
                ) : (
                    <>
                        <Save className="h-4 w-4 mr-2" />
                        {isCreateMode ? 'Create Product' : 'Save Changes'}
                    </>
                )}
            </Button>
        </div>
      </div>
      
      <form onSubmit={(e) => { e.preventDefault(); handleSave(e); }} className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2 space-y-8">
            <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-6">
                <h2 className="text-xl font-semibold mb-6">Details</h2>
                
                {validationErrors.length > 0 && (
                    <Alert variant="destructive" className="mb-6 bg-red-950/40 border-red-900 text-red-400">
                        <AlertCircle className="h-4 w-4" />
                        <AlertTitle>Please fix the following errors:</AlertTitle>
                        <AlertDescription>
                            <ul className="list-disc pl-5 mt-2 space-y-1">
                                {validationErrors.map((err, i) => (
                                    <li key={i}>{err}</li>
                                ))}
                            </ul>
                        </AlertDescription>
                    </Alert>
                )}

                <div className="space-y-6">
                    <div ref={titleRef} className="scroll-mt-24">
                        <Label>Product Title <span className="text-red-500">*</span></Label>
                        <Input 
                            value={model.title} 
                            onChange={e => handleModelChange('title', e.target.value)} 
                            required 
                            className="bg-zinc-950 mt-2"
                        />
                    </div>
                    <div>
                        <Label>Description <span className="text-zinc-500 font-normal ml-2">(optional)</span></Label>
                        <Textarea 
                            value={model.description || ''} 
                            onChange={e => handleModelChange('description', e.target.value)} 
                            rows={6} 
                            className="bg-zinc-950 mt-2"
                            placeholder="Descrição do produto..."
                        />
                    </div>
                    <div>
                        <Label>SEO Description</Label>
                        <Textarea 
                            value={model.seo_description || ''} 
                            onChange={e => handleModelChange('seo_description', e.target.value)} 
                            rows={3} 
                            className="bg-zinc-950 mt-2"
                            placeholder="Brief description for search engines..."
                        />
                    </div>
                    
                    {hasVariants && (
                         <Alert className="bg-blue-500/10 border-blue-500/20 text-blue-400">
                             <Info className="h-4 w-4" />
                             <AlertTitle>Pricing Controlled by Variants</AlertTitle>
                             <AlertDescription>This product has variants. Pricing fields below act as fallbacks. Variants will control specific pricing and inventory.</AlertDescription>
                         </Alert>
                    )}

                    <div ref={priceRef} className="scroll-mt-24 grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <Label>Base Price {!hasVariants && <span className="text-red-500">*</span>}</Label>
                            <div className="relative mt-2">
                                <span className="absolute left-3 top-2.5 text-zinc-500">$</span>
                                <Input 
                                    type="number"
                                    min="0"
                                    step="0.01"
                                    value={model.price} 
                                    onChange={e => handleModelChange('price', e.target.value)} 
                                    className="bg-zinc-950 pl-8"
                                />
                            </div>
                        </div>

                        <div>
                            <Label>Available (Stock)</Label>
                            <Input 
                                type="number"
                                min="0"
                                value={model.inventory}
                                onChange={e => handleModelChange('inventory', e.target.value)}
                                disabled={hasVariants}
                                className="bg-zinc-950 mt-2 disabled:opacity-50 disabled:cursor-not-allowed"
                                title={hasVariants ? "Inventory is managed by variants" : "Set stock availability"}
                            />
                            {hasVariants && (
                                <p className="text-[10px] text-yellow-500/70 mt-1">Managed by variants</p>
                            )}
                        </div>
                    </div>
                </div>
            </div>

            <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-6" ref={imagesRef}>
                 <ImageGalleryManager
                    value={model.images}
                    onChange={imgs => {
                        console.log('[ProductEditPage] Images array changed:', imgs?.length);
                        handleModelChange('images', imgs);
                        
                        const currentCover = model.thumbnail_url;
                        const hasImages = imgs && imgs.length > 0;
                        
                        if (!currentCover && hasImages) {
                            console.log('[ProductEditPage] Auto-setting cover to first image');
                            handleModelChange('thumbnail_url', imgs[0].url || imgs[0].path);
                        } else if (currentCover && hasImages && !imgs.some(img => (img.url === currentCover || img.path === currentCover))) {
                            console.log('[ProductEditPage] Previous cover removed, setting to first image');
                            handleModelChange('thumbnail_url', imgs[0].url || imgs[0].path);
                        } else if (!hasImages && currentCover) {
                            console.log('[ProductEditPage] All images removed, clearing cover');
                            handleModelChange('thumbnail_url', '');
                        }
                    }}
                    onSetCover={url => {
                        console.log('[ProductEditPage] Cover image explicitly set:', url);
                        handleModelChange('thumbnail_url', url);
                    }}
                    coverPath={model.thumbnail_url}
                    showErrors={showErrors}
                  />
            </div>
            
            <MatrixVariantBuilder 
                productId={currentProductId}
                options={options} 
                onOptionsChange={handleOptionsChange}
                variants={variants}
                onVariantsChange={handleVariantsChange} 
            />
            <MatrixVariantsTable productId={currentProductId} variants={variants} onVariantsChange={handleVariantsChange} />

          </div>

          <div className="space-y-8">
             <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-6">
                <h2 className="text-sm font-bold uppercase text-zinc-500 mb-4">Status</h2>
                <StatusSelect 
                    value={model.status} 
                    onChange={v => handleModelChange('status', v)}
                />
             </div>

             <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-6 space-y-6">
                <h2 className="text-sm font-bold uppercase text-zinc-500">Organization</h2>
                
                <div>
                    <Label className="mb-2 block">Vendor</Label>
                    <VendorCombobox
                        value={model.vendor}
                        onChange={v => handleModelChange('vendor', v)}
                        options={vendorOptions}
                    />
                </div>
                <div>
                    <Label className="mb-2 block">Type</Label>
                    <TypeCombobox 
                        value={model.type} 
                        onChange={v => handleModelChange('type', v)}
                        options={typeOptions}
                    />
                </div>
                <div>
                    <Label className="mb-2 block">Collections</Label>
                    <CollectionsMultiSelect 
                        value={model.collectionIds}
                        onChange={ids => handleModelChange('collectionIds', ids)}
                        collections={collectionOptions}
                    />
                </div>
                <div>
                    <Label className="mb-2 block">Tags</Label>
                    <TagsMultiSelect 
                        value={model.tags}
                        onChange={t => handleModelChange('tags', t)}
                    />
                </div>
             </div>
          </div>
      </form>
    </div>
  );
}
