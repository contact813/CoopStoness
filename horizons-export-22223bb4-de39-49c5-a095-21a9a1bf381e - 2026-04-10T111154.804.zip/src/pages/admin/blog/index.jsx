import React, { useEffect, useMemo, useState, useCallback } from "react";
import { Link } from "react-router-dom";
import { listPosts, deletePost } from "@/lib/postsApi";
import { Plus, Pencil, Trash2, Image as ImageIcon, CalendarDays, Search } from "lucide-react";

export default function AdminBlogList() {
  const [items, setItems] = useState([]);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  const [search, setSearch] = useState("");
  const perPage = 12;
  const totalPages = useMemo(() => Math.max(1, Math.ceil(total / perPage)), [total, perPage]);
  const [loading, setLoading] = useState(false);

  const load = useCallback(async (currentPage, currentSearch) => {
    setLoading(true);
    try {
      const { items, total } = await listPosts({ search: currentSearch, page: currentPage, perPage });
      setItems(items);
      setTotal(total);
    } finally {
      setLoading(false);
    }
  }, [perPage]);

  useEffect(() => {
    const handler = setTimeout(() => {
        if (page !== 1) {
            setPage(1);
        } else {
            load(1, search);
        }
    }, 300); // debounce search
    return () => clearTimeout(handler);
  }, [search]);

  useEffect(() => {
    load(page, search);
  }, [page, load]);


  async function handleDelete(id) {
    if (!window.confirm("Excluir este post?")) return;
    await deletePost(id);
    // Reload current page
    load(page, search);
  }

  return (
    <div className="max-w-6xl mx-auto px-4 py-8 text-white">
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-semibold">Manage Blog</h1>
        <Link to="/admin/blog/new" className="inline-flex items-center gap-2 px-4 py-2 rounded-lg shadow bg-yellow-500 text-black font-semibold">
          <Plus size={18} /> New Post
        </Link>
      </div>

      <div className="mb-6 flex gap-2">
        <div className="flex-1 relative">
          <input className="w-full rounded-lg px-4 py-2 bg-zinc-900 border border-zinc-700 outline-none focus:ring-2 focus:ring-yellow-500" placeholder="Buscar por título" value={search} onChange={e => setSearch(e.target.value)} />
          <Search size={18} className="absolute right-3 top-2.5 text-zinc-400" />
        </div>
      </div>

      {loading && <div className="text-center text-zinc-400">Carregando...</div>}

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {items.map(p => (
          <article key={p.id} className="rounded-lg bg-zinc-900 border border-zinc-800 shadow p-4 flex flex-col transition-transform hover:scale-105">
            <div className="aspect-video bg-zinc-800 rounded-md mb-3 overflow-hidden flex items-center justify-center">
              {p.cover_url ? (
                <img src={p.cover_url} alt={p.title} className="w-full h-full object-cover" />
              ) : (
                <ImageIcon className="text-zinc-500" size={40}/>
              )}
            </div>
            <h3 className="text-lg font-semibold line-clamp-2 mb-2 text-zinc-100">{p.title}</h3>
            <div className="text-sm text-zinc-400 flex items-center gap-2 mb-4">
              <CalendarDays size={16} />
              <span>{p.published_at ? new Date(p.published_at).toLocaleDateString() : "Rascunho"}</span>
            </div>
            <div className="mt-auto flex items-center justify-end gap-2">
              <Link to={`/admin/blog/${p.id}`} className="inline-flex items-center gap-2 rounded-md px-3 py-1.5 bg-zinc-800 hover:bg-zinc-700 text-zinc-200 text-sm">
                <Pencil size={14} /> Editar
              </Link>
              <button onClick={() => handleDelete(p.id)} className="inline-flex items-center gap-2 rounded-md px-3 py-1.5 bg-red-600 hover:bg-red-700 text-white text-sm">
                <Trash2 size={14} /> Excluir
              </button>
            </div>
          </article>
        ))}
      </div>

      {totalPages > 1 && (
          <div className="flex items-center justify-center gap-2 mt-8">
            <button disabled={page === 1} onClick={() => setPage(p => Math.max(1, p - 1))} className="px-3 py-2 rounded-md bg-zinc-800 disabled:opacity-50">Anterior</button>
            <span className="px-2 text-zinc-400">Página {page} de {totalPages}</span>
            <button disabled={page === totalPages} onClick={() => setPage(p => Math.min(totalPages, p + 1))} className="px-3 py-2 rounded-md bg-zinc-800 disabled:opacity-50">Próxima</button>
          </div>
      )}
    </div>
  );
}