import React, { useEffect, useRef, useState } from "react";
import { useNavigate, useParams, Link } from "react-router-dom";
import { createPost, getPost, updatePost, uploadCover } from "@/lib/postsApi";
import { ArrowLeft, Image as ImageIcon, Save, Upload } from "lucide-react";

const empty = {
  title: "",
  slug: "",
  description: "",
  content: "",
  cover_url: "",
  published_at: "",
  status: "draft",
};

function slugify(str = "") {
  return str
    .toLowerCase()
    .normalize("NFD").replace(/\p{Diacritic}+/gu, "")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/(^-|-$)+/g, "");
}

export default function AdminBlogEdit() {
  const { id } = useParams();
  const isNew = id === "new";
  const [data, setData] = useState(empty);
  const [saving, setSaving] = useState(false);
  const [uploading, setUploading] = useState(false);
  const fileRef = useRef();
  const navigate = useNavigate();

  useEffect(() => {
    if (!isNew) {
      getPost(id).then(setData).catch(() => {});
    }
  }, [id, isNew]);

  function handleChange(e) {
    const { name, value } = e.target;
    setData(prev => ({ ...prev, [name]: value }));
  }

  async function handleUpload() {
    const file = fileRef.current?.files?.[0];
    if (!file) return;
    setUploading(true);
    try {
        const url = await uploadCover(file);
        setData(prev => ({ ...prev, cover_url: url }));
    } finally {
        setUploading(false);
    }
  }

  async function handleSave(e) {
    e.preventDefault();
    setSaving(true);
    try {
      const payload = {
        ...data,
        title: data.title.trim(),
        slug: data.slug.trim() || slugify(data.title),
        published_at: data.published_at || null,
      };
      if (isNew) {
        const created = await createPost(payload);
        navigate(`/admin/blog/${created.id}`);
      } else {
        await updatePost(id, payload);
        alert("Salvo");
      }
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="max-w-4xl mx-auto px-4 py-8 text-white">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <Link to="/admin/blog" className="inline-flex items-center gap-2 rounded-lg px-3 py-2 bg-zinc-800 hover:bg-zinc-700"><ArrowLeft size={16}/> Voltar</Link>
          <h1 className="text-2xl font-semibold">{isNew ? "Novo Post" : "Editar Post"}</h1>
        </div>
        <button onClick={handleSave} disabled={saving || uploading} className="inline-flex items-center gap-2 rounded-lg px-4 py-2 bg-yellow-500 text-black font-semibold disabled:opacity-50">
          <Save size={18}/> {saving ? "Salvando..." : "Salvar"}
        </button>
      </div>

      <form onSubmit={handleSave} className="space-y-6">
        <div className="grid md:grid-cols-2 gap-4">
          <div>
            <label className="block mb-1 text-sm text-zinc-400">Título</label>
            <input name="title" value={data.title} onChange={handleChange} className="w-full rounded-lg px-4 py-2 bg-zinc-900 border border-zinc-700" placeholder="Título do post" required />
          </div>
          <div>
            <label className="block mb-1 text-sm text-zinc-400">Slug</label>
            <input name="slug" value={data.slug} onChange={handleChange} className="w-full rounded-lg px-4 py-2 bg-zinc-900 border border-zinc-700" placeholder="ex: future-of-quartz-2025" />
          </div>
        </div>

        <div className="grid md:grid-cols-2 gap-4">
          <div>
            <label className="block mb-1 text-sm text-zinc-400">Data de publicação</label>
            <input type="date" name="published_at" value={data.published_at?.substring(0,10) || ""} onChange={handleChange} className="w-full rounded-lg px-4 py-2 bg-zinc-900 border border-zinc-700" />
          </div>
          <div>
            <label className="block mb-1 text-sm text-zinc-400">Status</label>
            <select name="status" value={data.status} onChange={handleChange} className="w-full rounded-lg px-4 py-2 bg-zinc-900 border border-zinc-700">
              <option value="draft">Rascunho</option>
              <option value="published">Publicado</option>
            </select>
          </div>
        </div>

        <div>
          <label className="block mb-1 text-sm text-zinc-400">Descrição curta</label>
          <textarea name="description" value={data.description || ""} onChange={handleChange} rows={3} className="w-full rounded-lg px-4 py-2 bg-zinc-900 border border-zinc-700" placeholder="Texto que aparece na listagem do blog"></textarea>
        </div>

        <div>
          <label className="block mb-1 text-sm text-zinc-400">Capa</label>
          <div className="flex items-center gap-4">
            <div className="w-64 aspect-video bg-zinc-800 rounded-lg flex items-center justify-center overflow-hidden">
              {data.cover_url ? <img src={data.cover_url} alt="Capa" className="w-full h-full object-cover"/> : <ImageIcon className="text-zinc-500" size={40}/>}
            </div>
            <div className="space-y-2">
              <input ref={fileRef} type="file" accept="image/*" className="block text-sm file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-yellow-500 file:text-black hover:file:bg-yellow-600" />
              <button type="button" onClick={handleUpload} disabled={uploading} className="rounded-lg px-3 py-2 bg-zinc-800 inline-flex items-center gap-2 disabled:opacity-50">
                  <Upload size={16} />
                  {uploading ? 'Enviando...' : 'Enviar imagem'}
              </button>
            </div>
          </div>
        </div>

        <div>
          <label className="block mb-1 text-sm text-zinc-400">Conteúdo completo</label>
          <textarea name="content" value={data.content || ""} onChange={handleChange} rows={12} className="w-full rounded-lg px-4 py-2 bg-zinc-900 border border-zinc-700" placeholder="Conteúdo principal do post."></textarea>
        </div>
      </form>
    </div>
  );
}