
import React from 'react';
import { Helmet } from 'react-helmet';

const TermsAndConditions = () => {
  return (
    <div className="container mx-auto px-4 py-16 md:px-8 max-w-4xl">
      <Helmet>
        <title>Terms & Conditions – COOPSTONES</title>
        <meta name="description" content="Read the Terms & Conditions for COOPSTONES. Understand our usage policies, platform rules, and legal agreements." />
        <meta property="og:title" content="Terms & Conditions – COOPSTONES" />
        <meta property="og:description" content="Read the Terms & Conditions for COOPSTONES." />
        <link rel="canonical" href="https://coopstones.com/terms-and-conditions" />
      </Helmet>

      <h1 className="text-4xl font-bold text-white mb-2">Terms & Conditions</h1>
      <p className="text-zinc-400 mb-8">Last Updated: December 2, 2025</p>

      <div className="space-y-8 text-zinc-300 leading-relaxed">
        <section>
          <h2 className="text-2xl font-semibold text-yellow-500 mb-4">1. Acceptance of Terms</h2>
          <p>
            By accessing or using the website located at https://coopstones.com ("Service"), owned and operated by COOPSTONES LLC ("Company", "we", "us", or "our"), you agree to be bound by these Terms & Conditions ("Terms"). If you disagree with any part of the terms, you may not access the Service.
          </p>
        </section>

        <section>
          <h2 className="text-2xl font-semibold text-yellow-500 mb-4">2. Eligibility</h2>
          <p>
            You must be at least 18 years old to use our Service. By agreeing to these Terms, you represent and warrant that you are at least 18 years of age and have the legal capacity to enter into binding contracts.
          </p>
        </section>

        <section>
          <h2 className="text-2xl font-semibold text-yellow-500 mb-4">3. Accounts and Registration</h2>
          <p>
            To access certain features of the Service, such as the Platform or Rounds, you may be required to register for an account. You agree to provide accurate, current, and complete information during the registration process and to update such information to keep it accurate, current, and complete. You are responsible for safeguarding your password.
          </p>
        </section>

        <section>
          <h2 className="text-2xl font-semibold text-yellow-500 mb-4">4. Round Orders & Payments</h2>
          <p className="mb-4">
            <strong>Pricing:</strong> All prices are listed in U.S. Dollars (USD). We reserve the right to change prices at any time without prior notice.
          </p>
          <p className="mb-4">
            <strong>Payment Processing:</strong> Payments are processed securely via Stripe. By providing a payment method, you represent that you are authorized to use the payment method provided and authorize us to charge the full amount of your purchase.
          </p>
          <p>
            <strong>Taxes:</strong> You are responsible for all applicable taxes, duties, and other governmental charges associated with your purchase.
          </p>
        </section>

        <section>
          <h2 className="text-2xl font-semibold text-yellow-500 mb-4">5. Subscriptions</h2>
          <p>
            COOPSTONES offers membership subscriptions that grant access to exclusive pricing and group buying rounds. Subscriptions are billed in advance on a recurring basis (monthly or annually). You may cancel your subscription at any time through your account settings; however, refunds for partial billing periods are governed by our Refund Policy.
          </p>
        </section>

        <section>
          <h2 className="text-2xl font-semibold text-yellow-500 mb-4">6. User Conduct & Usage Policy</h2>
          <p>
            You agree not to use the Service for any unlawful purpose or in any way that interrupts, damages, or impairs the service. You are prohibited from:
          </p>
          <ul className="list-disc pl-6 mt-2 space-y-2">
            <li>Harassing, abusing, or harming another person or group.</li>
            <li>Using the service to distribute spam or malicious software.</li>
            <li>Attempting to gain unauthorized access to our systems or user accounts.</li>
            <li>Reselling products purchased through the cooperative in violation of vendor agreements.</li>
          </ul>
        </section>

        <section>
          <h2 className="text-2xl font-semibold text-yellow-500 mb-4">7. Intellectual Property</h2>
          <p>
            The Service and its original content, features, and functionality are and will remain the exclusive property of COOPSTONES LLC and its licensors. The Service is protected by copyright, trademark, and other laws of both the United States and foreign countries.
          </p>
        </section>

        <section>
          <h2 className="text-2xl font-semibold text-yellow-500 mb-4">8. Limitation of Liability</h2>
          <p>
            In no event shall COOPSTONES LLC, nor its directors, employees, partners, agents, suppliers, or affiliates, be liable for any indirect, incidental, special, consequential, or punitive damages, including without limitation, loss of profits, data, use, goodwill, or other intangible losses, resulting from your access to or use of or inability to access or use the Service.
          </p>
        </section>

        <section>
          <h2 className="text-2xl font-semibold text-yellow-500 mb-4">9. Dispute Resolution</h2>
          <p>
            Any dispute arising from these Terms shall be resolved through binding arbitration in the state of Massachusetts, in accordance with the rules of the American Arbitration Association. The prevailing party shall be entitled to recover reasonable attorney's fees.
          </p>
        </section>

        <section>
          <h2 className="text-2xl font-semibold text-yellow-500 mb-4">10. Contact Information</h2>
          <p>
            If you have any questions about these Terms, please contact us at:
          </p>
          <div className="mt-4 p-4 bg-zinc-900 rounded-lg border border-zinc-800">
            <p><strong>COOPSTONES LLC</strong></p>
            <p>W St Conrad St</p>
            <p>Massachusetts, USA</p>
            <p className="mt-2">Email: <a href="mailto:contact@coopstones.com" className="text-yellow-500 hover:underline">contact@coopstones.com</a></p>
          </div>
        </section>
      </div>
    </div>
  );
};

export default TermsAndConditions;
