import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { supabase } from '@/lib/supabaseClient';

const BlogPage = () => {
  const [loading, setLoading] = useState(true);
  const [posts, setPosts] = useState([]);

  useEffect(() => {
    const fetchPosts = async () => {
      setLoading(true);
      const { data, error } = await supabase
        .from('v_posts_public') // Using the public view
        .select('*')
        .order('published_at', { ascending: false });

      if (error) {
        console.error('Error fetching posts:', error);
      } else {
        setPosts(data);
      }
      setLoading(false);
    };

    fetchPosts();
  }, []);

  return (
    <>
      <Helmet>
        <title>Blog - Coop Stones</title>
        <meta name="description" content="Read the latest news, insights, and stories from the stone industry on the Coop Stones blog." />
      </Helmet>
      <div className="min-h-screen bg-black text-white flex flex-col">
        <main className="flex-grow pt-8 pb-16">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="text-center mb-16"
            >
              <h1 className="text-4xl md:text-6xl font-bold text-white mb-4 tracking-tight">
                From Our <span className="text-yellow-400">Blog</span>
              </h1>
              <p className="text-lg text-gray-400 max-w-2xl mx-auto">
                Stay updated with the latest industry news, business tips, and technology insights from experts.
              </p>
            </motion.div>

            {loading ? (
              <div className="text-center text-yellow-400">Loading posts...</div>
            ) : (
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
                {posts.map((post, index) => (
                  <motion.div
                    key={post.id}
                    initial={{ opacity: 0, y: 30 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.5, delay: index * 0.1 }}
                  >
                    <Link to={`/blog/${post.slug}`} className="bg-gray-900/50 rounded-xl overflow-hidden group block border border-yellow-400/20 hover:border-yellow-400/60 transition-all duration-300 backdrop-blur-sm">
                      <div className="relative h-48 overflow-hidden">
                        {post.cover_url && <img className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" alt={post.title} src={post.cover_url} />}
                      </div>
                      <div className="p-6">
                        <h3 className="text-xl font-bold text-white mb-3 group-hover:text-yellow-400 transition-colors">
                          {post.title}
                        </h3>
                        <p className="text-gray-400 text-sm leading-relaxed line-clamp-3">
                          {post.description}
                        </p>
                      </div>
                    </Link>
                  </motion.div>
                ))}
              </div>
            )}
          </div>
        </main>
      </div>
    </>
  );
};

export default BlogPage;