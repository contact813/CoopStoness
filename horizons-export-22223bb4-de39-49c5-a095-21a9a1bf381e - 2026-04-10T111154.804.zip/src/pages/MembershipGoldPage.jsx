
import React, { useEffect } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Users, ShoppingBag, Megaphone, Wrench, ShieldCheck } from 'lucide-react';
import { Badge } from "@/components/ui/badge";
import MembershipApplicationForm from '@/components/MembershipApplicationForm';

const benefits = [
  { icon: ShoppingBag, title: "Group Purchasing Power", description: "Access 25-75% discounts on essential supplies through our collective bargaining power." },
  { icon: Users, title: "Verified Suppliers", description: "Direct access to a network of vetted material suppliers and service providers." },
  { icon: Wrench, title: "Round Access", description: "Unlock premium round features and benefits within our trusted community." },
  { icon: Megaphone, title: "Marketing Support", description: "Resources and tools to help you grow your local presence and attract more clients." },
  { icon: ShieldCheck, title: "Workshops & Training", description: "Exclusive educational content and workshops to upskill your team." }
];

export default function MembershipGoldPage() {

  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  return (
    <>
      <Helmet>
        <title>Gold Membership - Coop Stones</title>
        <meta name="description" content="Join Coop Stones Gold Membership for group purchasing power, round access, and exclusive industry resources." />
      </Helmet>
      
      <div className="min-h-screen bg-black text-white">
        <section className="relative h-[80vh] min-h-[600px] flex items-center justify-center overflow-hidden">
          <div className="absolute inset-0 z-0 bg-cover bg-center" style={{ backgroundImage: 'url(https://horizons-cdn.hostinger.com/22223bb4-de39-49c5-a095-21a9a1bf381e/6797c64454b05265587c4a2db4cc8e2f.png)', backgroundSize: 'cover', backgroundPosition: 'center', backgroundAttachment: 'fixed' }}>
             <div className="absolute inset-0 bg-black bg-opacity-40" />
          </div>

          <div className="relative z-10 max-w-4xl mx-auto px-6 text-center">
            <motion.div initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.8 }}>
              <Badge className="bg-yellow-400/20 text-yellow-400 border-yellow-400/50 mb-6 px-4 py-1.5 text-sm uppercase tracking-widest">Most Popular</Badge>
              <h1 className="text-5xl md:text-7xl font-bold mb-6 tracking-tight">Gold <span className="text-yellow-400">Membership</span></h1>
              <p className="text-xl md:text-2xl text-zinc-300 max-w-2xl mx-auto mb-10 leading-relaxed">Unlock group purchasing power and exclusive benefits designed to scale your stone business.</p>
              <a href="#apply" className="inline-block bg-yellow-400 text-black font-bold text-lg px-8 py-4 rounded-full hover:bg-yellow-300 transition-all hover:scale-105 shadow-lg shadow-yellow-400/20">Apply for Membership</a>
            </motion.div>
          </div>
        </section>

        <section className="py-24 bg-zinc-950">
          <div className="max-w-7xl mx-auto px-6">
            <div className="text-center mb-16">
              <h2 className="text-3xl md:text-4xl font-bold mb-4 text-white">Why Choose <span className="text-yellow-400">Gold?</span></h2>
              <p className="text-zinc-400 max-w-2xl mx-auto">Everything you need to reduce costs and improve operations.</p>
            </div>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              {benefits.map((benefit, index) => (
                <motion.div key={index} initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: index * 0.1 }} className="bg-zinc-900/50 border border-zinc-800 p-8 rounded-2xl hover:border-yellow-400/30 transition-colors">
                  <div className="w-14 h-14 bg-yellow-400/10 rounded-xl flex items-center justify-center mb-6">
                    <benefit.icon className="w-7 h-7 text-yellow-400" />
                  </div>
                  <h3 className="text-xl font-bold mb-3 text-white">{benefit.title}</h3>
                  <p className="text-zinc-400 leading-relaxed">{benefit.description}</p>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        <section id="apply" className="py-24 bg-zinc-950 border-t border-zinc-900">
          <div className="max-w-3xl mx-auto px-6">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold mb-4 text-white">Apply for <span className="text-yellow-400">Gold Membership</span></h2>
              <p className="text-zinc-400">Fill out the form below to start your application.</p>
            </div>
            
            <div className="bg-zinc-900/50 border border-zinc-800 p-8 md:p-12 rounded-2xl shadow-xl">
               <MembershipApplicationForm plan="Gold" />
            </div>
          </div>
        </section>
      </div>
    </>
  );
}
