
import React, { useEffect, useState } from "react";
import { useParams, useNavigate, Navigate } from "react-router-dom";
import { Helmet } from "react-helmet";
import { useAuth } from "@/contexts/AuthContext";
import { useToast } from "@/components/ui/use-toast";
import { getRoundBySlug, getUserRoundCart, submitRoundOrder, updateRoundCartItem, removeFromRoundCart } from "@/lib/roundsApi";
import { formatVariantOptions } from "@/utils/variantUtils";
import { Button } from "@/components/ui/button";
import { Loader2, ArrowLeft, ShoppingCart, Trash2, AlertCircle, CheckCircle, Plus, Minus } from "lucide-react";

export default function RoundCartPage() {
  const { slug } = useParams();
  const navigate = useNavigate();
  const { user, isAuthInitialized } = useAuth();
  const { toast } = useToast();

  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [updatingItemId, setUpdatingItemId] = useState(null);
  const [errorState, setErrorState] = useState(null);
  const [round, setRound] = useState(null);
  const [cart, setCart] = useState(null);
  const [items, setItems] = useState([]);

  useEffect(() => {
    if (!isAuthInitialized) return;

    if (!user) {
      console.log("[RoundCartPage] No user after auth init. Skipping fetch.");
      setLoading(false);
      return;
    }

    async function loadData() {
      if (!slug) {
        setErrorState('Invalid round identifier.');
        setLoading(false);
        return;
      }

      setLoading(true);
      setErrorState(null);
      try {
        console.log(`[RoundCartPage] Loading cart for round slug: ${slug}, User: ${user.id}`);
        const { data: roundData, error: roundError } = await getRoundBySlug(slug);
        
        if (roundError) {
          console.error(`[RoundCartPage] Error fetching round:`, roundError);
          throw new Error(roundError.message || "Round not found.");
        }
        if (!roundData) {
          throw new Error("Round not found.");
        }
        
        setRound(roundData);

        console.log(`[RoundCartPage] Fetching user cart via getUserRoundCart...`);
        const { data: userCart, error: cartErr } = await getUserRoundCart(roundData.id, user.id);
        
        if (cartErr) {
          console.error(`[RoundCartPage] Error fetching user cart:`, cartErr);
          throw new Error(cartErr.message || "Error fetching cart.");
        }
        
        console.log("[RoundCartPage] Cart fetch complete. Result:", userCart);
        setCart(userCart);
        
        const rawItems = userCart?.items ? (Array.isArray(userCart.items) ? userCart.items : [userCart.items]) : [];
        console.log(`[RoundCartPage] Normalized items count: ${rawItems.length}`);
        
        const activeItems = rawItems.filter(item => item.status === 'active');
        console.log(`[RoundCartPage] Active items count: ${activeItems.length}`);
        
        setItems(activeItems);
      } catch (err) {
        console.error("[RoundCartPage] Failed to load round cart exception:", err);
        setErrorState(err.message || "An error occurred while loading your cart.");
      } finally {
        setLoading(false);
      }
    }
    
    loadData();
  }, [slug, user, isAuthInitialized]);

  const handleConfirmOrder = async () => {
    if (!round || items.length === 0) return;
    
    console.log("[RoundCartPage] Order confirmation initiated...");
    setSubmitting(true);
    
    try {
      const result = await submitRoundOrder(round.id, user.id);
      console.log("[RoundCartPage] Order confirmed successfully:", result);
      
      toast({ 
        title: "Order Confirmed!", 
        description: "Your order has been successfully placed." 
      });
      
      navigate(`/account/orders`);
    } catch (err) {
      console.error("[RoundCartPage] Order submission error:", err);
      toast({ 
        variant: "destructive", 
        title: "Order Failed", 
        description: err.message || "An error occurred while confirming your order." 
      });
    } finally {
      setSubmitting(false);
    }
  };

  const handleIncreaseQty = async (item) => {
    if (updatingItemId) return;
    console.log(`[RoundCartPage] handleIncreaseQty called: ${item.id}`);
    setUpdatingItemId(item.id);
    try {
      const newQty = (item.qty ?? 1) + 1;
      console.log(`[RoundCartPage] Increasing qty to: ${newQty}`);
      await updateRoundCartItem(item.id, newQty, round.id);
      
      // Use functional state update to prevent race conditions
      setItems(prev => prev.map(i => i.id === item.id ? { ...i, qty: newQty } : i));
      toast({ title: "Cart Updated", description: "Item quantity increased." });
    } catch (err) {
      toast({ variant: "destructive", title: "Error", description: err.message || "Failed to update quantity." });
    } finally {
      setUpdatingItemId(null);
    }
  };

  const handleDecreaseQty = async (item) => {
    if (updatingItemId) return;
    const currentQty = item.qty ?? 1;
    if (currentQty <= 1) return;
    
    console.log(`[RoundCartPage] handleDecreaseQty called: ${item.id}`);
    setUpdatingItemId(item.id);
    try {
      const newQty = currentQty - 1;
      console.log(`[RoundCartPage] Decreasing qty to: ${newQty}`);
      await updateRoundCartItem(item.id, newQty, round.id);
      
      // Use functional state update to prevent race conditions
      setItems(prev => prev.map(i => i.id === item.id ? { ...i, qty: newQty } : i));
      toast({ title: "Cart Updated", description: "Item quantity decreased." });
    } catch (err) {
      toast({ variant: "destructive", title: "Error", description: err.message || "Failed to update quantity." });
    } finally {
      setUpdatingItemId(null);
    }
  };

  const handleRemoveItem = async (item) => {
    if (updatingItemId) return;
    console.log(`[RoundCartPage] handleRemoveItem called: ${item.id}`);
    console.log(`[RoundCartPage] Removing item: { itemId: ${item.id}, qty: ${item.qty} }`);
    
    setUpdatingItemId(item.id);
    try {
      await removeFromRoundCart(item.id, round.id);
      console.log('[RoundCartPage] Item removed successfully');
      
      // Use functional state update
      setItems(prev => prev.filter(i => i.id !== item.id));
      toast({ title: "Item Removed", description: "Item was removed from your cart." });
    } catch (err) {
      toast({ variant: "destructive", title: "Error", description: err.message || "Failed to remove item." });
    } finally {
      setUpdatingItemId(null);
    }
  };

  if (!isAuthInitialized || loading) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh] text-zinc-400">
        <Loader2 className="w-10 h-10 animate-spin text-yellow-500 mb-4" />
        <p>Loading your cart...</p>
      </div>
    );
  }

  if (!user) {
    return <Navigate to="/login" replace />;
  }

  if (errorState || !round) {
    return (
      <div className="max-w-4xl mx-auto p-6 text-center text-zinc-200 min-h-[50vh] flex flex-col items-center justify-center">
        <AlertCircle className="w-12 h-12 text-red-500 mb-4" />
        <h1 className="text-3xl font-bold text-red-400 mb-4">Error</h1>
        <p className="text-zinc-400 mb-8">{errorState || "Failed to load cart."}</p>
        <Button onClick={() => navigate(`/rounds/${slug}`)} variant="outline" className="border-zinc-700 text-white">
          Back to Round
        </Button>
      </div>
    );
  }

  const totalItems = items.reduce((sum, item) => sum + (item.qty ?? 1), 0);
  const totalAmount = items.reduce((sum, item) => { 
    const itemQty = item.qty ?? 1; 
    const itemUnitPrice = item.unit_price ?? 0; 
    return sum + (itemQty * itemUnitPrice); 
  }, 0);
  
  console.log(`[RoundCartPage] Cart totals: { totalItems: ${totalItems}, totalAmount: ${totalAmount}, itemCount: ${items.length} }`);

  return (
    <div className="min-h-screen py-12 relative">
      <Helmet>
        <title>Your Cart | {round.title}</title>
      </Helmet>

      <div className={`max-w-5xl mx-auto px-4 sm:px-6 lg:px-8`}>
        <Button 
          onClick={() => navigate(`/rounds/${round.slug || round.id}`)} 
          variant="ghost" 
          className="mb-6 text-zinc-400 hover:text-white"
        >
          <ArrowLeft className="w-4 h-4 mr-2" /> Back to {round.title}
        </Button>

        <h1 className="text-3xl md:text-4xl font-bold text-white mb-8 flex items-center gap-3">
          <ShoppingCart className="text-yellow-500 w-8 h-8" />
          Round Cart
        </h1>

        {items.length === 0 ? (
          <div className="bg-zinc-950 border border-zinc-800 rounded-2xl p-12 text-center text-zinc-400">
            <ShoppingCart className="w-12 h-12 mx-auto mb-4 text-zinc-700" />
            <p className="text-lg mb-6">Your cart for this round is currently empty.</p>
            <Button onClick={() => navigate(`/rounds/${round.slug || round.id}`)} className="bg-yellow-500 hover:bg-yellow-400 text-black font-bold">
              Continue Shopping
            </Button>
          </div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2 space-y-4">
              {items.map((item) => {
                const productTitle = item.variant?.title || item.product?.title || 'Unknown Product';
                const options = item.options ? formatVariantOptions(item.options) : '';
                const image = item.variant?.image_url || item.product?.thumbnail_url || item.product?.images?.[0]?.url || '/images/placeholder-product.svg';
                const isUpdating = updatingItemId === item.id;
                const itemQty = item.qty ?? 1;
                
                console.log(`[RoundCartPage] Rendering item: { id: ${item.id}, qty: ${itemQty}, unit_price: ${item.unit_price} }`);
                
                return (
                  <div key={item.id} className={`bg-zinc-900 border border-zinc-800 rounded-xl p-4 transition-opacity ${isUpdating ? 'opacity-50' : 'opacity-100'}`}>
                    <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 w-full">
                      
                      {/* LEFT: Image + Info */}
                      <div className="flex gap-4 flex-1 items-center min-w-0 w-full sm:w-auto">
                        <img src={image} alt={productTitle} className="w-20 h-20 object-contain bg-white rounded-md flex-shrink-0 border border-zinc-800" />
                        <div className="flex-1 min-w-0">
                          <h3 className="text-zinc-100 font-bold truncate">{productTitle}</h3>
                          {options && options !== '-' && <p className="text-xs text-zinc-500 truncate">{options}</p>}
                          <p className="text-yellow-500 font-bold mt-1">${Number(item.unit_price ?? 0).toFixed(2)}</p>
                        </div>
                      </div>
                      
                      {/* RIGHT: Qty + Delete Button */}
                      <div className="flex items-center justify-between w-full sm:w-auto gap-4 sm:gap-6 flex-shrink-0 border-t border-zinc-800 sm:border-0 pt-4 sm:pt-0">
                        {/* CENTER: Quantity controls */}
                        <div className="flex items-center border border-zinc-700 rounded-md bg-zinc-950 overflow-hidden flex-shrink-0">
                          <button 
                            onClick={() => handleDecreaseQty(item)}
                            disabled={isUpdating || itemQty <= 1}
                            className="px-3 py-2 text-zinc-400 hover:text-white hover:bg-zinc-800 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                          >
                            <Minus className="w-4 h-4" />
                          </button>
                          <div className="px-4 py-2 text-white font-medium text-sm min-w-[3rem] text-center border-x border-zinc-800">
                            {isUpdating ? "..." : itemQty}
                          </div>
                          <button 
                            onClick={() => handleIncreaseQty(item)}
                            disabled={isUpdating}
                            className="px-3 py-2 text-zinc-400 hover:text-white hover:bg-zinc-800 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                          >
                            <Plus className="w-4 h-4" />
                          </button>
                        </div>
                        
                        {/* RIGHT: Delete button */}
                        <button
                          onClick={() => handleRemoveItem(item)}
                          disabled={isUpdating}
                          className="text-red-500 hover:text-red-400 transition-colors min-w-fit whitespace-nowrap flex-shrink-0 flex items-center disabled:opacity-50 disabled:cursor-not-allowed"
                          title="Remove item"
                          aria-label="Remove item"
                        >
                          <Trash2 className="w-5 h-5 inline mr-1" />
                          Remove
                        </button>
                      </div>
                      
                    </div>
                  </div>
                );
              })}
            </div>

            <div className="bg-zinc-950 border border-zinc-800 rounded-2xl p-6 h-fit sticky top-24">
              <h2 className="text-xl font-bold text-white mb-6 border-b border-zinc-800 pb-4">Order Summary</h2>
              
              <div className="flex justify-between items-center text-zinc-400 mb-4">
                <span>Items ({totalItems})</span>
                <span>${totalAmount.toFixed(2)}</span>
              </div>
              
              <div className="flex justify-between items-center text-white text-xl font-bold mb-8 pt-4 border-t border-zinc-800">
                <span>Total</span>
                <span className="text-yellow-500">${totalAmount.toFixed(2)}</span>
              </div>

              <Button 
                onClick={handleConfirmOrder} 
                disabled={submitting || items.length === 0}
                className="w-full h-12 bg-yellow-500 hover:bg-yellow-400 text-black font-bold uppercase tracking-wide flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {submitting ? (
                  <>
                    <Loader2 className="w-5 h-5 animate-spin mr-2" />
                    Confirming...
                  </>
                ) : (
                  <>
                    <CheckCircle className="w-5 h-5 mr-2" />
                    Confirm Order
                  </>
                )}
              </Button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
