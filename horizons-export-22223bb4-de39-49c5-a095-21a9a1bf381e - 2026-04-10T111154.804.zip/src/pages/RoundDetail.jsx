
import React, { useEffect, useState } from "react";
import { useParams, Link, useNavigate, Navigate } from "react-router-dom";
import { Helmet } from "react-helmet";
import { getRoundBySlug, getRoundAvailableProducts, getRoundCommittedTotals } from "@/lib/roundsApi";
import { Loader2, ArrowLeft, Calendar, Package, AlertCircle, ShoppingBag } from "lucide-react";
import RoundProductCard from "@/components/rounds/RoundProductCard";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/contexts/AuthContext";

export default function RoundDetail() {
  const { slug } = useParams();
  const navigate = useNavigate();
  const { user, isAuthInitialized } = useAuth();
  
  const [round, setRound] = useState(null);
  const [products, setProducts] = useState([]);
  const [committedTotal, setCommittedTotal] = useState(0);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [productsError, setProductsError] = useState(null);

  useEffect(() => {
    if (!isAuthInitialized || !user) return;

    async function loadData() {
      if (!slug) {
        setError("Invalid round identifier.");
        setLoading(false);
        return;
      }

      setLoading(true);
      setError(null);
      setProductsError(null);
      
      try {
        console.log(`[RoundDetail] Loading round data for slug: ${slug}`);
        const { data: roundData, error: roundError } = await getRoundBySlug(slug);
        
        if (roundError) throw new Error(roundError.message || "Round not found.");
        if (!roundData) throw new Error("Round not found.");
        
        setRound(roundData);
        
        const [ { data: availableProducts, error: pErr }, totals ] = await Promise.all([
          getRoundAvailableProducts(roundData.id),
          getRoundCommittedTotals(roundData.id)
        ]);

        if (pErr) setProductsError(pErr.message || "Failed to load products.");

        setProducts(availableProducts || []);
        setCommittedTotal(totals || 0);

      } catch (err) {
        console.error("[RoundDetail] Failed to load round details exception:", err);
        setError(err.message || "The requested round could not be found or failed to load.");
      } finally {
        setLoading(false);
      }
    }
    
    loadData();
  }, [slug, isAuthInitialized, user]);

  if (!isAuthInitialized) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh] text-zinc-400">
        <Loader2 className="w-10 h-10 animate-spin text-yellow-500 mb-4" />
        <p>Verifying access...</p>
      </div>
    );
  }

  if (!user) {
    console.log('[RoundDetail] Access denied. Redirecting to login.');
    return <Navigate to="/login" replace />;
  }

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh] text-zinc-400">
        <Loader2 className="w-10 h-10 animate-spin text-yellow-500 mb-4" />
        <p>Loading round catalog...</p>
      </div>
    );
  }

  if (error || !round) {
    return (
      <div className="max-w-4xl mx-auto p-6 text-center text-zinc-200 min-h-[50vh] flex flex-col items-center justify-center">
        <h1 className="text-3xl font-bold text-red-400 mb-4">Round Not Found</h1>
        <p className="text-zinc-400 mb-8">{error || "This round might have ended or been removed."}</p>
        <Link to="/rounds" className="px-6 py-3 rounded-lg bg-yellow-500 text-black font-bold hover:bg-yellow-400 transition-colors">
          Browse All Rounds
        </Link>
      </div>
    );
  }

  const isRoundOpen = round.status === 'open' || round.status === 'active';

  return (
    <>
      <Helmet>
        <title>{round.title} - Catalog | Coop Stones</title>
      </Helmet>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="flex justify-between items-center mb-8">
          <Link to="/rounds" className="inline-flex items-center text-zinc-500 hover:text-yellow-500 transition-colors">
            <ArrowLeft className="w-4 h-4 mr-2" /> Back to Rounds
          </Link>
          <Button 
            onClick={() => navigate(`/rounds/${round.slug || round.id}/cart`)}
            className="bg-yellow-500 hover:bg-yellow-400 text-black font-bold flex items-center gap-2"
          >
            <ShoppingBag className="w-4 h-4" />
            View Cart
          </Button>
        </div>

        <div className="bg-zinc-950 border border-zinc-800 rounded-3xl p-8 md:p-12 mb-12 relative overflow-hidden">
          {round.cover_image_url && (
            <div className="absolute inset-0 opacity-20 pointer-events-none">
               <img src={round.cover_image_url} alt="" className="w-full h-full object-cover" />
               <div className="absolute inset-0 bg-gradient-to-t from-zinc-950 to-transparent"></div>
            </div>
          )}
          <div className="relative z-10 flex flex-col md:flex-row justify-between items-start gap-8">
            <div className="max-w-2xl">
              <div className="flex items-center gap-3 mb-4">
                <h1 className="text-4xl md:text-5xl font-extrabold text-white tracking-tight">{round.title}</h1>
                <span className={`px-3 py-1 rounded-full text-sm font-bold uppercase tracking-wide ${isRoundOpen ? 'bg-green-500 text-black' : 'bg-zinc-800 text-zinc-400'}`}>
                  {round.status || 'Active'}
                </span>
              </div>
              <p className="text-xl text-zinc-400 mb-6">{round.subtitle || round.description}</p>
              
              <div className="flex flex-wrap items-center gap-6 text-sm text-zinc-500">
                <div className="flex items-center gap-2">
                  <Calendar className="w-4 h-4" />
                  <span>Starts: {new Date(round.starts_at).toLocaleDateString()}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Calendar className="w-4 h-4" />
                  <span>Ends: {new Date(round.ends_at).toLocaleDateString()}</span>
                </div>
              </div>
            </div>

            <div className="bg-zinc-900/80 backdrop-blur-md border border-zinc-800 rounded-2xl p-6 min-w-[240px]">
              <div className="text-sm text-zinc-400 mb-1 font-bold uppercase tracking-wider">Total Committed</div>
              <div className="text-4xl font-extrabold text-yellow-500">${Number(committedTotal).toLocaleString('en-US', {minimumFractionDigits: 2})}</div>
              {round.goal_amount > 0 && (
                <div className="mt-4">
                  <div className="flex justify-between text-xs text-zinc-500 mb-2">
                    <span>Progress</span>
                    <span>{Math.round((committedTotal / round.goal_amount) * 100)}%</span>
                  </div>
                  <div className="h-2 w-full bg-zinc-800 rounded-full overflow-hidden">
                    <div className="h-full bg-yellow-500" style={{ width: `${Math.min(100, (committedTotal / round.goal_amount) * 100)}%`}}></div>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>

        <div className="mb-8">
          <h2 className="text-2xl font-bold text-white mb-6 flex items-center gap-3">
            <Package className="text-yellow-500" />
            Available Products
          </h2>
          
          {productsError ? (
             <div className="bg-red-500/10 border border-red-500/50 rounded-2xl p-6 flex flex-col items-center justify-center text-center">
              <AlertCircle className="w-8 h-8 text-red-500 mb-3" />
              <p className="text-red-400 font-medium">Failed to load available products.</p>
              <p className="text-red-400/80 text-sm mt-1">{productsError}</p>
             </div>
          ) : products.length === 0 ? (
            <div className="bg-zinc-950 border border-zinc-800 rounded-2xl p-12 text-center text-zinc-400">
              No products are currently available in this round catalog.
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {products.map(product => (
                <RoundProductCard 
                  key={product.id} 
                  product={product} 
                  roundId={round.id}
                  roundSlug={round.slug}
                />
              ))}
            </div>
          )}
        </div>
      </div>
    </>
  );
}
