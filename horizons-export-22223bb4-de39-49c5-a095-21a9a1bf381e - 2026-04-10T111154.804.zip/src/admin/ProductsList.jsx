
import React, { useState, useEffect, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import { getAllProducts, deleteProduct } from "@/lib/adminProductsApi";
import { Button } from "@/components/ui/button";
import { useToast } from "@/components/ui/use-toast";
import { Loader2, Edit, Trash2 } from "lucide-react";
import { PLACEHOLDER_IMAGE } from "@/lib/imageUtils";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";

function useDebounce(value, delay) {
  const [debouncedValue, setDebouncedValue] = useState(value);
  useEffect(() => {
    const handler = setTimeout(() => {
      setDebouncedValue(value);
    }, delay);
    return () => {
      clearTimeout(handler);
    };
  }, [value, delay]);
  return debouncedValue;
}

export default function ProductsList() {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [rows, setRows] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  
  const [q, setQ] = useState('');
  const debouncedQ = useDebounce(q, 500);
  
  const [sort, setSort] = useState('created_at.desc');
  const [pageSize, setPageSize] = useState(50);
  const [page, setPage] = useState(1);
  const [total, setTotal] = useState(0);

  const loadProducts = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      console.log(`[ProductsList] Fetching products page ${page}...`);
      
      const response = await getAllProducts({ 
        q: debouncedQ, 
        sort, 
        limit: pageSize, 
        page 
      });
      
      // Safely destructure, handling both format variations just in case
      const { data, rows: fallbackRows, count, error: apiErr } = response || {};
      
      if (apiErr) throw apiErr;
      
      const resultRows = data || fallbackRows || [];
      const resultCount = count || 0;
      
      console.log(`[ProductsList] Loaded ${resultRows.length} rows. Total: ${resultCount}`);
      
      if (!Array.isArray(resultRows)) {
          throw new Error("Invalid response format: Expected an array of products.");
      }

      setRows(resultRows);
      setTotal(resultCount);

    } catch (err) {
      console.error("[ProductsList] Error loading products:", err);
      setError(err.message || "Failed to load products.");
      toast({
        variant: "destructive",
        title: "Failed to load products",
        description: err.message,
      });
    } finally {
      setLoading(false);
    }
  }, [page, debouncedQ, sort, pageSize, toast]);

  useEffect(() => {
    loadProducts();
  }, [loadProducts]);

  const handleSearchChange = (e) => {
    setQ(e.target.value);
    setPage(1);
  };

  const handleDelete = async (productId, productTitle) => {
    try {
      const { error } = await deleteProduct(productId);
      if (error) throw error;
      toast({
        title: "Success",
        description: `Product "${productTitle}" deleted successfully.`,
      });
      loadProducts();
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Failed to delete product",
        description: error.message,
      });
    }
  };

  const totalPages = Math.max(1, Math.ceil(total / pageSize));

  return (
    <div className="p-4 sm:p-6 text-white">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
        <div>
          <h1 className="text-2xl font-bold">Products</h1>
          <p className="text-sm text-zinc-400 mt-1">
            {total.toLocaleString()} products
          </p>
        </div>
        <Button onClick={() => navigate("/admin/products/new")} className="bg-yellow-500 text-black hover:bg-yellow-400">
          New Product
        </Button>
      </div>

      {error && (
        <div className="bg-red-950/20 border border-red-900/50 p-4 rounded-lg mb-6 text-red-400">
            Error: {error}
        </div>
      )}

      <div className="bg-zinc-900 border border-zinc-800 rounded-lg p-4 mb-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          <input
            type="text"
            placeholder="Search products..."
            value={q}
            onChange={handleSearchChange}
            className="w-full px-3 py-2 rounded-md bg-zinc-800 border border-zinc-700 focus:ring-yellow-500 focus:border-yellow-500 text-white placeholder:text-zinc-500"
          />
          <select value={sort} onChange={e => { setPage(1); setSort(e.target.value); }} className="px-3 py-2 rounded-md bg-zinc-800 border border-zinc-700 focus:ring-yellow-500 focus:border-yellow-500 text-white">
            <option value="created_at.desc">Newest</option>
            <option value="created_at.asc">Oldest</option>
            <option value="title.asc">Title A–Z</option>
            <option value="title.desc">Title Z–A</option>
            <option value="price.asc">Price ↑</option>
            <option value="price.desc">Price ↓</option>
          </select>
          <select value={pageSize} onChange={e => { setPage(1); setPageSize(Number(e.target.value)); }} className="px-3 py-2 rounded-md bg-zinc-800 border border-zinc-700 focus:ring-yellow-500 focus:border-yellow-500 text-white">
            <option value={10}>10 per page</option>
            <option value={50}>50 per page</option>
            <option value={100}>100 per page</option>
          </select>
        </div>
      </div>

      <div className="overflow-x-auto rounded-lg border border-zinc-800">
        <table className="w-full text-sm text-left">
          <thead className="bg-zinc-800 text-zinc-400 uppercase tracking-wider">
            <tr>
              <th className="p-3 w-12"></th>
              <th className="p-3">Product</th>
              <th className="p-3">Vendor</th>
              <th className="p-3">Price</th>
              <th className="p-3">Agg. Inventory</th>
              <th className="p-3 text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="bg-zinc-900">
            {loading && (
              <tr>
                <td colSpan="6" className="text-center p-8">
                  <Loader2 className="mx-auto h-8 w-8 animate-spin text-yellow-500" />
                </td>
              </tr>
            )}
            {!loading && rows.map((row) => (
              <tr key={row.id} className="border-b border-zinc-800 hover:bg-zinc-800/50">
                <td className="p-2">
                  <img
                    src={row.thumbnail_url || PLACEHOLDER_IMAGE}
                    alt={row.title || 'Product'}
                    className="h-10 w-10 rounded-md object-cover bg-zinc-800"
                    onError={(e) => { 
                      e.currentTarget.onerror = null; 
                      e.currentTarget.src = PLACEHOLDER_IMAGE; 
                    }}
                  />
                </td>
                <td className="p-3 font-medium text-white">
                  {row.title || 'Untitled Product'}
                </td>
                <td className="p-3 text-zinc-400">
                  <span className="text-white">{row.vendor || '—'}</span>
                </td>
                <td className="p-3 text-zinc-400">
                    ${Number(row.price ?? 0).toFixed(2)}
                </td>
                <td className="p-3 text-zinc-400">{row.inventory ?? 0}</td>
                <td className="p-3 text-right">
                   <div className="flex justify-end gap-2">
                     <Button variant="outline" size="sm" onClick={() => navigate(`/admin/products/${row.id}`)}><Edit className="h-4 w-4 mr-2" />Edit</Button>
                      <AlertDialog>
                          <AlertDialogTrigger asChild>
                              <Button variant="destructive" size="sm"><Trash2 className="h-4 w-4 mr-2" />Delete</Button>
                          </AlertDialogTrigger>
                          <AlertDialogContent>
                              <AlertDialogHeader>
                                  <AlertDialogTitle>Are you sure?</AlertDialogTitle>
                                  <AlertDialogDescription>
                                      This will permanently delete the product "{row.title}". This action cannot be undone.
                                  </AlertDialogDescription>
                              </AlertDialogHeader>
                              <AlertDialogFooter>
                                  <AlertDialogCancel>Cancel</AlertDialogCancel>
                                  <AlertDialogAction onClick={() => handleDelete(row.id, row.title)}>
                                      Continue
                                  </AlertDialogAction>
                              </AlertDialogFooter>
                          </AlertDialogContent>
                      </AlertDialog>
                  </div>
                </td>
              </tr>
            ))}
            {!loading && rows.length === 0 && (
              <tr>
                <td colSpan="6" className="text-center p-8 text-zinc-500">
                  No products found.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
      {total > 0 && (
        <div className="mt-6 flex justify-between items-center">
          <p className="text-xs text-zinc-400">
            Showing {(page - 1) * pageSize + 1}–{Math.min(page * pageSize, total)} of {total}
          </p>
          {totalPages > 1 && (
            <div className="flex gap-2">
              <Button variant="outline" size="sm" disabled={page <= 1} onClick={() => setPage(p => p - 1)}>Previous</Button>
              <Button variant="outline" size="sm" disabled={page >= totalPages} onClick={() => setPage(p => p + 1)}>Next</Button>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
