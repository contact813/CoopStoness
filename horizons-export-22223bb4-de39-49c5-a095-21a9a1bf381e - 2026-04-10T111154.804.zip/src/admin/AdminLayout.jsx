import React from 'react';
import { Outlet } from 'react-router-dom';
import AdminSidebar from '@/components/admin/AdminSidebar';
import AdminHeader from '@/components/admin/AdminHeader';

/**
 * FILENAME: src/admin/AdminLayout.jsx
 * PURPOSE: Root layout for all /admin routes.
 * FIX: 
 * 1. AdminHeader is fixed at the top with z-[60].
 * 2. Sidebar and Main content are wrapped in a container with lower z-index stacking.
 * 3. Ensured no absolute/fixed positioning in this layout conflicts with the header.
 */
const AdminLayout = () => {
  return (
    <div className="min-h-screen bg-zinc-950 text-white font-sans selection:bg-yellow-500/30 flex flex-col overflow-x-hidden">
      {/* Fixed AdminHeader - Height is 72px, z-[60] */}
      <AdminHeader />
      
      {/* Main Container: Offset by header height to prevent overlap */}
      <div className="flex flex-1 pt-[72px] relative z-10">
        {/* Sidebar: w-64, sticky at top-[72px], z-40 */}
        <AdminSidebar />
        
        {/* Main content takes remaining width */}
        <main className="flex-1 p-8 min-h-[calc(100vh-72px)] overflow-x-hidden relative z-0 bg-zinc-950">
          <div className="max-w-7xl mx-auto animate-in fade-in slide-in-from-bottom-4 duration-500">
            <Outlet />
          </div>
        </main>
      </div>
    </div>
  );
};

export default AdminLayout;