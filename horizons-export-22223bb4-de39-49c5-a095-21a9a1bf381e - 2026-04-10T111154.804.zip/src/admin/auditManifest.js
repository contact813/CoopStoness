/**
 * Audit Manifest
 * 
 * Provides a "map" of the frontend file structure for the backend audit 
 * to analyze. Since the Edge Function cannot access the frontend file system,
 * we generate this list using Vite's import.meta.glob and pass it during the audit run.
 */

export const getClientFileManifest = () => {
  // Get all jsx/js files in pages
  const modules = import.meta.glob('/src/pages/**/*.{jsx,js}');
  
  // REAL DATA: No masking. We send the raw list of files found.
  // The backend will determine if duplicates exist.
  return Object.keys(modules);
};

export const knownDuplicates = [];