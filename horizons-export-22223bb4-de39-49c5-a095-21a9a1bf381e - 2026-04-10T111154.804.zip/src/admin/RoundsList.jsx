
import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { PlusCircle, Edit, Trash2, Loader2, Circle, ArrowUp, ArrowDown } from "lucide-react";
import { listRoundsWithItems, updateRound, deleteRound, moveRound } from "@/lib/adminRoundsApi";
import { confirmDialog } from "@/lib/confirmDialog";
import { useToast } from "@/components/ui/use-toast";
import { Button } from "@/components/ui/button";
import { getProductImage } from "@/lib/image";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { cn } from "@/lib/utils";

const statusConfig = {
  active: { label: "Active", color: "text-green-400" },
  draft: { label: "Draft", color: "text-zinc-400" },
  archived: { label: "Archived", color: "text-red-500" },
};

const statusOptions = Object.keys(statusConfig);

const StatusSelector = ({ round, onUpdate }) => {
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();

  const handleStatusChange = async (newStatus) => {
    if (newStatus === round.status) return;

    setLoading(true);
    try {
      const { error } = await updateRound(round.id, { status: newStatus });
      if (error) throw error;
      onUpdate(round.id, newStatus);
      toast({ title: "Success", description: "Round status updated." });
    } catch (err) {
      console.error("Failed to update status:", err);
      toast({ title: "Error", description: "Could not update status.", variant: "destructive" });
    } finally {
      setLoading(false);
    }
  };
  
  const currentStatusConfig = statusConfig[round.status] || statusConfig.draft;

  return (
    <div className="relative flex items-center w-[120px]">
      <Select
        value={round.status}
        onValueChange={handleStatusChange}
        disabled={loading}
      >
        <SelectTrigger className="w-full border-zinc-700 bg-zinc-900 h-9">
          <SelectValue asChild>
            <div className="flex items-center gap-2">
                <Circle className={`w-2.5 h-2.5 fill-current ${currentStatusConfig.color}`} />
                <span className="text-sm">{currentStatusConfig.label}</span>
            </div>
          </SelectValue>
        </SelectTrigger>
        <SelectContent>
          {statusOptions.map((status) => {
            const config = statusConfig[status];
            return (
              <SelectItem key={status} value={status}>
                <div className="flex items-center gap-2">
                    <Circle className={`w-2.5 h-2.5 fill-current ${config.color}`} />
                    <span>{config.label}</span>
                </div>
              </SelectItem>
            );
          })}
        </SelectContent>
      </Select>
      {loading && <Loader2 className="absolute right-2 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-400 animate-spin" />}
    </div>
  );
};

export default function RoundsList() {
  const [rounds, setRounds] = useState([]);
  const [loading, setLoading] = useState(true);
  const [movingId, setMovingId] = useState(null);
  const { toast } = useToast();

  const fetchRounds = async () => {
    setLoading(true);
    try {
      const { data, error } = await listRoundsWithItems({ from: 0, to: 100 });
      if (error) throw error;
      setRounds(data || []);
    } catch (error) {
      console.error("Failed to load rounds:", error);
      toast({ title: "Error", description: "Failed to load rounds.", variant: "destructive" });
      setRounds([]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchRounds();
  }, []);

  const handleStatusUpdate = (roundId, newStatus) => {
    setRounds(prevRounds =>
      prevRounds.map(r => (r.id === roundId ? { ...r, status: newStatus } : r))
    );
  };

  const handleDeleteRound = async (roundId) => {
    if (await confirmDialog({ title: 'Delete Round', description: 'Are you sure you want to delete this round? This action cannot be undone.' })) {
      try {
        const { error } = await deleteRound(roundId);
        if (error) throw error;
        toast({ title: "Success", description: "Round deleted successfully." });
        setRounds(prevRounds => prevRounds.filter(r => r.id !== roundId));
      } catch (err) {
        toast({ title: "Error", description: `Could not delete round: ${err.message}`, variant: "destructive" });
      }
    }
  };

  const handleMoveRound = async (roundId, direction, round) => {
    if (movingId) return; // Prevent double clicks
    
    const roundsWithSameStatus = rounds.filter(r => r.status === round.status);
    const indexInGroup = roundsWithSameStatus.findIndex(r => r.id === roundId);
    const isFirstInGroup = indexInGroup === 0;
    const isLastInGroup = indexInGroup === roundsWithSameStatus.length - 1;

    console.log(`[handleMoveRound] Moving ${direction}: ${roundId}, Status: ${round.status}, Group size: ${roundsWithSameStatus.length}, Index: ${indexInGroup}`);

    if (direction === 'up' && isFirstInGroup) return;
    if (direction === 'down' && isLastInGroup) return;

    setMovingId(roundId);
    try {
        const { data, error } = await moveRound(roundId, direction);
        if (error) throw error;
        if (data && data.length > 0) {
            setRounds(data);
        } else {
             await fetchRounds();
        }
    } catch (err) {
        console.error("Move error:", err);
        toast({ title: "Error", description: "Failed to move round." });
    } finally {
        setMovingId(null);
    }
  };

  return (
    <div className="relative z-0">
      <div className="flex justify-end mb-6 sticky top-0 bg-zinc-950 py-4 z-10 border-b border-zinc-900/50">
        <Link to="/admin/rounds/new">
          <Button className="bg-yellow-500 hover:bg-yellow-400 text-black shadow-none border-0">
            <PlusCircle size={18} className="mr-2" />
            New Round
          </Button>
        </Link>
      </div>

      <div className="overflow-x-auto rounded-lg border border-zinc-800 bg-zinc-950">
        <table className="w-full text-sm text-left text-zinc-400">
          <thead className="text-xs text-zinc-400 uppercase bg-zinc-950">
            <tr>
              <th scope="col" className="px-6 py-3 w-[100px] text-center">Order</th>
              <th scope="col" className="px-6 py-3 w-[40%]">Round Title</th>
              <th scope="col" className="px-6 py-3">Status</th>
              <th scope="col" className="px-6 py-3">Date Range</th>
              <th scope="col" className="px-6 py-3">Products</th>
              <th scope="col" className="px-6 py-3 text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-zinc-800">
            {loading ? (
              <tr><td colSpan="6" className="text-center py-8"><Loader2 className="mx-auto w-6 h-6 animate-spin"/></td></tr>
            ) : rounds.length === 0 ? (
              <tr><td colSpan="6" className="text-center py-8">No rounds found.</td></tr>
            ) : (
              rounds.map((round) => {
                const roundsWithSameStatus = rounds.filter(r => r.status === round.status);
                const indexInGroup = roundsWithSameStatus.findIndex(r => r.id === round.id);
                const isFirstInGroup = indexInGroup === 0;
                const isLastInGroup = indexInGroup === roundsWithSameStatus.length - 1;

                return (
                  <tr 
                      key={round.id} 
                      className={cn(
                          "bg-zinc-900 transition-colors duration-300",
                          movingId === round.id ? "bg-zinc-800/80 animate-pulse" : "hover:bg-zinc-800/50"
                      )}
                  >
                    <td className="px-6 py-4">
                       <div className="flex items-center justify-center gap-2">
                          <span className="text-zinc-500 font-mono w-6 text-center">{round.order_index ?? '-'}</span>
                          <div className="flex flex-col gap-1">
                              <button 
                                  onClick={() => handleMoveRound(round.id, 'up', round)}
                                  disabled={isFirstInGroup || !!movingId}
                                  className="text-zinc-600 hover:text-yellow-400 disabled:opacity-30 disabled:hover:text-zinc-600 disabled:cursor-not-allowed transition-colors"
                              >
                                  <ArrowUp size={14} />
                              </button>
                              <button 
                                  onClick={() => handleMoveRound(round.id, 'down', round)}
                                  disabled={isLastInGroup || !!movingId}
                                  className="text-zinc-600 hover:text-yellow-400 disabled:opacity-30 disabled:hover:text-zinc-600 disabled:cursor-not-allowed transition-colors"
                              >
                                  <ArrowDown size={14} />
                              </button>
                          </div>
                       </div>
                    </td>

                    <td className="px-6 py-4">
                      <div className="flex items-center gap-4">
                        <img 
                          src={round.cover_image_url || '/images/placeholder-product.svg'} 
                          alt={round.title} 
                          className="w-16 h-10 rounded-md object-cover flex-shrink-0 bg-zinc-800 border border-zinc-700"
                          referrerPolicy="no-referrer"
                        />
                        <div>
                          <Link to={`/admin/rounds/${round.id}`} className="font-medium text-white hover:text-yellow-400 transition-colors">{round.title}</Link>
                          <p className="text-xs text-zinc-500 font-normal mt-1">/{round.slug}</p>
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <StatusSelector round={round} onUpdate={handleStatusUpdate} />
                    </td>
                    <td className="px-6 py-4 text-xs">
                      <span className="block text-zinc-300">{new Date(round.starts_at).toLocaleDateString()}</span>
                      <span className="block text-zinc-500">{new Date(round.ends_at).toLocaleDateString()}</span>
                    </td>
                    <td className="px-6 py-4">
                      {round.items && round.items.length > 0 ? (
                         <div className="flex items-center -space-x-2 hover:space-x-1 transition-all">
                          {round.items.slice(0, 3).map((item) => (
                            <img 
                              key={item.product_id || item.id} 
                              src={getProductImage(item) || '/images/placeholder-product.svg'} 
                              alt={item.title || 'Product'} 
                              className="w-8 h-8 rounded-full border-2 border-zinc-700 object-cover bg-zinc-800 transition-transform hover:scale-110 hover:z-10" 
                              referrerPolicy="no-referrer" 
                            />
                          ))}
                          {round.items.length > 3 && <span className="pl-3 text-xs z-10 font-medium text-zinc-400">+{round.items.length - 3}</span>}
                        </div>
                      ) : <span className="text-xs text-zinc-500 italic">None</span>}
                    </td>
                    <td className="px-6 py-4 text-right">
                      <div className="flex items-center justify-end">
                        <Link to={`/admin/rounds/${round.id}`}>
                          <Button 
                            variant="outline" 
                            size="icon" 
                            className="h-8 w-8 border-zinc-700 text-zinc-400 hover:bg-zinc-800 hover:text-white transition-colors"
                          >
                            <Edit size={14} />
                          </Button>
                        </Link>
                        <Button 
                          variant="ghost" 
                          size="icon" 
                          className="h-8 w-8 bg-red-600 text-white hover:bg-red-700 ml-2 transition-colors border-0 inline-flex items-center justify-center rounded-md" 
                          onClick={() => handleDeleteRound(round.id)}
                        >
                          <Trash2 size={14} className="text-white" />
                        </Button>
                      </div>
                    </td>
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
