
import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { createProduct, getProductById, updateProduct } from '@/lib/adminProductsApi';
import { uploadProductImage } from '@/lib/storageApi';
import { useToast } from '@/components/ui/use-toast';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Loader2, ArrowLeft, Save, UploadCloud } from 'lucide-react';
import { PLACEHOLDER_IMAGE } from '@/lib/imageUtils';

const emptyModel = {
  title: "",
  vendor: "",
  type: "",
  price: 0,
  inventory: 0,
  description: "",
  tags: "",
  thumbnail_url: "",
  seo_description: ""
};

export default function ProductEdit() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { toast } = useToast();
  const isNew = id === 'new';

  const [model, setModel] = useState(emptyModel);
  const [loading, setLoading] = useState(!isNew);
  const [saving, setSaving] = useState(false);
  const [uploadingImage, setUploadingImage] = useState(false);
  const [error, setError] = useState(null);

  useEffect(() => {
    if (isNew) {
      setModel(emptyModel);
      setLoading(false);
      return;
    }

    setLoading(true);
    setError(null);
    
    console.log(`[ProductEdit] Loading product ID: ${id}`);
    getProductById(id)
      .then(({ data, error: apiErr }) => {
        if (apiErr) {
           console.error("[ProductEdit] API Error loading product:", apiErr);
           setError(apiErr.message || "Failed to load product");
           toast({ variant: "destructive", title: "Error", description: apiErr.message });
           navigate('/admin/products');
           return;
        } 
        
        if (data) {
          console.log("[ProductEdit] Successfully loaded product:", data.id);
          setModel({
            ...emptyModel,
            ...data,
            inventory: data.inventory || 0,
            price: data.price || 0,
          });
        } else {
          console.warn("[ProductEdit] Product not found in database.");
          toast({
            variant: "destructive",
            title: "Product not found",
            description: `A product with ID "${id}" could not be found.`,
          });
          navigate('/admin/products');
        }
      })
      .catch(err => {
        console.error("[ProductEdit] Uncaught error:", err);
        setError(err.message || "Failed to load product");
        toast({
          variant: "destructive",
          title: "Failed to load product",
          description: err.message,
        });
      })
      .finally(() => setLoading(false));
  }, [id, isNew, navigate, toast]);

  const handleImageUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setUploadingImage(true);
    try {
        const uploadProductId = isNew ? 'temp' : id;
        const url = await uploadProductImage(file, uploadProductId);
        setModel(prev => ({ ...prev, thumbnail_url: url }));
        toast({ title: "Image uploaded successfully" });
    } catch (err) {
        toast({ variant: "destructive", title: "Upload Failed", description: err.message });
    } finally {
        setUploadingImage(false);
        if (e.target) e.target.value = null;
    }
  };

  const handleSave = async (e) => {
    e.preventDefault();
    if (!model.title.trim()) {
        toast({ variant: "destructive", title: "Validation Error", description: "Title is required" });
        return;
    }

    setSaving(true);
    setError(null);

    const payload = {
      title: model.title,
      vendor: model.vendor || "",
      type: model.type || "",
      tags: model.tags || "",
      description: model.description || "",
      price: parseFloat(model.price) || 0,
      inventory: parseInt(model.inventory) || 0,
      thumbnail_url: model.thumbnail_url || "",
      seo_description: model.seo_description || ""
    };

    try {
      if (isNew) {
        const { data, error: createErr } = await createProduct(payload);
        if (createErr) throw createErr;
        
        toast({ title: "Product created successfully!" });
        if (data && data.id) {
            navigate(`/admin/products/${data.id}`);
        } else {
            navigate('/admin/products');
        }
      } else {
        const { error: updateErr } = await updateProduct(id, payload);
        if (updateErr) throw updateErr;
        
        toast({ title: "Product updated successfully!" });
        navigate('/admin/products');
      }
    } catch (err) {
      console.error("[ProductEdit] Save error:", err);
      setError(err.message || "An error occurred while saving the product.");
      toast({
        variant: "destructive",
        title: "Save failed",
        description: err.message || "An error occurred while saving the product.",
      });
    } finally {
      setSaving(false);
    }
  };
  
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setModel(prev => ({ ...prev, [name]: value }));
  }

  if (loading) {
    return <div className="flex justify-center items-center h-[50vh]"><Loader2 className="h-10 w-10 animate-spin text-yellow-500" /></div>;
  }

  return (
    <div className="container mx-auto max-w-7xl px-4 py-8 text-white">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between mb-8 gap-4">
        <div>
           <Button variant="ghost" onClick={() => navigate('/admin/products')} className="mb-2 pl-0 hover:bg-transparent hover:text-yellow-500 text-zinc-400">
             <ArrowLeft className="w-4 h-4 mr-2" /> Back to Products
           </Button>
           <h1 className="text-3xl font-bold tracking-tight">{isNew ? 'New Product' : `Edit: ${model.title}`}</h1>
        </div>
        
        <div className="flex items-center gap-3 w-full sm:w-auto">
            <Button variant="outline" onClick={() => navigate('/admin/products')} className="flex-1 sm:flex-none border-zinc-700 hover:bg-zinc-800 text-zinc-300">
                Cancel
            </Button>
            <Button onClick={handleSave} disabled={saving} className="flex-1 sm:flex-none bg-yellow-500 text-black hover:bg-yellow-400 font-semibold min-w-[120px]">
                {saving ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : <Save className="h-4 w-4 mr-2" />}
                {isNew ? 'Create' : 'Save Changes'}
            </Button>
        </div>
      </div>

      {error && (
        <div className="bg-red-950/20 border border-red-900/50 text-red-400 p-4 rounded-lg mb-6">
          {error}
        </div>
      )}
      
      <form onSubmit={handleSave} className="space-y-8">
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          
          <div className="lg:col-span-2 space-y-8">
            <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-6 shadow-sm">
                <h2 className="text-xl font-semibold mb-6 text-zinc-100">Product Details</h2>
                
                <div className="space-y-6">
                    <div>
                        <Label htmlFor="title" className="text-zinc-300 mb-2 block">Product Title</Label>
                        <Input 
                            id="title" 
                            name="title" 
                            value={model.title} 
                            onChange={handleInputChange} 
                            placeholder="e.g. Quartzite Taj Mahal Leather 3cm" 
                            required 
                            className="bg-zinc-950 border-zinc-800 h-12 text-lg"
                        />
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                            <Label htmlFor="vendor" className="text-zinc-300 mb-2 block">Vendor</Label>
                            <Input id="vendor" name="vendor" value={model.vendor} onChange={handleInputChange} placeholder="Brand or Supplier Name" className="bg-zinc-950 border-zinc-800" />
                        </div>
                        <div>
                            <Label htmlFor="type" className="text-zinc-300 mb-2 block">Category (Type)</Label>
                            <Input id="type" name="type" value={model.type} onChange={handleInputChange} placeholder="e.g. Slabs, Tile, Tools" className="bg-zinc-950 border-zinc-800" />
                        </div>
                    </div>

                    <div>
                        <Label htmlFor="description" className="text-zinc-300 mb-2 block">Description</Label>
                        <Textarea 
                            id="description" 
                            name="description" 
                            value={model.description} 
                            onChange={handleInputChange} 
                            rows={8} 
                            placeholder="Detailed product description..." 
                            className="bg-zinc-950 border-zinc-800 resize-y min-h-[160px]"
                        />
                    </div>

                    <div>
                        <Label htmlFor="seo_description" className="text-zinc-300 mb-2 block">SEO Description</Label>
                        <Textarea 
                            id="seo_description" 
                            name="seo_description" 
                            value={model.seo_description} 
                            onChange={handleInputChange} 
                            rows={3} 
                            placeholder="Brief description for search engines..." 
                            className="bg-zinc-950 border-zinc-800 resize-y"
                        />
                    </div>
                </div>
            </div>

            <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-6 shadow-sm">
                <h2 className="text-xl font-semibold mb-6 text-zinc-100">Image & Organization</h2>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                     <div className="space-y-4">
                        <Label className="text-zinc-300 mb-2 block">Thumbnail Image</Label>
                        <div className="w-full aspect-square max-w-[200px] border border-zinc-700 bg-zinc-950 rounded-lg overflow-hidden flex items-center justify-center relative group">
                            <img 
                                src={model.thumbnail_url || PLACEHOLDER_IMAGE} 
                                alt="Thumbnail" 
                                className="w-full h-full object-cover" 
                                onError={(e) => { e.currentTarget.src = PLACEHOLDER_IMAGE; }}
                            />
                            {uploadingImage && (
                                <div className="absolute inset-0 bg-black/50 flex items-center justify-center">
                                    <Loader2 className="w-8 h-8 text-yellow-500 animate-spin" />
                                </div>
                            )}
                        </div>
                        <div className="flex gap-2">
                             <Label htmlFor="image-upload" className="cursor-pointer bg-zinc-800 hover:bg-zinc-700 px-4 py-2 rounded-md text-sm font-medium transition-colors flex items-center">
                                 <UploadCloud className="w-4 h-4 mr-2" />
                                 Upload Image
                             </Label>
                             <Input 
                                id="image-upload" 
                                type="file" 
                                accept="image/*" 
                                className="hidden" 
                                onChange={handleImageUpload} 
                                disabled={uploadingImage}
                            />
                        </div>
                        <Input 
                            value={model.thumbnail_url} 
                            onChange={(e) => setModel(p => ({...p, thumbnail_url: e.target.value}))} 
                            placeholder="Or paste image URL" 
                            className="bg-zinc-950 border-zinc-800 text-xs" 
                        />
                    </div>
                    <div>
                        <Label htmlFor="tags" className="text-zinc-300 mb-2 block">Tags</Label>
                        <Input id="tags" name="tags" value={model.tags} onChange={handleInputChange} placeholder="Comma-separated (e.g. marble, white)" className="bg-zinc-950 border-zinc-800" />
                    </div>
                </div>
            </div>

          </div>

          <div className="space-y-8">
             <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-6 shadow-sm sticky top-6">
                <h2 className="text-xl font-semibold mb-6 text-zinc-100">Pricing & Base Stock</h2>
                <div className="space-y-6">
                    <div>
                        <Label htmlFor="price" className="text-zinc-300 mb-2 block">Default Price</Label>
                        <div className="relative">
                            <span className="absolute left-3 top-1/2 -translate-y-1/2 text-zinc-400 font-semibold">$</span>
                            <Input 
                                id="price" 
                                name="price" 
                                type="number" 
                                step="0.01" 
                                value={model.price} 
                                onChange={handleInputChange} 
                                placeholder="0.00" 
                                className="pl-7 bg-zinc-950 border-zinc-800"
                            />
                        </div>
                    </div>
                    <div>
                        <Label htmlFor="inventory" className="text-zinc-300 mb-2 block">Aggregated Inventory</Label>
                        <Input 
                            id="inventory" 
                            name="inventory" 
                            type="number"
                            value={model.inventory} 
                            onChange={handleInputChange} 
                            placeholder="0" 
                            className="bg-zinc-950 border-zinc-800"
                        />
                        <p className="text-xs text-zinc-500 mt-2">Note: Real inventory is tracked per variant (inventory_qty).</p>
                    </div>
                    <div className="pt-4 border-t border-zinc-800">
                        <Button type="submit" className="w-full bg-yellow-500 text-black hover:bg-yellow-400 font-bold" disabled={saving}>
                            {saving ? <Loader2 className="animate-spin" /> : "Save Changes"}
                        </Button>
                    </div>
                </div>
             </div>
          </div>

        </div>
      </form>
    </div>
  );
}
