
import React, { useState, useEffect, useRef } from "react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Search, Plus, Loader2, Check } from "lucide-react";
import { searchProducts } from "@/lib/productsApi";
import { cn } from "@/lib/utils";

export default function RoundProductSearch({ onAddProduct, linkedProductIds = [], isNewRound }) {
  const [searchTerm, setSearchTerm] = useState("");
  const [results, setResults] = useState([]);
  const [loading, setLoading] = useState(false);
  const [debouncedSearch, setDebouncedSearch] = useState("");
  const [showResults, setShowResults] = useState(false);
  const dropdownRef = useRef(null);

  useEffect(() => {
    const timer = setTimeout(() => {
      setDebouncedSearch(searchTerm);
    }, 500);
    return () => clearTimeout(timer);
  }, [searchTerm]);

  useEffect(() => {
    if (!debouncedSearch) {
      setResults([]);
      setShowResults(false);
      return;
    }
    runSearch(debouncedSearch);
  }, [debouncedSearch]);

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setShowResults(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);

  const runSearch = async (term) => {
    setLoading(true);
    setShowResults(true);
    try {
      console.log(`[RoundProductSearch] Searching for: "${term}"`);
      const response = await searchProducts(term, 20);
      
      if (response?.error) {
        console.error("[RoundProductSearch] Search error:", response.error);
        setResults([]);
        return;
      }

      const data = response?.data;
      if (Array.isArray(data)) {
        console.log(`[RoundProductSearch] Found ${data.length} results`);
        setResults(data);
      } else {
        console.warn("[RoundProductSearch] Invalid data format received:", data);
        setResults([]);
      }
    } catch (err) {
      console.error("[RoundProductSearch] Search failed with exception:", err);
      setResults([]);
    } finally {
      setLoading(false);
    }
  };

  const handleAdd = (product) => {
      if (linkedProductIds.includes(String(product.id))) {
          return;
      }
      onAddProduct(product);
      setSearchTerm("");
      setShowResults(false);
      setResults([]);
  };

  const handleInputFocus = () => {
    if (debouncedSearch && results.length > 0) {
      setShowResults(true);
    }
  };

  return (
    <div className="w-full space-y-4 relative" ref={dropdownRef}>
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-zinc-500 h-4 w-4" />
        <Input 
          placeholder="Search by Name, Vendor, or SKU..." 
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          onFocus={handleInputFocus}
          className="pl-9 bg-zinc-950 border-zinc-800 text-white placeholder:text-zinc-600 focus:border-yellow-500"
        />
        {loading && (
          <Loader2 className="absolute right-3 top-1/2 -translate-y-1/2 animate-spin text-yellow-500 h-4 w-4" />
        )}
      </div>

      {showResults && debouncedSearch && (
        <div className="absolute z-50 w-full mt-1 bg-zinc-950 border border-zinc-800 rounded-lg shadow-xl max-h-[300px] overflow-y-auto custom-scrollbar">
          {results.length === 0 && !loading ? (
             <div className="p-4 text-center text-zinc-500 text-sm">
               No products found.
             </div>
          ) : (
             <div className="p-2 space-y-2">
              {results.map((product) => {
                const isLinked = linkedProductIds.includes(String(product.id));
                const sku = product.variants?.[0]?.sku || 'No SKU';
                const price = `$${product.min_price.toFixed(2)}`;
                
                return (
                  <div 
                    key={product.id} 
                    className={cn(
                      "flex items-center justify-between p-3 rounded-lg border transition-all",
                      isLinked 
                        ? "bg-zinc-900/50 border-zinc-800 opacity-60" 
                        : "bg-zinc-900 border-zinc-800 hover:border-zinc-700"
                    )}
                  >
                    <div className="flex items-center gap-3 overflow-hidden">
                      <div className="h-10 w-10 bg-zinc-950 rounded overflow-hidden border border-zinc-800 flex-shrink-0">
                        {product.thumbnail_url ? (
                          <img src={product.thumbnail_url} alt="" className="h-full w-full object-cover" />
                        ) : (
                          <div className="w-full h-full flex items-center justify-center text-zinc-700 text-xs">IMG</div>
                        )}
                      </div>
                      <div className="min-w-0 flex-1">
                        <h4 className="text-sm font-medium text-zinc-200 truncate" title={product.title}>{product.title}</h4>
                        <div className="flex flex-col gap-0.5 text-xs text-zinc-500">
                          <div className="flex items-center gap-2 truncate">
                            <span className="text-zinc-400 truncate max-w-[120px]" title={product.vendor}>{product.vendor}</span>
                            <span className="text-zinc-600">•</span>
                            <span className="text-zinc-500 font-mono" title={sku}>SKU: {sku}</span>
                          </div>
                          <div>
                            <span className="text-yellow-500/80">{price}</span>
                            <span className="mx-1 text-zinc-600">•</span>
                             <span>Stock: {product.inventory}</span>
                          </div>
                        </div>
                      </div>
                    </div>

                    <Button
                      size="sm"
                      variant={isLinked ? "ghost" : "secondary"}
                      disabled={isLinked}
                      onClick={() => handleAdd(product)}
                      className={cn(
                        "h-8 w-8 p-0 flex-shrink-0 rounded-full",
                        isLinked ? "text-green-500 cursor-default hover:text-green-500 hover:bg-transparent" : "bg-zinc-800 hover:bg-zinc-700 text-white"
                      )}
                    >
                      {isLinked ? (
                        <Check className="h-4 w-4" />
                      ) : (
                        <Plus className="h-4 w-4" />
                      )}
                    </Button>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
