import React, { useState } from 'react';
import { supabase } from '@/lib/supabaseClient';
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  ChevronRight, 
  ChevronDown, 
  Loader2, 
  Plus, 
  Trash2, 
  Image as ImageIcon 
} from "lucide-react";
import { cn } from "@/lib/utils";
import { useToast } from "@/components/ui/use-toast";

/**
 * Component to manage the complex nested list of Products and their Variants
 * for a specific Round.
 */
export default function RoundEditProductList({ 
  roundId, 
  items, // Current items in round_products (both parents and variants)
  onAddVariant, 
  onRemoveItem 
}) {
  const [expandedProducts, setExpandedProducts] = useState(new Set());
  const [loadingVariants, setLoadingVariants] = useState(new Set());
  const [productVariants, setProductVariants] = useState({}); // Map product_id -> variants[]
  const { toast } = useToast();

  const toggleExpand = async (productId) => {
    const newExpanded = new Set(expandedProducts);
    const isExpanding = !newExpanded.has(productId);

    if (isExpanding) {
      newExpanded.add(productId);
      // Fetch variants if not already cached
      if (!productVariants[productId]) {
        await fetchVariants(productId);
      }
    } else {
      newExpanded.delete(productId);
    }
    setExpandedProducts(newExpanded);
  };

  const fetchVariants = async (productId) => {
    setLoadingVariants(prev => new Set(prev).add(productId));
    try {
      const { data, error } = await supabase
        .from('product_variants')
        .select('*')
        .eq('product_id', productId)
        .eq('is_active', true)
        .order('position');

      if (error) throw error;
      setProductVariants(prev => ({ ...prev, [productId]: data || [] }));
    } catch (err) {
      console.error("Error fetching variants:", err);
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to load variants."
      });
    } finally {
      setLoadingVariants(prev => {
        const next = new Set(prev);
        next.delete(productId);
        return next;
      });
    }
  };

  // Helper to check if a specific variant is already added to the round
  const isVariantAdded = (variantId) => {
    return items.some(item => item.variant_id === variantId);
  };

  // Filter items to show only PARENT products (variant_id is null) in the main list
  // Variants are shown as children when expanded
  const parentItems = items.filter(item => !item.variant_id);

  return (
    <div className="rounded-md border border-zinc-800 bg-zinc-950/50">
      <Table>
        <TableHeader className="bg-zinc-900/50">
          <TableRow className="border-zinc-800 hover:bg-transparent">
            <TableHead className="w-[50px]"></TableHead>
            <TableHead className="w-[80px]">Image</TableHead>
            <TableHead>Product / Variant</TableHead>
            <TableHead>SKU</TableHead>
            <TableHead>Price</TableHead>
            <TableHead>Goal</TableHead>
            <TableHead>Progress</TableHead>
            <TableHead className="text-right">Actions</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {parentItems.length === 0 ? (
            <TableRow>
              <TableCell colSpan={8} className="h-24 text-center text-zinc-500">
                No products added to this round yet.
              </TableCell>
            </TableRow>
          ) : (
            parentItems.map((item) => (
              <React.Fragment key={item.product_id}>
                {/* Parent Row */}
                <TableRow className="border-zinc-800 hover:bg-zinc-900/50">
                  <TableCell>
                    <Button 
                      variant="ghost" 
                      size="sm" 
                      onClick={() => toggleExpand(item.product_id)}
                      className="h-8 w-8 p-0"
                    >
                      {loadingVariants.has(item.product_id) ? (
                        <Loader2 className="h-4 w-4 animate-spin" />
                      ) : expandedProducts.has(item.product_id) ? (
                        <ChevronDown className="h-4 w-4" />
                      ) : (
                        <ChevronRight className="h-4 w-4" />
                      )}
                    </Button>
                  </TableCell>
                  <TableCell>
                    <div className="h-10 w-10 rounded-md bg-zinc-900 flex items-center justify-center overflow-hidden border border-zinc-800">
                      {item.thumbnail_url ? (
                        <img src={item.thumbnail_url} alt="" className="h-full w-full object-cover" />
                      ) : (
                        <ImageIcon className="h-5 w-5 text-zinc-700" />
                      )}
                    </div>
                  </TableCell>
                  <TableCell className="font-medium text-zinc-200">
                    {item.title}
                  </TableCell>
                  <TableCell className="text-zinc-400 font-mono text-xs">
                    {item.SKU || '-'}
                  </TableCell>
                  <TableCell className="text-zinc-300">
                    ${item.special_price || item.min_price || item.price}
                  </TableCell>
                  <TableCell className="text-zinc-400">
                    {item.goal_qty || '-'} {item.goal_unit}
                  </TableCell>
                  <TableCell>
                    {/* Simple progress bar placeholder */}
                    <div className="w-24 h-1.5 bg-zinc-800 rounded-full overflow-hidden">
                      <div 
                        className="h-full bg-yellow-600" 
                        style={{ width: `${Math.min(100, ((item.items_sold || 0) / (item.goal_qty || 1)) * 100)}%` }} 
                      />
                    </div>
                  </TableCell>
                  <TableCell className="text-right">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => onRemoveItem(item.product_id, null)}
                      className="text-red-400 hover:text-red-300 hover:bg-red-950/50"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </TableCell>
                </TableRow>

                {/* Variants Rows (Indented) */}
                {expandedProducts.has(item.product_id) && (
                  <>
                    {/* List actual database variants for this product */}
                    {productVariants[item.product_id]?.map((variant) => {
                      const added = isVariantAdded(variant.id);
                      const linkedItem = items.find(i => i.variant_id === variant.id);
                      
                      return (
                        <TableRow key={variant.id} className="border-zinc-800 bg-zinc-950/30 hover:bg-zinc-900/30">
                          <TableCell></TableCell> {/* Indent */}
                          <TableCell>
                             {/* Optionally show variant image */}
                             {variant.image_url && (
                               <img src={variant.image_url} alt="" className="h-8 w-8 rounded object-cover opacity-70" />
                             )}
                          </TableCell>
                          <TableCell className="pl-8">
                            <span className="text-sm text-zinc-400 flex items-center gap-2">
                              <span className="w-6 h-[1px] bg-zinc-700 inline-block"></span>
                              {variant.title}
                            </span>
                          </TableCell>
                          <TableCell className="text-zinc-500 font-mono text-xs">
                            {variant.sku}
                          </TableCell>
                          <TableCell className="text-zinc-400 text-sm">
                             {linkedItem?.special_price ? (
                               <span className="text-yellow-500">${linkedItem.special_price}</span>
                             ) : (
                               <span>${variant.price}</span>
                             )}
                          </TableCell>
                          <TableCell className="text-zinc-500 text-sm">
                            {linkedItem?.goal_qty ? `${linkedItem.goal_qty} ${linkedItem.goal_unit}` : '-'}
                          </TableCell>
                          <TableCell>
                             {/* Variant progress if linked */}
                          </TableCell>
                          <TableCell className="text-right">
                            {added ? (
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => onRemoveItem(item.product_id, variant.id)}
                                className="text-red-400 hover:text-red-300 hover:bg-red-950/50 h-7 text-xs"
                              >
                                Remove
                              </Button>
                            ) : (
                              <Button
                                variant="secondary"
                                size="sm"
                                onClick={() => onAddVariant(item.product_id, variant)}
                                className="h-7 text-xs bg-zinc-800 hover:bg-zinc-700 text-zinc-300"
                              >
                                <Plus className="h-3 w-3 mr-1" /> Add
                              </Button>
                            )}
                          </TableCell>
                        </TableRow>
                      );
                    })}
                    {(!productVariants[item.product_id] || productVariants[item.product_id].length === 0) && (
                       <TableRow>
                          <TableCell colSpan={8} className="text-center text-zinc-600 py-4 italic text-sm">
                             No variants found for this product.
                          </TableCell>
                       </TableRow>
                    )}
                  </>
                )}
              </React.Fragment>
            ))
          )}
        </TableBody>
      </Table>
    </div>
  );
}