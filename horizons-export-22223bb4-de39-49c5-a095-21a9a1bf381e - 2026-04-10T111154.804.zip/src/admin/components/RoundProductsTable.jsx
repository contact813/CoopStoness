
import React, { useMemo, useState, useEffect } from 'react';
import { supabase } from "@/lib/supabaseClient";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ChevronRight, ChevronDown, Trash2, Plus, Check, X, Loader2, FileImage as ImageIcon } from 'lucide-react';
import { cn } from "@/lib/utils";
import { PLACEHOLDER_IMAGE } from "@/lib/imageUtils";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { useToast } from "@/components/ui/use-toast";

// --- Sub-Components ---

const PricingInput = ({ item, onChange, roundDiscountPct }) => {
  const minPrice = useMemo(() => {
    return Number(item.variant_price ?? item.price ?? 0);
  }, [item.variant_price, item.price]);

  const computedPrice = useMemo(() => {
    const itemPct = item.discount_pct != null && item.discount_pct !== '' ? Number(String(item.discount_pct).replace(',', '.')) : null;
    const pctToUse = itemPct ?? (roundDiscountPct != null && roundDiscountPct !== '' ? Number(roundDiscountPct) : null);
    
    if (item.special_price != null && item.special_price !== '') {
      return Number(item.special_price).toFixed(2);
    }
    
    if (pctToUse != null && !Number.isNaN(pctToUse)) {
      return (minPrice * (1 - pctToUse / 100)).toFixed(2);
    }
    return "";
  }, [item.discount_pct, item.special_price, roundDiscountPct, minPrice]);

  return (
    <div className="space-y-1">
      <div className="text-[10px] text-zinc-400">Base: ${minPrice.toFixed(2)}</div>
      <Input
        type="number"
        value={item.special_price ?? ''}
        onChange={(e) => onChange({ ...item, special_price: e.target.value, discount_pct: '' })}
        placeholder="Price"
        className="h-8 bg-zinc-900 border-zinc-700 text-xs"
      />
      <div className="text-xs font-bold text-yellow-500">
        Final: ${computedPrice || minPrice.toFixed(2)}
      </div>
    </div>
  );
};

const GoalInput = ({ item, onChange }) => {
  const handleUnitChange = (val) => onChange({ ...item, goal_unit: val });
  const handleGoalChange = (e) => onChange({ ...item, goal_qty: e.target.value });
  const handleBoxSizeChange = (e) => onChange({ ...item, box_size: e.target.value });

  return (
    <div className="space-y-1">
      <div className="flex items-center gap-2 flex-nowrap">
        <Input
          type="number"
          value={item.goal_qty ?? ''}
          onChange={handleGoalChange}
          className="min-w-[64px] w-[64px] flex-shrink-0 h-8 bg-zinc-900 border-zinc-700 text-xs px-2"
          placeholder="Qty"
        />
        <Select value={item.goal_unit || 'un'} onValueChange={handleUnitChange}>
           <SelectTrigger className="min-w-[64px] w-[64px] flex-shrink-0 h-8 bg-zinc-900 border-zinc-700 text-[10px] px-1">
               <SelectValue />
           </SelectTrigger>
           <SelectContent>
               <SelectItem value="un">UN</SelectItem>
               <SelectItem value="caixa">BOX</SelectItem>
               <SelectItem value="kg">KG</SelectItem>
               <SelectItem value="sqft">SQFT</SelectItem>
               <SelectItem value="m2">M2</SelectItem>
           </SelectContent>
        </Select>
      </div>
      {item.goal_unit === 'caixa' && (
        <Input
          type="number"
          value={item.box_size ?? ''}
          onChange={handleBoxSizeChange}
          className="w-full h-7 bg-zinc-900 border-zinc-700 text-[10px]"
          placeholder="Units/Box"
        />
      )}
    </div>
  );
};

const SalesProgress = ({ item }) => {
  const salesGoal = useMemo(() => Number(item.goal_qty ?? 0), [item.goal_qty]);
  const itemsSold = useMemo(() => Number(item.items_sold ?? 0), [item.items_sold]);
  const progress = useMemo(() => (salesGoal > 0 ? Math.min(100, (itemsSold / salesGoal) * 100) : 0), [itemsSold, salesGoal]);

  if (salesGoal <= 0) {
    return (
        <div className="min-w-[120px] whitespace-nowrap text-left">
            <p className="text-xs text-gray-400">No goal set</p>
        </div>
    );
  }

  return (
    <div className="min-w-[120px] space-y-1">
      <div className="flex justify-between items-center text-[10px] mb-1">
        <span className="text-zinc-400">Sold</span>
        <span className="font-medium text-zinc-300">{itemsSold} / {salesGoal}</span>
      </div>
      <div className="w-full bg-zinc-800 rounded-full h-1.5 overflow-hidden">
        <div 
          className="bg-yellow-500 h-full rounded-full transition-all duration-500" 
          style={{ width: `${progress}%` }}
        />
      </div>
    </div>
  );
};

const AvailableVariantsRow = ({ productId, existingVariantIds, onAdd, onCancel }) => {
    const [variants, setVariants] = useState([]);
    const [loading, setLoading] = useState(true);
    const [selectedId, setSelectedId] = useState("");

    useEffect(() => {
        const fetchVariants = async () => {
            const { data } = await supabase
                .from('product_variants')
                .select('id, title, sku, price')
                .eq('product_id', productId)
                .eq('is_active', true);
            setVariants(data || []);
            setLoading(false);
        };
        fetchVariants();
    }, [productId]);

    const available = variants.filter(v => !existingVariantIds.includes(v.id));

    const handleAdd = () => {
        const variant = variants.find(v => v.id === selectedId);
        if (variant) onAdd(variant);
    };

    if (loading) return <div className="p-2 pl-12 text-xs text-zinc-500 flex items-center"><Loader2 className="h-3 w-3 animate-spin mr-2"/> Loading...</div>;

    if (available.length === 0) {
        return (
            <div className="flex items-center justify-between p-2 pl-12 bg-zinc-900/30 border-b border-zinc-800">
                <span className="text-xs text-zinc-500 italic">All variants linked.</span>
                <Button variant="ghost" size="sm" onClick={onCancel} className="h-6 w-6 p-0"><X className="h-3 w-3" /></Button>
            </div>
        );
    }

    return (
        <div className="flex items-center gap-2 p-2 pl-12 bg-zinc-900/30 border-b border-zinc-800 animate-in slide-in-from-top-1 fade-in">
            <Select value={selectedId} onValueChange={setSelectedId}>
                <SelectTrigger className="h-8 w-[300px] bg-zinc-950 border-zinc-700 text-xs">
                    <SelectValue placeholder="Select variant to add..." />
                </SelectTrigger>
                <SelectContent>
                    {available.map(v => (
                        <SelectItem key={v.id} value={v.id}>
                            {v.title} ({v.sku}) - ${v.price}
                        </SelectItem>
                    ))}
                </SelectContent>
            </Select>
            <Button size="sm" onClick={handleAdd} disabled={!selectedId} className="h-8 bg-yellow-500 text-black hover:bg-yellow-400 text-xs">
                Add Variant
            </Button>
            <Button size="sm" variant="ghost" onClick={onCancel} className="h-8 text-zinc-400 hover:text-white text-xs">
                Cancel
            </Button>
        </div>
    );
};

const TableRow = ({ item, isVariant, roundDiscountPct, onUpdate, onDelete, onExpand, isExpanded, onAddVariantChild }) => {
    const [isAddingVariant, setIsAddingVariant] = useState(false);

    const title = isVariant ? item.variant_title : item.title;
    const sku = isVariant ? item.variant_sku : '—';
    const image = isVariant 
        ? (item.variant_image || item.thumbnail_url || PLACEHOLDER_IMAGE) 
        : (item.thumbnail_url || PLACEHOLDER_IMAGE);

    return (
        <React.Fragment>
            <div className={cn(
                "grid grid-cols-12 gap-4 items-center p-3 border-b border-zinc-800 hover:bg-zinc-900/20 transition-colors text-sm",
                isVariant && "bg-zinc-900/10"
            )}>
                <div className="col-span-1 flex justify-center">
                    {!isVariant ? (
                        <Button 
                            variant="ghost" 
                            size="sm" 
                            className="h-6 w-6 p-0 text-zinc-500 hover:text-white"
                            onClick={onExpand}
                        >
                            {isExpanded ? <ChevronDown className="h-4 w-4" /> : <ChevronRight className="h-4 w-4" />}
                        </Button>
                    ) : (
                        <div className="w-px h-full bg-zinc-800 ml-auto mr-4" />
                    )}
                </div>

                <div className="col-span-4 flex items-start gap-3">
                    <div className={cn(
                        "rounded bg-zinc-800 overflow-hidden flex-shrink-0 border border-zinc-700 flex items-center justify-center",
                        isVariant ? "w-8 h-8 opacity-80" : "w-10 h-10"
                    )}>
                        <img 
                            src={image} 
                            alt="" 
                            className="w-full h-full object-cover" 
                            onError={(e) => { e.currentTarget.src = PLACEHOLDER_IMAGE; }}
                        />
                    </div>
                    <div className="min-w-0">
                        <div className={cn("font-medium truncate", isVariant ? "text-zinc-300" : "text-white")}>
                            {title}
                        </div>
                        {isVariant && (
                            <span className="inline-flex items-center rounded-sm bg-zinc-800 px-1.5 py-0.5 text-[10px] font-medium text-zinc-400 mt-0.5">
                                VARIANT
                            </span>
                        )}
                    </div>
                </div>

                <div className="col-span-2 text-xs text-zinc-500 font-mono break-all">
                    {sku}
                </div>

                <div className="col-span-2">
                    <PricingInput item={item} onChange={onUpdate} roundDiscountPct={roundDiscountPct} />
                </div>

                <div className="col-span-1 min-w-[160px] w-[160px] flex-shrink-0">
                    <GoalInput item={item} onChange={onUpdate} />
                </div>

                <div className="col-span-1 min-w-[120px] w-[120px] flex-shrink-0">
                    <SalesProgress item={item} />
                </div>

                <div className="col-span-1 flex justify-end">
                    <Button 
                        variant="ghost" 
                        size="icon" 
                        className="h-8 w-8 text-zinc-500 hover:text-red-400 hover:bg-red-950/20"
                        onClick={onDelete}
                    >
                        <Trash2 className="h-4 w-4" />
                    </Button>
                </div>
            </div>

            {isExpanded && !isVariant && (
                <div className="bg-zinc-950/30 border-b border-zinc-800 relative">
                     <div className="absolute left-[3.5%] top-0 bottom-0 w-px bg-zinc-800 -z-10" />

                     {item.childVariants?.map((variant, idx) => (
                         <TableRow 
                            key={variant.variant_id || idx}
                            item={variant}
                            isVariant={true}
                            roundDiscountPct={roundDiscountPct}
                            onUpdate={(updated) => onUpdate(updated, item.product_id)}
                            onDelete={() => onDelete(variant, item.product_id)}
                         />
                     ))}

                     {isAddingVariant ? (
                         <AvailableVariantsRow 
                            productId={item.product_id}
                            existingVariantIds={item.childVariants?.map(v => v.variant_id) || []}
                            onAdd={(vData) => {
                                onAddVariantChild(item.product_id, vData);
                                setIsAddingVariant(false);
                            }}
                            onCancel={() => setIsAddingVariant(false)}
                         />
                     ) : (
                         <div className="p-2 pl-12 border-b border-zinc-800 bg-zinc-900/10">
                             <Button 
                                variant="outline" 
                                size="sm" 
                                className="h-7 text-xs border-zinc-700 text-zinc-400 hover:text-white bg-zinc-900 hover:bg-zinc-800"
                                onClick={() => setIsAddingVariant(true)}
                             >
                                <Plus className="h-3 w-3 mr-1.5" /> Add Variant
                             </Button>
                         </div>
                     )}
                </div>
            )}
        </React.Fragment>
    );
};

export default function RoundProductsTable({ items, roundDiscountPct, onItemsChange, onAddVariant }) {
    const [expandedIds, setExpandedIds] = useState(new Set());
    const [itemToDelete, setItemToDelete] = useState(null);
    const { toast } = useToast();

    const toggleExpand = (id) => {
        setExpandedIds(prev => {
            const next = new Set(prev);
            if (next.has(id)) next.delete(id);
            else next.add(id);
            return next;
        });
    };

    const handleUpdateItem = (updatedItem, parentProductId) => {
        onItemsChange(prevItems => {
            return prevItems.map(parent => {
                if (parent.product_id === updatedItem.product_id && !updatedItem.variant_id) {
                    return { ...parent, ...updatedItem };
                }
                
                if (parent.product_id === (parentProductId || updatedItem.product_id)) {
                    const updatedChildren = parent.childVariants.map(child => {
                        if (child.variant_id === updatedItem.variant_id) {
                            return { ...child, ...updatedItem, variant_id: child.variant_id };
                        }
                        return child;
                    });
                    return { ...parent, childVariants: updatedChildren };
                }
                
                return parent;
            });
        });
    };

    const handleDeleteRequest = (item, parentProductId) => {
        setItemToDelete({ item, parentProductId });
    };

    const confirmDelete = () => {
        if (!itemToDelete) return;
        const { item, parentProductId } = itemToDelete;

        onItemsChange(prevItems => {
            if (!item.variant_id) {
                return prevItems.filter(p => p.product_id !== item.product_id);
            } else {
                return prevItems.map(parent => {
                    if (parent.product_id === parentProductId) {
                        return {
                            ...parent,
                            childVariants: parent.childVariants.filter(v => v.variant_id !== item.variant_id)
                        };
                    }
                    return parent;
                });
            }
        });
        setItemToDelete(null);
        toast({ title: "Removed", description: item.variant_id ? "Variant removed." : "Product removed." });
    };

    const handleAddVariantInternal = (productId, variantData) => {
        if (onAddVariant) {
            onAddVariant(productId, variantData);
        } else {
            console.error("onAddVariant prop missing");
        }
    };

    if (!items || items.length === 0) {
        return <div className="text-center text-zinc-500 py-12 italic border border-dashed border-zinc-800 rounded-xl">No products linked. Search above to add.</div>;
    }

    return (
        <div className="rounded-xl border border-zinc-800 bg-zinc-950 overflow-hidden">
             <div className="grid grid-cols-12 gap-4 p-3 bg-zinc-900 border-b border-zinc-800 text-[10px] font-bold text-zinc-400 uppercase tracking-wider">
                <div className="col-span-1"></div>
                <div className="col-span-4">Product</div>
                <div className="col-span-2">SKU</div>
                <div className="col-span-2">Pricing</div>
                <div className="col-span-1">Goal</div>
                <div className="col-span-1">Progress</div>
                <div className="col-span-1 text-right">Actions</div>
             </div>

             <div className="divide-y divide-zinc-800">
                {items.map(item => (
                    <TableRow 
                        key={item.product_id}
                        item={item}
                        isVariant={false}
                        roundDiscountPct={roundDiscountPct}
                        onUpdate={handleUpdateItem}
                        onDelete={() => handleDeleteRequest(item)}
                        onExpand={() => toggleExpand(item.product_id)}
                        isExpanded={expandedIds.has(item.product_id)}
                        onAddVariantChild={handleAddVariantInternal}
                    />
                ))}
             </div>

            <AlertDialog open={!!itemToDelete} onOpenChange={(open) => !open && setItemToDelete(null)}>
                <AlertDialogContent className="bg-zinc-950 border-zinc-800 text-white">
                    <AlertDialogHeader>
                        <AlertDialogTitle>Remove Item?</AlertDialogTitle>
                        <AlertDialogDescription className="text-zinc-400">
                            Are you sure you want to remove "{itemToDelete?.item.title || itemToDelete?.item.variant_title}"?
                            {itemToDelete?.item.variant_id ? " This variant will be unlinked." : " This will also remove all linked variants for this product."}
                        </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                        <AlertDialogCancel className="bg-transparent border-zinc-700 text-zinc-300 hover:bg-zinc-800 hover:text-white">Cancel</AlertDialogCancel>
                        <AlertDialogAction onClick={confirmDelete} className="bg-red-600 hover:bg-red-700 text-white">Remove</AlertDialogAction>
                    </AlertDialogFooter>
                </AlertDialogContent>
            </AlertDialog>
        </div>
    );
}
