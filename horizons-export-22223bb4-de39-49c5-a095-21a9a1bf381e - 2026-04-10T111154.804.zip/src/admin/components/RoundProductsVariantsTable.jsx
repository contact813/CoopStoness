
import React, { useState, useEffect } from 'react';
import { supabase } from "@/lib/supabaseClient";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { 
  ChevronRight, 
  ChevronDown, 
  Trash2, 
  Plus, 
  Check, 
  X, 
  Loader2
} from "lucide-react";
import { cn } from "@/lib/utils";
import { PLACEHOLDER_IMAGE } from "@/lib/imageUtils";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useToast } from "@/components/ui/use-toast";

const EditableInput = ({ value, onSave, type = "text", placeholder, prefix, suffix, className }) => {
    const [isEditing, setIsEditing] = useState(false);
    const [localValue, setLocalValue] = useState(value);
    
    useEffect(() => { setLocalValue(value); }, [value]);

    const handleSave = () => {
        onSave(localValue);
        setIsEditing(false);
    };

    if (isEditing) {
        return (
            <div className="flex items-center gap-1">
                <Input 
                    type={type} 
                    value={localValue} 
                    onChange={e => setLocalValue(e.target.value)} 
                    className={cn("h-8 text-xs bg-zinc-900", className)}
                    autoFocus
                    onKeyDown={e => {
                        if (e.key === 'Enter') handleSave();
                        if (e.key === 'Escape') setIsEditing(false);
                    }}
                />
                <Button size="sm" variant="ghost" onClick={handleSave} className="h-8 w-8 p-0 text-green-500"><Check className="h-4 w-4" /></Button>
            </div>
        );
    }

    return (
        <div 
            onClick={() => setIsEditing(true)} 
            className="cursor-pointer hover:bg-zinc-800 px-2 py-1 rounded flex items-center gap-1 group"
        >
            <span className={cn("text-sm", !value && "text-zinc-500")}>
                {prefix}{value || placeholder}{suffix}
            </span>
        </div>
    );
};

const AddVariantRow = ({ productId, parentTitle, existingVariantIds, onAdd, onCancel }) => {
    const [variants, setVariants] = useState([]);
    const [loading, setLoading] = useState(true);
    const [selectedId, setSelectedId] = useState("");

    useEffect(() => {
        const fetchVariants = async () => {
            const { data } = await supabase
                .from('product_variants')
                .select('id, title, sku, price')
                .eq('product_id', productId)
                .eq('is_active', true);
            setVariants(data || []);
            setLoading(false);
        };
        fetchVariants();
    }, [productId]);

    const available = variants.filter(v => !existingVariantIds.includes(v.id));

    const handleAdd = () => {
        const variant = variants.find(v => v.id === selectedId);
        if (variant) onAdd(variant);
    };

    if (loading) return <div className="p-4 text-xs text-zinc-500"><Loader2 className="h-3 w-3 animate-spin inline mr-2"/>Loading variants...</div>;

    if (available.length === 0) {
        return (
            <div className="p-3 bg-zinc-900/50 flex justify-between items-center text-xs text-zinc-400 rounded mx-4 my-2">
                <span>All variants added.</span>
                <Button size="sm" variant="ghost" onClick={onCancel}><X className="h-3 w-3" /></Button>
            </div>
        );
    }

    return (
        <div className="flex gap-2 items-center p-3 bg-zinc-900/50 mx-4 my-2 rounded border border-zinc-800 animate-in fade-in slide-in-from-top-1">
            <Select value={selectedId} onValueChange={setSelectedId}>
                <SelectTrigger className="h-8 bg-zinc-950 border-zinc-700 text-xs w-[300px]">
                    <SelectValue placeholder="Select variant..." />
                </SelectTrigger>
                <SelectContent>
                    {available.map(v => (
                        <SelectItem key={v.id} value={v.id}>
                            {v.title} - {v.sku} (${v.price})
                        </SelectItem>
                    ))}
                </SelectContent>
            </Select>
            <Button size="sm" onClick={handleAdd} disabled={!selectedId} className="h-8 text-xs bg-yellow-500 text-black hover:bg-yellow-400">Add</Button>
            <Button size="sm" variant="ghost" onClick={onCancel} className="h-8 w-8 p-0"><X className="h-4 w-4" /></Button>
        </div>
    );
};

const ProductRow = ({ item, isChild, isExpanded, onExpand, onUpdate, onDelete, onAddVariantChild }) => {
    const [addingVariant, setAddingVariant] = useState(false);
    
    const title = isChild ? item.variant_title : item.title;
    const sku = isChild ? item.variant_sku : '—';
    const basePrice = Number(isChild ? item.variant_price : item.price);
    const specialPrice = item.special_price;
    const image = isChild ? (item.variant_image || item.thumbnail_url || PLACEHOLDER_IMAGE) : (item.thumbnail_url || PLACEHOLDER_IMAGE);
    
    const sold = Number(item.items_sold || 0);
    const goal = Number(item.goal_qty || 0);
    const progress = goal > 0 ? Math.min(100, (sold / goal) * 100) : 0;
    const inventoryQty = isChild ? item.variant_inventory_qty : item.inventory;

    return (
        <>
            <div className={cn(
                "grid grid-cols-12 gap-4 items-center p-3 border-b border-zinc-800 hover:bg-zinc-900/30 transition-colors",
                isChild && "bg-zinc-900/20"
            )}>
                <div className="col-span-1 flex justify-center">
                    {!isChild ? (
                        <Button variant="ghost" size="sm" onClick={onExpand} className="h-6 w-6 p-0 text-zinc-500">
                            {isExpanded ? <ChevronDown className="h-4 w-4" /> : <ChevronRight className="h-4 w-4" />}
                        </Button>
                    ) : (
                        <div className="w-4 h-[1px] bg-zinc-700 ml-auto" />
                    )}
                </div>

                <div className="col-span-4 flex items-center gap-3">
                    <div className="h-10 w-10 bg-zinc-800 rounded border border-zinc-700 overflow-hidden flex-shrink-0">
                        <img src={image} alt="" className="h-full w-full object-cover" onError={(e) => { e.currentTarget.src = PLACEHOLDER_IMAGE; }} />
                    </div>
                    <div className="min-w-0">
                        <div className={cn("text-sm font-medium truncate", isChild ? "text-zinc-300" : "text-white")}>
                            {title}
                        </div>
                        {isChild && <div className="text-[10px] text-zinc-500 uppercase tracking-wider">Variant (Inv: {inventoryQty || 0})</div>}
                        {!isChild && <div className="text-[10px] text-zinc-500">Agg. Inv: {inventoryQty || 0}</div>}
                    </div>
                </div>

                <div className="col-span-2 text-xs text-zinc-500 font-mono">
                    {sku}
                </div>

                <div className="col-span-2">
                     <div className="text-[10px] text-zinc-500">Base: ${basePrice.toFixed(2)}</div>
                     <EditableInput 
                        value={specialPrice} 
                        onSave={(val) => onUpdate({ ...item, special_price: val })} 
                        placeholder="Price"
                        prefix="$"
                        className="w-24"
                     />
                </div>

                <div className="col-span-2 space-y-1">
                    <div className="flex items-center gap-2">
                        <EditableInput 
                            value={goal} 
                            onSave={(val) => onUpdate({ ...item, goal_qty: val })} 
                            type="number"
                            placeholder="0"
                            className="w-16"
                        />
                        <span className="text-xs text-zinc-500">{item.goal_unit || 'un'}</span>
                    </div>
                    {goal > 0 && (
                        <div className="h-1 bg-zinc-800 rounded-full w-full overflow-hidden">
                             <div className="h-full bg-yellow-500" style={{ width: `${progress}%` }} />
                        </div>
                    )}
                </div>

                <div className="col-span-1 flex justify-end">
                    <Button variant="ghost" size="icon" onClick={onDelete} className="h-8 w-8 text-zinc-600 hover:text-red-400">
                        <Trash2 className="h-4 w-4" />
                    </Button>
                </div>
            </div>

            {isExpanded && !isChild && (
                <div className="border-b border-zinc-800 bg-zinc-950/30">
                    {item.childVariants && item.childVariants.map((variant, idx) => (
                        <ProductRow
                            key={variant.variant_id || `v-${idx}`}
                            item={variant}
                            isChild={true}
                            onUpdate={(updated) => onUpdate(updated, item.product_id)} 
                            onDelete={() => onDelete(variant, item.product_id)}
                        />
                    ))}

                    {addingVariant ? (
                        <AddVariantRow 
                            productId={item.product_id} 
                            parentTitle={item.title}
                            existingVariantIds={item.childVariants?.map(v => v.variant_id) || []}
                            onAdd={(vData) => {
                                onAddVariantChild(item.product_id, vData);
                                setAddingVariant(false);
                            }}
                            onCancel={() => setAddingVariant(false)}
                        />
                    ) : (
                        <div className="pl-16 py-2">
                             <Button 
                                variant="outline" 
                                size="sm" 
                                onClick={() => setAddingVariant(true)}
                                className="h-7 text-xs border-zinc-800 bg-zinc-900/50 text-zinc-400 hover:text-white"
                             >
                                <Plus className="h-3 w-3 mr-1" /> Add Variant
                             </Button>
                        </div>
                    )}
                </div>
            )}
        </>
    );
};

export default function RoundProductsVariantsTable({ selectedItems, onItemsChange, roundId }) {
    const [expandedIds, setExpandedIds] = useState(new Set());
    const { toast } = useToast();

    const toggleExpand = (id) => {
        setExpandedIds(prev => {
            const next = new Set(prev);
            if (next.has(id)) next.delete(id);
            else next.add(id);
            return next;
        });
    };

    const handleUpdateItem = (updatedItem, parentProductId) => {
        onItemsChange(prevItems => {
            return prevItems.map(parent => {
                if (parent.product_id === updatedItem.product_id && !updatedItem.variant_id) {
                    return { ...parent, ...updatedItem };
                }
                
                if (parent.product_id === (parentProductId || updatedItem.product_id)) {
                    const updatedChildren = parent.childVariants.map(child => {
                        if (child.variant_id === updatedItem.variant_id) {
                            return { ...child, ...updatedItem };
                        }
                        return child;
                    });
                    return { ...parent, childVariants: updatedChildren };
                }
                
                return parent;
            });
        });
    };

    const handleDelete = (item, parentProductId) => {
        onItemsChange(prevItems => {
            if (!item.variant_id) {
                return prevItems.filter(p => p.product_id !== item.product_id);
            }
            
            return prevItems.map(parent => {
                if (parent.product_id === parentProductId) {
                    return {
                        ...parent,
                        childVariants: parent.childVariants.filter(v => v.variant_id !== item.variant_id)
                    };
                }
                return parent;
            });
        });
    };

    const handleAddVariantChild = (productId, variantData) => {
        onItemsChange(prevItems => {
            return prevItems.map(parent => {
                if (parent.product_id === productId) {
                    const newVariant = {
                        round_id: roundId,
                        product_id: productId,
                        product_id_text_backup: String(productId),
                        variant_id: variantData.id,
                        
                        variant_title: variantData.title,
                        variant_sku: variantData.sku,
                        variant_price: variantData.price,
                        variant_image: variantData.image_url,
                        
                        special_price: variantData.price,
                        discount_pct: null,
                        goal_qty: 0,
                        goal_unit: 'un',
                        is_featured: false,
                        
                        position: (parent.childVariants?.length || 0) + 1
                    };
                    
                    return {
                        ...parent,
                        childVariants: [...(parent.childVariants || []), newVariant]
                    };
                }
                return parent;
            });
        });
        toast({ title: "Variant Added", description: "Variant linked to round." });
    };

    if (!selectedItems || selectedItems.length === 0) {
        return <div className="text-center text-zinc-500 py-8 italic border border-dashed border-zinc-800 rounded-xl">No products linked. Search above to add.</div>;
    }

    return (
        <div className="rounded-xl border border-zinc-800 bg-zinc-950 overflow-hidden">
            <div className="grid grid-cols-12 gap-4 p-3 bg-zinc-900 border-b border-zinc-800 text-xs font-semibold text-zinc-400 uppercase tracking-wider">
                <div className="col-span-1"></div>
                <div className="col-span-4">Product</div>
                <div className="col-span-2">SKU</div>
                <div className="col-span-2">Pricing</div>
                <div className="col-span-2">Goal</div>
                <div className="col-span-1 text-right">Actions</div>
            </div>

            <div>
                {selectedItems.map(item => (
                    <ProductRow 
                        key={item.product_id} 
                        item={item} 
                        isChild={false}
                        isExpanded={expandedIds.has(item.product_id)}
                        onExpand={() => toggleExpand(item.product_id)}
                        onUpdate={handleUpdateItem}
                        onDelete={() => handleDelete(item)}
                        onAddVariantChild={handleAddVariantChild}
                    />
                ))}
            </div>
        </div>
    );
}
