import React from 'react';
import { Draggable } from "@hello-pangea/dnd";
import { format } from "date-fns";
import { Badge } from "@/components/ui/badge";
import { Calendar, User, Mail, MessageSquare } from "lucide-react";
import { cn } from "@/lib/utils";

export default function ApplicationCard({ application, index, onClick, badgeClassName }) {
  // Extract color class for border based on badge color to maintain visual consistency
  const getBorderColor = () => {
    if (badgeClassName.includes('blue')) return 'border-l-blue-500';
    if (badgeClassName.includes('yellow')) return 'border-l-yellow-500';
    if (badgeClassName.includes('green')) return 'border-l-green-500';
    if (badgeClassName.includes('purple')) return 'border-l-purple-500';
    if (badgeClassName.includes('emerald')) return 'border-l-emerald-500';
    if (badgeClassName.includes('red')) return 'border-l-red-500';
    return 'border-l-zinc-500';
  };

  return (
    <Draggable draggableId={application.id} index={index}>
      {(provided, snapshot) => (
        <div
          ref={provided.innerRef}
          {...provided.draggableProps}
          {...provided.dragHandleProps}
          onClick={onClick}
          className={cn(
            "mb-3 bg-zinc-900 border border-zinc-800 rounded-lg p-4 cursor-pointer hover:bg-zinc-800/80 transition-colors group relative overflow-hidden shadow-sm",
            "border-l-4", getBorderColor(),
            snapshot.isDragging && "shadow-lg shadow-black/50 ring-2 ring-yellow-500/50 rotate-1 scale-105 z-50 bg-zinc-800"
          )}
        >
          <div className="flex justify-between items-start mb-2 gap-2">
            <h4 className="font-bold text-zinc-100 text-sm leading-tight truncate">
              {application.company_name || application.applicant_name}
            </h4>
            <Badge variant="outline" className={cn("text-[10px] whitespace-nowrap px-1.5 py-0", badgeClassName)}>
              {application.plan}
            </Badge>
          </div>
          
          <div className="space-y-1.5 mt-3">
            <div className="flex items-center text-zinc-400 text-xs gap-2">
              <User className="w-3.5 h-3.5 opacity-70" />
              <span className="truncate">{application.applicant_name}</span>
            </div>
            <div className="flex items-center text-zinc-400 text-xs gap-2">
              <Mail className="w-3.5 h-3.5 opacity-70" />
              <span className="truncate">{application.email}</span>
            </div>
          </div>

          <div className="mt-4 flex items-center justify-between border-t border-zinc-800/50 pt-2 text-[11px] text-zinc-500">
            <div className="flex items-center gap-1.5">
              <Calendar className="w-3 h-3" />
              {format(new Date(application.created_at), 'MMM d, yyyy')}
            </div>
            {application.message && (
              <div className="flex items-center gap-1 text-zinc-400 bg-zinc-800/50 px-1.5 py-0.5 rounded" title="Has message">
                <MessageSquare className="w-3 h-3" />
              </div>
            )}
          </div>
        </div>
      )}
    </Draggable>
  );
}