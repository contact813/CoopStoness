
import React, { useEffect, useState, useCallback } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { 
  createRound, 
  updateRound, 
  deleteRound, 
  getRoundWithItems, 
  syncRoundProducts,
  addProductToRound
} from "@/lib/adminRoundsApi";
import ImageManager from "@/admin/ImageManager";
import { Save, Loader2, Trash2, ArrowLeft } from "lucide-react";
import { useToast } from "@/components/ui/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import RoundProductSearch from "@/admin/components/RoundProductSearch";
import RoundProductsTable from "@/admin/components/RoundProductsTable";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { cn } from "@/lib/utils";

const FormField = React.memo(({ id, label, children, required, className }) => (
  <div className={className}>
    <Label htmlFor={id} className="text-sm text-zinc-400">
      {label} {required && <span className="text-red-500">*</span>}
    </Label>
    <div className="mt-1.5 relative">{children}</div>
  </div>
));

export default function RoundEdit() {
  const { id } = useParams();
  const nav = useNavigate();
  const { toast } = useToast();
  const isNew = id === 'new' || id === undefined;
  
  const [loading, setLoading] = useState(!isNew);
  const [saving, setSaving] = useState(false);
  const [slugDirty, setSlugDirty] = useState(false);
  const [deleteRoundOpen, setDeleteRoundOpen] = useState(false);

  const [form, setForm] = useState({
    slug: '', title: '', subtitle: '', description: '',
    cover_image_url: null,
    starts_at: '', ends_at: '',
    status: 'draft',
    discount_pct: '',
    goal_amount: '',
  });

  const [selectedItems, setSelectedItems] = useState([]);

  // Helpers
  const toLocal = (iso) => {
      if (!iso) return '';
      try {
        const d = new Date(iso);
        // Adjust for timezone offset to display local time correctly in datetime-local input
        const tzOffset = d.getTimezoneOffset() * 60000; 
        const localDate = new Date(d.getTime() - tzOffset);
        return localDate.toISOString().slice(0, 16);
      } catch (e) {
        return '';
      }
  };

  const setFormData = (roundData) => {
    setForm({
      slug: roundData.slug || '',
      title: roundData.title || '',
      subtitle: roundData.subtitle || '',
      description: roundData.description || '',
      cover_image_url: roundData.cover_image_url ? { url: roundData.cover_image_url, path: roundData.cover_path || roundData.cover_image_url.split('round-covers/').pop() } : null,
      starts_at: toLocal(roundData.starts_at),
      ends_at: toLocal(roundData.ends_at),
      status: roundData.status || 'draft',
      discount_pct: roundData.discount_pct?.toString() ?? '',
      goal_amount: roundData.goal_amount ? Number(roundData.goal_amount).toFixed(2) : '', // Initialize with 2 decimals if exists
    });
    setSlugDirty(!!roundData.slug);
  };

  const loadData = useCallback(async () => {
    if (isNew) {
      setLoading(false);
      setForm({
        slug: '', title: '', subtitle: '', description: '',
        cover_image_url: null,
        starts_at: '', ends_at: '',
        status: 'draft',
        discount_pct: '',
        goal_amount: '',
      });
      setSelectedItems([]);
      return;
    }
    setLoading(true);
    try {
      const { data: roundData, error } = await getRoundWithItems(id);
      if (error) throw error;
      if (roundData) {
        setFormData(roundData);
        setSelectedItems(roundData.selectedItems || []);
      } else {
        toast({ title: "Error", description: "Round not found.", variant: "destructive" });
        nav('/admin/rounds');
      }
    } catch (err) {
      console.error("Failed to load round:", err);
      toast({ title: "Error", description: "Could not load round data.", variant: "destructive" });
    } finally {
      setLoading(false);
    }
  }, [id, isNew, toast, nav]);

  useEffect(() => {
    loadData();
  }, [loadData]);

  // Auto-generate slug
  useEffect(() => {
    if (!slugDirty && form.title && !form.slug) {
      const slug = form.title.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '');
      setForm(f => ({ ...f, slug }));
    }
  }, [form.title, form.slug, slugDirty]);

  const handleFormChange = useCallback((field, value) => {
    if (field === 'slug') setSlugDirty(true);
    setForm(f => ({ ...f, [field]: value }));
  }, []);

  // Currency formatting helpers
  const formatCurrency = (value) => {
    if (!value) return '';
    const num = parseFloat(String(value).replace(/[^0-9.-]+/g, ''));
    if (isNaN(num)) return value;
    return num.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  };

  const parseCurrency = (value) => {
    if (!value) return '';
    return String(value).replace(/[^0-9.-]+/g, '');
  };

  // --- Handlers for Products ---
  
  const handleAddProduct = async (product) => {
    // Strict duplicate check for PARENT products
    if (selectedItems.some(i => String(i.product_id) === String(product.id))) {
      toast({ title: "Duplicate", description: "Product already in round.", variant: "destructive" });
      return;
    }

    const newItem = {
      product_id: String(product.id),
      product_id_text_backup: String(product.id), // Ensure this is set as string
      title: product.title,
      thumbnail_url: product.thumbnail_url,
      images: product.images,
      price: product.price, 
      inventory: product.inventory,
      sku_raw: product.sku_raw,
      discount_pct: '', 
      special_price: product.price,
      goal_qty: '', 
      stock_override: '',
      is_featured: false, 
      position: selectedItems.length,
      items_sold: 0,
      goal_unit: 'un', 
      childVariants: []
    };

    try {
      if (!isNew) {
        // Optimistically add to list
        setSelectedItems(prev => [...prev, newItem]);
        toast({ title: "Product Added", description: `${product.title} added to round.`, duration: 3000 });
      } else {
        setSelectedItems(prev => [...prev, newItem]);
        toast({ title: "Product Staged", description: `${product.title} will be saved on creation.`, duration: 3000 });
      }
    } catch (error) {
      console.error("Add product error:", error);
      toast({ title: "Error", description: "Failed to add product.", variant: "destructive" });
    }
  };

  const handleAddVariant = (productId, variantData) => {
    // 1. Locate the parent product
    const parentIndex = selectedItems.findIndex(p => String(p.product_id) === String(productId));
    if (parentIndex === -1) {
      toast({ title: "Error", description: "Parent product not found.", variant: "destructive" });
      return;
    }

    const parent = selectedItems[parentIndex];

    // 2. CHECK FOR DUPLICATES: Check if this specific variant is already in the childVariants
    const isDuplicate = parent.childVariants?.some(v => String(v.variant_id) === String(variantData.id));
    if (isDuplicate) {
      toast({ title: "Duplicate", description: "This variant is already added to this round.", variant: "destructive" });
      return;
    }

    // 3. Create the new variant object
    const newVariant = {
        round_id: id !== 'new' ? id : null,
        product_id: String(productId),
        product_id_text_backup: String(productId),
        variant_id: String(variantData.id),
        
        // Display / Meta
        variant_title: variantData.title,
        variant_sku: variantData.sku,
        variant_price: variantData.price,
        variant_image: variantData.image_url,
        
        // Round Config Defaults
        special_price: variantData.price,
        discount_pct: null,
        goal_qty: 0,
        goal_unit: 'un',
        is_featured: false,
        
        // Fake position
        position: (parent.childVariants?.length || 0) + 1
    };

    // 4. Update state safely
    setSelectedItems(prev => {
        const next = [...prev];
        const updatedParent = { ...next[parentIndex] };
        updatedParent.childVariants = [...(updatedParent.childVariants || []), newVariant];
        next[parentIndex] = updatedParent;
        return next;
    });

    toast({ title: "Success", description: "Variant added to round." });
  };

  const validateItems = (items) => {
    const seen = new Set();
    const duplicates = [];
    
    items.forEach(item => {
      // Must have product_id
      if (!item.product_id) {
        duplicates.push("Item without product_id");
      }
      
      const key = `${String(item.product_id)}-null`;
      if (seen.has(key)) duplicates.push(item.title);
      seen.add(key);
      
      if (item.childVariants) {
        item.childVariants.forEach(child => {
          if (!child.variant_id) {
             duplicates.push(`${item.title} (Variant without variant_id)`);
          }
          const childKey = `${String(child.product_id)}-${String(child.variant_id)}`;
          if (seen.has(childKey)) duplicates.push(`${item.title} (Variant)`);
          seen.add(childKey);
        });
      }
    });
    
    return duplicates;
  };

  async function saveRound() {
    if (!form.starts_at || !form.ends_at) {
        toast({ title: "Validation Error", description: "Start date and End date are required.", variant: "destructive" });
        return;
    }

    if (!form.title) {
        toast({ title: "Validation Error", description: "Round Title is required.", variant: "destructive" });
        return;
    }

    // Validate duplicates in the hierarchical structure
    const duplicates = validateItems(selectedItems);
    if (duplicates.length > 0) {
      toast({ 
        title: "Duplicate/Invalid Products Detected", 
        description: `Please fix issues before saving: ${duplicates.slice(0, 3).join(', ')}...`, 
        variant: "destructive" 
      });
      return;
    }

    setSaving(true);
    
    // Clean goal amount for saving
    const cleanGoalAmount = form.goal_amount ? String(form.goal_amount).replace(/[^0-9.-]+/g, '') : '';

    const payload = {
      title: form.title?.trim() || '',
      slug: form.slug?.trim() || null,
      subtitle: form.subtitle || null,
      description: form.description || null,
      starts_at: new Date(form.starts_at).toISOString(),
      ends_at: new Date(form.ends_at).toISOString(),
      status: form.status,
      discount_pct: form.discount_pct !== '' && form.discount_pct != null ? Number(String(form.discount_pct).replace(',', '.')) : null,
      // Fix for goal_amount constraint: send 0 if empty
      goal_amount: cleanGoalAmount === '' ? 0 : Number(cleanGoalAmount),
      cover_image_url: form.cover_image_url?.url || null,
      cover_path: form.cover_image_url?.path || null,
    };

    try {
      let roundId = id;
      
      if (isNew) {
        const {data: created, error} = await createRound(payload);
        if (error) throw error;
        roundId = created.id;
      } else {
        const { error } = await updateRound(id, payload);
        if (error) throw error;
      }

      // Flatten items before sending to ensure we control the structure
      const flatItems = [];
      selectedItems.forEach(item => {
          // Add parent
          const { childVariants, ...parentProps } = item;
          flatItems.push(parentProps);
          
          // Add children
          if (childVariants && childVariants.length > 0) {
              childVariants.forEach(child => flatItems.push(child));
          }
      });

      const { error: syncError } = await syncRoundProducts(roundId, flatItems);
      
      if (syncError) {
        console.error("Sync error:", syncError);
        if (syncError.message?.includes('duplicate key') || syncError.code === '23505') {
           toast({
             title: "Sync Error",
             description: "Database reported duplicate products. Please ensure no variants are added twice and try again.",
             variant: "destructive"
           });
           throw new Error("Duplicate products detected.");
        }
        throw syncError;
      }

      toast({ title: "Success!", description: "Round saved successfully." });
      
      // Redirect to list
      nav(`/admin/rounds`);
      
    } catch (err) {
      console.error("Failed to save round:", err);
      toast({ title: "Error", description: err.message, variant: "destructive" });
    } finally {
      setSaving(false);
    }
  }

  const handleHardDelete = async () => {
    try {
      const { error } = await deleteRound(id);
      if (error) throw error;
      nav('/admin/rounds');
      toast({ title: "Success", description: "Round deleted." });
    } catch (err) {
      toast({ title: "Error", description: `Could not delete round: ${err.message}`, variant: "destructive" });
    } finally {
      setDeleteRoundOpen(false);
    }
  }

  if (loading) return (
    <div className="flex justify-center items-center h-[50vh]">
      <div className="text-center space-y-4">
         <Loader2 className="h-10 w-10 animate-spin text-yellow-500 mx-auto" />
         <p className="text-zinc-500 animate-pulse">Loading round details...</p>
      </div>
    </div>
  );

  return (
    <div className="space-y-8 pb-20">
      <div className="flex items-center justify-between">
        <Button variant="ghost" onClick={() => nav('/admin/rounds')} className="text-zinc-400 hover:text-white pl-0">
          <ArrowLeft className="mr-2 h-4 w-4" /> Back to Rounds
        </Button>
      </div>

      <div className="flex flex-col gap-8">
        {/* Round Settings */}
        <div className="p-6 rounded-2xl bg-zinc-950 border border-zinc-800 space-y-6">
             <h2 className="font-bold text-lg text-white mb-4">Round Settings</h2>
             
             <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                 {/* Title */}
                 <FormField id="title" label="Title" required className="col-span-1">
                   <Input 
                     name="title" 
                     value={form.title} 
                     onChange={e => handleFormChange('title', e.target.value)} 
                     required 
                     className="bg-zinc-900 border-zinc-800 focus:border-yellow-500 transition-colors" 
                   />
                 </FormField>
                 
                 {/* Slug */}
                 <FormField id="slug" label="Slug (URL)" className="col-span-1">
                   <Input 
                     name="slug" 
                     value={form.slug} 
                     onChange={e => handleFormChange('slug', e.target.value)} 
                     placeholder="auto-generated" 
                     className="bg-zinc-900 border-zinc-800 text-zinc-400 focus:border-yellow-500 transition-colors" 
                   />
                 </FormField>
                 
                 {/* Status */}
                 <FormField label="Status" className="col-span-1">
                   <select 
                      className="w-full px-3 py-2 rounded-lg bg-zinc-900 border border-zinc-800 text-white focus:ring-1 focus:ring-yellow-500 transition-colors appearance-none cursor-pointer" 
                      value={form.status} 
                      onChange={e => handleFormChange('status', e.target.value)}
                   >
                     <option value="draft">Draft</option>
                     <option value="active">Active</option>
                     <option value="archived">Archived</option>
                   </select>
                 </FormField>
                 
                 {/* Discount */}
                 <FormField label="Global Discount %" className="col-span-1">
                     <Input 
                       type="number" 
                       value={form.discount_pct} 
                       onChange={e => handleFormChange('discount_pct', e.target.value)} 
                       placeholder="0" 
                       className="bg-zinc-900 border-zinc-800 focus:border-yellow-500 transition-colors" 
                     />
                 </FormField>

                 {/* Goal Amount - Formatted Currency Input */}
                 <FormField label="Global Goal ($)" className="col-span-1">
                     <div className="relative">
                       <span className="absolute left-3 top-1/2 -translate-y-1/2 text-zinc-400 pointer-events-none">$</span>
                       <Input 
                         type="text" 
                         value={form.goal_amount} 
                         onChange={e => handleFormChange('goal_amount', e.target.value)} 
                         onBlur={(e) => handleFormChange('goal_amount', formatCurrency(e.target.value))}
                         onFocus={(e) => handleFormChange('goal_amount', parseCurrency(e.target.value))}
                         placeholder="e.g. 50,000.00" 
                         className="bg-zinc-900 border-zinc-800 focus:border-yellow-500 transition-colors pl-7" 
                       />
                     </div>
                 </FormField>

                 {/* Starts At */}
                 <FormField label="Starts" required className="col-span-1 md:col-span-2 lg:col-start-1">
                    <Input 
                        type="datetime-local" 
                        value={form.starts_at} 
                        onChange={e => handleFormChange('starts_at', e.target.value)} 
                        className="bg-zinc-900 border-zinc-800 text-sm pl-3 pr-4 focus:border-yellow-500 transition-colors [&::-webkit-calendar-picker-indicator]:invert [&::-webkit-calendar-picker-indicator]:opacity-100 [&::-webkit-calendar-picker-indicator]:w-6 [&::-webkit-calendar-picker-indicator]:h-6" 
                      />
                 </FormField>

                 {/* Ends At */}
                 <FormField label="Ends" required className="col-span-1 md:col-span-2">
                    <Input 
                        type="datetime-local" 
                        value={form.ends_at} 
                        onChange={e => handleFormChange('ends_at', e.target.value)} 
                        className="bg-zinc-900 border-zinc-800 text-sm pl-3 pr-4 focus:border-yellow-500 transition-colors [&::-webkit-calendar-picker-indicator]:invert [&::-webkit-calendar-picker-indicator]:opacity-100 [&::-webkit-calendar-picker-indicator]:w-6 [&::-webkit-calendar-picker-indicator]:h-6" 
                      />
                 </FormField>
                 
                 {/* Subtitle */}
                 <FormField label="Subtitle" className="col-span-full">
                     <Input 
                       value={form.subtitle} 
                       onChange={e => handleFormChange('subtitle', e.target.value)} 
                       className="bg-zinc-900 border-zinc-800 focus:border-yellow-500 transition-colors" 
                     />
                 </FormField>
                 
                 {/* Description */}
                 <FormField label="Description" className="col-span-full">
                     <Textarea 
                       value={form.description} 
                       onChange={e => handleFormChange('description', e.target.value)} 
                       rows={6}
                       className="bg-zinc-900 border-zinc-800 min-h-[140px] focus:border-yellow-500 transition-colors" 
                     />
                 </FormField>
                 
                 {/* Cover Image */}
                 <div className="col-span-full">
                     <Label className="text-zinc-400 text-sm mb-2 block">Cover Image</Label>
                     <ImageManager bucket="round-covers" folder={form.slug || 'round'} value={form.cover_image_url} onChange={(fileObj) => handleFormChange('cover_image_url', fileObj)} />
                 </div>
             </div>

             <div className="pt-6 flex justify-between items-center border-t border-zinc-800">
               {!isNew ? (
                 <AlertDialog open={deleteRoundOpen} onOpenChange={setDeleteRoundOpen}>
                    <AlertDialogTrigger asChild>
                        <Button variant="ghost" className="text-red-400 hover:text-red-300 hover:bg-red-950/30 p-2 h-auto">
                            <Trash2 size={18} />
                        </Button>
                    </AlertDialogTrigger>
                    <AlertDialogContent className="bg-zinc-950 border-zinc-800 text-white">
                        <AlertDialogHeader>
                            <AlertDialogTitle>Delete Round?</AlertDialogTitle>
                            <AlertDialogDescription className="text-zinc-400">
                                This will permanently delete this round. This action cannot be undone.
                            </AlertDialogDescription>
                        </AlertDialogHeader>
                        <AlertDialogFooter>
                            <AlertDialogCancel className="bg-transparent border-zinc-700 text-zinc-300 hover:bg-zinc-900">Cancel</AlertDialogCancel>
                            <AlertDialogAction onClick={handleHardDelete} className="bg-red-600 hover:bg-red-700 text-white">Delete</AlertDialogAction>
                        </AlertDialogFooter>
                    </AlertDialogContent>
                 </AlertDialog>
               ) : <div />}
               
               <Button onClick={saveRound} disabled={saving} className="bg-yellow-500 hover:bg-yellow-400 text-black font-bold">
                 {saving ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : <Save className="w-4 h-4 mr-2" />}
                 {saving ? 'Saving...' : 'Save Round'}
               </Button>
             </div>
        </div>

        {/* Products Section */}
        <div className="p-6 rounded-2xl bg-zinc-950 border border-zinc-800 min-h-[500px]">
            <h3 className="text-xl font-bold text-white mb-2">Linked Products</h3>
            <p className="text-sm text-zinc-500 mb-6">
              Add products here. Changes are saved when you click "Save Round".
            </p>
            
            <div className="mb-8 p-4 bg-zinc-900/50 rounded-xl border border-zinc-800/50">
               <RoundProductSearch 
                 onAddProduct={handleAddProduct}
                 linkedProductIds={selectedItems.map(i => i.product_id)}
                 isNewRound={isNew}
               />
            </div>
            
            <RoundProductsTable 
              items={selectedItems}
              onItemsChange={setSelectedItems}
              roundDiscountPct={form.discount_pct}
              onAddVariant={handleAddVariant}
            />
        </div>
      </div>
    </div>
  );
}
