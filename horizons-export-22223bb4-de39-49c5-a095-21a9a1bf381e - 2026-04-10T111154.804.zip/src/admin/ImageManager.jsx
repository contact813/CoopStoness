import React, { useState, useRef } from "react";
import { uploadImage, deleteImage } from "@/lib/storage";
import { Upload, X, Loader2 } from "lucide-react";

export default function ImageManager({ bucket, value, onChange, folder='' }) {
  const [busy, setBusy] = useState(false);
  const fileInputRef = useRef(null);

  async function onFileChange(e) {
    const file = e.target.files?.[0];
    if (!file) return;
    setBusy(true);
    try {
      if (value?.path) {
          await deleteImage({ bucket, path: value.path });
      }
      const { path, url } = await uploadImage({ bucket, file, folder });
      onChange?.({ path, url });
    } catch (err) {
        console.error("Upload failed:", err);
    } finally { 
      setBusy(false); 
      if(fileInputRef.current) {
          fileInputRef.current.value = "";
      }
    }
  }

  async function remove() {
    if (!value?.path) { onChange?.(null); return; }
    setBusy(true);
    try {
      await deleteImage({ bucket, path: value.path });
      onChange?.(null);
    } catch(err) {
        console.error("Delete failed:", err);
    } finally { setBusy(false); }
  }

  return (
    <div>
      <label className="block text-sm text-zinc-300 mb-1">Cover / Image</label>
      <div className="flex items-center gap-4">
        <div className="w-40 aspect-video rounded-xl overflow-hidden bg-zinc-800 border border-zinc-700 grid place-items-center">
          {busy ? (
            <Loader2 className="w-8 h-8 text-yellow-400 animate-spin" />
          ) : value?.url ? (
            <img src={value.url} alt="Cover" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
          ) : (
             <span className="text-zinc-500 text-xs">No image</span>
          )}
        </div>
        <div className="flex items-center gap-2">
           <input type="file" accept="image/*" onChange={onFileChange} disabled={busy} ref={fileInputRef} className="hidden" id="file-upload" />
           <label htmlFor="file-upload" className={`flex items-center gap-2 px-3 py-2 rounded-lg border cursor-pointer ${busy ? 'opacity-50' : 'hover:border-yellow-500'} bg-zinc-900 border-zinc-700`}>
              <Upload size={16} />
              <span>{value?.url ? 'Change' : 'Upload'}</span>
           </label>

          {value?.url && (
            <button onClick={remove} className="flex items-center gap-2 px-3 py-2 rounded-lg bg-zinc-900 border border-zinc-700 hover:border-red-500 text-red-400" disabled={busy}>
              <X size={16} />
            </button>
          )}
        </div>
      </div>
    </div>
  );
}