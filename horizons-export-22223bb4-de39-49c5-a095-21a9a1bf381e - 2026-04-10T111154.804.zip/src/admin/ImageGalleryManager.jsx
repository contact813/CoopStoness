
import React, { useState } from 'react';
import { uploadImage, deleteImage } from '@/lib/storage';
import { Loader2, Trash2, Star, Plus, Upload } from 'lucide-react';
import { cn } from '@/lib/utils';
import { toast } from '@/components/ui/use-toast';
import { normalizeImages } from '@/lib/adminProductsApi';

function pickDisplayUrl(img) {
  if (!img) return '';
  if (typeof img === 'string') return img;
  return img.url || '';
}

export default function ImageGalleryManager({ bucket = "product-images", folder = "product", value = [], onChange, onSetCover, coverPath, showErrors = false }) {
  const [busy, setBusy] = useState(false);

  // Task 9: Call normalizeImages at the start
  console.log('[ImageGalleryManager] Initializing with value:', value);
  const safeValue = normalizeImages(value).filter(img => img.url && img.path);
  console.log('[ImageGalleryManager] safeValue after normalization:', safeValue);

  const hasValidImages = safeValue.length > 0;
  const isInvalid = showErrors && !hasValidImages;

  // Task 6: handleImageUpload
  async function handleImageUpload(e) {
    const files = e.target.files;
    if (!files || files.length === 0) return;
    
    console.log(`[ImageGalleryManager] Starting upload for ${files.length} file(s)`);
    setBusy(true);
    const newImages = [];
    const errors = [];

    try {
      await Promise.all(Array.from(files).map(async (file) => {
        try {
            console.log(`[ImageGalleryManager] Uploading file: ${file.name}`);
            const { url, path } = await uploadImage({ bucket, file, folder });
            
            if (url && path) {
                // Normalize returned url
                const normalized = normalizeImages([{ url, path }]);
                if (normalized.length > 0) {
                    newImages.push(normalized[0]);
                    console.log(`[ImageGalleryManager] Upload success, normalized:`, normalized[0]);
                }
            } else {
                console.warn(`[ImageGalleryManager] Upload incomplete for file: ${file.name}`);
                errors.push(`${file.name} (invalid response)`);
            }
        } catch (err) {
            console.error(`[ImageGalleryManager] Failed to upload ${file.name}:`, err);
            errors.push(file.name);
        }
      }));

      if (newImages.length > 0) {
        const existingUrls = new Set(safeValue.map(i => i.url));
        const uniqueNewImages = newImages.filter(i => !existingUrls.has(i.url));
        
        const combined = [...safeValue, ...uniqueNewImages];
        console.log('[ImageGalleryManager] Upload complete. Calling onChange with:', combined);
        onChange(combined);
        
        if (errors.length === 0) {
            toast({ title: "Images uploaded successfully" });
        } else {
             toast({ 
                title: "Some images uploaded", 
                description: `Uploaded ${uniqueNewImages.length} images. Failed: ${errors.join(", ")}`,
                variant: "warning"
            });
        }
      } else if (errors.length > 0) {
         toast({ 
            title: "Upload failed", 
            description: `Failed to upload: ${errors.join(", ")}`,
            variant: "destructive"
        });
      }

    } catch (error) {
        console.error("[ImageGalleryManager] Upload error:", error);
        toast({ title: "Error uploading images", description: error.message, variant: "destructive" });
    } finally { 
        setBusy(false); 
        if (e.target) e.target.value = "";
    }
  }

  // Task 7: handleRemoveImage
  async function handleRemoveImage(idx) {
    const item = safeValue[idx];
    console.log(`[ImageGalleryManager] Removing image at index ${idx}:`, item);
    setBusy(true);
    try {
      const pathToDelete = item.path || item.url;
      
      if (pathToDelete) {
         try {
             await deleteImage({ bucket, path: pathToDelete });
             console.log(`[ImageGalleryManager] Deleted from storage: ${pathToDelete}`);
         } catch (e) {
             console.warn("[ImageGalleryManager] Failed to delete from storage:", e);
         }
      }
      
      const next = safeValue.filter((_, i) => i !== idx);
      console.log('[ImageGalleryManager] Calling onChange with filtered array:', next);
      onChange?.(next);
      toast({ title: "Image removed" });
    } catch (err) {
        console.error("[ImageGalleryManager] Delete error:", err);
        toast({ title: "Failed to delete image", variant: "destructive" });
    } finally { setBusy(false); }
  }

  // Task 8: handleSetCover
  function handleSetCover(idx) {
    const img = safeValue[idx];
    console.log(`[ImageGalleryManager] Set cover requested for index ${idx}:`, img);
    if (img && img.url) {
      onSetCover(img.url);
    } else {
      console.warn('[ImageGalleryManager] Invalid image for set cover:', img);
    }
  }

  return (
    <div className={cn(
        "w-full rounded-xl p-2 transition-colors duration-200 border",
        isInvalid ? "border-red-500 bg-red-900/20" : "border-transparent"
    )}>
      <div className="flex items-center justify-between mb-4">
        <label className="text-lg font-semibold text-zinc-100">
          Gallery Images
        </label>
        <div className="flex items-center gap-3">
            {isInvalid && <span className="text-sm font-semibold text-red-400">Required</span>}
            <span className="text-sm text-zinc-400">{safeValue.length} images</span>
        </div>
      </div>
      
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4">
        {/* Upload Buttons */}
        <label className={cn(
            "relative group flex flex-col items-center justify-center aspect-[4/5] border-2 border-dashed border-zinc-700 rounded-xl cursor-pointer hover:border-yellow-500 hover:bg-zinc-800/50 transition-all duration-200",
            busy && "opacity-50 pointer-events-none"
        )}>
          {busy ? (
            <Loader2 className="w-8 h-8 animate-spin text-yellow-500"/>
          ) : (
            <>
                <Plus className="w-8 h-8 text-zinc-400 group-hover:text-yellow-500 mb-2 transition-colors" />
                <span className="text-sm font-medium text-zinc-400 group-hover:text-yellow-500 transition-colors">Add Image</span>
            </>
          )}
          <input type="file" accept="image/*" className="hidden" onChange={handleImageUpload} disabled={busy}/>
        </label>

        <label className={cn(
            "relative group flex flex-col items-center justify-center aspect-[4/5] border-2 border-dashed border-zinc-700 rounded-xl cursor-pointer hover:border-blue-500 hover:bg-zinc-800/50 transition-all duration-200",
            busy && "opacity-50 pointer-events-none"
        )}>
           {busy ? (
            <Loader2 className="w-8 h-8 animate-spin text-blue-500"/>
          ) : (
            <>
                <Upload className="w-8 h-8 text-zinc-400 group-hover:text-blue-500 mb-2 transition-colors" />
                <span className="text-sm font-medium text-zinc-400 group-hover:text-blue-500 transition-colors">Bulk Upload</span>
            </>
          )}
          <input type="file" accept="image/*" multiple className="hidden" onChange={handleImageUpload} disabled={busy}/>
        </label>

        {/* Image Grid */}
        {safeValue.map((img, i) => {
          const url = pickDisplayUrl(img);
          const isCover = coverPath === url || (img.path && coverPath === img.path);

          return (
            <div key={i} className={cn(
                "relative group rounded-xl overflow-hidden bg-zinc-900 shadow-md transition-transform duration-200 hover:scale-[1.02] aspect-[4/5]",
                isCover ? "ring-2 ring-yellow-500" : "ring-1 ring-zinc-800"
            )}>
              <img 
                src={url}
                alt={`Product image ${i + 1}`}
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
                loading="lazy"
                onError={(e)=>{ e.currentTarget.src = '/images/placeholder-product.svg'; }}
              />
              
              {/* Overlay Gradient */}
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-black/40 opacity-0 group-hover:opacity-100 transition-opacity duration-200 pointer-events-none" />

              {/* Action Buttons */}
              <div className="absolute top-2 right-2 flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity duration-200 z-10">
                 <button 
                  type="button" 
                  onClick={() => handleSetCover(i)}
                  className={cn(
                    "p-2 rounded-full backdrop-blur-md transition-colors shadow-sm",
                    isCover 
                        ? "bg-yellow-500 text-black shadow-yellow-500/20" 
                        : "bg-black/50 text-white hover:bg-white hover:text-black"
                  )}
                  title={isCover ? "Current Cover" : "Set as Cover"}
                  disabled={busy}
                >
                  <Star size={16} fill={isCover ? "currentColor" : "none"} />
                </button>
                <button 
                  type="button" 
                  onClick={() => handleRemoveImage(i)}
                  className="p-2 rounded-full bg-red-500/80 text-white hover:bg-red-600 backdrop-blur-md transition-colors shadow-sm"
                  title="Remove Image"
                  disabled={busy}
                >
                  <Trash2 size={16} />
                </button>
              </div>

               {isCover && (
                <div className="absolute bottom-0 left-0 right-0 bg-yellow-500/90 text-black text-xs font-bold text-center py-1.5 backdrop-blur-sm">
                    COVER IMAGE
                </div>
               )}
            </div>
          );
        })}
      </div>
      <p className="text-xs text-zinc-500 mt-4 flex items-center gap-2">
        <Star size={12} className="text-yellow-500" fill="currentColor" />
        <span>Star icon indicates the primary cover image displayed in listings.</span>
      </p>
    </div>
  );
}
