
# Image System Implementation

## 1. Upload Flow for Products and Variants
Images are uploaded to Supabase Storage via `src/lib/storageApi.js`. 
- **Products**: Uploaded to the `product-images` bucket within the `products/{productId}` folder. The returned `publicUrl` is saved to `product.thumbnail_url`.
- **Variants**: Uploaded to the `product-images` bucket within the `variants/{variantId}` folder. The returned `publicUrl` is saved to `variant.image_url`.

The upload functions enforce file validation (JPEG, PNG, WebP, GIF), limit file sizes to 5MB, and generate randomized filenames to prevent cache collisions.

## 2. Fallback Logic Implementation
To ensure consistent visual presentation across the catalog, a strict fallback chain is implemented for all product variants:
`variant.image_url || product.thumbnail_url || product.images?.[0]?.url || PLACEHOLDER_IMAGE`

This logic is enforced at multiple layers:
- **API Layer (`src/lib/productsApi.js`)**: The `normalizeProductWithValidVariants` function maps `image_url` onto every variant, pulling from `product.thumbnail_url` if the variant lacks a dedicated image.
- **Component Layer**: View components respect this fallback directly (e.g., `Product.jsx`, `RoundProductCard.jsx`, `ProductGallery.jsx`).

## 3. Display Patterns Across Components
- **`Product.jsx`**: Selects the image based on `activeVariant?.image_url || product?.thumbnail_url`. Updates both the main gallery view and the cart payload.
- **`ProductGallery.jsx`**: Highlights the selected variant image if passed via `selectedVariantImage`, otherwise defaults to the first product image.
- **`RoundProductCard.jsx` & `RelatedProducts.jsx`**: Directly apply the `product.thumbnail_url` or `variant_image` fallback pattern.

## 4. Storage Folder Organization
