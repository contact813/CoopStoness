
import { supabase } from '@/lib/supabaseClient';
import { getOrCreateCartSessionId } from './cartSessionId';

/**
 * Reserves stock for a specific product and session.
 * 
 * @param {number|string} productId 
 * @param {number} qty 
 * @param {string} context - 'rounds'
 * @returns {Promise<{success: boolean, message: string, available_qty?: number, expires_at?: string}>}
 */
export async function reserveStock(productId, qty = 1, context = 'rounds') {
  const sessionId = getOrCreateCartSessionId();

  try {
    const { data, error } = await supabase.rpc('reserve_stock', {
      p_product_id: productId,
      p_qty: qty,
      p_session_id: sessionId,
      p_context: context
    });

    if (error) throw error;
    return data;
  } catch (err) {
    console.error('Error reserving stock:', err);
    return { success: false, message: err.message };
  }
}

/**
 * Releases a hold on stock for a specific product.
 * 
 * @param {number|string} productId 
 * @returns {Promise<{success: boolean, message: string}>}
 */
export async function releaseStock(productId) {
  const sessionId = getOrCreateCartSessionId();
  
  try {
    const { data, error } = await supabase.rpc('release_stock', {
      p_product_id: productId,
      p_session_id: sessionId
    });

    if (error) throw error;
    return data;
  } catch (err) {
    console.error('Error releasing stock:', err);
    return { success: false, message: err.message };
  }
}

/**
 * Fetches the real-time availability of a product.
 * 
 * @param {number|string} productId 
 * @returns {Promise<number>}
 */
export async function getProductAvailability(productId) {
  try {
    const { data, error } = await supabase
      .from('products_with_availability')
      .select('available_qty')
      .eq('id', productId)
      .single();

    if (error) throw error;
    return data ? data.available_qty : 0;
  } catch (err) {
    console.error('Error getting availability:', err);
    return 0;
  }
}

/**
 * Confirms purchase of reserved items (used at checkout success).
 */
export async function confirmReservationPurchase(orderId) {
   const sessionId = getOrCreateCartSessionId();
   
   try {
    const { data, error } = await supabase.rpc('confirm_reservation_purchase', {
      p_order_id: orderId,
      p_session_id: sessionId
    });
    
    if (error) throw error;
    return data;
   } catch (err) {
     console.error("Error confirming reservation purchase:", err);
     return { success: false, message: err.message };
   }
}
