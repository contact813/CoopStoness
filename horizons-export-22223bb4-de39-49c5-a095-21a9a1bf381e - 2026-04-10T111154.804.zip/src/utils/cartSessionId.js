import { v4 as uuidv4 } from 'uuid';

const STORAGE_KEY = 'cart_session_id';

export function getOrCreateCartSessionId() {
  let sessionId = localStorage.getItem(STORAGE_KEY);
  
  if (!sessionId) {
    sessionId = uuidv4();
    localStorage.setItem(STORAGE_KEY, sessionId);
  }
  
  return sessionId;
}

export function clearCartSessionId() {
  localStorage.removeItem(STORAGE_KEY);
}