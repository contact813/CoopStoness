
export function formatVariantOptions(optionValues) {
  if (!Array.isArray(optionValues) || optionValues.length === 0) {
    return '-';
  }
  return optionValues
    .filter(ov => ov && ov.optionName && ov.value)
    .map(ov => `${ov.optionName}: ${ov.value}`)
    .join(' / ');
}

export function getVariantDisplayTitle(variant, productTitle) {
  if (variant && variant.title && variant.title.trim() !== '') {
    return variant.title;
  }
  return productTitle || 'Unknown Product';
}

export function isVariantValid(variant) {
  if (!variant) return false;
  if (variant.is_active === false) return false;
  
  const sku = String(variant.sku || '').trim();
  if (!sku || sku === '-') return false;
  
  const price = parseFloat(variant.price);
  if (isNaN(price) || price <= 0) return false;
  
  return true;
}

export function isOptionValuesValid(optionValues) {
  if (!Array.isArray(optionValues) || optionValues.length === 0) {
    return false;
  }
  return optionValues.every(ov => ov && ov.option_id && ov.option_value_id);
}

export function logVariantIssue(issue, variant) {
  console.warn(`[Variant Issue] ${issue}`, variant ? `Variant ID: ${variant.id}` : 'No variant provided', variant);
}
