
import React from 'react';
import ReactDOM from 'react-dom/client';
import { BrowserRouter } from 'react-router-dom';
import App from '@/App';
import '@/index.css';
import '@/styles/scrollbar.css';
import { AuthProvider } from '@/contexts/AuthContext';
import { CartProvider } from '@/contexts/CartContext';
import { initErrorLogger } from '@/lib/errorLogger';

// Global error logging middleware
window.addEventListener('error', (event) => {
  console.error('[Global Error Middleware] Uncaught Exception:', {
    message: event.message,
    filename: event.filename,
    lineno: event.lineno,
    colno: event.colno,
    error: event.error,
    timestamp: new Date().toISOString()
  });
});

window.addEventListener('unhandledrejection', (event) => {
  console.error('[Global Error Middleware] Unhandled Promise Rejection:', {
    reason: event.reason,
    timestamp: new Date().toISOString()
  });
});

// Initialize global error logging
try {
  initErrorLogger();
  console.log('[main.jsx] Error logger initialized successfully');
} catch (e) {
  console.error("[main.jsx] Failed to init error logger", e);
}

const root = ReactDOM.createRoot(document.getElementById('root'));

root.render(
  <>
    <BrowserRouter>
      <AuthProvider>
        <CartProvider>
          <App />
        </CartProvider>
      </AuthProvider>
    </BrowserRouter>
  </>
);
