
import React, { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabaseClient';
import { getCachedProducts } from '@/lib/productsCache';
import { PLACEHOLDER_IMAGE } from '@/lib/imageUtils';
import { ProductSkeletonGrid } from '@/components/ProductSkeleton';
import { AlertCircle, Loader2 } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';

const FeaturedProducts = () => {
  const { user, isAuthInitialized } = useAuth();
  const [products, setProducts] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    let isMounted = true;
    
    const fetchFeaturedProducts = async () => {
      if (!isAuthInitialized || !user) return;

      try {
        setIsLoading(true);
        console.log('[FeaturedProducts] Fetching featured products for authenticated user...');
        
        const data = await getCachedProducts(async () => {
          const { data: dbData, error: dbError } = await supabase
            .from('products')
            .select('*')
            .eq('status', 'active')
            .limit(4);
            
          if (dbError) throw dbError;
          return dbData || [];
        }, 'featured-products');
        
        if (isMounted) {
          setProducts(data);
          setError(null);
        }
      } catch (err) {
        console.error("[FeaturedProducts] Error loading featured products:", err);
        if (isMounted) {
          setError(`Failed to load products: ${err.message || 'Unknown error'}`);
        }
      } finally {
        if (isMounted) {
          setIsLoading(false);
        }
      }
    };

    fetchFeaturedProducts();
    
    return () => { isMounted = false; };
  }, [user, isAuthInitialized]);

  if (!isAuthInitialized) return null;
  if (!user) {
    console.log('[FeaturedProducts] Component skipped rendering: no authenticated user.');
    return null;
  }

  return (
    <section className="py-16 px-4 max-w-7xl mx-auto">
      <div className="mb-10 text-center">
        <h2 className="text-3xl md:text-4xl font-bold mb-4 text-white">Featured Products</h2>
        <p className="text-zinc-400 max-w-2xl mx-auto">Discover top-quality stone products curated for our members.</p>
      </div>
      
      {isLoading ? (
        <div className="flex flex-col items-center justify-center py-12">
          <Loader2 className="w-10 h-10 animate-spin text-yellow-500 mb-4" />
          <p className="text-zinc-400">Loading featured products...</p>
          <div className="w-full mt-8">
            <ProductSkeletonGrid count={4} />
          </div>
        </div>
      ) : error ? (
        <div className="text-center text-red-400 bg-red-950/20 border border-red-900 p-8 rounded-xl flex flex-col items-center">
          <AlertCircle className="w-12 h-12 mb-4 text-red-500" />
          <h3 className="text-xl font-bold mb-2">Connection Issue</h3>
          <p>{error}</p>
        </div>
      ) : products.length > 0 ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
          {products.map(product => (
            <div key={product.id} className="flex flex-col bg-zinc-900 border border-zinc-800 rounded-xl overflow-hidden group hover:border-yellow-500/50 transition-all">
              <div className="aspect-[4/3] bg-zinc-900 relative overflow-hidden block">
                <img 
                  src={product.thumbnail_url || PLACEHOLDER_IMAGE} 
                  alt={product.title}
                  loading="lazy"
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                  onError={(e) => { e.currentTarget.onerror = null; e.currentTarget.src = PLACEHOLDER_IMAGE; }}
                />
              </div>
              <div className="p-5 flex flex-col flex-grow space-y-2">
                {product.vendor && <p className="text-zinc-500 text-[10px] uppercase font-bold tracking-widest">{product.vendor}</p>}
                <h3 className="text-zinc-100 font-bold line-clamp-2 leading-tight">
                  {product.title}
                </h3>
                <div className="mt-auto pt-4 flex items-center justify-between">
                   <span className="text-yellow-500 font-bold">${Number(product.price || 0).toFixed(2)}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="text-center text-zinc-500 p-8">
          <p>No featured products available at the moment.</p>
        </div>
      )}
    </section>
  );
};

export default FeaturedProducts;
