import React from 'react';
import { motion } from 'framer-motion';
import { ShoppingBag, Gem, Megaphone, Truck, GraduationCap, Users } from 'lucide-react';

const benefitsData = [
  {
    icon: ShoppingBag,
    title: "Group Purchasing",
    description: "Negotiated group pricing on blades, pads, chemicals, sinks, tools, machinery, and imported materials — with savings of up to 75% below MSRP through collective buying power."
  },
  {
    icon: Gem,
    title: "Exclusive Materials",
    description: "Access to Coop Stones–branded quartz and porcelain lines, cooperative imports of natural stone, and container-level pricing not available to the open market."
  },
  {
    icon: Megaphone,
    title: "Marketing & Digital Tools",
    description: "Reputation management tools, digital visibility resources, and marketing support designed specifically for stone fabricators — not generic agencies."
  },
  {
    icon: Truck,
    title: "Equipment & Machinery",
    description: "Group purchasing and partner discounts on CNCs, saws, polishers, forklifts, waterjets, compressors, and material handling equipment."
  },
  {
    icon: GraduationCap,
    title: "Training & Education",
    description: "Workshops and technical training covering pricing, safety, installation, fabrication operations, and chemical usage."
  },
  {
    icon: Users,
    title: "Community & Support",
    description: "Member-to-member collaboration, remnant and inventory exchange, project partnerships, administrative support, and access to vetted industry partners."
  }
];

const Benefits = () => {
  return (
    <section className="bg-black py-24 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <motion.h2 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-3xl md:text-5xl font-bold text-white mb-6"
          >
            Exclusive Member <span className="text-yellow-400">Benefits</span>
          </motion.h2>
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
            className="text-zinc-400 text-lg max-w-2xl mx-auto"
          >
            Designed to give you the leverage of a national player while maintaining your independence.
          </motion.p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {benefitsData.map((benefit, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1, duration: 0.5 }}
              whileHover={{ y: -5 }}
              className="bg-zinc-900/50 border border-zinc-800 rounded-xl p-8 shadow-lg hover:shadow-2xl hover:shadow-yellow-400/10 hover:border-yellow-400/30 transition-all duration-300"
            >
              <div className="w-14 h-14 bg-yellow-400/10 rounded-lg flex items-center justify-center mb-6">
                <benefit.icon className="w-7 h-7 text-yellow-400" />
              </div>
              <h3 className="text-xl font-bold text-white mb-4">{benefit.title}</h3>
              <p className="text-zinc-400 leading-relaxed text-sm">
                {benefit.description}
              </p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Benefits;