import React from 'react';
import { useMemo } from "react";
import { Facebook, Twitter, Linkedin } from "lucide-react";

export default function SocialShare({ title }) {
  const url = typeof window !== 'undefined' ? window.location.href : '';
  const share = useMemo(() => ({
    fb: `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(url)}`,
    tw: `https://twitter.com/intent/tweet?url=${encodeURIComponent(url)}&text=${encodeURIComponent(title||'')}`,
    in: `https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(url)}`
  }), [url, title]);

  const Btn = ({ href, children, label }) => (
    <a href={href} target="_blank" rel="noreferrer"
       className="inline-flex items-center justify-center w-9 h-9 rounded-full bg-zinc-900 border border-zinc-800 hover:border-yellow-500"
       aria-label={label}>{children}</a>
  );

  return (
    <div className="flex items-center gap-3 mt-6">
      <Btn href={share.fb} label="Share on Facebook"><Facebook size={18}/></Btn>
      <Btn href={share.tw} label="Share on X"><Twitter size={18}/></Btn>
      <Btn href={share.in} label="Share on LinkedIn"><Linkedin size={18}/></Btn>
    </div>
  );
}