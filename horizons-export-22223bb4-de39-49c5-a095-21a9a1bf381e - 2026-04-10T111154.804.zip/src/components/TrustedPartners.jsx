import React from 'react';
import { motion } from 'framer-motion';

const partners = [
  { name: 'Aardwolf', logoUrl: 'https://horizons-cdn.hostinger.com/22223bb4-de39-49c5-a095-21a9a1bf381e/fa400b2d60281064347bedccf52ebe26.png' },
  { name: 'Gorbel', logoUrl: 'https://horizons-cdn.hostinger.com/22223bb4-de39-49c5-a095-21a9a1bf381e/cfa8b2b98034e0282aff387d9a01b904.png' },
  { name: 'Diamax', logoUrl: 'https://horizons-cdn.hostinger.com/22223bb4-de39-49c5-a095-21a9a1bf381e/da93b6b67914dbacda1ce9762db8d3bb.png' },
  { name: 'Schulz', logoUrl: 'https://horizons-cdn.hostinger.com/22223bb4-de39-49c5-a095-21a9a1bf381e/239811b64d70d5770d09ef703f9657a9.png' },
  { name: 'Water Treatment Solutions', logoUrl: 'https://horizons-cdn.hostinger.com/22223bb4-de39-49c5-a095-21a9a1bf381e/0d5e62f14afdc7f0618cedb70cded370.png' },
  { name: 'Soudal', logoUrl: 'https://horizons-cdn.hostinger.com/22223bb4-de39-49c5-a095-21a9a1bf381e/2b7f12a7533e473bb22b50674b2d3ef1.png' },
  { name: 'Metabo', logoUrl: 'https://horizons-cdn.hostinger.com/22223bb4-de39-49c5-a095-21a9a1bf381e/ee46bb4fdb6c7742b6f5c0aa476fec04.png' },
  { name: 'Tyrolit', logoUrl: 'https://horizons-cdn.hostinger.com/22223bb4-de39-49c5-a095-21a9a1bf381e/a7cb52b8df6800f8696980650a65a41e.png' },
  { name: 'Weha', logoUrl: 'https://horizons-cdn.hostinger.com/22223bb4-de39-49c5-a095-21a9a1bf381e/955c254fc4bec8ad443b1f62070baa65.png' },
  { name: 'Tenax', logoUrl: 'https://horizons-cdn.hostinger.com/22223bb4-de39-49c5-a095-21a9a1bf381e/73d9765c3e81f1abfced86863bd0e1d3.png' },
];

const TrustedPartners = () => {
  const duplicatedPartners = [...partners, ...partners];

  return (
    <section className="bg-black py-24 relative overflow-hidden text-white">
      <div className="max-w-screen-xl mx-auto px-4 sm:px-6 lg:px-8 relative z-20">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold text-white mb-4">
            Our <span className="text-yellow-400">Trusted Partners</span>
          </h2>
        </motion.div>
      </div>
      <div
        className="flex relative z-20"
        style={{
          animation: 'scroll 40s linear infinite',
        }}
      >
        {duplicatedPartners.map((partner, index) => (
          <div
            key={index}
            className="flex-shrink-0 mx-4 flex items-center justify-center"
            style={{ width: '250px' }}
          >
            <img
              src={partner.logoUrl}
              alt={partner.name}
              className="h-24 w-auto object-contain grayscale opacity-60 hover:grayscale-0 hover:opacity-100 transition-all duration-300"
            />
          </div>
        ))}
      </div>
    </section>
  );
};

export default TrustedPartners;