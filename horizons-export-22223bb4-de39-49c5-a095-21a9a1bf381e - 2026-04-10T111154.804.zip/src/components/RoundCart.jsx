
import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Trash2, ShoppingCart, ArrowLeft, Loader2 } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import { Button } from '@/components/ui/button';

export default function RoundCart() {
  const { slug } = useParams();
  const navigate = useNavigate();
  const { toast } = useToast();
  
  const [cartItems, setCartItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [isRedirecting, setIsRedirecting] = useState(false);

  useEffect(() => {
    const loadCart = () => {
      try {
        const localCart = localStorage.getItem(`round_cart_${slug}`);
        if (localCart) {
          const parsed = JSON.parse(localCart);
          const items = parsed.items || parsed.cartItems || parsed;
          if (Array.isArray(items)) {
            setCartItems(items);
          }
        }
      } catch (error) {
        console.error('[RoundCart] Error loading cart data:', error);
      } finally {
        setLoading(false);
      }
    };
    
    loadCart();
  }, [slug]);

  useEffect(() => {
    if (!loading && cartItems.length === 0 && !isRedirecting) {
      setIsRedirecting(true);
      const timer = setTimeout(() => {
        navigate(`/rounds/${slug}`);
      }, 1500);
      
      return () => clearTimeout(timer);
    }
  }, [cartItems.length, loading, navigate, slug, isRedirecting]);

  const deleteItem = (itemId) => {
    const updatedItems = cartItems.filter(item => 
      item.id !== itemId && 
      item.variant_id !== itemId && 
      item.product_id !== itemId
    );
    
    setCartItems(updatedItems);
    
    const cartKey = `round_cart_${slug}`;
    const localCart = localStorage.getItem(cartKey);
    let updatedStorage = updatedItems;
    
    if (localCart) {
      try {
        const parsed = JSON.parse(localCart);
        if (parsed.items) {
          parsed.items = updatedItems;
          updatedStorage = parsed;
        } else if (parsed.cartItems) {
          parsed.cartItems = updatedItems;
          updatedStorage = parsed;
        }
      } catch (e) {
        console.error('[RoundCart] Error updating local storage payload:', e);
      }
    }
    
    localStorage.setItem(cartKey, JSON.stringify(updatedStorage));
    window.dispatchEvent(new Event('cart_updated'));
    
    toast({
      title: "Item Deleted",
      description: "The item was successfully removed from your cart.",
    });
  };

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[50vh] text-zinc-400">
        <Loader2 className="w-10 h-10 animate-spin text-yellow-500 mb-4" />
        <p>Loading cart...</p>
      </div>
    );
  }

  if (cartItems.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[50vh] p-8 text-center space-y-6 animate-in fade-in duration-300">
        <div className="bg-zinc-900/50 p-6 rounded-full border border-zinc-800">
          <ShoppingCart className="w-16 h-16 text-zinc-600" />
        </div>
        <div>
          <h2 className="text-3xl font-bold text-white mb-2">Cart Empty</h2>
          <p className="text-zinc-400 max-w-md mx-auto">
            There are no items in your cart. You will be redirected back to the round shortly...
          </p>
        </div>
        <Button 
          onClick={() => navigate(`/rounds/${slug}`)} 
          className="bg-yellow-500 hover:bg-yellow-400 text-black font-bold uppercase tracking-wide mt-4"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to Round
        </Button>
      </div>
    );
  }

  const subtotal = cartItems.reduce((sum, item) => {
    const qty = item.qty ?? item.quantity ?? 1;
    const price = item.price ?? item.unit_price ?? 0;
    return sum + (qty * price);
  }, 0);
  
  const tax = subtotal * 0.05; // Dummy 5% tax for display purposes if needed
  const total = subtotal + tax;

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <Button 
        onClick={() => navigate(`/rounds/${slug}`)} 
        variant="ghost" 
        className="mb-8 text-zinc-400 hover:text-white"
      >
        <ArrowLeft className="w-4 h-4 mr-2" /> Back to Round
      </Button>

      <h1 className="text-3xl md:text-4xl font-bold text-white mb-8 flex items-center gap-3">
        <ShoppingCart className="text-yellow-500 w-8 h-8" />
        Your Cart
      </h1>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-4">
          {cartItems.map((item, index) => {
            const uniqueId = item.id || item.variant_id || item.product_id || index;
            const title = item.title || item.variant?.title || item.product?.title || 'Unknown Product';
            const price = item.price ?? item.unit_price ?? 0;
            const qty = item.qty ?? item.quantity ?? 1;
            const image = item.image_url || item.thumbnail_url || item.variant?.image_url || item.product?.thumbnail_url || '/images/placeholder-product.svg';
            const itemSubtotal = qty * price;

            return (
              <div 
                key={uniqueId} 
                className="bg-zinc-950 border border-zinc-800 rounded-xl p-4 flex flex-col sm:flex-row gap-6 items-center shadow-sm"
              >
                <div className="flex w-full sm:w-auto items-center gap-4 flex-1">
                  <div className="w-20 h-20 bg-white rounded-lg border border-zinc-800 flex items-center justify-center overflow-hidden shrink-0">
                    <img 
                      src={image} 
                      alt={title} 
                      className="w-full h-full object-contain"
                      onError={(e) => { e.target.src = '/images/placeholder-product.svg'; }}
                    />
                  </div>
                  <div className="flex-1 min-w-0">
                    <h3 className="text-zinc-100 font-bold text-lg truncate">{title}</h3>
                    <div className="text-sm text-yellow-500 font-bold mt-1">
                      ${Number(price).toFixed(2)}
                    </div>
                  </div>
                </div>
                
                <div className="flex items-center gap-4 w-full sm:w-auto justify-between sm:justify-end border-t sm:border-t-0 pt-4 sm:pt-0 border-zinc-800">
                  <div className="flex items-center border border-zinc-700 rounded-md bg-zinc-950 overflow-hidden">
                     <div className="px-4 py-2 text-white font-medium text-sm min-w-[3rem] text-center">
                        Qty: {qty}
                     </div>
                  </div>
                  
                  <div className="text-right min-w-[5rem] mr-4">
                    <p className="text-zinc-100 font-bold">${itemSubtotal.toFixed(2)}</p>
                  </div>
                  
                  <button
                    onClick={() => deleteItem(uniqueId)}
                    aria-label="Delete item"
                    title="Delete item"
                    className="p-2 bg-zinc-900 text-zinc-400 hover:text-white hover:bg-[#EF4444] rounded-md transition-colors shrink-0"
                  >
                    <Trash2 className="w-5 h-5" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>

        <div className="lg:col-span-1">
          <div className="bg-zinc-950 border border-zinc-800 rounded-2xl p-6 sticky top-24 shadow-lg">
            <h2 className="text-xl font-bold text-white mb-6 border-b border-zinc-800 pb-4">Order Summary</h2>
            
            <div className="space-y-3 text-sm mb-6">
              <div className="flex justify-between text-zinc-400">
                <span>Subtotal</span>
                <span className="text-white">${subtotal.toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-zinc-400">
                <span>Estimated Tax (5%)</span>
                <span className="text-white">${tax.toFixed(2)}</span>
              </div>
            </div>
            
            <div className="flex justify-between items-center text-white text-xl font-bold mb-8 pt-4 border-t border-zinc-800">
              <span>Total</span>
              <span className="text-yellow-500">${total.toFixed(2)}</span>
            </div>

            <Button 
              onClick={() => navigate(`/rounds/${slug}/checkout`)} 
              className="w-full h-12 bg-yellow-500 hover:bg-yellow-400 text-black font-bold uppercase tracking-wide flex items-center justify-center transition-all"
            >
              Proceed to Checkout
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
