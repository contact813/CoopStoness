
export default function MarketplaceSearch() {
  return null;
}
