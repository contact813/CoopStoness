
import React from 'react';

/**
 * LEGACY: Marketplace and Collection Menu functionality disabled.
 */
export default function CollectionMenu() {
  return null;
}
