import React from 'react';
import { Link } from 'react-router-dom';
import { Linkedin, Instagram } from 'lucide-react';

const Footer = () => {
  return (
    <footer className="bg-black border-t border-gray-800/50 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid md:grid-cols-4 gap-8 mb-8">
          {/* Logo & Desc */}
          <div>
            <Link to="/" className="inline-block mb-4">
              <img 
                src="https://horizons-cdn.hostinger.com/22223bb4-de39-49c5-a095-21a9a1bf381e/1fce079730e7c3e48d2af4ba706d0e3e.png" 
                alt="Coop Stones Logo" 
                className="h-12 w-auto"
              />
            </Link>
            <p className="text-gray-400 text-sm">
              Uniting stone professionals to leverage collective power, reduce
              costs, and grow stronger together.
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <span className="text-yellow-400 font-semibold text-lg mb-4 block">QUICK LINKS</span>
            <nav className="space-y-2">
              <Link to="/about" className="block text-gray-400 hover:text-yellow-400 transition-colors text-sm">
                About Us
              </Link>
              <Link to="/membership" className="block text-gray-400 hover:text-yellow-400 transition-colors text-sm">
                Membership
              </Link>
              <Link to="/blog" className="block text-gray-400 hover:text-yellow-400 transition-colors text-sm">
                Our Blog
              </Link>
              <Link to="/contact" className="block text-gray-400 hover:text-yellow-400 transition-colors text-sm">
                Contact Us
              </Link>
            </nav>
          </div>

          {/* Legal Column - New */}
          <div>
            <span className="text-yellow-400 font-semibold text-lg mb-4 block">LEGAL</span>
            <nav className="space-y-2">
              <Link to="/terms-and-conditions" className="block text-gray-400 hover:text-yellow-400 transition-colors text-sm">
                Terms & Conditions
              </Link>
              <Link to="/privacy-policy" className="block text-gray-400 hover:text-yellow-400 transition-colors text-sm">
                Privacy Policy
              </Link>
              <Link to="/refund-policy" className="block text-gray-400 hover:text-yellow-400 transition-colors text-sm">
                Refund Policy
              </Link>
              <Link to="/company-information" className="block text-gray-400 hover:text-yellow-400 transition-colors text-sm">
                Company Info
              </Link>
            </nav>
          </div>

          {/* Contact */}
          <div>
            <span className="text-yellow-400 font-semibold text-lg mb-4 block">CONTACT</span>
            <div className="space-y-2 text-sm">
              <p className="text-gray-400">
                <span className="font-medium text-zinc-300">Email:</span> contact@coopstones.com
              </p>
              <div className="text-gray-400 mt-2">
                <span className="font-medium text-zinc-300">Headquarters:</span><br/>
                COOPSTONES LLC<br/>
                W St Conrad St<br/>
                Massachusetts, USA
              </div>
              <div className="flex space-x-4 mt-4">
                <a 
                  href="https://linkedin.com" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="text-gray-400 hover:text-yellow-400 transition-colors"
                  aria-label="LinkedIn"
                >
                  <Linkedin size={20} />
                </a>
                <a 
                  href="https://instagram.com" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="text-gray-400 hover:text-yellow-400 transition-colors"
                  aria-label="Instagram"
                >
                  <Instagram size={20} />
                </a>
              </div>
            </div>
          </div>
        </div>

        <div className="border-t border-gray-800/50 pt-8 flex flex-col md:flex-row justify-between items-center text-sm text-gray-400">
          <p>© 2025 COOP STONES. All rights reserved.</p>
          <p className="mt-2 md:mt-0">
            Built with <span className="text-red-500">❤</span> for the stone community.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;