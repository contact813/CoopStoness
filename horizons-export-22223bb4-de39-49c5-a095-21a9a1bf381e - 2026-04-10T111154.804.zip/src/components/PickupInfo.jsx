import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Phone } from "lucide-react";

export default function PickupInfo({
  location = "Sarasota Warehouse",
  addressLines = [
    "7040 15th St SE #12",
    "Sarasota FL 34243",
    "United States"
  ],
  phone = "+1 941 807 2727",
}) {
  const [showPickupModal, setShowPickupModal] = useState(false);

  return (
    <>
      <div className="mt-6 p-4 rounded-xl bg-zinc-900 border border-zinc-800">
        <div className="text-zinc-300">
          Pickup available at <span className="text-zinc-100">{location}</span>
        </div>
        <button
          onClick={() => setShowPickupModal(true)}
          className="text-yellow-400 text-sm mt-1 inline-block hover:underline hover:text-yellow-300 transition-colors"
        >
          View store information
        </button>
      </div>

      <Dialog open={showPickupModal} onOpenChange={setShowPickupModal}>
        <DialogContent className="bg-zinc-900 border-zinc-800 text-white max-w-md w-full p-8 rounded-lg gap-6">
          <DialogHeader className="space-y-3 text-left">
            <DialogTitle className="text-2xl font-bold text-white leading-tight">
              {location}
            </DialogTitle>
            <DialogDescription className="text-zinc-400 text-base">
              Pickup available at our warehouse location.
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-6">
            <div className="text-zinc-300 text-base leading-relaxed space-y-1">
              {addressLines.map((line, i) => (
                <div key={i}>{line}</div>
              ))}
            </div>

            <a 
              href={`tel:${phone.replace(/\s+/g, '')}`} 
              className="flex items-center gap-3 text-zinc-300 hover:text-white transition-colors group w-fit"
            >
              <Phone className="w-5 h-5 text-yellow-400 group-hover:text-yellow-300 transition-colors" /> 
              <span className="text-lg font-medium">{phone}</span>
            </a>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}