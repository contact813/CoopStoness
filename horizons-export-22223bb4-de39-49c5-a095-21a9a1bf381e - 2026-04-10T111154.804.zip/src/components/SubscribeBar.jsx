import React from 'react';
import { useState } from "react";

export default function SubscribeBar({ onSubmit }) {
  const [email, setEmail] = useState("");

  const submit = (e) => {
    e.preventDefault();
    if (!email) return;
    onSubmit?.(email);
    setEmail("");
  };

  return (
    <div className="mt-10 rounded-2xl bg-yellow-500 text-black">
      <div className="max-w-6xl mx-auto px-4 py-6 flex flex-col md:flex-row md:items-center gap-3">
        <div className="flex-1">
          <div className="font-semibold text-lg">Subscribe to our newsletter</div>
          <div className="text-sm/6 opacity-90">Receive special offers</div>
        </div>
        <form onSubmit={submit} className="flex w-full md:w-auto gap-2">
          <input
            type="email"
            required
            placeholder="Your email"
            value={email}
            onChange={(e)=>setEmail(e.target.value)}
            className="flex-1 md:w-80 px-3 py-2 rounded-lg bg-white text-black outline-none"
          />
          <button
            type="submit"
            className="px-4 py-2 rounded-lg bg-black text-yellow-400 hover:bg-zinc-900"
          >
            Subscribe
          </button>
        </form>
      </div>
    </div>
  );
}