import React from 'react';
import { Link } from "react-router-dom";
import { Badge } from "@/components/ui/badge";

export default function RoundCard({ product, round }) {
  if (!product || !round) return null;

  const displayImage = product.thumbnail_url || product.images?.[0]?.url || '/images/placeholder-product.svg';
  const displayTitle = product.title || 'Unknown Product';
  const displayPrice = product.roundConfig?.special_price || product.price || product.min_price || 0;
  const discountPct = product.roundConfig?.discount_pct || 0;
  const isFeatured = product.roundConfig?.is_featured || false;

  return (
    <div className="rounded-2xl overflow-hidden bg-zinc-900 border border-zinc-800 flex flex-col h-full group hover:border-yellow-500 transition-colors duration-300">
      <Link to={`/rounds/${round.slug || round.id}/product/${product.id}`} className="block relative">
        <div className="aspect-[4/3] bg-zinc-800 overflow-hidden relative">
          <img 
            src={displayImage} 
            alt={displayTitle} 
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" 
            onError={(e) => {
              e.target.onerror = null; 
              e.target.src = '/images/placeholder-product.svg';
            }}
          />
          <div className="absolute top-3 left-3 flex flex-col gap-2">
            {discountPct > 0 && (
              <Badge className="bg-red-500 text-white font-bold">{discountPct}% OFF</Badge>
            )}
            {isFeatured && (
              <Badge className="bg-yellow-500 text-black font-bold">Featured</Badge>
            )}
          </div>
        </div>
      </Link>

      <div className="p-5 flex flex-col flex-grow text-left">
        <h3 className="text-white font-bold text-lg leading-tight line-clamp-2 min-h-[3.5rem] group-hover:text-yellow-500 transition-colors">
          <Link to={`/rounds/${round.slug || round.id}/product/${product.id}`}>
            {displayTitle}
          </Link>
        </h3>

        {product.description && (
          <p className="text-sm text-zinc-400 mt-2 line-clamp-2" dangerouslySetInnerHTML={{ __html: product.description }} />
        )}

        <div className="flex-grow" />

        <div className="mt-4 flex items-center justify-between">
          <div className="flex flex-col">
             <span className="text-[10px] uppercase tracking-wider text-zinc-500 font-bold">Price</span>
             <span className="text-yellow-500 font-bold text-xl">${Number(displayPrice).toFixed(2)}</span>
          </div>
          <Link
            to={`/rounds/${round.slug || round.id}/product/${product.id}`}
            className="inline-flex items-center justify-center px-4 py-2 rounded-xl bg-zinc-800 text-white font-bold text-xs hover:bg-yellow-500 hover:text-black transition-colors"
          >
            View Details
          </Link>
        </div>
      </div>
    </div>
  );
}