
import React, { useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { PLACEHOLDER_IMAGE } from '@/lib/imageUtils';
import { sanitizeUuid } from '@/lib/roundsApi';
import { Progress } from '@/components/ui/progress';

export default function RoundProductCard({ product, roundId, roundSlug }) {
  const navigate = useNavigate();

  const handleProductClick = useCallback(() => {
    if (!product || !product.id) {
      console.warn(`[RoundProductCard] Missing product data for click handler.`);
      return;
    }

    const cleanProductId = sanitizeUuid(product.id);
    if (!cleanProductId) {
      console.warn(`[RoundProductCard] Invalid product UUID: ${product.id}`);
      return;
    }

    const targetRoundIdentifier = roundSlug || roundId;
    if (!targetRoundIdentifier) {
      console.warn(`[RoundProductCard] Missing round identifier (slug or ID).`);
      return;
    }

    if (!roundSlug && roundId) {
      const cleanRoundId = sanitizeUuid(roundId);
      if (!cleanRoundId) {
        console.warn(`[RoundProductCard] Invalid round UUID: ${roundId}`);
        return;
      }
      navigate(`/rounds/${cleanRoundId}/product/${cleanProductId}`);
      return;
    }

    navigate(`/rounds/${targetRoundIdentifier}/product/${cleanProductId}`);
  }, [product, roundId, roundSlug, navigate]);

  if (!product) {
    console.warn(`[RoundProductCard] Product missing. Skipping render.`);
    return null;
  }

  const displayTitle = product.title || 'Untitled Product';
  
  // FALLBACK LOGIC: variant image -> product thumbnail -> product images -> placeholder
  const displayImage = product.variant_image || product.thumbnail_url || product.images?.[0]?.url || PLACEHOLDER_IMAGE;
  const displayPrice = product.price || 0;
  const displayCompareAtPrice = product.compare_at_price || product.variant_compare_at_price || 0;
  
  const goalQty = product.roundConfig?.goal_qty || product.goal_qty || 0;
  const committedQty = product.items_sold || product.committed_qty || 0;
  const progressPct = goalQty > 0 ? Math.min(100, Math.round((committedQty / goalQty) * 100)) : 0;
  
  const variantsCount = product.variants_count || product.variants?.length || 0;

  return (
    <div 
      onClick={handleProductClick} 
      className="flex flex-col bg-zinc-900 border border-zinc-800 rounded-xl overflow-hidden hover:border-yellow-500/50 transition-all group h-full cursor-pointer relative"
    >
      <div className="aspect-[4/3] bg-zinc-900 relative overflow-visible flex items-center justify-center p-4">
        <img 
          src={displayImage} 
          alt={displayTitle} 
          className="w-full h-auto object-contain transition-transform duration-500 group-hover:scale-105"
          onError={(e) => { e.currentTarget.onerror = null; e.currentTarget.src = PLACEHOLDER_IMAGE; }}
        />
      </div>

      <div className="p-5 flex flex-col flex-grow space-y-4">
        <div>
          {product.vendor && <p className="text-zinc-500 text-[10px] uppercase font-bold tracking-widest mb-1">{product.vendor}</p>}
          <h3 className="text-zinc-100 font-bold line-clamp-2 group-hover:text-yellow-500 transition-colors leading-tight" title={displayTitle}>
            {displayTitle}
          </h3>
          <div className="mt-3 price-with-compare">
             {displayCompareAtPrice > displayPrice && (
               <span className="compare-at-price">${Number(displayCompareAtPrice).toFixed(2)}</span>
             )}
             <span className="text-lg font-bold text-yellow-500">${Number(displayPrice).toFixed(2)}</span>
          </div>
        </div>

        <div className="flex flex-col mt-auto">
          {goalQty > 0 ? (
            <div className="space-y-2 w-full mt-2">
              <div className="flex justify-between items-center text-xs">
                <span className="text-zinc-400 font-medium">Goal Progress</span>
                <span className="text-zinc-300">{progressPct}%</span>
              </div>
              <Progress value={progressPct} className="h-2 bg-zinc-800" indicatorClassName="bg-yellow-500" />
              <div className="text-[10px] text-zinc-500 text-right">
                {committedQty} / {goalQty} committed
              </div>
            </div>
          ) : (
             <div className="text-xs text-zinc-500">No specific goal set</div>
          )}

          {variantsCount > 1 && (
            <span className="text-xs text-zinc-500 font-normal mt-3">{variantsCount} variants</span>
          )}
        </div>
      </div>
    </div>
  );
}
