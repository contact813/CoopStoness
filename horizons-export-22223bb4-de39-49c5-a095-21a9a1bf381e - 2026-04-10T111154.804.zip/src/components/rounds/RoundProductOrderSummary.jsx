
import React from 'react';
import { Button } from '@/components/ui/button';
import { Minus, Plus, Trash2, Package, Info } from 'lucide-react';
import { cn } from '@/lib/utils';

export default function RoundProductOrderSummary({ 
  productItems = [], 
  product, 
  roundId, 
  onRemoveItem, 
  onUpdateQuantity 
}) {
  if (!productItems || !productItems.length) {
    return (
      <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-6 text-center">
        <Package className="w-10 h-10 text-zinc-600 mx-auto mb-3" />
        <h3 className="text-zinc-300 font-medium mb-1">No items added</h3>
        <p className="text-sm text-zinc-500">Select options and add to your order to see the summary.</p>
      </div>
    );
  }

  const totalItems = productItems.reduce((sum, item) => sum + (item.quantity || 0), 0);
  const totalAmount = productItems.reduce((sum, item) => sum + (item.price * (item.quantity || 0)), 0);

  const handleRemove = (item) => {
    if (window.confirm('Are you sure you want to remove this item from your order?')) {
      if (onRemoveItem) onRemoveItem(item);
    }
  };

  return (
    <div className="bg-zinc-900 border border-zinc-800 rounded-xl overflow-hidden flex flex-col">
      <div className="p-4 border-b border-zinc-800 bg-zinc-950">
        <h3 className="font-bold text-white flex items-center justify-between">
          <span>Order Summary</span>
          <span className="text-xs bg-yellow-500 text-black px-2 py-0.5 rounded-full">{totalItems} items</span>
        </h3>
      </div>
      
      <div className="p-4 flex-1 overflow-y-auto max-h-[400px] space-y-4">
        {productItems.map((item) => (
          <div key={item.round_cart_item_id || item.variant_id || item.id} className="flex flex-col gap-3 p-3 bg-zinc-950 rounded-lg border border-zinc-800/50">
            <div className="flex justify-between items-start gap-2">
              <div className="flex-1 min-w-0">
                <h4 className="text-sm font-medium text-zinc-200 truncate" title={item.variant_title || item.title || product?.title}>
                  {item.variant_title || item.title || product?.title || 'Default Item'}
                </h4>
                {item.variant_sku && (
                  <p className="text-xs text-zinc-500 font-mono mt-0.5">SKU: {item.variant_sku}</p>
                )}
              </div>
              <button 
                onClick={() => handleRemove(item)}
                className="text-zinc-600 hover:text-red-400 p-1 flex-shrink-0 transition-colors"
                title="Remove Item"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
            
            <div className="flex items-center justify-between mt-1">
              <div className="flex items-center gap-2 bg-zinc-900 border border-zinc-800 rounded-md p-1">
                <button 
                  onClick={() => onUpdateQuantity && onUpdateQuantity(item, Math.max(1, (item.quantity || 1) - 1))}
                  className="p-1 hover:bg-zinc-800 hover:text-white text-zinc-400 rounded transition-colors"
                  disabled={item.quantity <= 1}
                >
                  <Minus className="w-3 h-3" />
                </button>
                <span className="text-xs font-medium w-6 text-center text-zinc-200">{item.quantity}</span>
                <button 
                  onClick={() => onUpdateQuantity && onUpdateQuantity(item, (item.quantity || 1) + 1)}
                  className="p-1 hover:bg-zinc-800 hover:text-white text-zinc-400 rounded transition-colors"
                >
                  <Plus className="w-3 h-3" />
                </button>
              </div>
              <div className="text-right">
                <div className="text-sm font-bold text-emerald-400">${(item.price * item.quantity).toFixed(2)}</div>
                <div className="text-[10px] text-zinc-500">${item.price.toFixed(2)} ea</div>
              </div>
            </div>
          </div>
        ))}

        <div className="flex items-start gap-2 bg-blue-500/10 text-blue-400 p-3 rounded-lg border border-blue-500/20 mt-2">
          <Info className="w-4 h-4 mt-0.5 flex-shrink-0" />
          <p className="text-xs">You can add more variants of this product to your order by selecting different options above and clicking "Add Variant to Order".</p>
        </div>
      </div>

      <div className="p-4 border-t border-zinc-800 bg-zinc-950">
        <div className="flex justify-between items-center text-lg font-bold mb-4">
          <span className="text-zinc-300">Order Total</span>
          <span className="text-yellow-500">${totalAmount.toFixed(2)}</span>
        </div>
      </div>
    </div>
  );
}
