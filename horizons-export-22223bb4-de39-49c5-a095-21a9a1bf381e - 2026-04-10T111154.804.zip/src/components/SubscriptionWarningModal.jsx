import React, { useEffect, useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { AlertTriangle } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { markWarningSeen } from '@/lib/usersApi';
import { useNavigate } from 'react-router-dom';

export default function SubscriptionWarningModal() {
  const { profile, user } = useAuth();
  const [open, setOpen] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    if (profile && profile.subscription_status === 'late' && !profile.warning_popup_shown) {
      setOpen(true);
    }
  }, [profile]);

  const handleDismiss = async () => {
    try {
      if (user?.id) {
        await markWarningSeen(user.id);
      }
      setOpen(false);
    } catch (e) {
      console.error("Failed to mark warning seen", e);
      setOpen(false);
    }
  };

  const handlePayment = () => {
      handleDismiss();
      navigate('/account'); // Assuming account page has payment details
  };

  return (
    <Dialog open={open} onOpenChange={handleDismiss}>
      <DialogContent className="sm:max-w-md border-red-900/50 bg-zinc-950">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-red-500">
            <AlertTriangle size={24} />
            Payment Overdue
          </DialogTitle>
        </DialogHeader>
        <div className="py-4 text-zinc-300">
          <p>Your membership payment is overdue.</p>
          <p className="mt-2 text-sm text-zinc-400">
            Please update your payment information to avoid account suspension. Your account will be suspended automatically after 15 days of non-payment.
          </p>
        </div>
        <DialogFooter className="gap-2 sm:gap-0">
          <Button variant="ghost" onClick={handleDismiss} className="text-zinc-400 hover:text-white">
            Later
          </Button>
          <Button onClick={handlePayment} className="bg-red-600 hover:bg-red-700 text-white">
            Update Payment
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}