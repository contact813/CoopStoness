
import React from 'react';
import { motion } from 'framer-motion';
import { Check } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';

const MembershipPlans = () => {
  const goldBenefits = [
    'Group purchasing discounts (25%-75%)',
    'Access to Coop Stones quartz & porcelain',
    'Access exclusive round deals and early ordering',
    'Basic marketing & web assistance',
    'Workshops and technical training',
  ];

  const platinumBenefits = [
    'All Gold benefits, plus:',
    'Proprietary reputation & reviews software',
    'Deeper equipment discounts via partners',
    'Exclusive cabinet manufacturer program (36% discount)',
    'Premium specialist support',
    'Access to capital funds & group insurance (coming soon)',
  ];

  const handleScrollToTop = () => {
    window.scrollTo(0, 0);
  };

  return (
    <section className="section-bg py-24">
      <div className="max-w-screen-lg mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold text-white mb-4">
            Choose Your <span className="text-yellow-400">Membership Plan</span>
          </h2>
          <p className="text-gray-400 text-lg">
            Select the plan that fits your goals and start enjoying members-only benefits.
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 gap-8 items-stretch mb-12">
          {/* Gold Plan */}
          <motion.div
            initial={{ opacity: 0, y: 30, scale: 0.95 }}
            whileInView={{ opacity: 1, y: 0, scale: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.1 }}
            className="bg-gray-900/50 border border-yellow-400/30 rounded-xl p-8 h-full flex flex-col backdrop-blur-sm"
          >
            <h3 className="text-3xl font-bold text-white mb-6 text-center">Gold Plan</h3>
            <ul className="space-y-4 mb-8 flex-grow">
              {goldBenefits.map((benefit, i) => (
                <li key={i} className="flex items-start">
                  <Check className="w-5 h-5 text-yellow-400 mr-3 mt-1 flex-shrink-0" />
                  <span className="text-gray-300">{benefit}</span>
                </li>
              ))}
            </ul>
            <Link to="/membership/gold" onClick={handleScrollToTop}>
              <Button 
                size="lg" 
                className="w-full bg-yellow-400 hover:bg-yellow-500 text-black font-bold py-6 text-lg transition-colors"
              >
                Start with Gold
              </Button>
            </Link>
          </motion.div>

          {/* Platinum Plan */}
          <motion.div
            initial={{ opacity: 0, y: 30, scale: 0.95 }}
            whileInView={{ opacity: 1, y: 0, scale: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.2 }}
            className="bg-gray-900/50 border-2 border-yellow-400 rounded-xl p-8 relative h-full flex flex-col backdrop-blur-sm shadow-2xl shadow-yellow-400/20"
          >
            <h3 className="text-3xl font-bold text-yellow-400 mb-6 text-center">Platinum Plan</h3>
            <ul className="space-y-4 mb-8 flex-grow">
              {platinumBenefits.map((benefit, i) => (
                <li key={i} className="flex items-start">
                  <Check className="w-5 h-5 text-yellow-400 mr-3 mt-1 flex-shrink-0" />
                  <span className="text-gray-300">{benefit}</span>
                </li>
              ))}
            </ul>
            <Link to="/membership/platinum" onClick={handleScrollToTop}>
              <Button 
                size="lg" 
                className="w-full bg-yellow-400 hover:bg-yellow-500 text-black font-bold py-6 text-lg transition-colors"
              >
                Join Platinum
              </Button>
            </Link>
          </motion.div>
        </div>
        
        <div className="max-w-2xl mx-auto text-center border-t border-gray-800 pt-8">
            <p className="text-gray-500 text-sm">
              Submitting an application does not guarantee acceptance. All applications are reviewed prior to approval.
            </p>
        </div>
      </div>
    </section>
  );
};

export default MembershipPlans;
