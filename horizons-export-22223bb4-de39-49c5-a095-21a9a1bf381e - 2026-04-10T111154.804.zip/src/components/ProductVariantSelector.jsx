
import React from 'react';
import { cn } from '@/lib/utils';
import { Label } from '@/components/ui/label';

export default function ProductVariantSelector({ product, variants, selectedVariant, onSelectVariant }) {
  console.log(`[ProductVariantSelector] Rendering ${variants?.length || 0} variants`);

  if (!variants || variants.length === 0) {
    console.log('[ProductVariantSelector] No variants provided, returning null');
    return null;
  }

  try {
    // Normalize variants to always have optionValues for unified rendering
    const normalizedVariants = variants.map(v => {
      if (v.optionValues && v.optionValues.length > 0) return v;
      return {
        ...v,
        optionValues: [{ 
          optionName: v.option_name || 'Opção', 
          value: v.option_value || v.title || 'Padrão',
          valueId: v.id // Fallback ID for compatibility
        }]
      };
    });

    // Helper to map variant to an object { OptionName: Value }
    const variantToOptionMap = (variant) => {
      const map = {};
      if (variant.optionValues && Array.isArray(variant.optionValues)) {
        variant.optionValues.forEach(ov => {
          map[ov.optionName] = ov.value;
        });
      }
      return map;
    };

    // Determine official option order (cascade order)
    let optionOrder = [];
    if (product?.options && Array.isArray(product.options) && product.options.length > 0) {
      optionOrder = product.options
        .slice()
        .sort((a, b) => (a.position || 0) - (b.position || 0))
        .map(o => o.name);
    } else {
      const names = new Set();
      normalizedVariants.forEach(v => {
        v.optionValues.forEach(ov => names.add(ov.optionName));
      });
      optionOrder = Array.from(names);
    }

    console.log('[ProductVariantSelector] Official option order:', optionOrder);

    // Build current selection map
    const currentSelectionMap = {};
    if (selectedVariant && selectedVariant.optionValues) {
      selectedVariant.optionValues.forEach(ov => {
        currentSelectionMap[ov.optionName] = ov.value;
      });
    } else if (selectedVariant && selectedVariant.option_name) {
      currentSelectionMap[selectedVariant.option_name] = selectedVariant.option_value || selectedVariant.title;
    }

    // Cascading filter helper
    const isCompatibleWithPreviousSelections = (variant, selections, currentIndex) => {
      const variantMap = variantToOptionMap(variant);
      // Only check compatibility with groups that come strictly before currentIndex
      for (let i = 0; i < currentIndex; i++) {
        const optName = optionOrder[i];
        if (selections[optName] && variantMap[optName] !== selections[optName]) {
          return false;
        }
      }
      return true;
    };

    // Group variants according to optionOrder and cascade logic
    const groupedVariants = {};
    
    optionOrder.forEach((optionName, index) => {
      groupedVariants[optionName] = [];
      
      const compatibleVariants = normalizedVariants.filter(v =>
        isCompatibleWithPreviousSelections(v, currentSelectionMap, index)
      );
      
      const seenValues = new Set();
      compatibleVariants.forEach(variant => {
        if (!variant.optionValues) return;
        variant.optionValues.forEach(ov => {
          const uniqueKey = ov.valueId || ov.value;
          if (ov.optionName === optionName && !seenValues.has(uniqueKey)) {
            seenValues.add(uniqueKey);
            groupedVariants[optionName].push(ov);
          }
        });
      });
    });

    console.log(`[ProductVariantSelector] Grouped options count: ${Object.keys(groupedVariants).length}`);

    const handleOptionClick = (optionName, optionValue, optionIndex) => {
      console.log(`[ProductVariantSelector] Selected option: ${optionName} = ${optionValue.value}`);
      
      const nextSelection = { ...currentSelectionMap };
      nextSelection[optionName] = optionValue.value;
      
      // Clear selections for all downstream option groups to enforce cascade
      for (let i = optionIndex + 1; i < optionOrder.length; i++) {
        delete nextSelection[optionOrder[i]];
      }

      // Find the first variant that matches all remaining selections
      let matchingVariant = normalizedVariants.find(v => {
        const variantMap = variantToOptionMap(v);
        for (const [optName, optValue] of Object.entries(nextSelection)) {
          if (variantMap[optName] !== optValue) {
            return false;
          }
        }
        return true;
      });

      if (matchingVariant) {
        console.log('[ProductVariantSelector] Found matching variant:', matchingVariant.id);
        const originalVariant = variants.find(v => v.id === matchingVariant.id) || matchingVariant;
        onSelectVariant(originalVariant);
      } else {
        console.log('[ProductVariantSelector] No strict match found. Falling back.');
        const fallbackVariant = normalizedVariants.find(v => variantToOptionMap(v)[optionName] === optionValue.value);
        if (fallbackVariant) {
          const originalVariant = variants.find(v => v.id === fallbackVariant.id) || fallbackVariant;
          onSelectVariant(originalVariant);
        }
      }
    };

    return (
      <div className="space-y-4 mb-6">
        {optionOrder.map((optionName, index) => {
          const optionValues = groupedVariants[optionName] || [];
          if (optionValues.length === 0) return null;

          const currentSelectedValue = currentSelectionMap[optionName];

          return (
            <div key={optionName} className="space-y-2">
              <Label className="text-zinc-400 block text-xs uppercase tracking-wider font-bold mb-2">
                {optionName}: <span className="text-white">{currentSelectedValue || 'Selecione...'}</span>
              </Label>
              <div className="flex flex-wrap gap-2">
                {optionValues.map((ov, idx) => {
                  const isSelected = currentSelectedValue === ov.value;

                  return (
                    <button
                      key={ov.valueId || `${ov.value}-${idx}`}
                      onClick={() => handleOptionClick(optionName, ov, index)}
                      className={cn(
                        "px-4 py-2 border rounded text-sm transition-all",
                        isSelected
                          ? "bg-yellow-500 border-yellow-500 text-black font-medium"
                          : "bg-transparent border-zinc-700 text-zinc-300 hover:border-zinc-500"
                      )}
                    >
                      {ov.value}
                    </button>
                  );
                })}
              </div>
            </div>
          );
        })}
      </div>
    );
  } catch (error) {
    console.error('[ProductVariantSelector] Error rendering selector:', error);
    return <p className="text-red-500 text-sm">Erro ao carregar opções.</p>;
  }
}
