// DEPRECATED
export default function SupabaseHealth() { return null; }