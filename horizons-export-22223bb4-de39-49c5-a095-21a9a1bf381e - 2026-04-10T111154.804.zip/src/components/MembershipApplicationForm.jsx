import React, { useState } from 'react';
import { supabase } from '@/lib/supabaseClient';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/components/ui/use-toast";
import { Loader2, CheckCircle2 } from "lucide-react";
import { motion } from 'framer-motion';

export default function MembershipApplicationForm({ plan, onSuccess }) {
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    company_name: '',
    email: '',
    phone: '',
    street: '',
    city: '',
    state: '',
    zip: '',
    message: ''
  });

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      const payload = {
        company_name: formData.company_name,
        applicant_name: formData.name,
        plan: plan,
        email: formData.email,
        phone: formData.phone,
        street: formData.street,
        city: formData.city,
        state: formData.state,
        zip: formData.zip,
        message: formData.message
      };

      const { data, error } = await supabase.functions.invoke('create-membership-application', {
        body: payload
      });

      if (error) {
        throw error;
      }

      if (data && data.error) {
        throw new Error(data.error);
      }

      setSuccess(true);
      toast({
        title: "Application Submitted",
        description: "Your application has been submitted and is under review.",
      });

      // Clear form
      setFormData({ name: '', company_name: '', email: '', phone: '', street: '', city: '', state: '', zip: '', message: '' });

      if (onSuccess) {
        setTimeout(() => onSuccess(), 2000);
      }

    } catch (error) {
      console.error("Submission Error:", error);
      toast({
        variant: "destructive",
        title: "Submission Failed",
        description: error.message || "There was an error submitting your application.",
      });
    } finally {
      setLoading(false);
    }
  };

  if (success) {
    return (
      <motion.div 
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        className="bg-green-500/10 border border-green-500/20 rounded-xl p-8 text-center"
      >
        <div className="flex justify-center mb-4">
          <CheckCircle2 className="w-16 h-16 text-green-500" />
        </div>
        <h3 className="text-2xl font-bold text-white mb-2">Application Received!</h3>
        <p className="text-zinc-300">
          Thank you for applying for the {plan} Membership. We will review your information and get back to you shortly.
        </p>
        <Button 
          variant="outline" 
          className="mt-6 border-zinc-700 text-zinc-300 hover:text-white"
          onClick={() => setSuccess(false)}
        >
          Submit Another Application
        </Button>
      </motion.div>
    );
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="grid md:grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="company_name" className="text-zinc-300">Company Name <span className="text-red-500">*</span></Label>
          <Input id="company_name" name="company_name" value={formData.company_name} onChange={handleChange} required placeholder="Stone Works LLC" className="bg-zinc-900 border-zinc-700 text-white placeholder:text-zinc-500 focus:ring-yellow-500/50" />
        </div>
        <div className="space-y-2">
          <Label htmlFor="name" className="text-zinc-300">Applicant Name <span className="text-red-500">*</span></Label>
          <Input id="name" name="name" value={formData.name} onChange={handleChange} required placeholder="John Doe" className="bg-zinc-900 border-zinc-700 text-white placeholder:text-zinc-500 focus:ring-yellow-500/50" />
        </div>
      </div>

      <div className="grid md:grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="email" className="text-zinc-300">Email Address <span className="text-red-500">*</span></Label>
          <Input id="email" name="email" type="email" value={formData.email} onChange={handleChange} required placeholder="john@example.com" className="bg-zinc-900 border-zinc-700 text-white placeholder:text-zinc-500 focus:ring-yellow-500/50" />
        </div>
        <div className="space-y-2">
          <Label htmlFor="phone" className="text-zinc-300">Phone Number <span className="text-red-500">*</span></Label>
          <Input id="phone" name="phone" type="tel" value={formData.phone} onChange={handleChange} required placeholder="(555) 123-4567" className="bg-zinc-900 border-zinc-700 text-white placeholder:text-zinc-500 focus:ring-yellow-500/50" />
        </div>
      </div>

      <div className="space-y-2">
        <Label htmlFor="street" className="text-zinc-300">Street Address <span className="text-red-500">*</span></Label>
        <Input id="street" name="street" value={formData.street} onChange={handleChange} required placeholder="123 Main St, Apt 2" className="bg-zinc-900 border-zinc-700 text-white placeholder:text-zinc-500 focus:ring-yellow-500/50" />
      </div>

      <div className="grid md:grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="city" className="text-zinc-300">City <span className="text-red-500">*</span></Label>
          <Input id="city" name="city" value={formData.city} onChange={handleChange} required placeholder="New York" className="bg-zinc-900 border-zinc-700 text-white placeholder:text-zinc-500 focus:ring-yellow-500/50" />
        </div>
        <div className="space-y-2">
          <Label htmlFor="state" className="text-zinc-300">State / Province <span className="text-red-500">*</span></Label>
          <Input id="state" name="state" value={formData.state} onChange={handleChange} required placeholder="NY" className="bg-zinc-900 border-zinc-700 text-white placeholder:text-zinc-500 focus:ring-yellow-500/50" />
        </div>
      </div>

      <div className="grid md:grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="zip" className="text-zinc-300">ZIP Code <span className="text-red-500">*</span></Label>
          <Input id="zip" name="zip" value={formData.zip} onChange={handleChange} required placeholder="10001" className="bg-zinc-900 border-zinc-700 text-white placeholder:text-zinc-500 focus:ring-yellow-500/50" />
        </div>
        <div className="hidden md:block"></div>
      </div>

      <div className="space-y-2">
        <Label htmlFor="message" className="text-zinc-300">Additional Message (Optional)</Label>
        <Textarea id="message" name="message" value={formData.message} onChange={handleChange} placeholder="Tell us about your business needs..." className="bg-zinc-900 border-zinc-700 text-white placeholder:text-zinc-500 focus:ring-yellow-500/50 min-h-[100px]" />
      </div>

      <Button type="submit" disabled={loading} className="w-full bg-yellow-500 text-black hover:bg-yellow-400 font-bold py-6 text-lg mt-4">
        {loading ? <Loader2 className="w-5 h-5 animate-spin mr-2" /> : null}
        {loading ? "Submitting..." : `Submit ${plan} Application`}
      </Button>
    </form>
  );
}