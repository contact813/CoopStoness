
import React, { useEffect, useRef, useState } from 'react';
import { Link, NavLink, useNavigate, useLocation, useParams } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import { 
  Menu, X, 
  LayoutDashboard, Package, Users, Settings, LogOut, 
  User, ListOrdered, PiggyBank, Boxes, ShoppingBag, ClipboardCheck,
  Crown, BadgeCheck, ClipboardList, AlertCircle, ShoppingCart
} from "lucide-react";
import { cn } from "@/lib/utils";

function UserMenu({ mobile = false, closeMenu }) {
  const { user, profile, signOut, isAuthLoading, authError } = useAuth();
  const nav = useNavigate();
  const [open, setOpen] = useState(false);
  const ref = useRef(null);

  useEffect(() => {
    function onDocClick(e) {
      if (ref.current && !ref.current.contains(e.target)) {
        setOpen(false);
      }
    }
    if (!mobile) document.addEventListener("mousedown", onDocClick);
    return () => {
      if (!mobile) document.removeEventListener("mousedown", onDocClick);
    };
  }, [mobile]);

  const isAdmin = 
    (profile?.is_admin === true) || 
    (profile?.role === 'admin') ||
    (user?.app_metadata?.role === 'admin') || 
    (user?.user_metadata?.is_admin === true) ||
    (user?.role === 'service_role');

  if (isAuthLoading) return <div className="w-24 h-9 rounded-xl bg-zinc-800 animate-pulse" />;

  if (!user) {
    return (
      <Link 
        to="/login" 
        onClick={closeMenu}
        className={cn(
          "px-5 py-2.5 rounded-xl bg-yellow-500 text-black font-bold hover:bg-yellow-400 transition-all shadow-lg shadow-yellow-500/20",
          mobile && "w-full text-center block mt-4"
        )}
      >
        Login
      </Link>
    );
  }

  const handleLogout = async () => {
    if (closeMenu) closeMenu();
    setOpen(false);
    await signOut();
    nav("/");
  };

  const AdminNavLink = ({ to, icon: Icon, label }) => (
    <NavLink 
      to={to} 
      onClick={() => { setOpen(false); closeMenu?.(); }} 
      className={({ isActive }) => cn(
        "flex items-center gap-3 px-4 py-2 text-sm transition-colors",
        isActive 
          ? "bg-zinc-800 text-yellow-400" 
          : "text-zinc-300 hover:bg-zinc-800 hover:text-yellow-400"
      )}
    >
      <Icon size={16} /> {label}
    </NavLink>
  );

  const MenuContent = () => (
    <div className={cn("flex flex-col", mobile ? "space-y-1" : "py-2")}>
      <div className="px-4 py-3 border-b border-zinc-800 mb-2 bg-zinc-900/50">
        <p className="text-xs text-zinc-500 font-medium uppercase tracking-wider mb-1">Logged in as</p>
        <p className="text-sm text-white font-medium truncate max-w-[200px] mb-2">{user.email}</p>
        
        {authError && (
           <div className="flex items-center gap-2 text-xs text-red-400 mb-2">
             <AlertCircle size={12} />
             <span>Profile load error</span>
           </div>
        )}

        {(profile?.membership_tier || profile?.membership_status) && (
          <div className="flex flex-col gap-1 mt-2 pt-2 border-t border-zinc-800/50">
             {profile?.membership_tier && (
               <div className="flex items-center gap-1.5 text-xs text-amber-400">
                 <Crown size={12} />
                 <span className="uppercase tracking-wide font-bold">{profile.membership_tier} Member</span>
               </div>
             )}
             {profile?.membership_status && (
               <div className="flex items-center gap-1.5 text-xs text-emerald-400">
                 <BadgeCheck size={12} />
                 <span className="capitalize">Status: {profile.membership_status}</span>
               </div>
             )}
          </div>
        )}
      </div>

      {isAdmin ? (
        <>
          <div className="px-4 py-1 text-[10px] font-bold text-zinc-500 uppercase tracking-widest mt-1">Admin Tools</div>
          <AdminNavLink to="/admin" icon={LayoutDashboard} label="Dashboard" />
          <AdminNavLink to="/admin/products" icon={Boxes} label="Products" />
          <AdminNavLink to="/admin/rounds" icon={Package} label="Rounds" />
          <AdminNavLink to="/admin/orders" icon={ShoppingBag} label="Orders" />
          <AdminNavLink to="/admin/users" icon={Users} label="Users" />
          <AdminNavLink to="/admin/membership-applications" icon={ClipboardList} label="Applications" />
          <AdminNavLink to="/admin/audit" icon={ClipboardCheck} label="Audit" />
          
          <div className="h-px bg-zinc-800 my-1 mx-4" />
          <NavLink 
            to="/account?tab=settings" 
            onClick={() => { setOpen(false); closeMenu?.(); }} 
            className={({ isActive }) => cn(
              "flex items-center gap-3 px-4 py-2 text-sm transition-colors",
              isActive 
                ? "bg-zinc-800 text-yellow-400" 
                : "text-zinc-300 hover:bg-zinc-800 hover:text-yellow-400"
            )}
          >
            <Settings size={16} /> Settings
          </NavLink>
        </>
      ) : (
        <>
          <Link to="/account?tab=overview" onClick={() => { setOpen(false); closeMenu?.(); }} className="flex items-center gap-3 px-4 py-2.5 text-sm text-zinc-300 hover:bg-zinc-800 hover:text-yellow-400 transition-colors">
            <User size={18} /> My Account
          </Link>
          <Link to="/account?tab=orders" onClick={() => { setOpen(false); closeMenu?.(); }} className="flex items-center gap-3 px-4 py-2.5 text-sm text-zinc-300 hover:bg-zinc-800 hover:text-yellow-400 transition-colors">
            <ListOrdered size={18} /> My Orders
          </Link>
          <Link to="/account?tab=savings" onClick={() => { setOpen(false); closeMenu?.(); }} className="flex items-center gap-3 px-4 py-2.5 text-sm text-zinc-300 hover:bg-zinc-800 hover:text-yellow-400 transition-colors">
            <PiggyBank size={18} /> Savings Overview
          </Link>
        </>
      )}

      <div className="h-px bg-zinc-800 my-2 mx-4" />
      
      <button 
        onClick={handleLogout} 
        className="w-full flex items-center gap-3 px-4 py-2.5 text-sm text-red-400 hover:bg-zinc-800 hover:text-red-300 text-left transition-colors"
      >
        <LogOut size={18} /> Logout
      </button>
    </div>
  );

  if (mobile) {
    return <MenuContent />;
  }

  return (
    <div className="relative" ref={ref}>
      <div className="flex items-center gap-3">
        <span className="hidden lg:block text-sm font-medium text-zinc-300 max-w-[150px] truncate">
          {user.email}
        </span>
        <button 
          onClick={() => setOpen(v => !v)} 
          className="w-10 h-10 rounded-xl bg-yellow-500 text-black flex items-center justify-center hover:bg-yellow-400 transition-all shadow-lg shadow-yellow-500/20"
          aria-label="User Menu"
        >
          <Menu size={20} className="stroke-[2.5px]" />
        </button>
      </div>

      {open && (
        <div className="absolute right-0 mt-3 w-72 rounded-2xl bg-zinc-950 border border-zinc-800 shadow-2xl ring-1 ring-black/5 overflow-hidden z-50 animate-in fade-in slide-in-from-top-2 duration-200">
          <MenuContent />
        </div>
      )}
    </div>
  );
}

const Header = () => {
  const { user, profile } = useAuth();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const location = useLocation();
  const params = useParams();
  const navigate = useNavigate();
  const [cartCount, setCartCount] = useState(0);
  
  const isAdmin = 
    (profile?.is_admin === true) || 
    (profile?.role === 'admin') ||
    (user?.app_metadata?.role === 'admin') || 
    (user?.user_metadata?.is_admin === true) ||
    (user?.role === 'service_role');
  
  // 2. Extract current round slug
  const slug = React.useMemo(() => {
    if (params.slug) return params.slug;
    const match = location.pathname.match(/^\/rounds\/([^\/]+)/);
    return match ? match[1] : null;
  }, [params.slug, location.pathname]);

  // 3. Track cart items count
  useEffect(() => {
    const updateCount = () => {
      if (!slug) {
        setCartCount(0);
        return;
      }
      try {
        const localCart = localStorage.getItem(`round_cart_${slug}`);
        if (localCart) {
          const parsed = JSON.parse(localCart);
          const items = parsed.items || parsed.cartItems || parsed;
          if (Array.isArray(items)) {
            const count = items.reduce((acc, item) => acc + (item.qty ?? item.quantity ?? 1), 0);
            setCartCount(count);
            return;
          }
        }
        
        // Generic fallback check if needed
        const coopCart = localStorage.getItem('coop_cart');
        if (coopCart) {
          const parsed = JSON.parse(coopCart);
          if (Array.isArray(parsed)) {
            const count = parsed.reduce((acc, item) => acc + (item.qty ?? item.quantity ?? 1), 0);
            setCartCount(count);
            return;
          }
        }
        
        setCartCount(0);
      } catch (e) {
        console.error('[Header] Failed to parse cart count:', e);
        setCartCount(0);
      }
    };

    updateCount();
    window.addEventListener('storage', updateCount);
    window.addEventListener('cart_updated', updateCount);
    
    return () => {
      window.removeEventListener('storage', updateCount);
      window.removeEventListener('cart_updated', updateCount);
    };
  }, [slug, location.pathname]);

  const handleCartClick = () => {
    if (!slug) {
      alert("Please select a round first to view its cart.");
      return;
    }
    navigate(`/rounds/${slug}/cart`);
  };

  const getNavLinks = () => {
    const links = [
      { to: "/", text: "Home" }
    ];

    if (!user || isAdmin) {
      links.push({ to: "/about", text: "About Us" });
      links.push({ to: "/membership", text: "Membership" });
    }

    if (user) {
      links.push({ to: "/rounds", text: "Rounds" });
    }

    links.push({ to: "/blog", text: "Blog" });
    links.push({ to: "/contact", text: "Contact" });

    return links;
  };

  const navLinks = getNavLinks();

  return (
    <header className="fixed top-0 left-0 right-0 z-50 w-full border-b border-white/5 bg-black/80 backdrop-blur-md supports-[backdrop-filter]:bg-black/60">
      <div className="max-w-[1400px] mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between">
        
        <Link to="/" className="flex items-center gap-2 shrink-0">
            <img className="h-10 w-auto object-contain" alt="Coop Stones Logo" src="https://horizons-cdn.hostinger.com/22223bb4-de39-49c5-a095-21a9a1bf381e/logo-coop-stones-04-b6WuY.png" />
        </Link>
        
        <nav className="hidden lg:flex items-center justify-center gap-8 flex-1 px-8">
          {navLinks.map(link => (
            <NavLink 
              key={link.to} 
              to={link.to} 
              className={({ isActive }) => 
                `text-sm font-medium transition-colors relative py-1 hover:text-yellow-400 ${
                  isActive ? 'text-yellow-400' : 'text-zinc-300'
                }`
              }
            >
              {link.text}
            </NavLink>
          ))}
        </nav>
        
        <div className="flex items-center gap-4 shrink-0">
          
          <button 
            onClick={handleCartClick}
            disabled={!slug}
            title={slug ? "Shopping Cart" : "Please select a round first"}
            className={cn(
              "relative p-2 transition-colors",
              slug 
                ? "text-zinc-300 hover:text-yellow-500" 
                : "text-zinc-600 opacity-50 cursor-not-allowed"
            )}
          >
            <ShoppingCart className="w-6 h-6" />
            {cartCount > 0 && (
              <span className="absolute -top-1 -right-1 bg-yellow-500 text-black text-[10px] font-bold rounded-full w-5 h-5 flex items-center justify-center border-2 border-black">
                {cartCount > 99 ? '99+' : cartCount}
              </span>
            )}
          </button>

          <div className="hidden lg:block">
            <UserMenu />
          </div>

          <button 
            className="lg:hidden p-2 text-zinc-300 hover:text-white"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          >
            {mobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
      </div>

      {mobileMenuOpen && (
        <div className="lg:hidden fixed inset-0 top-20 bg-black z-40 flex flex-col overflow-y-auto border-t border-zinc-800">
          <nav className="flex flex-col p-6">
            {navLinks.map(link => (
              <NavLink 
                key={link.to} 
                to={link.to} 
                onClick={() => setMobileMenuOpen(false)}
                className={({ isActive }) => 
                  `text-xl font-medium py-4 border-b border-zinc-900 ${
                    isActive ? 'text-yellow-400' : 'text-zinc-300'
                  }`
                }
              >
                {link.text}
              </NavLink>
            ))}
            
            <div className="mt-6">
               <UserMenu mobile={true} closeMenu={() => setMobileMenuOpen(false)} />
            </div>
          </nav>
        </div>
      )}
    </header>
  );
};

export default Header;
