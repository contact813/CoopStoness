
/**
 * FILENAME: src/components/AdminGate.jsx
 * PURPOSE: Enforces Admin permissions. Checks DB profile and Auth Metadata.
 */
import React from 'react';
import { Navigate, Outlet } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { Loader2 } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';

const AdminGate = ({ children }) => {
  const { user, profile, isAuthInitialized } = useAuth();
  const { toast } = useToast();

  if (!isAuthInitialized) {
    console.log("[AdminGate] Auth initializing. Showing loader...");
    return (
      <div className="flex items-center justify-center min-h-screen bg-black">
        <Loader2 className="h-8 w-8 animate-spin text-yellow-500" />
      </div>
    );
  }

  if (!user) {
    console.log("[AdminGate] No user found. Redirecting to login...");
    return <Navigate to="/login" replace />;
  }

  // SECTION: Comprehensive Admin Verification
  const isAdmin = 
    (profile?.is_admin === true) ||                   // Check 1: DB Profile (Primary)
    (profile?.role === 'admin') ||                    // Check 2: DB Profile Role
    (user?.app_metadata?.role === 'admin') ||         // Check 3: Auth Provider Metadata
    (user?.user_metadata?.is_admin === true) ||       // Check 4: User Metadata
    (user?.role === 'service_role');                  // Check 5: Service Role (Dev/System)

  if (!isAdmin) {
    console.warn("[AdminGate] Access Denied. User is not an admin:", user.email);
    return <Navigate to="/" replace />;
  }

  console.log("[AdminGate] User verified as Admin. Granting access.");
  return children || <Outlet />;
};

export default AdminGate;
