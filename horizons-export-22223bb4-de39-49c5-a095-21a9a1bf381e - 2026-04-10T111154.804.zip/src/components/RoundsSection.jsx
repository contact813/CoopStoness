import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { supabase } from '@/lib/supabaseClient';
import { useAuth } from '@/contexts/AuthContext';
import RoundCard from '@/components/RoundCard';
import { Loader2, AlertTriangle } from 'lucide-react';

const RoundsSection = () => {
  const [rounds, setRounds] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const { user } = useAuth(); 

  useEffect(() => {
    if (user) {
      async function fetchRounds() {
        setLoading(true);
        setError(null);
        try {
          // Added limit(3) to show only top 3 active rounds on the main dashboard/marketplace view
          const { data, error } = await supabase
            .from('rounds')
            .select('id, slug, title, subtitle, description, cover_image_url, cover_path, starts_at, ends_at, status, discount_pct, order_index, goal_amount, committed_amount')
            .eq('status', 'active')
            .order('order_index', { ascending: true })
            .limit(3);
          
          if (error) throw error;
          setRounds(data || []);
        } catch (err) {
          console.error('Error fetching rounds:', err);
          setError("Failed to load active rounds. Please try again later.");
          setRounds([]);
        } finally {
          setLoading(false);
        }
      }
      fetchRounds();
    } else {
      setRounds([]);
      setLoading(false);
    }
  }, [user]);

  if (!user) {
    return null;
  }

  return (
    <div className="text-center py-12 rounded-3xl bg-gradient-to-br from-zinc-900 via-black to-zinc-900 border border-zinc-800">
      <h2 className="text-4xl font-bold text-white mb-2">Ongoing Purchase Rounds</h2>
      <p className="text-zinc-400 mb-8">Join these active rounds to get the best prices through collective buying.</p>
      
      {loading ? (
        <div className="flex justify-center items-center py-12">
          <Loader2 className="w-8 h-8 animate-spin text-zinc-500" />
        </div>
      ) : error ? (
        <div className="flex flex-col items-center justify-center py-8 text-red-400 gap-2">
          <AlertTriangle className="w-8 h-8" />
          <p>{error}</p>
        </div>
      ) : rounds.length > 0 ? (
        <div className="max-w-6xl mx-auto grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 px-4">
          {rounds.map((round, index) => (
            <motion.div
              key={round.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
            >
              <RoundCard round={round} /> 
            </motion.div>
          ))}
        </div>
      ) : (
        <div className="py-8 text-zinc-500">
          No active rounds at the moment.
        </div>
      )}

      <div className="mt-8 flex justify-center">
        <Link 
          to="/rounds" 
          className="inline-block px-6 py-3 rounded-xl bg-yellow-400 text-black font-medium hover:bg-yellow-300 transition-colors shadow-lg hover:shadow-yellow-400/20"
        >
          View All Rounds
        </Link>
      </div>
    </div>
  );
};

export default RoundsSection;