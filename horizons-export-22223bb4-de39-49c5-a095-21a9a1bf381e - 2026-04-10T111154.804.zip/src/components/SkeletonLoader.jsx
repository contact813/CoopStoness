import React from 'react';

export const SkeletonCard = () => {
  return (
    <div className="rounded-xl border border-zinc-800 bg-zinc-900/50 p-4 animate-pulse">
      <div className="flex gap-4">
        <div className="h-16 w-16 bg-zinc-800 rounded-md"></div>
        <div className="flex-1 space-y-3 py-1">
          <div className="h-4 bg-zinc-800 rounded w-3/4"></div>
          <div className="h-3 bg-zinc-800 rounded w-1/2"></div>
        </div>
      </div>
      <div className="mt-4 space-y-2">
         <div className="h-3 bg-zinc-800 rounded w-full"></div>
         <div className="h-3 bg-zinc-800 rounded w-5/6"></div>
      </div>
    </div>
  );
};

export default SkeletonCard;