
import React, { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabaseClient';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { ArrowLeft, Package, CreditCard, Box, Tag, Calendar, Clock } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { format } from 'date-fns';
import { Loader2 } from 'lucide-react';

export default function AccountOrderDetail({ orderId, onBack }) {
  const [cartData, setCartData] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!orderId) return;

    const fetchDetails = async () => {
      setLoading(true);
      try {
        const { data, error } = await supabase
          .from('round_carts')
          .select(`
            id, status, created_at, updated_at,
            rounds ( title ),
            round_cart_items (
              id, qty, unit_price, original_unit_price, status,
              products ( title ),
              product_variants ( title, sku )
            )
          `)
          .eq('id', orderId)
          .single();

        if (error) throw error;
        setCartData(data);
      } catch (error) {
        console.error("Error fetching cart details:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchDetails();
  }, [orderId]);

  if (loading) {
    return (
       <div className="flex justify-center items-center py-20">
         <Loader2 className="h-8 w-8 animate-spin text-yellow-500" />
       </div>
    );
  }

  if (!cartData) return null;

  const items = cartData.round_cart_items || [];
  let totalItems = 0;
  let totalAmount = 0;
  let cartSavings = 0;

  items.forEach(item => {
      const qty = item.qty || 1;
      const price = Number(item.unit_price || 0);
      const originalPrice = Number(item.original_unit_price || price);
      
      totalItems += qty;
      totalAmount += qty * price;
      if (originalPrice > price) {
          cartSavings += (originalPrice - price) * qty;
      }
  });

  const roundName = cartData.rounds?.title || 'Unknown Round';

  const getStatusColor = (status) => {
    const s = (status || '').toLowerCase();
    if (['paid', 'completed'].includes(s)) return 'bg-green-500/10 text-green-500 border-green-500/20';
    if (['confirmed', 'eligible_to_pay'].includes(s)) return 'bg-yellow-500/10 text-yellow-500 border-yellow-500/20';
    return 'bg-zinc-800 text-zinc-300 border-zinc-700';
  };

  return (
    <div className="space-y-6">
      <Button 
        variant="ghost" 
        onClick={onBack}
        className="text-zinc-400 hover:text-white hover:bg-zinc-800 -ml-4"
      >
        <ArrowLeft className="mr-2 h-4 w-4" /> Back to Orders
      </Button>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="bg-zinc-900 border-zinc-800 md:col-span-2">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <Package className="h-5 w-5 text-yellow-500" /> Order Information
            </CardTitle>
          </CardHeader>
          <CardContent className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-sm">
            <div>
              <p className="text-zinc-500 mb-1">Order ID</p>
              <p className="font-mono text-zinc-200 truncate" title={cartData.id}>{cartData.id}</p>
            </div>
            <div>
              <p className="text-zinc-500 mb-1">Status</p>
              <Badge variant="outline" className={`uppercase font-bold tracking-wider text-[10px] ${getStatusColor(cartData.status)}`}>
                {cartData.status.replace(/_/g, ' ') || 'Pending'}
              </Badge>
            </div>
            <div>
              <p className="text-zinc-500 mb-1">Created At</p>
              <div className="flex items-center text-zinc-200">
                <Calendar className="w-3.5 h-3.5 mr-1.5 text-zinc-500" />
                {cartData.created_at ? format(new Date(cartData.created_at), 'PPP') : 'Unknown'}
              </div>
            </div>
            <div>
              <p className="text-zinc-500 mb-1">Last Updated</p>
              <div className="flex items-center text-zinc-200">
                <Clock className="w-3.5 h-3.5 mr-1.5 text-zinc-500" />
                {cartData.updated_at ? format(new Date(cartData.updated_at), 'PPP pp') : (cartData.created_at ? format(new Date(cartData.created_at), 'PPP pp') : 'Unknown')}
              </div>
            </div>
            <div className="sm:col-span-2">
              <p className="text-zinc-500 mb-1">Round</p>
              <p className="font-medium text-zinc-200 truncate">
                {roundName}
              </p>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-zinc-900 border-zinc-800">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <CreditCard className="h-5 w-5 text-yellow-500" /> Summary
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex justify-between text-sm">
              <span className="text-zinc-400">Total Items</span>
              <span className="text-zinc-200 font-medium">{totalItems}</span>
            </div>
            {cartSavings > 0 && (
              <div className="flex justify-between text-sm">
                <span className="text-green-500">Total Savings</span>
                <span className="text-green-500 font-bold">+${cartSavings.toFixed(2)}</span>
              </div>
            )}
            <div className="border-t border-zinc-800 pt-4 flex justify-between items-center">
              <span className="font-medium text-zinc-400">Total Amount</span>
              <span className="text-2xl font-bold text-yellow-500">${totalAmount.toFixed(2)}</span>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card className="bg-zinc-900 border-zinc-800 overflow-hidden">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Box className="h-5 w-5 text-yellow-500" /> Order Items
          </CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          {items.length === 0 ? (
            <p className="text-zinc-500 text-center py-8">No items found for this order.</p>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm text-left">
                <thead className="text-xs text-zinc-400 uppercase bg-zinc-950 border-b border-zinc-800">
                  <tr>
                    <th className="px-6 py-4">Product</th>
                    <th className="px-6 py-4">Variant</th>
                    <th className="px-6 py-4">SKU</th>
                    <th className="px-6 py-4 text-center">Qty</th>
                    <th className="px-6 py-4 text-right">Price</th>
                    <th className="px-6 py-4 text-right">Subtotal</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-zinc-800">
                  {items.map((item, idx) => {
                    const title = item.products?.title || 'Unknown Product';
                    const variantTitle = item.product_variants?.title || '-';
                    const sku = item.product_variants?.sku || '-';
                    const qty = item.qty || 1;
                    const price = Number(item.unit_price || 0);
                    const originalPrice = Number(item.original_unit_price || price);
                    const hasDiscount = originalPrice > price;
                    const itemSavings = hasDiscount ? (originalPrice - price) * qty : 0;
                    const subtotal = qty * price;

                    return (
                      <tr key={item.id || idx} className="hover:bg-zinc-800/50 transition-colors">
                        <td className="px-6 py-4 font-medium text-zinc-200">{title}</td>
                        <td className="px-6 py-4 text-zinc-400 text-xs">
                          {variantTitle !== '-' ? (
                            <Badge variant="secondary" className="bg-zinc-800 text-zinc-300 border-none font-normal text-[10px]">
                              {variantTitle}
                            </Badge>
                          ) : '-'}
                        </td>
                        <td className="px-6 py-4 text-zinc-500 font-mono text-xs">{sku}</td>
                        <td className="px-6 py-4 text-center text-zinc-300 font-medium">{qty}</td>
                        <td className="px-6 py-4 text-right">
                            <div className="flex flex-col items-end">
                                <span className="text-zinc-200">${price.toFixed(2)}</span>
                                {hasDiscount && (
                                    <span className="text-xs text-zinc-500 line-through">${originalPrice.toFixed(2)}</span>
                                )}
                            </div>
                        </td>
                        <td className="px-6 py-4 text-right">
                           <div className="flex flex-col items-end">
                              <span className="font-bold text-white">${subtotal.toFixed(2)}</span>
                              {itemSavings > 0 && (
                                  <span className="text-[10px] text-green-500 uppercase font-semibold tracking-wide">
                                      Saved ${itemSavings.toFixed(2)}
                                  </span>
                              )}
                           </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>
      
      {cartSavings > 0 && (
         <div className="bg-green-950/30 border border-green-900/50 p-4 rounded-xl flex items-center justify-center gap-3">
            <Tag className="text-green-500 h-5 w-5" />
            <p className="text-green-400 font-medium">You saved <span className="font-bold">${cartSavings.toFixed(2)}</span> on this order!</p>
         </div>
      )}
    </div>
  );
}
