
import React, { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabaseClient';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Package, DollarSign, Calendar, Clock, CheckCircle, TrendingUp, RefreshCw, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { format } from 'date-fns';

const CONFIRMED_STATUSES = ['confirmed', 'eligible_to_pay', 'paid', 'completed'];
const ACTIVE_STATUSES = ['confirmed', 'eligible_to_pay', 'reserved'];
const COMPLETED_STATUSES = ['paid', 'completed'];

export default function AccountOverview({ user }) {
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const fetchStats = async () => {
    if (!user?.id) {
      setLoading(false);
      return;
    }
    
    setLoading(true);
    setError(null);
    
    try {
      const { data: carts, error: cartsError } = await supabase
        .from('round_carts')
        .select(`
          id,
          status,
          created_at,
          updated_at,
          round_cart_items (
            qty,
            unit_price,
            original_unit_price
          )
        `)
        .eq('user_id', user.id)
        .in('status', CONFIRMED_STATUSES)
        .order('updated_at', { ascending: false });

      if (cartsError) {
        console.error("Failed to load carts:", cartsError);
        throw cartsError;
      }
      
      let totalSaved = 0;
      let totalOrders = carts?.length || 0;
      let totalItemsPurchased = 0;
      let activeOrders = 0;
      let completedOrders = 0;
      
      // Determine member since by oldest cart or user created_at
      let memberSince = user.created_at;
      if (carts && carts.length > 0) {
          const oldestCart = [...carts].sort((a, b) => new Date(a.created_at) - new Date(b.created_at))[0];
          memberSince = oldestCart.created_at;
      }

      // Determine last order date from most recently updated cart
      let lastOrderDate = carts?.length > 0 ? carts[0].updated_at || carts[0].created_at : null;

      (carts || []).forEach(cart => {
        const status = (cart.status || '').toLowerCase();
        
        if (ACTIVE_STATUSES.includes(status)) activeOrders++;
        if (COMPLETED_STATUSES.includes(status)) completedOrders++;

        (cart.round_cart_items || []).forEach(item => {
          const qty = item.qty || 1;
          const unitPrice = Number(item.unit_price || 0);
          const originalPrice = Number(item.original_unit_price || item.unit_price || 0);
          
          totalItemsPurchased += qty;
          
          if (originalPrice > unitPrice) {
            totalSaved += (originalPrice - unitPrice) * qty;
          }
        });
      });

      setStats({
        totalSaved,
        totalOrders,
        totalItemsPurchased,
        activeOrders,
        completedOrders,
        lastOrderDate,
        memberSince
      });

    } catch (err) {
      console.error("Error fetching stats:", err);
      setError("Failed to load account statistics. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchStats();
  }, [user]);

  if (loading) {
    return (
      <div className="flex flex-col justify-center items-center py-20 bg-zinc-900/50 rounded-xl border border-zinc-800">
        <Loader2 className="h-8 w-8 animate-spin text-yellow-500 mb-4" />
        <p className="text-zinc-500">Loading dashboard data...</p>
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex flex-col items-center justify-center py-16 bg-red-950/20 border border-red-900/50 rounded-xl text-center">
        <p className="text-red-400 mb-4">{error}</p>
        <Button variant="outline" onClick={fetchStats} className="border-red-900/50 text-red-400 hover:bg-red-900/20">
          <RefreshCw className="mr-2 h-4 w-4" /> Retry
        </Button>
      </div>
    );
  }

  if (!stats) return null;

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-white mb-2">Welcome back!</h2>
        <p className="text-zinc-400">Here's an overview of your account and confirmed purchases.</p>
      </div>

      <Card className="bg-yellow-500 border-yellow-400 overflow-hidden relative">
        <div className="absolute right-0 top-0 opacity-10 pointer-events-none transform translate-x-1/4 -translate-y-1/4">
           <TrendingUp className="w-64 h-64 text-black" />
        </div>
        <CardContent className="p-8 relative z-10">
          <div className="flex flex-col gap-2">
            <span className="text-yellow-950 font-bold uppercase tracking-wider text-sm flex items-center gap-2">
              <DollarSign className="w-4 h-4" /> Total Lifetime Savings
            </span>
            <span className="text-5xl font-black text-black">
              ${stats.totalSaved.toFixed(2)}
            </span>
            <span className="text-yellow-900 text-sm mt-2 font-medium">
              Saved from participating in group rounds
            </span>
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="bg-zinc-900 border-zinc-800">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-zinc-400 flex items-center gap-2">
              <Package className="h-4 w-4 text-yellow-500" /> Confirmed Orders
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-white">{stats.totalOrders}</div>
          </CardContent>
        </Card>

        <Card className="bg-zinc-900 border-zinc-800">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-zinc-400 flex items-center gap-2">
              <Package className="h-4 w-4 text-yellow-500" /> Items Purchased
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-white">{stats.totalItemsPurchased}</div>
          </CardContent>
        </Card>

        <Card className="bg-zinc-900 border-zinc-800">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-zinc-400 flex items-center gap-2">
              <Calendar className="h-4 w-4 text-yellow-500" /> Member Since
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-xl font-bold text-white mt-1">
              {stats.memberSince ? format(new Date(stats.memberSince), 'MMM yyyy') : 'N/A'}
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card className="bg-zinc-900 border-zinc-800">
          <CardContent className="p-6 flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 rounded-full bg-yellow-500/10 flex items-center justify-center">
                <Clock className="h-6 w-6 text-yellow-500" />
              </div>
              <div>
                <p className="text-sm text-zinc-400 font-medium">Active Orders</p>
                <p className="text-2xl font-bold text-white">{stats.activeOrders}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-zinc-900 border-zinc-800">
          <CardContent className="p-6 flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 rounded-full bg-green-500/10 flex items-center justify-center">
                <CheckCircle className="h-6 w-6 text-green-500" />
              </div>
              <div>
                <p className="text-sm text-zinc-400 font-medium">Completed Orders</p>
                <p className="text-2xl font-bold text-white">{stats.completedOrders}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {stats.lastOrderDate && (
        <div className="text-center text-sm text-zinc-500 mt-8">
          Your last confirmed order was updated on {format(new Date(stats.lastOrderDate), 'PPP')}
        </div>
      )}
    </div>
  );
}
