
import React, { useState } from 'react';
import { supabase } from '@/lib/supabaseClient';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Settings, Shield, Mail, Key, Loader2, CheckCircle2 } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import { format } from 'date-fns';

export default function AccountSettings({ user }) {
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const { toast } = useToast();

  const handleResetPassword = async () => {
    if (!user?.email) return;
    setLoading(true);
    setSuccess(false);

    try {
      const { error } = await supabase.auth.resetPasswordForEmail(user.email, {
        redirectTo: `${window.location.origin}/reset-password`,
      });

      if (error) throw error;
      
      setSuccess(true);
      toast({
        title: "Email Sent",
        description: "Password reset instructions have been sent to your inbox.",
      });
    } catch (error) {
      console.error("Error sending reset email:", error);
      toast({
        variant: "destructive",
        title: "Error",
        description: error.message || "Failed to send reset email. Please try again.",
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="bg-zinc-900 p-6 rounded-xl border border-zinc-800">
        <h2 className="text-xl font-bold text-white flex items-center gap-2 mb-2">
          <Settings className="h-5 w-5 text-yellow-500" /> Account Settings
        </h2>
        <p className="text-sm text-zinc-400">Manage your account preferences and security.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card className="bg-zinc-900 border-zinc-800">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-white">
              <Shield className="h-5 w-5 text-yellow-500" /> Security
            </CardTitle>
            <CardDescription className="text-zinc-400">
              Update your password and secure your account
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label className="text-zinc-300">Password</Label>
              <p className="text-sm text-zinc-500 mb-4">
                To change your password, we'll send a secure link to your email address.
              </p>
              
              {success ? (
                <div className="flex items-center gap-2 text-green-500 bg-green-500/10 p-3 rounded-md border border-green-500/20 text-sm">
                  <CheckCircle2 className="h-5 w-5" />
                  Password reset email sent! Check your inbox.
                </div>
              ) : (
                <Button 
                  onClick={handleResetPassword} 
                  disabled={loading || !user?.email}
                  className="bg-zinc-800 text-white hover:bg-zinc-700 w-full sm:w-auto"
                >
                  {loading ? (
                    <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  ) : (
                    <Key className="h-4 w-4 mr-2 text-yellow-500" />
                  )}
                  Send Password Reset Email
                </Button>
              )}
            </div>
          </CardContent>
        </Card>

        <Card className="bg-zinc-900 border-zinc-800">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-white">
              <Mail className="h-5 w-5 text-yellow-500" /> Account Information
            </CardTitle>
            <CardDescription className="text-zinc-400">
              Your primary account details
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label className="text-zinc-400">Email Address</Label>
              <Input 
                value={user?.email || ''} 
                disabled 
                className="bg-zinc-950 border-zinc-800 text-zinc-300 opacity-70"
              />
            </div>
            <div className="space-y-2">
              <Label className="text-zinc-400">User ID</Label>
              <Input 
                value={user?.id || ''} 
                disabled 
                className="bg-zinc-950 border-zinc-800 text-zinc-500 opacity-50 font-mono text-xs"
              />
            </div>
            <div className="space-y-2">
              <Label className="text-zinc-400">Account Created</Label>
              <Input 
                value={user?.created_at ? format(new Date(user.created_at), 'PPP') : 'Unknown'} 
                disabled 
                className="bg-zinc-950 border-zinc-800 text-zinc-300 opacity-70"
              />
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
