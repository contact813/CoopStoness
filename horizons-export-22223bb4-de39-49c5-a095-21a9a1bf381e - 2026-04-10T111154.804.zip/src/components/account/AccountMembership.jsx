
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Crown, Star } from 'lucide-react';

export default function AccountMembership({ user }) {
  return (
    <Card className="bg-zinc-900 border-zinc-800">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-white">
          <Crown className="h-5 w-5 text-yellow-500" /> Membership
        </CardTitle>
        <CardDescription className="text-zinc-400">
          View your membership status and benefits
        </CardDescription>
      </CardHeader>
      <CardContent className="flex flex-col items-center justify-center py-12 text-center">
        <Star className="h-12 w-12 text-zinc-600 mb-4" />
        <h3 className="text-xl font-medium text-zinc-300 mb-2">Membership Portal Coming Soon</h3>
        <p className="text-zinc-500 max-w-md">
          Access your exclusive membership benefits, view your current tier, and upgrade your plan directly from this page soon.
        </p>
      </CardContent>
    </Card>
  );
}
