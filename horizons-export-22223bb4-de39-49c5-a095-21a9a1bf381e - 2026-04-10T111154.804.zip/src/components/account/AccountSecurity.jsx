
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Shield, Lock } from 'lucide-react';

export default function AccountSecurity({ user }) {
  return (
    <Card className="bg-zinc-900 border-zinc-800">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-white">
          <Shield className="h-5 w-5 text-yellow-500" /> Security
        </CardTitle>
        <CardDescription className="text-zinc-400">
          Manage your security preferences
        </CardDescription>
      </CardHeader>
      <CardContent className="flex flex-col items-center justify-center py-12 text-center">
        <Lock className="h-12 w-12 text-zinc-600 mb-4" />
        <h3 className="text-xl font-medium text-zinc-300 mb-2">Security Settings Coming Soon</h3>
        <p className="text-zinc-500 max-w-md">
          Password updates and two-factor authentication will be available in a future update.
        </p>
      </CardContent>
    </Card>
  );
}
