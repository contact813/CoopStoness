import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { useToast } from '@/components/ui/use-toast';
import { supabase } from '@/lib/supabaseClient';
import { cn } from '@/lib/utils';

const ContactForm = ({ className }) => {
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    fullName: '',
    companyName: '',
    email: '',
    phone: '',
    message: '',
  });

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    const { error } = await supabase
      .from('contacts')
      .insert([
        { 
          full_name: formData.fullName, 
          company_name: formData.companyName, 
          email: formData.email, 
          phone: formData.phone, 
          message: formData.message 
        },
      ]);

    if (error) {
      toast({
        variant: "destructive",
        title: "Submission Failed",
        description: "There was a problem submitting your application. Please try again.",
      });
    } else {
      toast({
        title: "Application Submitted!",
        description: "Thank you for your interest. We'll be in touch soon!",
      });
      setFormData({
        fullName: '',
        companyName: '',
        email: '',
        phone: '',
        message: '',
      });
    }
    setLoading(false);
  };

  return (
    <section className={cn("py-24", className)}>
      <div className="max-w-screen-md mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <h1 className="text-3xl sm:text-4xl md:text-5xl font-bold text-white mb-4">
            Contact <span className="text-yellow-400">Us</span>
          </h1>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="mb-10 max-w-2xl mx-auto"
          >
            <p className="text-lg text-gray-300 mb-6">
              Ready to connect with the leading cooperative for stone industry experts?
              Whether you have questions, feedback, or are interested in partnership opportunities,
              our team is here to assist you. Fill out the form below, and we'll get back to you promptly.
              Let's build a stronger, more connected stone industry together!
            </p>
          </motion.div>
        </motion.div>

        <motion.form
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.4 }}
          onSubmit={handleSubmit}
          className="space-y-6 p-8 rounded-xl border-2 border-yellow-400/50 bg-gray-900/50 shadow-lg shadow-yellow-400/10"
        >
          <div className="grid md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <Label htmlFor="fullName" className="text-gray-300">Full Name</Label>
              <Input
                id="fullName"
                name="fullName"
                value={formData.fullName}
                onChange={handleChange}
                required
                className="bg-gray-900/50 border-yellow-400/30 text-white focus:border-yellow-400 focus:ring-yellow-400"
                placeholder="Full Name"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="companyName" className="text-gray-300">Company Name</Label>
              <Input
                id="companyName"
                name="companyName"
                value={formData.companyName}
                onChange={handleChange}
                required
                className="bg-gray-900/50 border-yellow-400/30 text-white focus:border-yellow-400 focus:ring-yellow-400"
                placeholder="Company Name"
              />
            </div>
          </div>

          <div className="grid md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <Label htmlFor="email" className="text-gray-300">Email Address</Label>
              <Input
                id="email"
                name="email"
                type="email"
                value={formData.email}
                onChange={handleChange}
                required
                className="bg-gray-900/50 border-yellow-400/30 text-white focus:border-yellow-400 focus:ring-yellow-400"
                placeholder="Email Address"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="phone" className="text-gray-300">Phone Number</Label>
              <Input
                id="phone"
                name="phone"
                type="tel"
                value={formData.phone}
                onChange={handleChange}
                required
                className="bg-gray-900/50 border-yellow-400/30 text-white focus:border-yellow-400 focus:ring-yellow-400"
                placeholder="Phone Number"
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="message" className="text-gray-300">Your Message</Label>
            <Textarea
              id="message"
              name="message"
              value={formData.message}
              onChange={handleChange}
              required
              rows={6}
              className="bg-gray-900/50 border-yellow-400/30 text-white focus:border-yellow-400 focus:ring-yellow-400 resize-none"
              placeholder="Your Message"
            />
          </div>

          <div className="text-center">
            <Button
              type="submit"
              size="lg"
              className="bg-yellow-400 hover:bg-yellow-500 text-black font-bold px-12 py-6 text-lg shadow-lg shadow-yellow-400/20 transition-all duration-300 transform hover:scale-105"
              disabled={loading}
            >
              {loading ? 'Submitting...' : 'Submit Application'}
            </Button>
          </div>
        </motion.form>
      </div>
    </section>
  );
};

export default ContactForm;