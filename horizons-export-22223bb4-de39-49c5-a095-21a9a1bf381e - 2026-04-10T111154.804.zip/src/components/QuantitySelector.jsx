
import React, { useState, useEffect } from "react";

export default function QuantitySelector({ 
  value, 
  onChange, 
  min = 1, 
  quantity, 
  onQuantityChange, 
  max, 
  disabled 
}) {
  const controlledValue = quantity ?? value ?? 1;
  const emitChange = onQuantityChange ?? onChange;
  
  const [qty, setQty] = useState(controlledValue);

  useEffect(() => {
    setQty(controlledValue);
  }, [controlledValue]);

  const set = (v) => {
    if (disabled) return;
    let n = parseInt(v, 10);
    if (isNaN(n)) n = min;
    n = Math.max(min, n);
    if (max !== undefined && max !== null) {
      n = Math.min(max, n);
    }
    console.log(`[QuantitySelector] changing from ${qty} to ${n}`);
    setQty(n);
    emitChange?.(n);
  };

  return (
    <div className={`inline-flex items-center rounded-xl overflow-hidden border border-zinc-800 bg-zinc-900 ${disabled ? 'opacity-50 pointer-events-none' : ''}`}>
      <button 
        onClick={() => set(qty - 1)} 
        disabled={disabled || qty <= min}
        className="px-3 py-2 hover:bg-zinc-800 text-zinc-300 hover:text-white disabled:opacity-50 disabled:cursor-not-allowed"
      >
        -
      </button>
      <input
        type="number"
        className="w-16 text-center bg-transparent outline-none py-2 text-white disabled:opacity-50"
        value={qty}
        min={min}
        max={max}
        disabled={disabled}
        onChange={(e) => set(e.target.value)}
      />
      <button 
        onClick={() => set(qty + 1)} 
        disabled={disabled || (max !== undefined && max !== null && qty >= max)}
        className="px-3 py-2 hover:bg-zinc-800 text-zinc-300 hover:text-white disabled:opacity-50 disabled:cursor-not-allowed"
      >
        +
      </button>
    </div>
  );
}
