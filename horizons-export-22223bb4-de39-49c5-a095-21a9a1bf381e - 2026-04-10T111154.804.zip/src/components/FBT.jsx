
import React, { useEffect, useMemo, useState } from "react";
import { getAllProducts, getProductById } from "@/lib/productsApi";
import { getProductImage } from "@/lib/imageUtils";
import { useCart } from "@/contexts/CartContext";
import { Loader2, AlertCircle } from "lucide-react";
import { useToast } from "@/components/ui/use-toast";

export default function FBT({ product: initialProduct, currentProductId, limit = 3 }) {
  const [product, setProduct] = useState(initialProduct);
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [checked, setChecked] = useState({});
  const { addItem } = useCart();
  const { toast } = useToast();

  // Resolve the main product to base recommendations on
  useEffect(() => {
    let mounted = true;

    async function resolveProduct() {
      const targetId = currentProductId || initialProduct?.id;

      if (!targetId) {
        if (mounted) setLoading(false);
        return;
      }

      if (initialProduct && initialProduct.category && initialProduct.vendor && initialProduct.price) {
        if (mounted) setProduct(initialProduct);
      } else {
        try {
          const { data, error } = await getProductById(targetId);
          if (error) throw error;
          
          if (mounted && data) {
            setProduct(data);
          }
        } catch (err) {
          console.error("FBT: Failed to resolve product details", err);
          if (mounted) setError("Could not load product details.");
        }
      }
    }

    resolveProduct();
    return () => { mounted = false; };
  }, [initialProduct, currentProductId]);

  // Fetch related items with fallback logic
  useEffect(() => {
    if (!product || !product.id) return;

    let mounted = true;
    setLoading(true);

    async function fetchRecommendations() {
      try {
        const { data: allProducts, error } = await getAllProducts(1000);
        if (error) throw error;

        let candidates = (allProducts || []).filter(p => String(p.id) !== String(product.id));

        // Prefer same category if available
        let categoryCandidates = candidates.filter(p => p.type === product.type || p.category === product.category);
        
        let finalCandidates = [];
        if (categoryCandidates.length >= limit) {
           finalCandidates = categoryCandidates.slice(0, limit);
        } else {
           // Use category ones, then fill remaining with other general products
           const seen = new Set(categoryCandidates.map(c => c.id));
           finalCandidates = [...categoryCandidates];
           
           for (const item of candidates) {
             if (!seen.has(item.id)) {
               finalCandidates.push(item);
               seen.add(item.id);
             }
             if (finalCandidates.length >= limit) break;
           }
        }

        if (!mounted) return;

        setItems(finalCandidates);
        
        // Initialize checked state
        const init = {};
        finalCandidates.forEach(p => init[p.id] = true);
        setChecked(init);

      } catch (err) {
        console.error("FBT: Error fetching recommendations", err);
        if (mounted) setError("Failed to load recommendations.");
      } finally {
        if (mounted) setLoading(false);
      }
    }
    
    fetchRecommendations();
    
    return () => { mounted = false; };
  }, [product, limit]);

  const total = useMemo(() => {
    if (!product) return 0;
    const currentPrice = Number(product.min_price || product.price || 0);
    const othersPrice = items.reduce((sum, it) => checked[it.id] ? sum + Number(it.min_price || it.price || 0) : sum, 0);
    return currentPrice + othersPrice;
  }, [checked, items, product]);

  const addSelected = () => {
    if (!product) return;
    
    addItem(product);
    
    items.forEach(it => {
      if (checked[it.id]) {
        addItem(it);
      }
    });

    toast({
      title: "Bundle added to cart",
      description: "Selected items have been added to your cart.",
    });
  };

  if (loading) {
    return (
      <div className="mt-8 p-8 rounded-2xl bg-zinc-900 border border-zinc-800 flex justify-center">
        <Loader2 className="animate-spin text-zinc-500" />
      </div>
    );
  }

  if (error) {
     return (
       <div className="mt-8 p-4 md:p-6 rounded-2xl bg-zinc-900 border border-zinc-800 flex items-center justify-center text-zinc-400 gap-2">
         <AlertCircle className="w-5 h-5 text-red-400" />
         <span>{error}</span>
       </div>
     );
  }

  if (!product || items.length === 0) return null;

  return (
    <div className="mt-8 p-4 md:p-6 rounded-2xl bg-zinc-900 border border-zinc-800">
      <h3 className="text-zinc-100 font-semibold mb-6 text-lg">Frequently Bought Together</h3>

      <div className="flex flex-col md:flex-row gap-6 items-center md:items-start">
        {/* Main Product */}
        <div className="shrink-0">
            <Card it={product} checked readOnly />
        </div>

        <div className="text-3xl text-zinc-600 font-light hidden md:block mt-12">+</div>
        <div className="text-3xl text-zinc-600 font-light md:hidden">+</div>

        {/* Suggested Items */}
        <div className="flex flex-wrap justify-center md:justify-start gap-4 flex-1">
          {items.map(it => (
            <Card
              key={it.id}
              it={it}
              checked={!!checked[it.id]}
              onToggle={() => setChecked(prev => ({ ...prev, [it.id]: !prev[it.id] }))}
            />
          ))}
        </div>
        
        {/* Total & Action */}
        <div className="w-full md:w-auto md:ml-auto flex flex-col items-center md:items-end gap-3 min-w-[200px] border-t md:border-t-0 border-zinc-800 pt-6 md:pt-0 mt-2 md:mt-0">
            <div className="text-zinc-400 text-sm">Total price:</div>
            <div className="text-2xl text-white font-bold">${total.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</div>
            <button 
                onClick={addSelected} 
                className="w-full md:w-auto px-6 py-3 rounded-xl bg-yellow-500 text-black font-bold hover:bg-yellow-400 transition-colors shadow-lg hover:shadow-yellow-500/20"
            >
            Add Selected
            </button>
        </div>
      </div>
    </div>
  );
}

function Card({ it, checked = false, onToggle, readOnly = false }) {
  const img = getProductImage(it);
  const price = Number(it.min_price || it.price || 0);
  
  return (
    <div className={`w-40 md:w-48 p-3 rounded-xl border transition-all duration-200 ${checked ? 'bg-zinc-950 border-zinc-700 shadow-md' : 'bg-zinc-900/50 border-zinc-800 opacity-70'}`}>
      {!readOnly && (
        <label className="flex items-center gap-2 text-sm mb-3 cursor-pointer select-none">
          <div className={`w-5 h-5 rounded border flex items-center justify-center transition-colors ${checked ? 'bg-yellow-500 border-yellow-500 text-black' : 'border-zinc-600 bg-transparent'}`}>
             {checked && <svg width="12" height="12" viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M10 3L4.5 8.5L2 6" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/></svg>}
          </div>
          <input type="checkbox" checked={checked} onChange={onToggle} className="hidden" />
          <span className={checked ? "text-zinc-200" : "text-zinc-500"}>Include</span>
        </label>
      )}
      {readOnly && (
         <div className="mb-3 text-sm text-zinc-400 flex items-center gap-2">
            <div className="w-5 h-5 rounded-full bg-zinc-800 border border-zinc-700 flex items-center justify-center text-[10px] text-zinc-400">✓</div>
            <span>This Item</span>
         </div>
      )}
      
      <div className="aspect-square rounded-lg overflow-hidden bg-zinc-800 mb-3 relative group">
        {img ? (
            <img 
                src={img} 
                alt={it.title} 
                className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110" 
                onError={(e) => {
                    e.target.style.display = 'none';
                    e.target.nextSibling.style.display = 'flex';
                }}
            />
        ) : null}
        <div className="absolute inset-0 flex items-center justify-center bg-zinc-800 text-zinc-600 hidden">
             No Image
        </div>
      </div>
      
      <div className="text-sm font-medium text-zinc-100 line-clamp-2 h-10 leading-tight" title={it.title}>{it.title}</div>
      <div className="text-sm font-bold text-yellow-500 mt-2">${price.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</div>
    </div>
  );
}
