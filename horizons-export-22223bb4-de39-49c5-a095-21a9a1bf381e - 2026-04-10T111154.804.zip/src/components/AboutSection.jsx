import React from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';

const AboutSection = () => {
  return (
    <section className="section-bg py-24">
      <div className="max-w-screen-xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid md:grid-cols-2 gap-16 items-center">
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold text-white mb-6">
              About <span className="text-yellow-400">Coop Stones</span>
            </h2>
            <p className="text-gray-300 text-lg mb-6 leading-relaxed">
              Coop Stones is an exclusive cooperative built by and for stone industry
              experts. We unite fabricators, installers, and suppliers, creating a powerful
              network to share resources, negotiate superior pricing on materials and
              tools, and unlock new revenue streams.
            </p>
            <p className="text-gray-300 text-lg mb-8 leading-relaxed">
              Our model ensures that members benefit directly from our collective success, all
              while upholding the highest standards of quality and ethics.
            </p>
            <Link to="/about">
              <Button 
                size="lg"
                variant="outline"
                className="border-2 border-yellow-400/80 text-yellow-400 hover:bg-yellow-400 hover:text-black font-bold px-8 py-6 text-lg transition-all duration-300 transform hover:scale-105"
              >
                Learn More About Us
              </Button>
            </Link>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="relative"
          >
            <div className="aspect-w-4 aspect-h-3 rounded-lg overflow-hidden shadow-2xl shadow-yellow-400/10">
              <img 
                className="w-full h-full object-cover" 
                alt="Handshake over a contract, representing partnership and growth at Coop Stones"
                src="https://horizons-cdn.hostinger.com/22223bb4-de39-49c5-a095-21a9a1bf381e/06dd8bd32d015382b64fc9b53e7117b7.png" />
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default AboutSection;