import React, { useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { CheckCircle, AlertCircle, X } from 'lucide-react';
import { cn } from '@/lib/utils';

const icons = {
  success: CheckCircle,
  error: AlertCircle,
  warning: AlertCircle,
  info: AlertCircle
};

const styles = {
  success: "bg-green-950/90 border-green-500 text-green-100",
  error: "bg-red-950/90 border-red-500 text-red-100",
  warning: "bg-yellow-950/90 border-yellow-500 text-yellow-100",
  info: "bg-blue-950/90 border-blue-500 text-blue-100"
};

export default function Toast({ toast, onClose, duration = 5000 }) {
  useEffect(() => {
    if (toast && duration > 0) {
      const timer = setTimeout(onClose, duration);
      return () => clearTimeout(timer);
    }
  }, [toast, duration, onClose]);

  if (!toast) return null;

  const { type = 'info', message } = toast;
  const Icon = icons[type] || icons.info;

  return (
    <div className="fixed top-4 right-4 z-50 flex flex-col gap-2 pointer-events-none">
      <AnimatePresence>
        <motion.div
          key="toast-message"
          initial={{ opacity: 0, x: 50 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: 50 }}
          transition={{ duration: 0.3, ease: "easeOut" }}
          className={cn(
            "pointer-events-auto flex items-center gap-3 px-4 py-3 rounded-lg shadow-xl border backdrop-blur-md min-w-[320px] max-w-md",
            styles[type]
          )}
        >
          <Icon className="w-5 h-5 flex-shrink-0" />
          <p className="flex-1 text-sm font-medium leading-tight">{message}</p>
          <button 
            onClick={onClose} 
            className="p-1 hover:bg-white/10 rounded-full transition-colors flex-shrink-0"
            aria-label="Close notification"
          >
            <X className="w-4 h-4" />
          </button>
        </motion.div>
      </AnimatePresence>
    </div>
  );
}