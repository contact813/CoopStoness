import React from 'react';
import { Truck, Package, Phone, BadgeCheck } from "lucide-react";

const Item = ({ icon: Icon, title, subtitle }) => (
  <div className="flex items-center gap-3 px-4 py-3 rounded-xl bg-zinc-900 border border-zinc-800">
    <div className="p-2 rounded-lg bg-zinc-800"><Icon size={18} /></div>
    <div>
      <div className="text-zinc-100 text-sm font-medium">{title}</div>
      {subtitle && <div className="text-[12px] text-zinc-400">{subtitle}</div>}
    </div>
  </div>
);

export default function FeatureBar() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3">
      <Item icon={Truck} title="Delivered to Your Door" subtitle="Domestic & International" />
      <Item icon={Package} title="10,000+ Products" subtitle="Purchased per month" />
      <Item icon={Phone} title="Contact Us" subtitle="+1 (561) 555-7487 • sales@onpoint.plus" />
      <Item icon={BadgeCheck} title="100+ Brands" subtitle="Popular • Trusted Brands" />
    </div>
  );
}