import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { supabase } from '@/lib/supabaseClient';
import { Button } from '@/components/ui/button';
import { FileImage as ImageIcon } from 'lucide-react';

const BlogPreview = () => {
  const [posts, setPosts] = useState([]);

  useEffect(() => {
    const fetchPosts = async () => {
      // Use the public view to fetch only published posts
      const { data, error } = await supabase
        .from('v_posts_public')
        .select('slug, title, description, cover_url')
        .order('published_at', { ascending: false })
        .limit(3);

      if (error) {
        console.error('Error fetching posts:', error);
      } else {
        setPosts(data);
      }
    };

    fetchPosts();
  }, []);

  return (
    <section className="section-bg py-24">
      <div className="max-w-screen-xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold text-white mb-4">
            From Our <span className="text-yellow-400">Blog</span>
          </h2>
          <p className="text-gray-400 text-lg max-w-2xl mx-auto">
            Stay updated with the latest industry news, business tips, and technology insights.
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {posts.map((post, index) => (
            <motion.div
              key={post.slug}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
            >
              <Link to={`/blog/${post.slug}`} className="bg-gray-900/50 rounded-xl overflow-hidden group block border border-yellow-400/20 hover:border-yellow-400/60 transition-all duration-300 backdrop-blur-sm h-full flex flex-col">
                <div className="relative h-56 overflow-hidden bg-zinc-800 flex items-center justify-center">
                  {post.cover_url ? (
                    <img className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" alt={post.title} src={post.cover_url} />
                  ) : (
                    <ImageIcon className="w-12 h-12 text-zinc-500" />
                  )}
                </div>
                <div className="p-6 flex flex-col flex-grow">
                  <h3 className="text-xl font-bold text-white mb-3 group-hover:text-yellow-400 transition-colors flex-grow">
                    {post.title}
                  </h3>
                  <p className="text-gray-400 text-sm leading-relaxed line-clamp-3">
                    {post.description}
                  </p>
                </div>
              </Link>
            </motion.div>
          ))}
        </div>
        
        <motion.div 
          className="text-center mt-16"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.3 }}
        >
          <Link to="/blog">
            <Button
              size="lg"
              className="bg-yellow-400 hover:bg-yellow-500 text-black font-bold px-10 py-6 text-lg shadow-lg shadow-yellow-400/20 transition-all duration-300 transform hover:scale-105"
            >
              Visit Our Blog
            </Button>
          </Link>
        </motion.div>
      </div>
    </section>
  );
};

export default BlogPreview;