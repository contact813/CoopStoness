import React, { useState, useEffect } from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { ScrollArea } from "@/components/ui/scroll-area";

// --- Edit Price Modal ---
export function EditPriceModal({ open, onOpenChange, onConfirm, selectedVariants = [] }) {
  const [values, setValues] = useState({});

  useEffect(() => {
    if (open) {
      // Initialize with current values
      const initial = {};
      selectedVariants.forEach(v => {
        initial[v.id] = v.price;
      });
      setValues(initial);
    }
  }, [open, selectedVariants]);

  const handleChange = (id, val) => {
    setValues(prev => ({ ...prev, [id]: val }));
  };

  const handleConfirm = () => {
    onConfirm(values);
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[500px] bg-zinc-900 border-zinc-800 text-white max-h-[85vh] flex flex-col">
        <DialogHeader>
          <DialogTitle>Edit Prices</DialogTitle>
        </DialogHeader>
        <div className="py-2 flex-1 overflow-hidden flex flex-col">
          <p className="text-zinc-400 text-sm mb-4">Editing prices for {selectedVariants.length} variants</p>
          <ScrollArea className="flex-1 pr-4 -mr-4">
            <div className="space-y-4 pb-4">
              {selectedVariants.map((variant) => (
                <div key={variant.id} className="grid gap-2">
                  <Label className="text-xs text-zinc-300 font-medium truncate">
                    {variant.title}
                  </Label>
                  <div className="relative">
                    <span className="absolute left-3 top-2.5 text-zinc-500">$</span>
                    <Input 
                      type="number" 
                      min="0"
                      step="0.01"
                      placeholder="0.00"
                      value={values[variant.id] ?? ''}
                      onChange={(e) => handleChange(variant.id, e.target.value)}
                      className="pl-8 bg-zinc-950 border-zinc-700 focus:border-yellow-500/50"
                    />
                  </div>
                </div>
              ))}
            </div>
          </ScrollArea>
        </div>
        <DialogFooter className="mt-4">
          <Button variant="outline" onClick={() => onOpenChange(false)} className="border-zinc-700 text-zinc-300 hover:bg-zinc-800 hover:text-white">Cancel</Button>
          <Button onClick={handleConfirm} className="bg-yellow-500 text-black hover:bg-yellow-400 font-medium">Apply Changes</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// --- Edit Inventory Modal ---
export function EditInventoryModal({ open, onOpenChange, onConfirm, selectedVariants = [] }) {
  const [values, setValues] = useState({});

  useEffect(() => {
    if (open) {
      const initial = {};
      selectedVariants.forEach(v => {
        initial[v.id] = v.inventory_qty;
      });
      setValues(initial);
    }
  }, [open, selectedVariants]);

  const handleChange = (id, val) => {
    setValues(prev => ({ ...prev, [id]: val }));
  };

  const handleConfirm = () => {
    onConfirm(values);
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[500px] bg-zinc-900 border-zinc-800 text-white max-h-[85vh] flex flex-col">
        <DialogHeader>
          <DialogTitle>Edit Inventory</DialogTitle>
        </DialogHeader>
        <div className="py-2 flex-1 overflow-hidden flex flex-col">
          <p className="text-zinc-400 text-sm mb-4">Editing inventory for {selectedVariants.length} variants</p>
          <ScrollArea className="flex-1 pr-4 -mr-4">
            <div className="space-y-4 pb-4">
              {selectedVariants.map((variant) => (
                <div key={variant.id} className="grid gap-2">
                  <Label className="text-xs text-zinc-300 font-medium truncate">
                    {variant.title}
                  </Label>
                  <Input 
                    type="number" 
                    min="0"
                    step="1"
                    placeholder="0"
                    value={values[variant.id] ?? ''}
                    onChange={(e) => handleChange(variant.id, e.target.value)}
                    className="bg-zinc-950 border-zinc-700 focus:border-yellow-500/50"
                  />
                </div>
              ))}
            </div>
          </ScrollArea>
        </div>
        <DialogFooter className="mt-4">
          <Button variant="outline" onClick={() => onOpenChange(false)} className="border-zinc-700 text-zinc-300 hover:bg-zinc-800 hover:text-white">Cancel</Button>
          <Button onClick={handleConfirm} className="bg-yellow-500 text-black hover:bg-yellow-400 font-medium">Apply Changes</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// --- Edit SKU Modal ---
export function EditSKUModal({ open, onOpenChange, onConfirm, selectedVariants = [] }) {
    const [values, setValues] = useState({});
  
    useEffect(() => {
      if (open) {
        const initial = {};
        selectedVariants.forEach(v => {
          initial[v.id] = v.sku || '';
        });
        setValues(initial);
      }
    }, [open, selectedVariants]);
  
    const handleChange = (id, val) => {
      setValues(prev => ({ ...prev, [id]: val }));
    };
  
    const handleConfirm = () => {
      onConfirm(values);
      onOpenChange(false);
    };
  
    return (
      <Dialog open={open} onOpenChange={onOpenChange}>
        <DialogContent className="sm:max-w-[500px] bg-zinc-900 border-zinc-800 text-white max-h-[85vh] flex flex-col">
          <DialogHeader>
            <DialogTitle>Edit SKUs</DialogTitle>
          </DialogHeader>
          <div className="py-2 flex-1 overflow-hidden flex flex-col">
            <p className="text-zinc-400 text-sm mb-4">Editing SKUs for {selectedVariants.length} variants</p>
            <ScrollArea className="flex-1 pr-4 -mr-4">
              <div className="space-y-4 pb-4">
                {selectedVariants.map((variant) => (
                  <div key={variant.id} className="grid gap-2">
                    <Label className="text-xs text-zinc-300 font-medium truncate">
                      {variant.title}
                    </Label>
                    <Input 
                      type="text"
                      placeholder="e.g. PRODUCT-SKU-001"
                      value={values[variant.id] ?? ''}
                      onChange={(e) => handleChange(variant.id, e.target.value)}
                      className="bg-zinc-950 border-zinc-700 focus:border-yellow-500/50"
                    />
                  </div>
                ))}
              </div>
            </ScrollArea>
          </div>
          <DialogFooter className="mt-4">
            <Button variant="outline" onClick={() => onOpenChange(false)} className="border-zinc-700 text-zinc-300 hover:bg-zinc-800 hover:text-white">Cancel</Button>
            <Button onClick={handleConfirm} className="bg-yellow-500 text-black hover:bg-yellow-400 font-medium">Apply Changes</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    );
}

// --- Bulk Delete Modal (Kept for compatibility) ---
export function BulkDeleteVariantsModal({ open, onOpenChange, onConfirm, count }) {
    return (
      <Dialog open={open} onOpenChange={onOpenChange}>
        <DialogContent className="sm:max-w-[425px] bg-zinc-900 border-zinc-800 text-white">
          <DialogHeader>
            <DialogTitle>Delete variants?</DialogTitle>
          </DialogHeader>
          <div className="py-4 text-zinc-300">
             Are you sure you want to delete {count} variants? This action cannot be undone.
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => onOpenChange(false)} className="border-zinc-700 text-zinc-300 hover:bg-zinc-800 hover:text-white">Cancel</Button>
            <Button onClick={() => { onConfirm(); onOpenChange(false); }} className="bg-red-600 text-white hover:bg-red-700">Delete variants</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    );
}