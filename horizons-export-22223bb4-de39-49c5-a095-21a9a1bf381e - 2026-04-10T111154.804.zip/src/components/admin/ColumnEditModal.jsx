import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/components/ui/use-toast";
import { Loader2, Trash2 } from "lucide-react";
import { supabase } from '@/lib/supabaseClient';
import { isDefaultColumn, normalizeColumnName, canDeleteColumn } from "@/lib/membershipStatusUtils";

export default function ColumnEditModal({ isOpen, onClose, column, onSaved, applications = [] }) {
  const [name, setName] = useState("");
  const [saving, setSaving] = useState(false);
  const [deleting, setDeleting] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    if (column) {
      setName(column.name);
    }
  }, [column]);

  if (!column) return null;

  const isDefault = isDefaultColumn(column.name);
  const disableNameEdit = isDefault;

  const handleSave = async () => {
    if (!name.trim()) return;
    const normalizedName = normalizeColumnName(name);

    setSaving(true);
    try {
      const { error } = await supabase
        .from('crm_columns')
        .update({ name: normalizedName })
        .eq('id', column.id);

      if (error) throw error;
      toast({ title: "Success", description: "Column updated successfully." });
      onSaved();
    } catch (error) {
      toast({ variant: "destructive", title: "Error", description: error.message });
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async () => {
    if (!canDeleteColumn(column, applications)) {
      toast({ variant: "destructive", title: "Cannot delete", description: "Column contains applications or is a default column." });
      return;
    }

    if (!confirm(`Are you sure you want to delete "${column.name}"?`)) return;

    setDeleting(true);
    try {
      const { error } = await supabase
        .from('crm_columns')
        .delete()
        .eq('id', column.id);

      if (error) throw error;
      toast({ title: "Deleted", description: "Column deleted successfully." });
      onSaved();
    } catch (error) {
      toast({ variant: "destructive", title: "Error", description: error.message });
    } finally {
      setDeleting(false);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="bg-zinc-950 border-zinc-800 text-white">
        <DialogHeader>
          <DialogTitle>Edit Column</DialogTitle>
          <DialogDescription>Modify settings for this pipeline column.</DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-4">
          <div className="space-y-2">
            <Label>Column Name</Label>
            <Input
              value={name}
              onChange={(e) => setName(e.target.value)}
              disabled={disableNameEdit || saving || deleting}
              className="bg-zinc-900 border-zinc-800 text-white uppercase"
            />
            {disableNameEdit && (
              <p className="text-xs text-zinc-500">Default columns cannot be renamed.</p>
            )}
          </div>
        </div>

        <DialogFooter className="flex justify-between items-center sm:justify-between">
          {!isDefault ? (
            <Button
              variant="destructive"
              onClick={handleDelete}
              disabled={saving || deleting || !canDeleteColumn(column, applications)}
              className="bg-red-500/10 text-red-500 hover:bg-red-500/20"
            >
              {deleting ? <Loader2 className="w-4 h-4 animate-spin" /> : <Trash2 className="w-4 h-4 mr-2" />}
              Delete Column
            </Button>
          ) : (
            <div />
          )}
          
          <div className="flex gap-2">
            <Button variant="ghost" onClick={onClose} disabled={saving || deleting}>
              Cancel
            </Button>
            <Button
              className="bg-yellow-500 text-black hover:bg-yellow-400"
              onClick={handleSave}
              disabled={saving || deleting || disableNameEdit || name.trim() === column.name}
            >
              {saving ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : null}
              Save Changes
            </Button>
          </div>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}