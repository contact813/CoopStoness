
import React, { useState, useEffect } from 'react';
import { Check, ChevronsUpDown, Plus } from 'lucide-react';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from '@/components/ui/popover';
import { getUniqueVendors } from '@/lib/adminProductsApi';

export default function VendorCombobox({ value, onChange, options = [], className }) {
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState('');
  const [internalOptions, setInternalOptions] = useState([]);

  useEffect(() => {
    async function loadVendors() {
        if (options && options.length > 0) return;
        console.log('[VendorCombobox] Loading vendors');
        try {
            const vendors = await getUniqueVendors();
            const vendorList = Array.isArray(vendors) ? vendors.map(v => typeof v === 'object' ? v.value : v) : [];
            setInternalOptions(vendorList);
            console.log('[VendorCombobox] Loaded vendors:', vendorList.length);
        } catch (err) {
            console.error('[VendorCombobox] Exception:', err);
            setInternalOptions([]);
        }
    }
    loadVendors();
  }, [options]);
  
  const displayOptions = options && options.length > 0 ? options.map(o => typeof o === 'object' ? o.value : o) : internalOptions;
  const safeOptions = Array.isArray(displayOptions) ? displayOptions : [];
  
  const filteredOptions = query === '' 
    ? safeOptions 
    : safeOptions.filter((opt) => opt && opt.toLowerCase().includes(query.toLowerCase()));

  const showCreate = query !== '' && !safeOptions.some(opt => opt && opt.toLowerCase() === query.toLowerCase());

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <Button
          variant="outline"
          role="combobox"
          aria-expanded={open}
          className={cn("w-full justify-between bg-zinc-950 border-white/10 text-white hover:bg-zinc-900", className)}
        >
          {value || "Select vendor..."}
          <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-[300px] p-0 bg-zinc-950 border-white/10 shadow-2xl">
         <div className="flex flex-col">
            <input
              className="px-3 py-2 bg-transparent border-b border-white/10 text-white placeholder:text-zinc-500 text-sm outline-none"
              placeholder="Search vendor..."
              value={query}
              onChange={(e) => setQuery(e.target.value)}
            />
            <div className="max-h-[200px] overflow-y-auto p-1">
                {filteredOptions.length === 0 && !showCreate && (
                    <div className="py-6 text-center text-sm text-zinc-500">No vendor found.</div>
                )}
                {filteredOptions.map((option) => (
                    <div
                        key={option}
                        className={cn(
                            "flex items-center px-2 py-1.5 text-sm rounded cursor-pointer hover:bg-white/10 transition-colors",
                            value === option ? "text-white bg-white/5" : "text-zinc-400"
                        )}
                        onClick={() => {
                            onChange(option === value ? "" : option);
                            setOpen(false);
                        }}
                    >
                        <Check className={cn("mr-2 h-4 w-4", value === option ? "opacity-100" : "opacity-0")} />
                        {option}
                    </div>
                ))}
                
                {showCreate && (
                    <div 
                        className="flex items-center px-2 py-1.5 text-sm rounded cursor-pointer hover:bg-yellow-500/10 text-yellow-500 transition-colors mt-1 border-t border-white/5"
                        onClick={() => {
                            onChange(query);
                            setOpen(false);
                        }}
                    >
                        <Plus className="mr-2 h-4 w-4" />
                        Create "{query}"
                    </div>
                )}
            </div>
         </div>
      </PopoverContent>
    </Popover>
  );
}
