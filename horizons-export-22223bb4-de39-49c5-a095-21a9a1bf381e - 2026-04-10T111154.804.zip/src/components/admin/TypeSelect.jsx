import React, { useEffect, useState } from 'react';
import { getUniqueTypes } from '@/lib/adminProductsApi';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Loader2 } from "lucide-react";

export default function TypeSelect({ value, onChange, className }) {
  const [types, setTypes] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    getUniqueTypes()
      .then(data => setTypes(data))
      .catch(err => console.error("Failed to load types", err))
      .finally(() => setLoading(false));
  }, []);

  if (loading) {
    return (
      <div className="flex items-center gap-2 h-10 w-full rounded-md border border-zinc-800 bg-zinc-950 px-3 text-sm text-zinc-500">
        <Loader2 className="h-4 w-4 animate-spin" />
        Loading types...
      </div>
    );
  }

  if (types.length === 0) {
    return (
      <Input 
        value={value || ''} 
        onChange={(e) => onChange(e.target.value)} 
        placeholder="Enter product type"
        className={className}
      />
    );
  }

  const displayTypes = value && !types.includes(value) 
    ? [...types, value].sort() 
    : types;

  return (
    <Select value={value || ''} onValueChange={onChange}>
      <SelectTrigger className={className}>
        <SelectValue placeholder="Select type" />
      </SelectTrigger>
      <SelectContent>
          {displayTypes.map((t) => (
            <SelectItem key={t} value={t}>{t}</SelectItem>
          ))}
      </SelectContent>
    </Select>
  );
}