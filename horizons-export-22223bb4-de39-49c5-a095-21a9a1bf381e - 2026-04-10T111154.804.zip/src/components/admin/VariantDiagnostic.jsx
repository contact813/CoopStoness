
import React, { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabaseClient';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { Loader2, AlertCircle } from 'lucide-react';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';

export default function VariantDiagnostic() {
  const [products, setProducts] = useState([]);
  const [loadingProducts, setLoadingProducts] = useState(true);
  
  const [product1Id, setProduct1Id] = useState(null);
  const [product2Id, setProduct2Id] = useState(null);
  
  const [data1, setData1] = useState(null);
  const [data2, setData2] = useState(null);
  const [loadingData, setLoadingData] = useState(false);
  const [error, setError] = useState(null);

  useEffect(() => {
    async function loadProducts() {
      try {
        const { data, error } = await supabase
          .from('products')
          .select('id, title, vendor')
          .order('title');
        
        if (error) throw error;
        setProducts(data || []);
      } catch (err) {
        console.error("Failed to load products for diagnostic", err);
        setError("Failed to load products list");
      } finally {
        setLoadingProducts(false);
      }
    }
    loadProducts();
  }, []);

  const fetchDiagnosticData = async (productId) => {
    if (!productId) return null;
    
    try {
      const [productRes, variantsRes] = await Promise.all([
        supabase.from('products').select('*').eq('id', productId).single(),
        supabase.from('product_variants').select('*').eq('product_id', productId)
      ]);

      return {
        product: productRes.data,
        variants: variantsRes.data || [],
        queries: {
          product: `SELECT * FROM products WHERE id = ${productId};`,
          variants: `SELECT * FROM product_variants WHERE product_id = ${productId};`
        }
      };
    } catch (err) {
      console.error(`Error fetching data for ${productId}:`, err);
      return { error: err.message };
    }
  };

  const handleCompare = async () => {
    if (!product1Id || !product2Id) {
        setError("Please select both products to compare");
        return;
    }
    
    setLoadingData(true);
    setError(null);
    
    try {
        const [d1, d2] = await Promise.all([
            fetchDiagnosticData(product1Id),
            fetchDiagnosticData(product2Id)
        ]);
        
        setData1(d1);
        setData2(d2);
    } catch (err) {
        setError(err.message);
    } finally {
        setLoadingData(false);
    }
  };

  const renderProductData = (data, title) => {
    if (!data) return null;
    if (data.error) return <Alert variant="destructive"><AlertTitle>Error</AlertTitle><AlertDescription>{data.error}</AlertDescription></Alert>;

    return (
      <div className="space-y-4">
        <h3 className="text-xl font-bold text-yellow-500 border-b border-zinc-800 pb-2">{title} - {data.product?.title}</h3>
        
        <div className="bg-zinc-950 p-4 rounded border border-zinc-800">
            <h4 className="font-semibold text-zinc-300 mb-2">Product Table (id: {data.product?.id})</h4>
            <div className="text-xs text-zinc-400 font-mono bg-black p-2 rounded mb-2">{data.queries.product}</div>
            <pre className="text-xs text-zinc-300 overflow-x-auto">
                {JSON.stringify({
                    id: data.product?.id,
                    type: typeof data.product?.id,
                    status: data.product?.status,
                    inventory: data.product?.inventory
                }, null, 2)}
            </pre>
        </div>

        <div className="bg-zinc-950 p-4 rounded border border-zinc-800">
            <h4 className="font-semibold text-zinc-300 mb-2">Product Variants ({data.variants.length} found)</h4>
            <div className="text-xs text-zinc-400 font-mono bg-black p-2 rounded mb-2">{data.queries.variants}</div>
            {data.variants.length > 0 ? (
                <div className="space-y-2">
                    {data.variants.map((v, i) => (
                        <div key={v.id} className="text-xs bg-black p-2 rounded border border-zinc-800">
                            <span className="font-bold text-white">#{i+1} {v.title}</span><br/>
                            ID: {v.id} <br/>
                            Product ID: {v.product_id} (Type: {typeof v.product_id})<br/>
                            Active: {String(v.is_active)} | Price: {v.price} | Qty: {v.inventory_qty}
                        </div>
                    ))}
                </div>
            ) : (
                <p className="text-sm text-red-400">No variants found in database for this product_id.</p>
            )}
        </div>
      </div>
    );
  };

  return (
    <div className="p-6 max-w-7xl mx-auto space-y-6">
      <Card className="bg-zinc-900 border-zinc-800">
        <CardHeader>
          <CardTitle className="text-2xl text-white flex items-center gap-2">
            <AlertCircle className="text-yellow-500" />
            Variant Loading Diagnostic Tool
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                    <label className="text-sm font-medium text-zinc-400">Working Product (e.g. K BOND)</label>
                    <Select value={product1Id || ''} onValueChange={setProduct1Id} disabled={loadingProducts}>
                        <SelectTrigger className="bg-zinc-950 border-zinc-800 text-white">
                            <SelectValue placeholder={loadingProducts ? "Loading..." : "Select Product"} />
                        </SelectTrigger>
                        <SelectContent className="bg-zinc-900 border-zinc-800">
                            {products.map(p => (
                                <SelectItem key={p.id} value={String(p.id)} className="text-white">{p.title} ({p.id})</SelectItem>
                            ))}
                        </SelectContent>
                    </Select>
                </div>

                <div className="space-y-2">
                    <label className="text-sm font-medium text-zinc-400">Problematic Product (e.g. CYCLONE S)</label>
                    <Select value={product2Id || ''} onValueChange={setProduct2Id} disabled={loadingProducts}>
                        <SelectTrigger className="bg-zinc-950 border-zinc-800 text-white">
                            <SelectValue placeholder={loadingProducts ? "Loading..." : "Select Product"} />
                        </SelectTrigger>
                        <SelectContent className="bg-zinc-900 border-zinc-800">
                            {products.map(p => (
                                <SelectItem key={p.id} value={String(p.id)} className="text-white">{p.title} ({p.id})</SelectItem>
                            ))}
                        </SelectContent>
                    </Select>
                </div>
            </div>
            
            {error && (
                <Alert variant="destructive" className="bg-red-900/20 border-red-900/50 text-red-200">
                    <AlertTitle>Error</AlertTitle>
                    <AlertDescription>{error}</AlertDescription>
                </Alert>
            )}

            <Button 
                onClick={handleCompare} 
                disabled={loadingData || !product1Id || !product2Id}
                className="w-full bg-yellow-500 text-black hover:bg-yellow-400 font-bold"
            >
                {loadingData ? <Loader2 className="animate-spin mr-2" /> : null}
                Run Diagnostic Comparison
            </Button>
        </CardContent>
      </Card>

      {(data1 || data2) && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card className="bg-zinc-900 border-zinc-800">
                <CardContent className="pt-6">
                    {renderProductData(data1, "Working Reference")}
                </CardContent>
            </Card>
            <Card className="bg-zinc-900 border-zinc-800">
                <CardContent className="pt-6">
                    {renderProductData(data2, "Problematic Product")}
                </CardContent>
            </Card>
        </div>
      )}
    </div>
  );
}
