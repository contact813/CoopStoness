import React from 'react';
import { Button } from '@/components/ui/button';
import { AlertCircle, RefreshCw, ArrowLeft } from 'lucide-react';
import { Alert, AlertTitle, AlertDescription } from '@/components/ui/alert';

class AdminErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, error: null, errorInfo: null };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true, error };
  }

  componentDidCatch(error, errorInfo) {
    console.error("Uncaught error in Admin Boundary:", error, errorInfo);
    this.setState({ errorInfo });
  }

  handleRetry = () => {
    this.setState({ hasError: false, error: null, errorInfo: null });
    window.location.reload();
  };

  handleBack = () => {
    // Basic history back, or redirect to dashboard if history is empty/unsafe
    if (window.history.length > 1) {
      window.history.back();
    } else {
      window.location.href = '/admin';
    }
  };

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-[50vh] flex flex-col items-center justify-center p-6 text-center">
          <div className="max-w-xl w-full space-y-6">
            <Alert variant="destructive" className="border-red-900 bg-red-950/20 text-left">
              <AlertCircle className="h-5 w-5 text-red-500" />
              <AlertTitle className="text-xl font-bold text-red-400 ml-2">Something went wrong</AlertTitle>
              <AlertDescription className="mt-2 text-red-200">
                An unexpected error occurred in the admin panel.
                <div className="mt-2 p-2 bg-black/40 rounded text-xs font-mono text-red-300 overflow-auto max-h-32">
                  {this.state.error && this.state.error.toString()}
                </div>
              </AlertDescription>
            </Alert>

            <div className="flex items-center justify-center gap-4">
              <Button variant="outline" onClick={this.handleBack}>
                <ArrowLeft className="w-4 h-4 mr-2" />
                Go Back
              </Button>
              <Button onClick={this.handleRetry} className="bg-red-600 hover:bg-red-700 text-white">
                <RefreshCw className="w-4 h-4 mr-2" />
                Reload Page
              </Button>
            </div>

            {import.meta.env.MODE === 'development' && this.state.errorInfo && (
              <div className="mt-8 text-left">
                <h3 className="text-sm font-bold text-zinc-500 mb-2">Stack Trace (Dev Only)</h3>
                <pre className="bg-zinc-950 p-4 rounded text-xs text-zinc-600 overflow-auto max-h-96">
                  {this.state.errorInfo.componentStack}
                </pre>
              </div>
            )}
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}

export default AdminErrorBoundary;