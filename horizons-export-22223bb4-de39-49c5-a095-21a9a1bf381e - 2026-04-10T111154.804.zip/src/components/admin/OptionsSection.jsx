import React, { useState } from 'react';
import { Plus, Trash2, GripVertical, ChevronDown } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Label } from '@/components/ui/label';
import { useToast } from '@/components/ui/use-toast';
import { generateVariantCombinations } from '@/lib/variants/generateVariants';

export default function OptionsSection({ options, variants, onOptionsChange, onVariantsChange }) {
  const { toast } = useToast();
  const [newOptionValue, setNewOptionValue] = useState({});
  const [expandedOptions, setExpandedOptions] = useState(new Set());

  // Handlers
  const toggleExpand = (index) => {
    const next = new Set(expandedOptions);
    if (next.has(index)) next.delete(index);
    else next.add(index);
    setExpandedOptions(next);
  };

  const handleAddOption = (e) => {
    e.preventDefault(); // Prevent form submission
    if (options.length >= 3) return;
    
    // Ensure we create a unique default name to avoid collision in UI before rename
    const nextNum = options.length + 1;
    let defaultName = `Option ${nextNum}`;
    
    // Simple check to avoid name collision in UI
    while (options.some(o => o.name === defaultName)) {
        defaultName += ' Copy';
    }

    const newIndex = options.length;
    // Ensure structure matches DB expectation: { name, values: [], position } (id is temp)
    const newOpts = [...options, { 
        id: `temp-${Date.now()}`, 
        name: defaultName, 
        values: [],
        position: newIndex 
    }];
    
    onOptionsChange(newOpts);
    
    // Auto-expand the new option
    const next = new Set(expandedOptions);
    next.add(newIndex);
    setExpandedOptions(next);
  };
  
  const handleRemoveOption = (index) => {
    // Prevent accidental deletion if there are values
    if (options[index].values.length > 0 && !confirm("Deleting this option will remove all associated variants. Continue?")) {
        return;
    }

    const newOpts = options.filter((_, i) => i !== index);
    onOptionsChange(newOpts);
    
    // Regenerate variants to remove dependencies on this option
    const fresh = generateVariantCombinations(newOpts, []);
    onVariantsChange(fresh);
    toast({ title: "Option removed", description: "Related variants have been removed." });
  };
  
  const handleNameChange = (index, newName) => {
     const newOpts = [...options];
     newOpts[index].name = newName;
     onOptionsChange(newOpts);
  };

  const handleDoneEditingOption = (index) => {
      const next = new Set(expandedOptions);
      next.delete(index);
      setExpandedOptions(next);
  };
  
  const handleAddValue = (index, e) => {
    if (e.key !== 'Enter') return;
    e.preventDefault(); // Prevent form submission on Enter

    const val = newOptionValue[index]?.trim();
    if (!val) return;
    
    const newOpts = [...options];
    if (!Array.isArray(newOpts[index].values)) newOpts[index].values = [];
    
    // Prevent duplicates
    if (newOpts[index].values.some(v => v.value === val)) {
        toast({ variant: "destructive", title: "Value exists", description: "This option value already exists." });
        return;
    }

    // Use a temp ID that is clearly distinguishable
    newOpts[index].values.push({ 
        id: `temp-val-${Date.now()}`, 
        value: val,
        position: newOpts[index].values.length 
    });
    
    onOptionsChange(newOpts);
    setNewOptionValue({ ...newOptionValue, [index]: "" });

    // Auto-Generate Variants
    const generated = generateVariantCombinations(newOpts, variants);
    const addedCount = generated.length - variants.length;
    onVariantsChange(generated);
    
    if (addedCount > 0) {
        toast({ title: "Variants generated", description: `Added ${addedCount} new variants.` });
    }
  };

  const handleRemoveValue = (optIndex, valIndex) => {
      const newOpts = [...options];
      const valToRemove = newOpts[optIndex].values[valIndex].value;
      
      newOpts[optIndex].values.splice(valIndex, 1);
      onOptionsChange(newOpts);

      // Remove related variants
      const newVariants = variants.filter(v => {
          // Check optionValues array structure
          if (v.optionValues) {
             return !v.optionValues.some(ov => ov.optionName === newOpts[optIndex].name && ov.value === valToRemove);
          }
          return true;
      });
      
      const removedCount = variants.length - newVariants.length;
      onVariantsChange(newVariants);
      if (removedCount > 0) {
          toast({ title: "Variants updated", description: `Removed ${removedCount} variants associated with "${valToRemove}".` });
      }
  };

  return (
    <div className="bg-zinc-900 border border-zinc-800 rounded-xl overflow-hidden mb-8">
        <div className="p-6 border-b border-zinc-800">
             <h3 className="text-lg font-semibold text-white">Variants</h3>
        </div>
        
        <div className="p-6 space-y-4">
          {options.map((opt, idx) => {
            const isExpanded = expandedOptions.has(idx);
            
            return (
                <div key={opt.id || idx} className="bg-zinc-950 border border-zinc-800 rounded-lg overflow-hidden transition-all">
                  {/* Header / Summary View */}
                  <div 
                    className="flex items-center gap-4 p-4 cursor-pointer hover:bg-zinc-900/50"
                    onClick={() => toggleExpand(idx)}
                  >
                     <div className="text-zinc-600 cursor-move" onClick={e => e.stopPropagation()}>
                        <GripVertical className="w-5 h-5" />
                     </div>
                     
                     <div className="flex-1">
                        <div className="flex items-center justify-between mb-1">
                            <span className="font-semibold text-sm text-white">{opt.name}</span>
                            {isExpanded ? (
                                <Button 
                                    type="button"
                                    variant="ghost" 
                                    size="sm" 
                                    onClick={(e) => { e.stopPropagation(); handleRemoveOption(idx); }}
                                    className="h-6 text-zinc-500 hover:text-red-500 hover:bg-red-500/10 px-2"
                                >
                                    Remove
                                </Button>
                            ) : (
                                <Button type="button" variant="ghost" size="sm" className="h-6 w-6 p-0">
                                    <ChevronDown className="w-4 h-4 text-zinc-500" />
                                </Button>
                            )}
                        </div>
                        
                        {!isExpanded && (
                            <div className="flex flex-wrap gap-2">
                                {Array.isArray(opt.values) && opt.values.length > 0 ? (
                                    opt.values.map((val, vIdx) => (
                                        <Badge key={vIdx} variant="secondary" className="bg-zinc-800 text-zinc-300 border border-zinc-700 font-normal">
                                            {val.value}
                                        </Badge>
                                    ))
                                ) : (
                                    <span className="text-xs text-zinc-500 italic">No values yet</span>
                                )}
                            </div>
                        )}
                     </div>
                  </div>

                  {/* Expanded Edit View */}
                  {isExpanded && (
                      <div className="border-t border-zinc-800 p-4 bg-zinc-900/30">
                          <div className="space-y-4">
                              <div>
                                  <Label className="text-xs text-zinc-500 uppercase font-bold mb-1.5 block">Option Name</Label>
                                  <Input 
                                      value={opt.name}
                                      onChange={(e) => handleNameChange(idx, e.target.value)}
                                      onKeyDown={(e) => { if(e.key === 'Enter') e.preventDefault(); }}
                                      className="max-w-md bg-zinc-950 border-zinc-700"
                                  />
                              </div>
                              
                              <div>
                                  <Label className="text-xs text-zinc-500 uppercase font-bold mb-1.5 block">Option Values</Label>
                                  <div className="space-y-2">
                                      <div className="flex flex-wrap gap-2">
                                          {Array.isArray(opt.values) && opt.values.map((val, vIdx) => (
                                              <Badge key={vIdx} className="bg-zinc-800 hover:bg-zinc-700 text-white pl-3 pr-1 py-1.5 flex gap-1 text-sm border border-zinc-600">
                                                  {val.value}
                                                  <button 
                                                      type="button"
                                                      onClick={() => handleRemoveValue(idx, vIdx)} 
                                                      className="ml-1 p-0.5 hover:bg-zinc-600 rounded-full text-zinc-400 hover:text-red-400 transition-colors"
                                                  >
                                                      <Trash2 className="w-3 h-3" />
                                                  </button>
                                              </Badge>
                                          ))}
                                      </div>
                                      
                                      <Input 
                                          placeholder="Add value (e.g. Small, Medium)... press Enter" 
                                          value={newOptionValue[idx] || ""}
                                          onChange={(e) => setNewOptionValue({ ...newOptionValue, [idx]: e.target.value })}
                                          onKeyDown={(e) => handleAddValue(idx, e)}
                                          className="bg-zinc-950 border-zinc-700"
                                      />
                                  </div>
                              </div>
                              
                              <div className="flex justify-end pt-2">
                                  <Button type="button" size="sm" variant="outline" onClick={() => handleDoneEditingOption(idx)}>
                                      Done
                                  </Button>
                              </div>
                          </div>
                      </div>
                  )}
                </div>
            );
          })}

          {options.length < 3 && (
            <Button type="button" variant="ghost" onClick={handleAddOption} className="w-full justify-start pl-0 text-blue-400 hover:text-blue-300 hover:bg-transparent">
              <Plus className="w-4 h-4 mr-2" /> Add another option
            </Button>
          )}
        </div>
    </div>
  );
}