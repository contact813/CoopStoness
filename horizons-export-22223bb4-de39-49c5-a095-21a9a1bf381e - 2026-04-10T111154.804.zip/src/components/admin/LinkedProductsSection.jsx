import React, { useState, useEffect } from 'react';
import { 
  ChevronRight, 
  ChevronDown, 
  Trash2, 
  Image as ImageIcon, 
  Check, 
  Plus, 
  X, 
  AlertCircle,
  Package,
  Loader2
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/components/ui/use-toast";
import { cn } from "@/lib/utils";
import RoundProductSearch from "@/admin/components/RoundProductSearch";
import { supabase } from "@/lib/supabaseClient";

const AVAILABLE_UNITS = ['BOX', 'UN'];

// --- Sub-component: Variant Selection Form ---
const AvailableVariantsForm = ({ productId, parentTitle, existingVariantIds, onAddVariant, onCancel }) => {
  const [variants, setVariants] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedVariantId, setSelectedVariantId] = useState("");

  useEffect(() => {
    let isMounted = true;
    const fetchVariants = async () => {
      try {
        const { data, error } = await supabase
          .from('product_variants')
          .select('*')
          .eq('product_id', productId)
          .eq('is_active', true)
          .order('position', { ascending: true });
        
        if (error) throw error;
        if (isMounted) setVariants(data || []);
      } catch (err) {
        console.error("[LinkedProductsSection] Error fetching variants:", err);
      } finally {
        if (isMounted) setLoading(false);
      }
    };
    fetchVariants();
    return () => { isMounted = false; };
  }, [productId]);

  const available = variants.filter(v => !existingVariantIds.includes(v.id));

  const handleAdd = () => {
    if (!selectedVariantId) return;
    const variant = variants.find(v => v.id === selectedVariantId);
    if (variant) onAddVariant(variant);
  };

  if (loading) return <div className="flex items-center gap-2 text-sm text-zinc-500 p-4"><Loader2 className="h-3 w-3 animate-spin" /> Loading variants...</div>;

  if (available.length === 0) {
    return (
        <div className="flex items-center justify-between p-4 bg-zinc-900 border border-zinc-800 rounded-lg ml-12 mb-2">
            <span className="text-sm text-zinc-400">All available variants for {parentTitle} are already linked.</span>
            <Button variant="ghost" size="sm" onClick={onCancel}><X className="h-4 w-4" /></Button>
        </div>
    );
  }

  return (
    <div className="flex items-center gap-4 p-4 bg-zinc-900/50 border border-zinc-800 rounded-lg animate-in fade-in slide-in-from-top-2 ml-12 mb-2">
      <div className="flex-1">
        <Select value={selectedVariantId} onValueChange={setSelectedVariantId}>
            <SelectTrigger className="bg-zinc-950 border-zinc-700 text-zinc-200 h-9">
                <SelectValue placeholder="Select a variant to add..." />
            </SelectTrigger>
            <SelectContent>
                {available.map(v => (
                    <SelectItem key={v.id} value={v.id}>
                        {v.title} ({v.sku || 'No SKU'}) - ${v.price}
                    </SelectItem>
                ))}
            </SelectContent>
        </Select>
      </div>
      <div className="flex items-center gap-2">
        <Button 
            size="sm" 
            onClick={handleAdd} 
            disabled={!selectedVariantId}
            className="bg-yellow-500 text-black hover:bg-yellow-400 font-medium h-9"
        >
            Add Variant
        </Button>
        <Button variant="ghost" size="sm" onClick={onCancel} className="text-zinc-400 hover:text-white h-9">
            Cancel
        </Button>
      </div>
    </div>
  );
};

// --- Sub-component: Editable Input ---
const EditableInput = ({ value, onSave, type = "text", placeholder, prefix, suffix, className, inputClassName }) => {
    const [isEditing, setIsEditing] = useState(false);
    const [localValue, setLocalValue] = useState(value);
    const [saving, setSaving] = useState(false);
  
    useEffect(() => {
      setLocalValue(value);
    }, [value]);
  
    const handleSave = async () => {
      if (saving) return;
      setSaving(true);
      try {
        await onSave(localValue);
        setIsEditing(false);
      } catch (e) {
        console.error("[LinkedProductsSection] Save failed", e);
      } finally {
        setSaving(false);
      }
    };
  
    return (
      <div className={cn("relative w-full flex flex-col justify-center", className)}>
        {isEditing ? (
          <div className="flex items-center gap-1 w-full">
            <div className="relative flex-1">
                {prefix && <span className="absolute left-2 top-1/2 -translate-y-1/2 text-zinc-500 text-xs pointer-events-none">{prefix}</span>}
                <Input 
                    type={type} 
                    value={localValue}
                    onChange={(e) => setLocalValue(e.target.value)}
                    className={cn(
                        "h-9 bg-zinc-950 border-zinc-700 text-sm text-white pr-2 focus:ring-1 focus:ring-yellow-500",
                        prefix && "pl-6",
                        inputClassName
                    )}
                    placeholder={placeholder}
                    autoFocus
                    onKeyDown={(e) => {
                        if (e.key === 'Enter') handleSave();
                        if (e.key === 'Escape') {
                            setIsEditing(false);
                            setLocalValue(value);
                        }
                    }}
                />
            </div>
            <div className="flex gap-1">
              <Button 
                  size="sm" 
                  variant="ghost" 
                  onClick={handleSave} 
                  disabled={saving} 
                  className="h-9 w-8 p-0 text-green-500 hover:text-green-400 hover:bg-green-950/20 rounded-md flex-shrink-0"
              >
                {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Check className="h-4 w-4" />}
              </Button>
              <Button 
                  size="sm" 
                  variant="ghost" 
                  onClick={() => { setIsEditing(false); setLocalValue(value); }} 
                  className="h-9 w-8 p-0 text-zinc-500 hover:text-zinc-300 hover:bg-zinc-800 rounded-md flex-shrink-0"
              >
                <X className="h-4 w-4" />
              </Button>
            </div>
          </div>
        ) : (
            <div 
                className="group cursor-pointer border border-zinc-800/50 hover:border-zinc-600 bg-zinc-950/50 hover:bg-zinc-900 rounded px-3 py-2 transition-all flex items-center justify-between min-h-[36px]"
                onClick={() => setIsEditing(true)}
            >
                <span className={cn("text-sm truncate", !value && value !== 0 && "text-zinc-500 italic")}>
                    {prefix}{value}{suffix}
                </span>
            </div>
        )}
      </div>
    );
};

// --- Row Component ---
const RoundProductRow = ({ 
  item, 
  isVariant, 
  isExpanded, 
  onToggleExpand, 
  onRemove, 
  onUpdatePricing, 
  onUpdateGoal,
  onAddVariant,
  childVariants = []
}) => {
  const [showVariantForm, setShowVariantForm] = useState(false);
  const { toast } = useToast();

  const handleUpdatePrice = async (val) => {
    try {
        await onUpdatePricing(item.product_id, item.variant_id, val);
        toast({ title: "Updated", description: "Price updated successfully.", duration: 3000 });
    } catch (err) {
        toast({ variant: "destructive", title: "Error", description: "Failed to update price.", duration: 3000 });
        throw err;
    }
  };

  const handleUpdateGoalQty = async (val) => {
    try {
        await onUpdateGoal(item.product_id, item.variant_id, val, item.goal_unit);
        toast({ title: "Updated", description: "Goal quantity updated.", duration: 3000 });
    } catch (err) {
        toast({ variant: "destructive", title: "Error", description: "Failed to update goal.", duration: 3000 });
        throw err;
    }
  };
  
  const handleUpdateGoalUnit = async (val) => {
      try {
        await onUpdateGoal(item.product_id, item.variant_id, item.goal_qty, val);
        toast({ title: "Updated", description: "Unit updated.", duration: 3000 });
    } catch (err) {
        toast({ variant: "destructive", title: "Error", description: "Failed to update unit.", duration: 3000 });
        throw err;
    }
  }

  const imageUrl = item.image_url || null;
  const basePrice = Number(item.base_price || 0); 
  const specialPrice = item.special_price ? Number(item.special_price) : basePrice;
  
  const progress = item.goal_qty > 0 
    ? Math.min(100, ((item.items_sold || 0) / item.goal_qty) * 100) 
    : 0;
    
  const rowBgClass = isVariant 
    ? "bg-zinc-950/40 hover:bg-zinc-950/60 border-l-2 border-l-zinc-800/50" 
    : "bg-zinc-900/10 hover:bg-zinc-900/30";

  return (
    <>
      <div className={cn(
          "grid grid-cols-12 gap-3 py-4 px-4 border-b border-zinc-800 transition-colors min-h-[96px] items-start",
          rowBgClass
      )}>
        {/* 1. Product (Col-Span 3) */}
        <div className="col-span-3 flex items-start gap-3 h-full min-w-0 pt-1">
             {!isVariant && (
                <Button 
                    variant="ghost" 
                    size="sm"
                    onClick={() => onToggleExpand(item.product_id)}
                    className="h-6 w-6 p-0 mt-0.5 text-zinc-500 hover:text-white hover:bg-zinc-800 transition-colors flex-shrink-0"
                >
                    {isExpanded ? <ChevronDown className="h-4 w-4" /> : <ChevronRight className="h-4 w-4" />}
                </Button>
             )}
             {isVariant && <div className="w-6 flex-shrink-0" />} {/* Spacer for variant indentation */}

             <div className={cn(
                "flex-shrink-0 bg-zinc-900 rounded border border-zinc-800 overflow-hidden flex items-center justify-center mt-0.5",
                isVariant ? "h-8 w-8" : "h-10 w-10"
            )}>
                 {imageUrl ? (
                    <img src={imageUrl} alt="" className="h-full w-full object-cover" />
                 ) : (
                    <ImageIcon className="h-4 w-4 text-zinc-700" />
                 )}
            </div>
            
            <div className="flex flex-col gap-1 min-w-0 pt-0.5">
                 <span className={cn("font-medium text-sm leading-tight line-clamp-2", isVariant ? "text-zinc-300" : "text-zinc-100")}>
                    {item.display_title}
                </span>
                {isVariant && <span className="text-[10px] text-zinc-500 uppercase tracking-wider font-semibold leading-tight">Variant</span>}
            </div>
        </div>

        {/* 2. SKU (Col-Span 2) */}
        <div className="col-span-2 text-sm text-zinc-400 truncate leading-tight pt-2 pr-2">
             {item.sku || '—'}
        </div>

        {/* 3. Pricing (Col-Span 3) */}
        <div className="col-span-3 flex flex-col gap-2 h-full justify-start pt-1 pr-4">
             <div className="text-[10px] text-zinc-500 leading-tight">Base: <span className="text-zinc-400">${basePrice.toFixed(2)}</span></div>
             <div className="w-full">
                 <EditableInput 
                    value={specialPrice} 
                    onSave={handleUpdatePrice} 
                    placeholder="Set Price"
                    prefix="$"
                    className="w-full"
                    inputClassName="bg-zinc-950 border-zinc-700 leading-normal"
                 />
             </div>
             <div className="text-xs font-semibold text-yellow-500 leading-tight">
                Final: ${specialPrice.toFixed(2)}
             </div>
        </div>

        {/* 4. Goal (Col-Span 2) */}
        <div className="col-span-2 flex flex-col gap-2 h-full justify-start pt-1 pr-2">
             <div className="text-[10px] text-zinc-400 leading-tight">Goal Target</div>
             <div className="flex items-center gap-2">
                 <EditableInput 
                     value={item.goal_qty} 
                     onSave={handleUpdateGoalQty} 
                     placeholder="Qty"
                     type="number"
                     className="w-full min-w-[60px]"
                     inputClassName="bg-zinc-950 border-zinc-700 text-center leading-normal"
                 />
                 <Select value={item.goal_unit || 'un'} onValueChange={handleUpdateGoalUnit}>
                     <SelectTrigger className="h-9 w-[80px] bg-zinc-800 border-zinc-600 text-white text-xs px-2 flex-shrink-0 focus:ring-1 focus:ring-yellow-500">
                         <SelectValue />
                     </SelectTrigger>
                     <SelectContent className="bg-zinc-800 border-zinc-600 text-white">
                         {AVAILABLE_UNITS.map(unit => (
                           <SelectItem key={unit} value={unit.toLowerCase()} className="focus:bg-zinc-700 focus:text-white cursor-pointer">
                               {unit}
                           </SelectItem>
                         ))}
                     </SelectContent>
                 </Select>
             </div>
        </div>

        {/* 5. Progress (Col-Span 1) */}
        <div className="col-span-1 flex flex-col gap-2 h-full justify-start pt-1 min-w-[80px]">
            <div className="flex justify-between items-center w-full text-[10px] text-zinc-400 leading-tight mb-1">
                 <span>Sold</span>
                 <span className="font-mono text-zinc-300">{item.items_sold || 0} / {item.goal_qty}</span>
            </div>
            <div className="h-2 bg-zinc-800 rounded-full overflow-hidden w-full">
                 <div 
                    className={cn(
                        "h-full transition-all duration-500 rounded-full",
                        progress >= 100 ? "bg-green-500" : "bg-yellow-500"
                    )} 
                    style={{ width: `${progress}%` }} 
                 />
            </div>
            {item.goal_qty === 0 && (
                 <span className="text-[10px] text-zinc-600 flex items-center gap-1 leading-tight mt-1">
                    <AlertCircle className="h-3 w-3" /> Set goal
                </span>
            )}
        </div>

        {/* 6. Actions (Col-Span 1) */}
        <div className="col-span-1 flex justify-end h-full pt-2">
             <Button
                variant="ghost"
                size="icon"
                onClick={() => onRemove(item.product_id, item.variant_id)}
                className="h-8 w-8 text-zinc-600 hover:text-red-400 hover:bg-red-950/20 transition-colors flex-shrink-0"
                title={isVariant ? "Remove Variant" : "Remove Product"}
             >
                 <Trash2 className="h-4 w-4" />
             </Button>
        </div>
      </div>

      {/* Child Variants Render */}
      {isExpanded && !isVariant && (
        <div className="bg-zinc-950/30 border-b border-zinc-800/50 pl-4">
            {childVariants.length > 0 && childVariants.map(variant => (
                <RoundProductRow
                    key={variant.variant_id}
                    item={variant}
                    isVariant={true}
                    isExpanded={false}
                    onToggleExpand={() => {}}
                    onRemove={onRemove}
                    onUpdatePricing={onUpdatePricing}
                    onUpdateGoal={onUpdateGoal}
                />
            ))}
            
            {/* Add Variant Footer */}
            <div className="py-4 border-b border-zinc-800/50">
                {showVariantForm ? (
                    <AvailableVariantsForm 
                        productId={item.product_id}
                        parentTitle={item.display_title}
                        existingVariantIds={childVariants.map(v => v.variant_id)}
                        onAddVariant={(variant) => {
                            onAddVariant(item.product_id, variant);
                            setShowVariantForm(false);
                        }}
                        onCancel={() => setShowVariantForm(false)}
                    />
                ) : (
                    <div className="pl-12 ml-4">
                        <Button 
                            variant="outline" 
                            size="sm" 
                            onClick={() => setShowVariantForm(true)}
                            className="text-xs border-zinc-800 text-zinc-400 hover:text-white hover:bg-zinc-900 bg-zinc-950/50 h-9"
                        >
                            <Plus className="h-3 w-3 mr-2" /> Add Variant
                        </Button>
                    </div>
                )}
            </div>
        </div>
      )}
    </>
  );
};

export default function LinkedProductsSection({
  products,
  variantsMap,
  expandedProducts,
  onToggleExpand,
  onAddProduct,
  onAddVariant,
  onRemove,
  onUpdatePricing,
  onUpdateGoal
}) {
  return (
    <div className="rounded-2xl bg-zinc-950 border border-zinc-800 p-6 min-h-[600px] shadow-sm">
         <div className="mb-6">
             <h2 className="text-xl font-bold text-white">Linked Products</h2>
             <p className="text-sm text-zinc-500 mt-1">Add products here. Changes are saved when you click "Save Round".</p>
         </div>

         {/* Search Bar */}
         <div className="mb-8">
             <RoundProductSearch 
                onAddProduct={onAddProduct}
                linkedProductIds={products.map(i => i.product_id)}
             />
         </div>

         <div className="border border-zinc-800 rounded-lg overflow-hidden bg-zinc-950">
            {/* Grid Header - Sticky */}
            <div className="sticky top-0 z-10 bg-zinc-900/90 backdrop-blur-sm grid grid-cols-12 gap-3 text-xs font-semibold text-zinc-500 uppercase tracking-wider px-4 py-3 border-b border-zinc-800 shadow-sm items-center min-h-[48px] leading-tight">
                <div className="col-span-3 pl-2">Product</div>
                <div className="col-span-2">SKU</div>
                <div className="col-span-3">Pricing</div>
                <div className="col-span-2">Goal</div>
                <div className="col-span-1">Progress</div>
                <div className="col-span-1"></div> {/* Actions placeholder */}
            </div>

            {/* Product List */}
            <div className="divide-y divide-zinc-800">
                {products.length === 0 ? (
                    <div className="py-32 text-center text-zinc-500 italic flex flex-col items-center gap-4 bg-zinc-950/50">
                        <div className="h-16 w-16 rounded-full bg-zinc-900 flex items-center justify-center mb-2 border border-zinc-800">
                             <Package className="h-8 w-8 text-zinc-700" />
                        </div>
                        <p className="text-lg font-medium text-zinc-400">No products linked yet</p>
                        <p className="text-sm max-w-sm">Use the search bar above to find and add products to this round.</p>
                    </div>
                ) : (
                    products.map(product => (
                        <RoundProductRow 
                            key={product.product_id}
                            item={product}
                            isVariant={false}
                            isExpanded={expandedProducts.has(product.product_id)}
                            onToggleExpand={onToggleExpand}
                            onRemove={onRemove}
                            onUpdatePricing={onUpdatePricing}
                            onUpdateGoal={onUpdateGoal}
                            onAddVariant={onAddVariant}
                            childVariants={variantsMap[product.product_id] || []}
                        />
                    ))
                )}
            </div>
         </div>
    </div>
  );
}