import React, { useState, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { Search, Image as ImageIcon, ArrowLeft, Filter, X } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { cn } from '@/lib/utils';

export default function VariantSidebar({ 
  product, 
  variants = [], 
  options = [],
  activeVariantId, 
  productId,
  className,
  onCloseMobile // Callback to close sidebar on mobile selection
}) {
  const navigate = useNavigate();
  const [searchTerm, setSearchTerm] = useState('');
  const [filterOption, setFilterOption] = useState('all');
  const [filterValue, setFilterValue] = useState('all');

  // Safe array handling
  const safeVariants = Array.isArray(variants) ? variants : [];

  // Derived filters
  const availableValues = useMemo(() => {
    if (filterOption === 'all') return [];
    const opt = options.find(o => o.name === filterOption);
    return opt ? opt.values : [];
  }, [filterOption, options]);

  const filteredVariants = safeVariants.filter(v => {
    const matchesSearch = 
      v.title?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      v.sku?.toLowerCase().includes(searchTerm.toLowerCase());
    
    if (!matchesSearch) return false;

    if (filterOption !== 'all' && filterValue !== 'all') {
      const variantValue = v.optionValues?.find(ov => ov.optionName === filterOption);
      return variantValue?.value === filterValue;
    }

    return true;
  });

  const handleVariantClick = (id) => {
    navigate(`/admin/products/${productId}/variants/${id}`);
    if (onCloseMobile) onCloseMobile();
  };

  return (
    <div className={cn("flex flex-col h-full bg-zinc-950 border-r border-white/10", className)}>
      {/* Product Header */}
      <div className="p-4 border-b border-white/10">
        <Button 
          variant="ghost" 
          size="sm" 
          onClick={() => navigate(`/admin/products/${productId}`)}
          className="mb-3 -ml-2 text-zinc-400 hover:text-white hover:bg-white/5 pl-2"
        >
          <ArrowLeft className="w-4 h-4 mr-1" /> Back to Product
        </Button>
        <div className="flex items-start gap-3">
          <div className="w-12 h-12 rounded-lg border border-white/10 overflow-hidden bg-white/5 flex-shrink-0 flex items-center justify-center">
            {product?.thumbnail_url ? (
              <img src={product.thumbnail_url} alt="" className="w-full h-full object-cover" />
            ) : (
              <ImageIcon className="w-5 h-5 text-zinc-600" />
            )}
          </div>
          <div className="overflow-hidden min-w-0">
            <h3 className="font-semibold text-sm truncate text-white">{product?.title || 'Loading...'}</h3>
            <div className="flex items-center gap-2 mt-1">
              <Badge variant="outline" className={cn(
                "border-white/10 text-[10px] px-1.5 py-0 h-5",
                product?.status === 'active' ? "text-green-400 bg-green-400/10" : "text-zinc-400 bg-zinc-400/10"
              )}>
                {product?.status || 'draft'}
              </Badge>
              <span className="text-xs text-zinc-500">{safeVariants.length} variants</span>
            </div>
          </div>
        </div>
      </div>

      {/* Search & Filters */}
      <div className="p-4 border-b border-white/10 space-y-3 bg-zinc-900/50">
        <div className="relative">
          <Search className="absolute left-3 top-2.5 h-4 w-4 text-zinc-500" />
          <Input 
            placeholder="Search variants..." 
            className="pl-9 bg-black/40 border-white/10 text-white placeholder:text-zinc-600 focus-visible:ring-yellow-500/50 focus-visible:border-yellow-500/50" 
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        
        {options.length > 0 && (
          <div className="grid grid-cols-2 gap-2">
            <Select value={filterOption} onValueChange={(v) => { setFilterOption(v); setFilterValue('all'); }}>
              <SelectTrigger className="bg-black/40 border-white/10 text-zinc-300 h-8 text-xs">
                <SelectValue placeholder="Option" />
              </SelectTrigger>
              <SelectContent className="bg-zinc-900 border-white/10 text-white">
                <SelectItem value="all">All Options</SelectItem>
                {options.map(o => <SelectItem key={o.id} value={o.name}>{o.name}</SelectItem>)}
              </SelectContent>
            </Select>

            <Select 
              value={filterValue} 
              onValueChange={setFilterValue} 
              disabled={filterOption === 'all'}
            >
              <SelectTrigger className="bg-black/40 border-white/10 text-zinc-300 h-8 text-xs">
                <SelectValue placeholder="Value" />
              </SelectTrigger>
              <SelectContent className="bg-zinc-900 border-white/10 text-white">
                <SelectItem value="all">All Values</SelectItem>
                {availableValues.map(v => <SelectItem key={v.id} value={v.value}>{v.value}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
        )}
      </div>

      {/* Variants List */}
      <ScrollArea className="flex-1">
        {filteredVariants.length === 0 ? (
          <div className="p-8 text-center text-sm text-zinc-500 flex flex-col items-center gap-2">
            <Filter className="w-8 h-8 text-zinc-700 opacity-50" />
            <p>No variants found</p>
            {(searchTerm || filterOption !== 'all') && (
              <Button variant="link" onClick={() => { setSearchTerm(''); setFilterOption('all'); }} className="text-yellow-500 h-auto p-0">
                Clear filters
              </Button>
            )}
          </div>
        ) : (
          <div className="p-2 space-y-1">
            {filteredVariants.map((variant) => {
              const isActive = activeVariantId === variant.id;
              // Use image_url here
              const variantImage = variant.image_url || variant.image;
              
              return (
                <div
                  key={variant.id}
                  onClick={() => handleVariantClick(variant.id)}
                  className={cn(
                    "flex items-center gap-3 px-3 py-2.5 rounded-lg cursor-pointer transition-all border",
                    isActive 
                      ? "bg-yellow-500/10 border-yellow-500/30 ring-1 ring-yellow-500/20" 
                      : "bg-transparent border-transparent hover:bg-white/5 hover:border-white/5"
                  )}
                >
                  <div className={cn(
                    "w-9 h-9 rounded border overflow-hidden flex-shrink-0 flex items-center justify-center bg-black",
                    isActive ? "border-yellow-500/30" : "border-white/10"
                  )}>
                     {variantImage ? (
                        <img src={variantImage} alt="" className="w-full h-full object-cover" />
                      ) : (
                        <ImageIcon className="w-4 h-4 text-zinc-600" />
                      )}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex justify-between items-center mb-0.5">
                      <p className={cn("text-sm font-medium truncate", isActive ? "text-yellow-500" : "text-zinc-200")}>
                        {variant.title}
                      </p>
                      {isActive && <div className="w-1.5 h-1.5 rounded-full bg-yellow-500" />}
                    </div>
                    <div className="flex items-center gap-2 text-xs text-zinc-500">
                      <span className="truncate max-w-[80px]">{variant.sku || 'No SKU'}</span>
                      <span className="w-1 h-1 rounded-full bg-zinc-700" />
                      <span>{variant.inventory_qty} avail</span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </ScrollArea>

      <div className="p-4 border-t border-white/10 bg-zinc-900/50">
        <Button 
            className="w-full bg-yellow-500 text-black hover:bg-yellow-400 font-medium"
            onClick={() => handleVariantClick('new')}
        >
            + Add Variant
        </Button>
      </div>
    </div>
  );
}