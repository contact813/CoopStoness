import React from 'react';
import { Badge } from '@/components/ui/badge';
import { CheckSquare, Square } from 'lucide-react';
import { cn } from '@/lib/utils';

export default function CollectionsMultiSelect({ value = [], onChange, className, collections = [] }) {
  // Validate props
  const safeCollections = Array.isArray(collections) ? collections : [];
  const safeValue = Array.isArray(value) ? value : [];

  const toggleCollection = (id) => {
    const newIds = safeValue.includes(id)
      ? safeValue.filter(v => v !== id)
      : [...safeValue, id];
    onChange(newIds);
  };

  const selectedCollections = safeCollections.filter(c => safeValue.includes(c.id));

  return (
    <div className={cn("space-y-4", className)}>
      {/* Selected Badges */}
      <div className="flex flex-wrap gap-2 min-h-[32px] p-2 bg-zinc-900/50 rounded-md border border-zinc-800/50">
        {selectedCollections.length === 0 && <span className="text-xs text-zinc-500 italic p-1">No collections selected</span>}
        {selectedCollections.map(col => (
          <Badge key={col.id} variant="secondary" className="bg-yellow-500/10 text-yellow-500 border-yellow-500/20 hover:bg-yellow-500/20">
            {col.title}
          </Badge>
        ))}
      </div>

      {/* Selection List */}
      <div className="bg-zinc-900 border border-zinc-800 rounded-md p-1 max-h-60 overflow-y-auto">
        {safeCollections.length === 0 && (
            <div className="p-4 text-center text-zinc-500 text-sm">No collections found.</div>
        )}

        {safeCollections.map(col => {
          const isSelected = safeValue.includes(col.id);
          return (
            <div 
              key={col.id}
              onClick={() => toggleCollection(col.id)}
              className={cn(
                "flex items-center gap-3 px-3 py-2 cursor-pointer rounded-sm text-sm transition-colors",
                isSelected ? "bg-zinc-800 text-white" : "text-zinc-400 hover:bg-zinc-800/50 hover:text-zinc-200"
              )}
            >
              {isSelected ? (
                <CheckSquare className="w-4 h-4 text-yellow-500 shrink-0" />
              ) : (
                <Square className="w-4 h-4 text-zinc-600 shrink-0" />
              )}
              <span>{col.title}</span>
            </div>
          );
        })}
      </div>
    </div>
  );
}