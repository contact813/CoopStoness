import React, { useState, useEffect } from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogDescription
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { CheckCircle2, AlertCircle, Package } from 'lucide-react';
import { cn } from '@/lib/utils';

export default function ImportPreviewModal({ open, onOpenChange, products, onConfirm }) {
  const [selectedHandles, setSelectedHandles] = useState(new Set());

  // Initialize selection when products load
  useEffect(() => {
    if (open && products.length > 0) {
      const allHandles = new Set(products.map(p => p.handle));
      setSelectedHandles(allHandles);
    }
  }, [open, products]);

  const toggleSelect = (handle) => {
    const next = new Set(selectedHandles);
    if (next.has(handle)) next.delete(handle);
    else next.add(handle);
    setSelectedHandles(next);
  };

  const toggleSelectAll = (checked) => {
    if (checked) {
      setSelectedHandles(new Set(products.map(p => p.handle)));
    } else {
      setSelectedHandles(new Set());
    }
  };

  const handleConfirm = () => {
    const selected = products.filter(p => selectedHandles.has(p.handle));
    onConfirm(selected);
  };

  const selectedCount = selectedHandles.size;
  const totalCount = products.length;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl bg-zinc-950 border-zinc-800 text-white flex flex-col max-h-[85vh]">
        <DialogHeader>
          <DialogTitle>Preview Import</DialogTitle>
          <DialogDescription>
            Found {products.length} products. Review and select items to import.
          </DialogDescription>
        </DialogHeader>

        <div className="flex items-center gap-2 py-2 border-b border-zinc-800">
           <Checkbox 
             checked={selectedCount > 0 && selectedCount === totalCount}
             onCheckedChange={toggleSelectAll}
             className="border-zinc-600 data-[state=checked]:bg-blue-600"
           />
           <span className="text-sm font-medium text-zinc-300">
             Select All ({selectedCount}/{totalCount} selected)
           </span>
        </div>

        <ScrollArea className="flex-1 -mx-6 px-6">
           <div className="space-y-2 py-2">
             {products.map((product, idx) => (
               <div 
                 key={product.handle || idx} 
                 className={cn(
                    "flex items-start gap-4 p-3 rounded-lg border transition-colors",
                    selectedHandles.has(product.handle) 
                      ? "bg-zinc-900 border-zinc-700" 
                      : "bg-zinc-950 border-zinc-800 opacity-60"
                 )}
               >
                 <div className="pt-1">
                   <Checkbox 
                      checked={selectedHandles.has(product.handle)}
                      onCheckedChange={() => toggleSelect(product.handle)}
                      className="border-zinc-600 data-[state=checked]:bg-blue-600"
                   />
                 </div>
                 
                 <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                       <h4 className="font-semibold text-sm text-white truncate">{product.title}</h4>
                       <span className="text-xs text-zinc-500 font-mono">#{product.handle}</span>
                       {selectedHandles.has(product.handle) && <CheckCircle2 className="w-4 h-4 text-green-500" />}
                    </div>
                    
                    <p className="text-xs text-zinc-400 line-clamp-1 mb-2">
                      {product.description?.replace(/<[^>]*>?/gm, '') || 'No description'}
                    </p>

                    <div className="flex flex-wrap gap-2 text-xs">
                       <Badge variant="outline" className="border-zinc-700 text-zinc-400">
                          {product.variants.length} Variants
                       </Badge>
                       <Badge variant="outline" className="border-zinc-700 text-zinc-400">
                          {product.images.length} Images
                       </Badge>
                       {product.options.map((opt, i) => (
                         <Badge key={i} variant="secondary" className="bg-zinc-800 text-zinc-300">
                           {opt.name}: {opt.values.length}
                         </Badge>
                       ))}
                    </div>
                 </div>

                 {product.images.length > 0 && (
                   <div className="w-12 h-12 bg-zinc-800 rounded overflow-hidden flex-shrink-0 border border-zinc-700">
                      <img src={product.images[0].url} alt="" className="w-full h-full object-cover" />
                   </div>
                 )}
               </div>
             ))}
           </div>
        </ScrollArea>

        <DialogFooter className="border-t border-zinc-800 pt-4">
          <Button variant="ghost" onClick={() => onOpenChange(false)}>Cancel</Button>
          <Button 
            onClick={handleConfirm}
            disabled={selectedCount === 0}
            className="bg-yellow-500 text-black hover:bg-yellow-400"
          >
            Import {selectedCount} Products
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}