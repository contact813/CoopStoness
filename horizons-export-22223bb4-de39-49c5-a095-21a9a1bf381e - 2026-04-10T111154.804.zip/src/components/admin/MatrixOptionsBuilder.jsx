
import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Trash2, Edit2, Check, X, Plus, AlertCircle } from 'lucide-react';

export default function MatrixOptionsBuilder({ options, onOptionsChange, onVariantsGenerate }) {
    const [newName, setNewName] = useState('');
    const [newValues, setNewValues] = useState('');
    const [error, setError] = useState('');

    const [editingIndex, setEditingIndex] = useState(null);
    const [editName, setEditName] = useState('');
    const [editValues, setEditValues] = useState('');

    const generateCartesianVariants = (opts) => {
        if (!opts || opts.length === 0) return [];
        const arrays = opts.map(opt => opt.values);
        
        const cartesian = (arrs) => {
            if (arrs.length === 0) return [];
            return arrs.reduce((a, b) => a.flatMap(d => b.map(e => [d, e].flat())), [[]]);
        };
        
        const combos = cartesian(arrays);
        
        return combos.map(combo => {
            const comboArray = Array.isArray(combo) ? combo : [combo];
            return {
                title: comboArray.join(' / '),
                options: opts.map((opt, i) => ({
                    name: opt.name,
                    value: comboArray[i]
                }))
            };
        });
    };

    const handleAdd = () => {
        setError('');
        if (!newName.trim()) {
            setError('Option name cannot be empty.');
            return;
        }
        
        const parsedValues = newValues.split(',').map(v => v.trim()).filter(Boolean);
        if (parsedValues.length === 0) {
            setError('Option values cannot be empty. Please provide comma-separated values.');
            return;
        }
        
        const newOpts = [...options, { name: newName.trim(), values: parsedValues }];
        onOptionsChange(newOpts);
        onVariantsGenerate(generateCartesianVariants(newOpts));
        
        setNewName('');
        setNewValues('');
    };

    const handleDelete = (idx) => {
        const newOpts = options.filter((_, i) => i !== idx);
        onOptionsChange(newOpts);
        onVariantsGenerate(generateCartesianVariants(newOpts));
    };

    const handleEditStart = (idx) => {
        setEditingIndex(idx);
        setEditName(options[idx].name);
        setEditValues(options[idx].values.join(', '));
        setError('');
    };

    const handleEditSave = () => {
        setError('');
        if (!editName.trim()) {
            setError('Option name cannot be empty.');
            return;
        }
        
        const parsedValues = editValues.split(',').map(v => v.trim()).filter(Boolean);
        if (parsedValues.length === 0) {
            setError('Option values cannot be empty. Please provide comma-separated values.');
            return;
        }
        
        const newOpts = [...options];
        newOpts[editingIndex] = { name: editName.trim(), values: parsedValues };
        
        onOptionsChange(newOpts);
        onVariantsGenerate(generateCartesianVariants(newOpts));
        setEditingIndex(null);
    };

    const handleEditCancel = () => {
        setEditingIndex(null);
        setError('');
    };

    const combinations = options.length > 0 ? options.reduce((acc, opt) => acc * opt.values.length, 1) : 0;

    return (
        <div className="space-y-6">
            {error && (
                <Alert variant="destructive" className="bg-red-950/40 border-red-900 text-red-400">
                    <AlertCircle className="h-4 w-4" />
                    <AlertDescription>{error}</AlertDescription>
                </Alert>
            )}
            
            <div className="bg-zinc-900 border border-zinc-800 p-5 rounded-xl space-y-4">
                <h3 className="text-lg font-semibold text-white">Add New Option</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                        <Label className="text-zinc-400">Option Name</Label>
                        <Input 
                            placeholder="e.g. Size, Color" 
                            value={newName}
                            onChange={(e) => setNewName(e.target.value)}
                            className="bg-zinc-950 border-zinc-800 text-white mt-1.5"
                        />
                    </div>
                    <div>
                        <Label className="text-zinc-400">Values (comma-separated)</Label>
                        <Input 
                            placeholder="e.g. S, M, L or Red, Blue" 
                            value={newValues}
                            onChange={(e) => setNewValues(e.target.value)}
                            className="bg-zinc-950 border-zinc-800 text-white mt-1.5"
                        />
                    </div>
                </div>
                <Button onClick={handleAdd} className="bg-yellow-500 text-black hover:bg-yellow-400 w-full md:w-auto mt-2 font-medium">
                    <Plus className="w-4 h-4 mr-2" /> Add Option
                </Button>
            </div>

            {options.length > 0 && (
                <div className="space-y-4">
                    <div className="flex items-center justify-between border-b border-zinc-800 pb-2">
                        <h3 className="text-lg font-semibold text-white">Current Options</h3>
                        <span className="text-xs font-semibold uppercase tracking-wider text-yellow-500 bg-yellow-500/10 px-3 py-1 rounded-full border border-yellow-500/20">
                            {combinations} Combination{combinations !== 1 ? 's' : ''}
                        </span>
                    </div>
                    <div className="space-y-3">
                        {options.map((opt, idx) => (
                            <div key={idx} className="bg-zinc-900 border border-zinc-800 p-4 rounded-xl flex flex-col md:flex-row gap-4 items-start md:items-center justify-between transition-colors hover:border-zinc-700">
                                {editingIndex === idx ? (
                                    <div className="flex-1 w-full grid grid-cols-1 md:grid-cols-2 gap-4">
                                        <div>
                                            <Label className="text-zinc-400 text-xs uppercase font-bold tracking-wider">Edit Name</Label>
                                            <Input 
                                                value={editName}
                                                onChange={(e) => setEditName(e.target.value)}
                                                className="bg-zinc-950 border-zinc-700 text-white mt-1.5"
                                            />
                                        </div>
                                        <div>
                                            <Label className="text-zinc-400 text-xs uppercase font-bold tracking-wider">Edit Values</Label>
                                            <Input 
                                                value={editValues}
                                                onChange={(e) => setEditValues(e.target.value)}
                                                className="bg-zinc-950 border-zinc-700 text-white mt-1.5"
                                            />
                                        </div>
                                    </div>
                                ) : (
                                    <div className="flex-1">
                                        <p className="font-semibold text-white">{opt.name}</p>
                                        <div className="flex flex-wrap gap-2 mt-2.5">
                                            {opt.values.map((v, i) => (
                                                <span key={i} className="bg-zinc-800 text-zinc-300 text-xs px-2.5 py-1 rounded border border-zinc-700">
                                                    {v}
                                                </span>
                                            ))}
                                        </div>
                                    </div>
                                )}
                                
                                <div className="flex gap-2 w-full md:w-auto justify-end pt-2 md:pt-0">
                                    {editingIndex === idx ? (
                                        <>
                                            <Button variant="outline" size="sm" onClick={handleEditCancel} className="border-zinc-700 text-zinc-300 hover:text-white bg-zinc-950">
                                                <X className="w-4 h-4 mr-1.5" /> Cancel
                                            </Button>
                                            <Button size="sm" onClick={handleEditSave} className="bg-emerald-600 hover:bg-emerald-500 text-white">
                                                <Check className="w-4 h-4 mr-1.5" /> Save
                                            </Button>
                                        </>
                                    ) : (
                                        <>
                                            <Button variant="outline" size="icon" onClick={() => handleEditStart(idx)} className="border-zinc-700 text-zinc-400 hover:text-white hover:bg-zinc-800 bg-zinc-950">
                                                <Edit2 className="w-4 h-4" />
                                            </Button>
                                            <Button variant="outline" size="icon" onClick={() => handleDelete(idx)} className="border-red-900/50 text-red-500 hover:bg-red-900/30 hover:text-red-400 bg-zinc-950">
                                                <Trash2 className="w-4 h-4" />
                                            </Button>
                                        </>
                                    )}
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            )}
        </div>
    );
}
