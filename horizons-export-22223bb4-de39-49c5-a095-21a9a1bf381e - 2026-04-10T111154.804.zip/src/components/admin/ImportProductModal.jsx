import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { useToast } from "@/components/ui/use-toast";
import { AlertCircle, Upload, Loader2, FileJson, FileSpreadsheet } from "lucide-react";
import { parseShopifyCsv } from '@/lib/import/shopifyCsvParser';
import { importProductsBulk } from '@/lib/import/importProductsBulk';
import ImportPreviewModal from './ImportPreviewModal';
import { testImportWithSampleData } from '@/lib/import/testImport';

export default function ImportProductModal({ open, onOpenChange, onSuccess }) {
  const navigate = useNavigate();
  const { toast } = useToast();
  
  const [activeTab, setActiveTab] = useState("json");
  const [dataInput, setDataInput] = useState("");
  const [previewData, setPreviewData] = useState([]);
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(false);
  const [progress, setProgress] = useState({ msg: "", percent: 0 });
  
  const [uploadImages, setUploadImages] = useState(false);
  
  const [showPreviewModal, setShowPreviewModal] = useState(false);

  const handleFileChange = (e, type) => {
    const file = e.target.files[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      setDataInput(event.target.result);
    };
    reader.readAsText(file);
  };

  const handleLoadSample = () => {
    try {
       const csv = testImportWithSampleData();
       setDataInput(csv);
       setActiveTab('csv');
    } catch(e) {
       console.error(e);
    }
  };

  const handleParseAndPreview = () => {
    setError(null);
    setPreviewData([]);

    if (!dataInput.trim()) {
      setError("Please enter data or upload a file.");
      return;
    }

    try {
      let products = [];
      if (activeTab === "json") {
         const json = JSON.parse(dataInput);
         products = Array.isArray(json) ? json : [json];
         if (!products[0]?.title) throw new Error("Invalid JSON: missing 'title' field in first item");
      } else {
         products = parseShopifyCsv(dataInput);
         if (products.length === 0) throw new Error("No valid products parsed. Check your CSV format.");
      }
      
      setPreviewData(products);
      setShowPreviewModal(true);
    } catch (err) {
      setError(err.message);
    }
  };

  const handleConfirmImport = async (selectedProducts) => {
    setShowPreviewModal(false);
    setLoading(true);
    setProgress({ msg: "Starting...", percent: 0 });

    try {
      if (!selectedProducts || selectedProducts.length === 0) {
        throw new Error("No products selected for import.");
      }

      console.log("[handleConfirmImport] Starting import confirmation...");
      
      // Call import with progress callback
      const result = await importProductsBulk(selectedProducts, {
        uploadImages,
        onProgress: (msg, percent) => setProgress({ msg, percent })
      });

      console.log("[handleConfirmImport] Import Result Summary:", result);

      // 1. Partial Success or Full Success
      if (result.success.length > 0) {
        let description = `Imported ${result.success.length} products with ${result.totalImages || 0} images.`;
        if (result.failed.length > 0) {
          description += `\n⚠️ ${result.failed.length} products failed.`;
        }
        
        toast({
          title: result.failed.length === 0 ? "Import Complete" : "Import Partially Complete",
          description: description,
          className: result.failed.length === 0 ? "bg-green-600 text-white border-green-700" : "bg-yellow-600 text-white border-yellow-700"
        });
        
        // Clean up UI on any success
        setDataInput("");
        setPreviewData([]);
        if (onSuccess) onSuccess();
        onOpenChange(false);
      }

      // 2. Failure Handling
      if (result.failed.length > 0) {
        // Prepare error details
        const errorDetails = result.failed.slice(0, 3).map(f => `• ${f.title}: ${f.error}`).join('\n');
        
        // If ALL failed, we show destructive toast and keep modal open
        if (result.success.length === 0) {
           toast({
            variant: "destructive",
            title: `Import Failed (${result.failed.length} errors)`,
            description: errorDetails + (result.failed.length > 3 ? `\n...and ${result.failed.length - 3} more.` : ''),
            className: "whitespace-pre-wrap"
          });
          // Do NOT close modal, allow user to fix or retry
        }
      }

    } catch (err) {
      // Catch-all for catastrophic failure in the function call itself
      console.error("[handleConfirmImport] Critical Import Error:", err);
      toast({
        variant: "destructive",
        title: "System Error",
        description: err.message || "An unexpected error occurred."
      });
    } finally {
      setLoading(false);
      setProgress({ msg: "", percent: 0 });
    }
  };

  return (
    <>
      <Dialog open={open} onOpenChange={onOpenChange}>
        <DialogContent className="max-w-2xl bg-zinc-950 border-zinc-800 text-white">
          <DialogHeader>
            <DialogTitle>Import Products</DialogTitle>
            <DialogDescription>
              Import multiple products from Shopify CSV or JSON.
            </DialogDescription>
          </DialogHeader>

          <Tabs value={activeTab} onValueChange={(val) => { setActiveTab(val); setDataInput(""); setError(null); }}>
            <TabsList className="grid w-full grid-cols-2 bg-zinc-900">
              <TabsTrigger value="json" className="data-[state=active]:bg-zinc-800"><FileJson className="w-4 h-4 mr-2"/> JSON</TabsTrigger>
              <TabsTrigger value="csv" className="data-[state=active]:bg-zinc-800"><FileSpreadsheet className="w-4 h-4 mr-2"/> CSV (Shopify)</TabsTrigger>
            </TabsList>

            <div className="mt-4 space-y-4">
              <div className="space-y-2">
                <div className="flex justify-between items-center">
                  <label className="text-xs text-zinc-400 uppercase font-bold">Data Source</label>
                  <div className="flex gap-2">
                    <Button variant="ghost" size="sm" onClick={handleLoadSample} className="h-6 text-xs text-yellow-500 hover:text-yellow-400">
                       Load Test Data
                    </Button>
                    <div className="relative">
                      <input 
                        type="file" 
                        accept={activeTab === 'json' ? '.json' : '.csv'}
                        onChange={(e) => handleFileChange(e, activeTab)}
                        className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                      />
                      <Button variant="outline" size="sm" className="h-6 text-xs bg-zinc-800 border-zinc-700 hover:bg-zinc-700">
                        <Upload className="w-3 h-3 mr-1.5" /> Upload File
                      </Button>
                    </div>
                  </div>
                </div>
                <textarea
                  value={dataInput}
                  onChange={(e) => setDataInput(e.target.value)}
                  placeholder={activeTab === 'json' ? '[{ "title": "My Product", ... }]' : 'Handle,Title,Option1 Name,Option1 Value...'}
                  className="w-full h-32 bg-zinc-900 border border-zinc-800 rounded-md p-3 text-xs font-mono text-zinc-300 focus:outline-none focus:ring-1 focus:ring-yellow-500 resize-none"
                  disabled={loading}
                />
              </div>

              {error && (
                <div className="p-3 rounded bg-red-950/30 border border-red-900 text-red-400 text-sm flex items-start gap-2">
                  <AlertCircle className="w-4 h-4 mt-0.5 flex-shrink-0" />
                  <span>{error}</span>
                </div>
              )}
              
              <div className="flex items-center gap-2 pt-2">
                 <input 
                   type="checkbox" 
                   id="uploadImages"
                   checked={uploadImages} 
                   onChange={(e) => setUploadImages(e.target.checked)}
                   className="rounded border-zinc-700 bg-zinc-900 text-yellow-500 focus:ring-yellow-500"
                   disabled={loading}
                 />
                 <label htmlFor="uploadImages" className="text-sm text-zinc-300 cursor-pointer select-none">
                   Download & Upload images to Storage (slower)
                 </label>
              </div>

              {loading && (
                  <div className="space-y-2 bg-zinc-900/50 p-4 rounded border border-zinc-800">
                      <div className="flex items-center justify-between text-sm text-yellow-500">
                          <span className="flex items-center gap-2">
                              <Loader2 className="w-4 h-4 animate-spin" />
                              {progress.msg}
                          </span>
                          <span>{progress.percent}%</span>
                      </div>
                      <div className="h-1.5 bg-zinc-800 rounded-full overflow-hidden">
                          <div 
                              className="h-full bg-yellow-500 transition-all duration-300" 
                              style={{ width: `${progress.percent}%` }}
                          />
                      </div>
                  </div>
              )}
            </div>
          </Tabs>

          <DialogFooter className="mt-4">
              <Button variant="ghost" onClick={() => onOpenChange(false)} disabled={loading}>Cancel</Button>
              <Button 
                  onClick={handleParseAndPreview} 
                  disabled={loading || !dataInput}
                  className="bg-yellow-500 text-black hover:bg-yellow-400"
              >
                  Preview & Import
              </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      <ImportPreviewModal 
        open={showPreviewModal} 
        onOpenChange={setShowPreviewModal}
        products={previewData}
        onConfirm={handleConfirmImport}
      />
    </>
  );
}