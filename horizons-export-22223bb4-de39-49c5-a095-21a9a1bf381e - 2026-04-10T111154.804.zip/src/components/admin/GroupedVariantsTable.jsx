import React from 'react';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Trash2, Edit } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

export default function GroupedVariantsTable({ productId, variants = [], onVariantsChange }) {
  const navigate = useNavigate();

  // Group variants
  const groupedVariants = variants.reduce((acc, variant) => {
    const group = variant.variant_group || 'Ungrouped';
    if (!acc[group]) acc[group] = [];
    acc[group].push(variant);
    return acc;
  }, {});

  const handleUpdate = (id, field, value) => {
    const newVars = variants.map(v => v.id === id ? { ...v, [field]: value } : v);
    onVariantsChange(newVars);
  };

  const handleRemove = (id) => {
    if (confirm("Are you sure you want to remove this variant?")) {
      const newVars = variants.filter(v => v.id !== id);
      onVariantsChange(newVars);
    }
  };

  const handleEditClick = (variant) => {
    if (variant.is_temp) {
      alert("Please save the product first before editing full variant details.");
    } else {
      navigate(`/admin/products/${productId}/variants/${variant.id}`);
    }
  };

  if (variants.length === 0) return null;

  return (
    <div className="bg-zinc-900 border border-zinc-800 rounded-xl overflow-hidden mt-8">
      <div className="p-4 border-b border-zinc-800 bg-zinc-950">
        <h3 className="text-lg font-semibold">Grouped Variants List</h3>
      </div>
      
      {Object.entries(groupedVariants).map(([groupName, groupItems]) => (
        <div key={groupName} className="mb-6 last:mb-0">
          <div className="bg-zinc-800/50 px-4 py-2 font-bold text-zinc-300 border-y border-zinc-800">
            {groupName}
          </div>
          <Table>
            <TableHeader>
              <TableRow className="border-zinc-800 hover:bg-transparent">
                <TableHead className="text-zinc-400">Label</TableHead>
                <TableHead className="text-zinc-400">SKU</TableHead>
                <TableHead className="text-zinc-400 text-right w-[120px]">Price</TableHead>
                <TableHead className="text-zinc-400 text-right w-[120px]">Stock</TableHead>
                <TableHead className="w-[100px] text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {groupItems.map((v) => (
                <TableRow key={v.id} className="border-zinc-800 hover:bg-zinc-900/50">
                  <TableCell>
                    <Input 
                      value={v.variant_label || ''} 
                      onChange={e => handleUpdate(v.id, 'variant_label', e.target.value)} 
                      className="h-8 bg-transparent border-transparent hover:border-zinc-700 focus:bg-zinc-950 focus:border-yellow-500"
                      placeholder="Label"
                    />
                  </TableCell>
                  <TableCell>
                    <Input 
                      value={v.sku || ''} 
                      onChange={e => handleUpdate(v.id, 'sku', e.target.value)} 
                      className="h-8 bg-transparent border-transparent hover:border-zinc-700 focus:bg-zinc-950 focus:border-yellow-500"
                      placeholder="SKU"
                    />
                  </TableCell>
                  <TableCell className="text-right">
                    <Input 
                      type="number"
                      value={v.price} 
                      onChange={e => handleUpdate(v.id, 'price', parseFloat(e.target.value) || 0)} 
                      className="h-8 text-right bg-transparent border-transparent hover:border-zinc-700 focus:bg-zinc-950 focus:border-yellow-500"
                    />
                  </TableCell>
                  <TableCell className="text-right">
                    <Input 
                      type="number"
                      value={v.inventory_qty} 
                      onChange={e => handleUpdate(v.id, 'inventory_qty', parseInt(e.target.value) || 0)} 
                      className="h-8 text-right bg-transparent border-transparent hover:border-zinc-700 focus:bg-zinc-950 focus:border-yellow-500"
                    />
                  </TableCell>
                  <TableCell className="text-right">
                    <div className="flex items-center justify-end gap-1">
                      <Button variant="ghost" size="icon" onClick={() => handleEditClick(v)} className="h-8 w-8 text-zinc-400 hover:text-white">
                        <Edit size={14} />
                      </Button>
                      <Button variant="ghost" size="icon" onClick={() => handleRemove(v.id)} className="h-8 w-8 text-zinc-600 hover:text-red-500 hover:bg-red-950/20">
                        <Trash2 size={14} />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      ))}
    </div>
  );
}