
import React, { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabaseClient';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Loader2, Calendar } from 'lucide-react';
import { format } from 'date-fns';

export default function StandardOrdersList() {
    const [orders, setOrders] = useState([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        let mounted = true;
        async function fetchOrders() {
            try {
                // Fetch legacy standard orders (assuming order_type exists or we just fetch from orders)
                const { data, error } = await supabase
                    .from('orders')
                    .select('*, profiles:user_id(email, name)')
                    .eq('order_type', 'standard_order')
                    .order('created_at', { ascending: false })
                    .limit(50);
                
                if (error) {
                    // Fallback if order_type doesn't exist
                    const fallback = await supabase.from('orders').select('*, profiles:user_id(email, name)').order('created_at', { ascending: false }).limit(50);
                    if (!fallback.error && mounted) setOrders(fallback.data || []);
                } else if (mounted) {
                    setOrders(data || []);
                }
            } catch (error) {
                console.error('Error fetching legacy orders:', error);
            } finally {
                if (mounted) setLoading(false);
            }
        }
        fetchOrders();
        return () => { mounted = false; };
    }, []);

    if (loading) {
        return (
            <div className="bg-zinc-900/50 border border-zinc-800/50 rounded-xl p-8 flex justify-center">
                <Loader2 className="h-6 w-6 animate-spin text-zinc-500" />
            </div>
        );
    }

    if (orders.length === 0) {
        return (
            <div className="bg-zinc-900/50 border border-zinc-800/50 rounded-xl p-8 text-center">
                <Calendar className="h-8 w-8 text-zinc-600 mb-3 mx-auto opacity-50" />
                <p className="text-zinc-500 text-sm">No legacy standard orders found.</p>
            </div>
        );
    }

    return (
        <div className="rounded-xl border border-zinc-800/50 bg-zinc-900/50 overflow-hidden opacity-80 hover:opacity-100 transition-opacity">
            <Table>
                <TableHeader className="bg-zinc-950/50">
                    <TableRow className="border-zinc-800/50">
                        <TableHead className="text-zinc-500">Order ID</TableHead>
                        <TableHead className="text-zinc-500">Customer</TableHead>
                        <TableHead className="text-zinc-500 text-right">Total</TableHead>
                        <TableHead className="text-zinc-500">Status</TableHead>
                        <TableHead className="text-zinc-500 text-right">Date</TableHead>
                    </TableRow>
                </TableHeader>
                <TableBody className="divide-y divide-zinc-800/50">
                    {orders.map((order) => (
                        <TableRow key={order.id} className="border-zinc-800/50">
                            <TableCell className="font-mono text-xs text-zinc-500">
                                {order.id.substring(0, 8)}...
                            </TableCell>
                            <TableCell className="text-zinc-400 text-sm">
                                {order.profiles?.name || order.profiles?.email || 'Unknown'}
                            </TableCell>
                            <TableCell className="text-right font-mono text-zinc-400">
                                ${Number(order.total_amount || 0).toFixed(2)}
                            </TableCell>
                            <TableCell>
                                <div className="flex gap-2 items-center">
                                    <Badge variant="outline" className="bg-zinc-800 text-zinc-400 border-zinc-700 text-[10px]">
                                        {order.status?.toUpperCase() || 'UNKNOWN'}
                                    </Badge>
                                    <Badge variant="outline" className="bg-red-500/10 text-red-500/70 border-red-500/20 text-[10px]">
                                        LEGACY
                                    </Badge>
                                </div>
                            </TableCell>
                            <TableCell className="text-right text-zinc-500 text-xs">
                                {format(new Date(order.created_at), 'MMM dd, yyyy')}
                            </TableCell>
                        </TableRow>
                    ))}
                </TableBody>
            </Table>
        </div>
    );
}
