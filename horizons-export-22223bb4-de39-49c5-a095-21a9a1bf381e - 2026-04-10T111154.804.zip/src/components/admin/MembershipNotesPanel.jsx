import React, { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabaseClient';
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/components/ui/use-toast";
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { Loader2, Send, Edit2, Trash2, X, Check } from "lucide-react";
import { useAuth } from '@/contexts/AuthContext';

export default function MembershipNotesPanel({ applicationId, authorName }) {
  const { user } = useAuth();
  const { toast } = useToast();
  const [notes, setNotes] = useState([]);
  const [loading, setLoading] = useState(true);
  const [newNote, setNewNote] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [editingId, setEditingId] = useState(null);
  const [editContent, setEditContent] = useState("");

  const fetchNotes = async () => {
    try {
      const { data, error } = await supabase
        .from('membership_notes')
        .select('*')
        .eq('application_id', applicationId)
        .eq('is_deleted', false)
        .order('created_at', { ascending: false });

      if (error) throw error;
      setNotes(data || []);
    } catch (error) {
      console.error("Error fetching notes:", error);
      toast({ variant: "destructive", title: "Error", description: "Failed to load notes." });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (applicationId) {
      fetchNotes();
      
      const channel = supabase.channel(`notes-${applicationId}`)
        .on('postgres_changes', { 
            event: '*', 
            schema: 'public', 
            table: 'membership_notes',
            filter: `application_id=eq.${applicationId}`
        }, () => {
            fetchNotes();
        }).subscribe();

      return () => {
        supabase.removeChannel(channel);
      };
    }
  }, [applicationId]);

  const handleAddNote = async () => {
    if (!newNote.trim()) return;
    setSubmitting(true);
    try {
      const { error } = await supabase.from('membership_notes').insert([{
        application_id: applicationId,
        content: newNote.trim(),
        author_id: user?.id,
        author_name: authorName || user?.email || 'Admin',
      }]);

      if (error) throw error;
      setNewNote("");
      toast({ title: "Note added" });
    } catch (error) {
      toast({ variant: "destructive", title: "Error", description: error.message });
    } finally {
      setSubmitting(false);
    }
  };

  const handleUpdateNote = async (id) => {
    if (!editContent.trim()) return;
    try {
      const { error } = await supabase
        .from('membership_notes')
        .update({ 
            content: editContent.trim(), 
            updated_at: new Date().toISOString() 
        })
        .eq('id', id);

      if (error) throw error;
      setEditingId(null);
      setEditContent("");
      toast({ title: "Note updated" });
    } catch (error) {
      toast({ variant: "destructive", title: "Error", description: error.message });
    }
  };

  const handleDeleteNote = async (id) => {
    if (!confirm("Are you sure you want to delete this note?")) return;
    try {
      const { error } = await supabase
        .from('membership_notes')
        .update({ 
            is_deleted: true, 
            deleted_at: new Date().toISOString() 
        })
        .eq('id', id);

      if (error) throw error;
      toast({ title: "Note deleted" });
    } catch (error) {
      toast({ variant: "destructive", title: "Error", description: error.message });
    }
  };

  return (
    <div className="flex flex-col h-full bg-zinc-950 rounded-lg border border-zinc-800 p-4">
      {/* Input Area */}
      <div className="mb-6 space-y-2">
        <Textarea
          placeholder="Type a new note..."
          value={newNote}
          onChange={(e) => setNewNote(e.target.value)}
          className="bg-zinc-900 border-zinc-800 min-h-[100px] resize-none text-sm text-zinc-100 placeholder:text-zinc-500"
        />
        <div className="flex justify-end">
          <Button 
            onClick={handleAddNote} 
            disabled={!newNote.trim() || submitting}
            size="sm"
            className="bg-yellow-500 text-black hover:bg-yellow-400"
          >
            {submitting ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Send className="w-4 h-4 mr-2" />}
            Add Note
          </Button>
        </div>
      </div>

      {/* Notes List */}
      <div className="flex-1 overflow-y-auto space-y-4 pr-2 custom-scrollbar">
        {loading ? (
          <div className="flex justify-center py-8">
            <Loader2 className="w-6 h-6 animate-spin text-zinc-500" />
          </div>
        ) : notes.length === 0 ? (
          <div className="text-center py-8 text-zinc-500 text-sm italic">
            No notes yet. Be the first to add one.
          </div>
        ) : (
          notes.map((note) => (
            <div key={note.id} className="bg-zinc-900/50 rounded-lg p-4 border border-zinc-800/50 group">
              <div className="flex justify-between items-start mb-2">
                <div className="flex flex-col">
                  <span className="font-medium text-zinc-200 text-sm">{note.author_name}</span>
                  <span className="text-[11px] text-zinc-500">
                    {format(new Date(note.created_at), "dd 'de' MMMM, yyyy 'às' HH:mm", { locale: ptBR })}
                    {note.updated_at > note.created_at && " (editado)"}
                  </span>
                </div>
                
                <div className="opacity-0 group-hover:opacity-100 transition-opacity flex gap-1">
                  {editingId !== note.id && (
                    <>
                      <Button variant="ghost" size="icon" className="h-6 w-6 text-zinc-400 hover:text-white" onClick={() => { setEditingId(note.id); setEditContent(note.content); }}>
                        <Edit2 className="w-3 h-3" />
                      </Button>
                      <Button variant="ghost" size="icon" className="h-6 w-6 text-zinc-400 hover:text-red-400" onClick={() => handleDeleteNote(note.id)}>
                        <Trash2 className="w-3 h-3" />
                      </Button>
                    </>
                  )}
                </div>
              </div>

              {editingId === note.id ? (
                <div className="space-y-2 mt-2">
                  <Textarea
                    value={editContent}
                    onChange={(e) => setEditContent(e.target.value)}
                    className="bg-zinc-950 border-zinc-700 text-sm text-white"
                  />
                  <div className="flex justify-end gap-2">
                    <Button variant="ghost" size="sm" onClick={() => setEditingId(null)}>
                      <X className="w-3 h-3 mr-1" /> Cancel
                    </Button>
                    <Button size="sm" className="bg-green-600 hover:bg-green-500 text-white" onClick={() => handleUpdateNote(note.id)}>
                      <Check className="w-3 h-3 mr-1" /> Save
                    </Button>
                  </div>
                </div>
              ) : (
                <div className="text-sm text-zinc-300 whitespace-pre-wrap">{note.content}</div>
              )}
            </div>
          ))
        )}
      </div>
    </div>
  );
}