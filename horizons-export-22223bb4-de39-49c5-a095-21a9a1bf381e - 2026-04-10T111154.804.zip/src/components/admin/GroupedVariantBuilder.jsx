import React, { useState, useMemo } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Plus, Trash2 } from 'lucide-react';
import AddItemToGroupModal from './AddItemToGroupModal';

export default function GroupedVariantBuilder({ variants = [], onVariantsChange }) {
  const [newGroupName, setNewGroupName] = useState('');
  const [modalGroup, setModalGroup] = useState(null);

  // Derive unique groups from current variants
  const groups = useMemo(() => {
    const groupNames = new Set();
    variants.forEach(v => {
      if (v.variant_group) groupNames.add(v.variant_group);
    });
    return Array.from(groupNames);
  }, [variants]);

  const handleCreateGroup = () => {
    const name = newGroupName.trim();
    if (!name) return;
    if (groups.includes(name)) {
      alert("Group already exists.");
      return;
    }
    console.log("Group created:", name);
    // Open modal immediately to add first item to the new group
    setModalGroup(name);
    setNewGroupName('');
  };

  const handleDeleteGroup = (groupName) => {
    if (!confirm(`Are you sure you want to delete the group "${groupName}" and all its items?`)) return;
    console.log("Group deleted:", groupName);
    const newVariants = variants.filter(v => v.variant_group !== groupName);
    onVariantsChange(newVariants);
  };

  const handleAddItem = (newVariant) => {
    console.log("Item added to group:", newVariant.variant_group, newVariant);
    onVariantsChange([...variants, newVariant]);
  };

  return (
    <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-6 mb-8">
      <h3 className="text-lg font-semibold mb-4">Grouped Variant Builder</h3>
      
      <div className="flex items-end gap-4 mb-8">
        <div className="flex-1 max-w-sm">
          <Label className="mb-2 block text-zinc-400">Create New Group</Label>
          <Input 
            value={newGroupName} 
            onChange={e => setNewGroupName(e.target.value)} 
            placeholder="e.g., SNAIL LOCK"
            className="bg-zinc-950 border-zinc-800"
            onKeyDown={e => e.key === 'Enter' && handleCreateGroup()}
          />
        </div>
        <Button onClick={handleCreateGroup} variant="secondary" className="bg-zinc-800 hover:bg-zinc-700 text-white">
          <Plus className="w-4 h-4 mr-2" /> Add Group
        </Button>
      </div>

      <div className="space-y-6">
        {groups.map(groupName => {
          const groupItems = variants.filter(v => v.variant_group === groupName);
          
          return (
            <div key={groupName} className="border border-zinc-800 rounded-lg p-4 bg-zinc-950/50">
              <div className="flex items-center justify-between mb-4">
                <h4 className="font-bold text-lg text-white">{groupName}</h4>
                <div className="flex gap-2">
                  <Button size="sm" variant="outline" className="border-zinc-700" onClick={() => setModalGroup(groupName)}>
                    <Plus className="w-3 h-3 mr-2" /> Add Item
                  </Button>
                  <Button size="sm" variant="ghost" className="text-red-400 hover:text-red-300 hover:bg-red-500/10" onClick={() => handleDeleteGroup(groupName)}>
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </div>
              
              {groupItems.length === 0 ? (
                <p className="text-sm text-zinc-500 italic">No items in this group yet.</p>
              ) : (
                <div className="flex flex-wrap gap-2">
                  {groupItems.map(item => (
                    <div key={item.id} className="px-3 py-1.5 bg-zinc-900 border border-zinc-700 rounded-md text-sm text-zinc-300">
                      {item.variant_label}
                    </div>
                  ))}
                </div>
              )}
            </div>
          );
        })}
        {groups.length === 0 && (
          <p className="text-sm text-zinc-500 text-center py-4">No groups created yet. Create a group to start adding variants.</p>
        )}
      </div>

      <AddItemToGroupModal 
        isOpen={!!modalGroup} 
        onClose={() => setModalGroup(null)} 
        groupName={modalGroup} 
        onAdd={handleAddItem} 
      />
    </div>
  );
}