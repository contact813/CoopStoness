
import React, { useState, useEffect, useRef } from 'react';
import { fetchUniqueTags } from '@/lib/adminProductsApi';
import { X, Loader2 } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { cn } from '@/lib/utils';

export default function TagsMultiSelect({ value = [], onChange, className }) {
  const [inputValue, setInputValue] = useState('');
  const [allTags, setAllTags] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [suggestions, setSuggestions] = useState([]);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const wrapperRef = useRef(null);

  useEffect(() => {
    const loadTags = async () => {
      setIsLoading(true);
      try {
        const { data, error } = await fetchUniqueTags();
        if (error) {
          console.error("[TagsMultiSelect] Error fetching tags:", error);
          setAllTags([]);
        } else {
          setAllTags(data || []);
        }
      } catch (err) {
        console.error("[TagsMultiSelect] Exception fetching tags:", err);
        setAllTags([]);
      } finally {
        setIsLoading(false);
      }
    };
    
    loadTags();
  }, []);

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (wrapperRef.current && !wrapperRef.current.contains(event.target)) {
        setShowSuggestions(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const handleInputChange = (e) => {
    const val = e.target.value;
    setInputValue(val);
    if (val.trim()) {
      const filtered = allTags.filter(t => 
        t.toLowerCase().includes(val.toLowerCase()) && 
        !value.includes(t)
      );
      setSuggestions(filtered);
      setShowSuggestions(true);
    } else {
      setShowSuggestions(false);
    }
  };

  const addTag = (tag) => {
    const normalized = tag.trim();
    if (normalized && !value.includes(normalized)) {
      onChange([...value, normalized]);
    }
    setInputValue('');
    setShowSuggestions(false);
  };

  const removeTag = (tagToRemove) => {
    onChange(value.filter(t => t !== tagToRemove));
  };

  const handleKeyDown = (e) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      addTag(inputValue);
    }
  };

  return (
    <div className={cn("relative space-y-2", className)} ref={wrapperRef}>
      <div className="flex flex-wrap gap-2 mb-2">
        {value.map(tag => (
          <Badge key={tag} variant="secondary" className="bg-zinc-800 text-zinc-100 hover:bg-zinc-700 px-2 py-1 flex items-center gap-1">
            {tag}
            <button 
              type="button" 
              onClick={() => removeTag(tag)}
              className="text-zinc-400 hover:text-white"
            >
              <X size={14} />
            </button>
          </Badge>
        ))}
      </div>
      
      <div className="relative">
        <Input
          type="text"
          value={inputValue}
          onChange={handleInputChange}
          onKeyDown={handleKeyDown}
          onFocus={() => {
              if(inputValue) setShowSuggestions(true);
          }}
          placeholder="Type tag and press Enter..."
          className="bg-zinc-950 border-zinc-800"
          disabled={isLoading}
        />
        
        {isLoading && (
          <div className="absolute right-3 top-1/2 -translate-y-1/2">
            <Loader2 className="w-4 h-4 text-zinc-500 animate-spin" />
          </div>
        )}
        
        {showSuggestions && suggestions.length > 0 && (
          <div className="absolute z-10 w-full mt-1 bg-zinc-900 border border-zinc-800 rounded-md shadow-lg max-h-60 overflow-auto">
            {suggestions.map(tag => (
              <button
                key={tag}
                type="button"
                className="w-full text-left px-4 py-2 text-sm text-zinc-300 hover:bg-zinc-800 hover:text-white transition-colors"
                onClick={() => addTag(tag)}
              >
                {tag}
              </button>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
