import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { v4 as uuidv4 } from 'uuid';

export default function AddItemToGroupModal({ isOpen, onClose, groupName, onAdd }) {
  const [formData, setFormData] = useState({
    variant_label: '',
    price: 0,
    inventory_qty: 0,
    sku: '',
    barcode: '',
    image_url: ''
  });

  const handleChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleSave = () => {
    if (!formData.variant_label.trim()) {
      alert("Variant label is required.");
      return;
    }

    const newVariant = {
      id: `temp-${uuidv4()}`,
      is_temp: true,
      variant_group: groupName,
      variant_label: formData.variant_label,
      title: formData.variant_label, // Fallback title
      price: parseFloat(formData.price) || 0,
      inventory_qty: parseInt(formData.inventory_qty) || 0,
      sku: formData.sku,
      barcode: formData.barcode,
      image_url: formData.image_url,
      discount_type: 'percentage',
      discount_value: 0
    };

    onAdd(newVariant);
    setFormData({ variant_label: '', price: 0, inventory_qty: 0, sku: '', barcode: '', image_url: '' });
    onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="bg-zinc-900 border-zinc-800 text-white sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>Add Item to "{groupName}"</DialogTitle>
        </DialogHeader>
        <div className="grid gap-4 py-4">
          <div className="grid gap-2">
            <Label>Variant Label (e.g., 24 GRIT) *</Label>
            <Input 
              value={formData.variant_label} 
              onChange={e => handleChange('variant_label', e.target.value)} 
              className="bg-zinc-950 border-zinc-800"
              placeholder="Label"
            />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div className="grid gap-2">
              <Label>Price</Label>
              <Input 
                type="number" 
                value={formData.price} 
                onChange={e => handleChange('price', e.target.value)} 
                className="bg-zinc-950 border-zinc-800"
                min="0" step="0.01"
              />
            </div>
            <div className="grid gap-2">
              <Label>Stock</Label>
              <Input 
                type="number" 
                value={formData.inventory_qty} 
                onChange={e => handleChange('inventory_qty', e.target.value)} 
                className="bg-zinc-950 border-zinc-800"
                min="0"
              />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div className="grid gap-2">
              <Label>SKU</Label>
              <Input 
                value={formData.sku} 
                onChange={e => handleChange('sku', e.target.value)} 
                className="bg-zinc-950 border-zinc-800"
              />
            </div>
            <div className="grid gap-2">
              <Label>Barcode</Label>
              <Input 
                value={formData.barcode} 
                onChange={e => handleChange('barcode', e.target.value)} 
                className="bg-zinc-950 border-zinc-800"
              />
            </div>
          </div>
          <div className="grid gap-2">
            <Label>Image URL (Optional)</Label>
            <Input 
              value={formData.image_url} 
              onChange={e => handleChange('image_url', e.target.value)} 
              className="bg-zinc-950 border-zinc-800"
              placeholder="https://..."
            />
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose} className="border-zinc-700 text-zinc-300">Cancel</Button>
          <Button onClick={handleSave} className="bg-yellow-500 text-black hover:bg-yellow-400">Add Item</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}