import React from 'react';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Trash2, Plus } from 'lucide-react';
import { v4 as uuidv4 } from 'uuid';

export default function VariantsTable({ variants = [], onChange }) {
  
  const handleAdd = () => {
    const newVariant = {
        _tempId: uuidv4(), // Temporary ID for list key
        title: "New Variant",
        sku: "",
        price: 0,
        inventory_qty: 0,
        barcode: ""
    };
    onChange([...variants, newVariant]);
  };

  const handleRemove = (index) => {
    const newVars = [...variants];
    newVars.splice(index, 1);
    onChange(newVars);
  };

  const handleUpdate = (index, field, value) => {
    const newVars = [...variants];
    newVars[index] = { ...newVars[index], [field]: value };
    onChange(newVars);
  };

  return (
    <div className="space-y-4">
      <div className="rounded-md border border-zinc-800 overflow-hidden">
        <Table>
          <TableHeader className="bg-zinc-900">
            <TableRow className="border-zinc-800 hover:bg-zinc-900">
              <TableHead className="text-zinc-400">Title</TableHead>
              <TableHead className="text-zinc-400">SKU <span className="text-red-500">*</span></TableHead>
              <TableHead className="text-zinc-400">Price <span className="text-red-500">*</span></TableHead>
              <TableHead className="text-zinc-400">Inventory <span className="text-red-500">*</span></TableHead>
              <TableHead className="text-zinc-400">Barcode</TableHead>
              <TableHead className="w-[50px]"></TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {variants.length === 0 && (
                <TableRow>
                    <TableCell colSpan={6} className="text-center text-zinc-500 py-6">
                        No variants added. Product will be treated as simple product.
                    </TableCell>
                </TableRow>
            )}
            {variants.map((v, idx) => (
              <TableRow key={v.id || v._tempId} className="border-zinc-800 hover:bg-zinc-900/50">
                <TableCell>
                    <Input 
                        value={v.title} 
                        onChange={e => handleUpdate(idx, 'title', e.target.value)} 
                        className="h-8 bg-zinc-950 border-zinc-800"
                        placeholder="e.g. Small / Red"
                    />
                </TableCell>
                <TableCell>
                    <Input 
                        value={v.sku} 
                        onChange={e => handleUpdate(idx, 'sku', e.target.value)} 
                        className="h-8 bg-zinc-950 border-zinc-800"
                        placeholder="SKU-123"
                    />
                </TableCell>
                <TableCell>
                    <Input 
                        type="number"
                        value={v.price} 
                        onChange={e => handleUpdate(idx, 'price', e.target.value)} 
                        className="h-8 bg-zinc-950 border-zinc-800 w-24"
                    />
                </TableCell>
                <TableCell>
                    <Input 
                        type="number"
                        value={v.inventory_qty} 
                        onChange={e => handleUpdate(idx, 'inventory_qty', e.target.value)} 
                        className="h-8 bg-zinc-950 border-zinc-800 w-24"
                    />
                </TableCell>
                <TableCell>
                    <Input 
                        value={v.barcode} 
                        onChange={e => handleUpdate(idx, 'barcode', e.target.value)} 
                        className="h-8 bg-zinc-950 border-zinc-800"
                    />
                </TableCell>
                <TableCell>
                    <Button variant="ghost" size="icon" onClick={() => handleRemove(idx)} className="h-8 w-8 text-red-500 hover:text-red-400 hover:bg-red-950/20">
                        <Trash2 size={14} />
                    </Button>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
      <Button onClick={handleAdd} variant="outline" size="sm" className="border-zinc-800 text-zinc-300 hover:text-white hover:bg-zinc-800">
        <Plus className="w-4 h-4 mr-2" /> Add Variant
      </Button>
    </div>
  );
}