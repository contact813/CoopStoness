import React, { useState, useEffect } from 'react';
import { Badge } from '@/components/ui/badge';
import { Checkbox } from "@/components/ui/checkbox";
import { X } from 'lucide-react';
import { fetchAllCollectionsWithCounts } from '@/lib/adminProductsApi';
import { Label } from "@/components/ui/label";
import {
  DropdownMenu,
  DropdownMenuCheckboxItem,
  DropdownMenuContent,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Button } from '@/components/ui/button';

export default function MultiSelectCollections({ value = [], onChange }) {
  const [allCollections, setAllCollections] = useState([]);

  useEffect(() => {
    fetchAllCollectionsWithCounts().then(setAllCollections);
  }, []);

  const handleToggle = (id) => {
    if (value.includes(id)) {
      onChange(value.filter(v => v !== id));
    } else {
      onChange([...value, id]);
    }
  };

  const selectedObjects = allCollections.filter(c => value.includes(c.id));

  return (
    <div className="space-y-3">
      <div className="flex flex-wrap gap-2">
        {selectedObjects.map(col => (
          <Badge key={col.id} variant="secondary" className="px-3 py-1 bg-blue-900/30 text-blue-200 border border-blue-800">
            {col.title}
            <button onClick={() => handleToggle(col.id)} className="ml-2 hover:text-red-400">
              <X size={12} />
            </button>
          </Badge>
        ))}
      </div>
      
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button variant="outline" className="w-full justify-between bg-zinc-900 border-zinc-800 text-zinc-300">
            {value.length > 0 ? `${value.length} selected` : "Select collections"}
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent className="w-56 bg-zinc-900 border-zinc-800 text-zinc-300 max-h-[300px] overflow-y-auto">
          <DropdownMenuLabel>Collections</DropdownMenuLabel>
          <DropdownMenuSeparator className="bg-zinc-800" />
          {allCollections.map(col => (
            <DropdownMenuCheckboxItem
              key={col.id}
              checked={value.includes(col.id)}
              onCheckedChange={() => handleToggle(col.id)}
              className="text-zinc-300 focus:bg-zinc-800 focus:text-white"
            >
              {col.title} <span className="ml-auto text-xs opacity-50">({col.products_count})</span>
            </DropdownMenuCheckboxItem>
          ))}
        </DropdownMenuContent>
      </DropdownMenu>
    </div>
  );
}