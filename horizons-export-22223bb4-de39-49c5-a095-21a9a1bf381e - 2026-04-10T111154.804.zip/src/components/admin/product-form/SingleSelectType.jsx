import React, { useState, useEffect } from 'react';
import { getUniqueTypes } from '@/lib/adminProductsApi';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Plus } from 'lucide-react';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

export default function SingleSelectType({ value, onChange }) {
  const [types, setTypes] = useState([]);
  const [isCreating, setIsCreating] = useState(false);
  const [newType, setNewType] = useState("");

  useEffect(() => {
    getUniqueTypes().then(setTypes);
  }, []);

  const handleCreate = () => {
    if (newType.trim()) {
        const v = newType.trim();
        setTypes(prev => [...prev, v].sort());
        onChange(v);
        setIsCreating(false);
        setNewType("");
    }
  };

  if (isCreating) {
    return (
        <div className="flex gap-2">
            <Input 
                value={newType} 
                onChange={e => setNewType(e.target.value)} 
                placeholder="New Product Type"
                className="bg-zinc-900 border-zinc-800"
            />
            <Button onClick={handleCreate} size="sm" className="bg-green-600 hover:bg-green-500">Save</Button>
            <Button onClick={() => setIsCreating(false)} size="sm" variant="ghost">Cancel</Button>
        </div>
    );
  }

  return (
    <div className="flex gap-2">
        <Select value={value} onValueChange={onChange}>
            <SelectTrigger className="w-full bg-zinc-900 border-zinc-800">
                <SelectValue placeholder="Select type" />
            </SelectTrigger>
            <SelectContent className="bg-zinc-900 border-zinc-800">
                {types.map(v => (
                    <SelectItem key={v} value={v} className="text-zinc-300 focus:bg-zinc-800 focus:text-white">{v}</SelectItem>
                ))}
            </SelectContent>
        </Select>
        <Button onClick={() => setIsCreating(true)} size="icon" variant="outline" className="shrink-0 border-zinc-800 bg-zinc-900">
            <Plus size={16} />
        </Button>
    </div>
  );
}