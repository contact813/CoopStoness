import React, { useState, useEffect } from 'react';
import { getUniqueVendors } from '@/lib/adminProductsApi';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Plus } from 'lucide-react';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

export default function SingleSelectVendor({ value, onChange }) {
  const [vendors, setVendors] = useState([]);
  const [isCreating, setIsCreating] = useState(false);
  const [newVendor, setNewVendor] = useState("");

  useEffect(() => {
    getUniqueVendors().then(setVendors);
  }, []);

  const handleCreate = () => {
    if (newVendor.trim()) {
        const v = newVendor.trim();
        setVendors(prev => [...prev, v].sort());
        onChange(v);
        setIsCreating(false);
        setNewVendor("");
    }
  };

  if (isCreating) {
    return (
        <div className="flex gap-2">
            <Input 
                value={newVendor} 
                onChange={e => setNewVendor(e.target.value)} 
                placeholder="New Vendor Name"
                className="bg-zinc-900 border-zinc-800"
            />
            <Button onClick={handleCreate} size="sm" className="bg-green-600 hover:bg-green-500">Save</Button>
            <Button onClick={() => setIsCreating(false)} size="sm" variant="ghost">Cancel</Button>
        </div>
    );
  }

  return (
    <div className="flex gap-2">
        <Select value={value} onValueChange={onChange}>
            <SelectTrigger className="w-full bg-zinc-900 border-zinc-800">
                <SelectValue placeholder="Select vendor" />
            </SelectTrigger>
            <SelectContent className="bg-zinc-900 border-zinc-800">
                {vendors.map(v => (
                    <SelectItem key={v} value={v} className="text-zinc-300 focus:bg-zinc-800 focus:text-white">{v}</SelectItem>
                ))}
            </SelectContent>
        </Select>
        <Button onClick={() => setIsCreating(true)} size="icon" variant="outline" className="shrink-0 border-zinc-800 bg-zinc-900">
            <Plus size={16} />
        </Button>
    </div>
  );
}