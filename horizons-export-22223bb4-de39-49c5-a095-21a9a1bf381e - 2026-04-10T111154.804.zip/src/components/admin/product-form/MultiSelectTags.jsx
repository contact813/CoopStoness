import React, { useState, useEffect } from 'react';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { X, Plus } from 'lucide-react';
import { fetchAllTags } from '@/lib/adminProductsApi';

export default function MultiSelectTags({ value = "", onChange }) {
  const [tags, setTags] = useState([]);
  const [input, setInput] = useState('');
  const [suggestions, setSuggestions] = useState([]);
  const [allTags, setAllTags] = useState([]);

  useEffect(() => {
    // Parse CSV string to array
    if (value) {
      setTags(value.split(',').map(t => t.trim()).filter(Boolean));
    } else {
        setTags([]);
    }
  }, [value]);

  useEffect(() => {
    fetchAllTags().then(setAllTags);
  }, []);

  const handleAdd = (tagToAdd) => {
    const trimmed = tagToAdd.trim();
    if (trimmed && !tags.includes(trimmed)) {
      const newTags = [...tags, trimmed];
      onChange(newTags.join(', '));
    }
    setInput('');
    setSuggestions([]);
  };

  const handleRemove = (tagToRemove) => {
    const newTags = tags.filter(t => t !== tagToRemove);
    onChange(newTags.join(', '));
  };

  const handleInput = (e) => {
    const val = e.target.value;
    setInput(val);
    if (val.length > 1) {
        setSuggestions(allTags.filter(t => t.toLowerCase().includes(val.toLowerCase()) && !tags.includes(t)));
    } else {
        setSuggestions([]);
    }
  };

  const handleKeyDown = (e) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      handleAdd(input);
    }
  };

  return (
    <div className="space-y-3">
      <div className="flex flex-wrap gap-2 mb-2">
        {tags.map(tag => (
          <Badge key={tag} variant="secondary" className="px-3 py-1 bg-zinc-800 text-zinc-200 hover:bg-zinc-700">
            {tag}
            <button onClick={() => handleRemove(tag)} className="ml-2 hover:text-red-400">
              <X size={12} />
            </button>
          </Badge>
        ))}
      </div>
      <div className="relative">
        <div className="flex gap-2">
            <Input 
                value={input}
                onChange={handleInput}
                onKeyDown={handleKeyDown}
                placeholder="Add a tag..."
                className="bg-zinc-900 border-zinc-800"
            />
            <Button type="button" onClick={() => handleAdd(input)} variant="outline" size="icon">
                <Plus size={16} />
            </Button>
        </div>
        {suggestions.length > 0 && (
            <div className="absolute z-10 w-full mt-1 bg-zinc-800 border border-zinc-700 rounded-md shadow-lg max-h-40 overflow-y-auto">
                {suggestions.map(s => (
                    <div 
                        key={s} 
                        className="px-3 py-2 hover:bg-zinc-700 cursor-pointer text-sm"
                        onClick={() => handleAdd(s)}
                    >
                        {s}
                    </div>
                ))}
            </div>
        )}
      </div>
    </div>
  );
}