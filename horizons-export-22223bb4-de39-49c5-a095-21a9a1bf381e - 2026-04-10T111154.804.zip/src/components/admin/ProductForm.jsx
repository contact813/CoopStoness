
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '@/lib/supabaseClient';
import { getProductById, updateProduct, createProduct } from '@/lib/adminProductsApi';
import { uploadProductImage } from '@/lib/storageApi';
import MatrixOptionsBuilder from './MatrixOptionsBuilder';
import ImageGalleryPreview from './ImageGalleryPreview';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Loader2, Save, ArrowLeft, AlertCircle, Package, Image as ImageIcon, UploadCloud, CheckCircle2 } from 'lucide-react';
import { sanitizeUuid } from '@/lib/idUtils';

// Helper to validate URLs
const isValidImageUrl = (url) => {
    if (!url || typeof url !== 'string') return false;
    return url.startsWith('http://') || url.startsWith('https://');
};

export default function ProductForm({ productId }) {
    const navigate = useNavigate();
    
    const [title, setTitle] = useState('');
    const [description, setDescription] = useState('');
    const [thumbnailUrl, setThumbnailUrl] = useState('');
    const [vendor, setVendor] = useState('');
    const [type, setType] = useState('');
    const [inventory, setInventory] = useState(0);
    const [status, setStatus] = useState('active');
    const [price, setPrice] = useState(0);
    
    const [matrixOptions, setMatrixOptions] = useState([]);
    const [matrixVariants, setMatrixVariants] = useState([]);
    const [variantPrices, setVariantPrices] = useState({});
    const [variantCompareAtPrices, setVariantCompareAtPrices] = useState({});
    const [variantSkus, setVariantSkus] = useState({});
    
    const [loading, setLoading] = useState(false);
    
    // Image Upload State
    const [imageUploading, setImageUploading] = useState(false);
    const [uploadSuccess, setUploadSuccess] = useState(false);
    const [uploadError, setUploadError] = useState(null);
    
    const [initialLoading, setInitialLoading] = useState(true);
    const [error, setError] = useState(null);

    useEffect(() => {
        const loadProductData = async () => {
            if (!productId || productId === 'new') {
                setInitialLoading(false);
                return;
            }
            try {
                console.log(`[ProductForm] Loading product: ${productId}`);
                const { data: p, error: pErr } = await getProductById(productId);
                
                if (pErr) throw pErr;
                
                if (p) {
                    console.log('[ProductForm] Loaded product data successfully.');
                    setTitle(p.title || '');
                    setDescription(p.description || '');
                    setThumbnailUrl(p.thumbnail_url || '');
                    setVendor(p.vendor || '');
                    setType(p.type || '');
                    setInventory(p.inventory || 0);
                    setStatus(p.status || 'active');
                    setPrice(p.price || 0);
                } else {
                    console.warn(`[ProductForm] Product ${productId} not found.`);
                    throw new Error("Product not found.");
                }

                const cleanId = sanitizeUuid(productId);
                // Load options and variants specifically for matrix state setup
                const { data: opts } = await supabase.from('product_options').select('*, values:product_option_values(*)').eq('product_id', cleanId).order('position');
                if (opts) {
                    setMatrixOptions(opts.map(o => ({
                        name: o.name,
                        values: o.values.sort((a,b) => a.position - b.position).map(v => v.value)
                    })));
                }

                const { data: vars } = await supabase.from('product_variants').select('*').eq('product_id', cleanId).order('position');
                if (vars) {
                    const vPrices = {};
                    const vCompare = {};
                    const vSkus = {};
                    vars.forEach(v => {
                        vPrices[v.title] = v.price || '';
                        vCompare[v.title] = v.compare_at_price || '';
                        vSkus[v.title] = v.sku || '';
                    });
                    setVariantPrices(vPrices);
                    setVariantCompareAtPrices(vCompare);
                    setVariantSkus(vSkus);
                }
            } catch (err) {
                console.error("[ProductForm] Load error:", err);
                setError(err.message || "Failed to load product details.");
            } finally {
                setInitialLoading(false);
            }
        };
        loadProductData();
    }, [productId]);

    const handleProductImageUpload = async (e) => {
        const file = e.target.files?.[0];
        if (!file) return;

        console.log('[ProductForm] Starting image upload for file:', file.name);
        setImageUploading(true);
        setUploadError(null);
        setUploadSuccess(false);
        
        try {
            const uploadProductId = productId === 'new' ? 'temp' : sanitizeUuid(productId);
            
            // 1. Call uploadImage (which returns a string)
            const publicUrl = await uploadProductImage(file, uploadProductId);
            console.log('[ProductForm] Returned URL from storage API:', publicUrl);
            
            // 2. Immediately update state ONLY (no DB call here to avoid duplicate updates)
            setThumbnailUrl(publicUrl);
            
            // 3. Show success feedback
            setUploadSuccess(true);
            setTimeout(() => setUploadSuccess(false), 3000);
        } catch (err) {
            console.error("[ProductForm] Image upload error:", err);
            setUploadError(err.message || "Failed to upload image.");
        } finally {
            setImageUploading(false);
            if (e.target) e.target.value = null;
        }
    };

    const handleVariantsGenerate = (generatedVariants) => {
        setMatrixVariants(generatedVariants);
        const newPrices = { ...variantPrices };
        const newCompare = { ...variantCompareAtPrices };
        const newSkus = { ...variantSkus };
        generatedVariants.forEach(v => {
            if (!(v.title in newPrices)) newPrices[v.title] = '';
            if (!(v.title in newCompare)) newCompare[v.title] = '';
            if (!(v.title in newSkus)) newSkus[v.title] = '';
        });
        setVariantPrices(newPrices);
        setVariantCompareAtPrices(newCompare);
        setVariantSkus(newSkus);
    };

    const handleSaveProduct = async () => {
        try {
            setLoading(true);
            setError(null);
            
            if (!title.trim()) throw new Error("Product title is required.");
            if (!description.trim()) throw new Error("Product description is required.");

            let currentProductId = productId !== 'new' ? sanitizeUuid(productId) : null;
            
            // Ensure all required fields are included in the payload
            const productData = { 
                title: title.trim(), 
                description: description.trim(), 
                thumbnail_url: thumbnailUrl || null,
                vendor,
                type,
                inventory: parseInt(inventory) || 0,
                status,
                price: parseFloat(price) || 0,
                updated_at: new Date().toISOString()
            };
            
            console.log('[ProductForm] Submitting payload for save:', productData);
            
            if (!currentProductId) {
                const { data: pData, error: pErr } = await createProduct(productData);
                if (pErr) throw pErr;
                currentProductId = pData?.id;
                console.log('[ProductForm] Successfully created product:', currentProductId);
            } else {
                const { error: pErr } = await updateProduct(currentProductId, productData);
                if (pErr) throw pErr;
                console.log('[ProductForm] Successfully updated product:', currentProductId);
            }

            navigate('/admin/products');

        } catch (err) {
            console.error("[ProductForm] Save error:", err);
            setError(err.message || "An error occurred while saving the product.");
            window.scrollTo({ top: 0, behavior: 'smooth' });
        } finally {
            setLoading(false);
        }
    };

    if (initialLoading) {
        return (
            <div className="flex flex-col justify-center items-center h-[50vh] space-y-4">
                <Loader2 className="w-10 h-10 animate-spin text-yellow-500" />
                <p className="text-zinc-500 font-medium">Loading Product Matrix...</p>
            </div>
        );
    }

    return (
        <div className="space-y-8 pb-12 max-w-[1400px] mx-auto">
            {error && (
                <Alert variant="destructive" className="bg-red-950/40 border-red-900 shadow-sm animate-in fade-in zoom-in duration-300">
                    <AlertCircle className="h-4 w-4" />
                    <AlertTitle className="font-bold">Error</AlertTitle>
                    <AlertDescription className="text-red-200 mt-1">{error}</AlertDescription>
                </Alert>
            )}

            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center bg-zinc-900 p-4 rounded-xl border border-zinc-800 shadow-sm gap-4 sticky top-4 z-10">
                <div className="flex items-center gap-4">
                    <Button variant="ghost" onClick={() => navigate('/admin/products')} className="text-zinc-400 hover:text-white bg-zinc-950">
                        <ArrowLeft className="w-4 h-4 mr-2" /> Back
                    </Button>
                    <div className="flex items-center gap-2">
                        <Package className="w-5 h-5 text-yellow-500 hidden sm:block" />
                        <h2 className="text-xl font-bold text-white tracking-tight">Product Form</h2>
                    </div>
                </div>
                <Button onClick={handleSaveProduct} disabled={loading || imageUploading} className="bg-yellow-500 text-black hover:bg-yellow-400 font-bold uppercase tracking-wider w-full sm:w-auto">
                    {loading ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Save className="w-4 h-4 mr-2" />}
                    Save Product
                </Button>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                <div className="lg:col-span-2 space-y-8">
                    {/* Basic Info Section */}
                    <div className="bg-zinc-900 border border-zinc-800 p-6 rounded-xl space-y-5 shadow-sm">
                        <h3 className="text-lg font-semibold text-white border-b border-zinc-800 pb-2">Basic Information</h3>
                        <div>
                            <Label className="text-zinc-400 font-medium mb-1.5 block">Product Title <span className="text-red-500">*</span></Label>
                            <Input 
                                value={title} 
                                onChange={(e) => setTitle(e.target.value)} 
                                className="bg-zinc-950 border-zinc-800 text-white"
                                placeholder="Enter product title..."
                            />
                        </div>
                        <div>
                            <Label className="text-zinc-400 font-medium mb-1.5 block">Description <span className="text-red-500">*</span></Label>
                            <Textarea 
                                value={description} 
                                onChange={(e) => setDescription(e.target.value)} 
                                className="bg-zinc-950 border-zinc-800 text-white h-32 resize-y"
                                placeholder="Enter product description..."
                            />
                        </div>
                    </div>

                    {/* Gallery Images Section */}
                    <div className="bg-zinc-900 border border-zinc-800 p-6 rounded-xl space-y-6 shadow-sm">
                        <h3 className="text-lg font-semibold text-white border-b border-zinc-800 pb-2 flex items-center justify-between">
                            <span className="flex items-center gap-2"><ImageIcon className="w-5 h-5 text-zinc-400" /> Gallery Images</span>
                            {imageUploading && <Loader2 className="w-4 h-4 text-yellow-500 animate-spin" />}
                        </h3>
                        
                        {uploadError && (
                            <Alert variant="destructive" className="bg-red-950/40 border-red-900 shadow-sm mb-4 py-3">
                                <AlertCircle className="h-4 w-4" />
                                <AlertTitle>Upload Error</AlertTitle>
                                <AlertDescription className="text-red-200">{uploadError}</AlertDescription>
                            </Alert>
                        )}
                        
                        {uploadSuccess && (
                            <div className="bg-green-500/10 border border-green-500/20 text-green-400 p-3 rounded-lg flex items-center gap-2 mb-4 animate-in fade-in duration-300">
                                <CheckCircle2 className="w-5 h-5 text-green-500" />
                                <span className="font-medium">✅ Imagem salva com sucesso!</span>
                            </div>
                        )}

                        <div className="flex flex-col md:flex-row gap-6 items-start">
                            {/* Preview Area */}
                            <div className="w-32 relative flex flex-col gap-2">
                                <Label className="text-zinc-400 font-medium text-sm">Imagem Atual:</Label>
                                <div className="w-32 h-32 relative">
                                    {isValidImageUrl(thumbnailUrl) ? (
                                        <ImageGalleryPreview 
                                            imageUrl={thumbnailUrl} 
                                            title={title} 
                                            onRemove={() => setThumbnailUrl('')} 
                                        />
                                    ) : (
                                        <div className="w-full h-full rounded-lg border-2 border-dashed border-zinc-700 bg-zinc-950 flex flex-col items-center justify-center text-zinc-500">
                                            <ImageIcon className="w-8 h-8 mx-auto mb-2 opacity-50" />
                                            <p className="text-xs text-center px-2">No image selected</p>
                                        </div>
                                    )}
                                    
                                    {imageUploading && (
                                        <div className="absolute inset-0 bg-black/60 rounded-lg flex items-center justify-center backdrop-blur-sm z-10">
                                            <div className="flex flex-col items-center gap-2">
                                                <Loader2 className="w-6 h-6 text-yellow-500 animate-spin" />
                                                <span className="text-[10px] font-medium text-white">Uploading...</span>
                                            </div>
                                        </div>
                                    )}
                                </div>
                            </div>
                            
                            {/* Upload Area */}
                            <div className="flex-1 space-y-5">
                                <div className="p-4 border border-zinc-800 bg-zinc-950 rounded-lg">
                                    <Label className="text-zinc-300 font-medium mb-3 block text-sm">Upload New Image</Label>
                                    <div className="flex items-center gap-4">
                                        <Label 
                                            htmlFor="image-upload" 
                                            className={`flex-1 flex flex-col items-center justify-center gap-2 border-2 border-dashed border-zinc-700 hover:border-yellow-500 hover:bg-zinc-900 bg-zinc-950 text-zinc-400 hover:text-white px-4 py-8 rounded-lg cursor-pointer transition-all ${imageUploading ? 'opacity-50 pointer-events-none' : ''}`}
                                        >
                                            <UploadCloud className="w-8 h-8 mb-1" />
                                            <span className="font-medium">{imageUploading ? 'Uploading...' : 'Click to select a file'}</span>
                                            <span className="text-xs text-zinc-500">JPEG, PNG, WebP, GIF (Max 5MB)</span>
                                        </Label>
                                        <Input 
                                            id="image-upload" 
                                            type="file" 
                                            accept="image/jpeg, image/png, image/webp, image/gif" 
                                            onChange={handleProductImageUpload} 
                                            className="hidden" 
                                            disabled={imageUploading}
                                        />
                                    </div>
                                </div>
                                
                                <div>
                                    <Label className="text-zinc-400 font-medium mb-1.5 block text-sm">Or Enter Image URL</Label>
                                    <Input 
                                        value={thumbnailUrl} 
                                        onChange={(e) => setThumbnailUrl(e.target.value)} 
                                        className="bg-zinc-950 border-zinc-800 text-white"
                                        placeholder="https://..."
                                        disabled={imageUploading}
                                    />
                                </div>
                            </div>
                        </div>
                    </div>

                    <div className="bg-zinc-900 border border-zinc-800 p-6 rounded-xl space-y-6 shadow-sm">
                        <h3 className="text-lg font-semibold text-white border-b border-zinc-800 pb-2">Matrix Options</h3>
                        <MatrixOptionsBuilder 
                            options={matrixOptions}
                            onOptionsChange={setMatrixOptions}
                            onVariantsGenerate={handleVariantsGenerate}
                        />
                    </div>
                </div>
            </div>
        </div>
    );
}
