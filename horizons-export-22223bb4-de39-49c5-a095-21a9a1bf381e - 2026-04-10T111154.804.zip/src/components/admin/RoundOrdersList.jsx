
import React from 'react';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Loader2, Calendar } from 'lucide-react';
import { format } from 'date-fns';

export default function RoundOrdersList({ orders, loading, search, roundId, status, onViewDetail }) {
    
    const filteredOrders = orders.filter(order => {
        if (roundId && roundId !== 'all' && order.round_id !== roundId) return false;
        if (status && status !== 'all' && order.status !== status) return false;
        if (search && search.trim() !== '') {
            const term = search.toLowerCase();
            const emailMatch = order.customer_email?.toLowerCase().includes(term);
            const nameMatch = order.customer_name?.toLowerCase().includes(term);
            if (!emailMatch && !nameMatch) return false;
        }
        return true;
    });

    const getStatusBadge = (orderStatus) => {
        const normalized = (orderStatus || '').toLowerCase();
        const styles = {
            paid: 'bg-emerald-500/10 text-emerald-500 border-emerald-500/20',
            completed: 'bg-blue-500/10 text-blue-500 border-blue-500/20',
            cancelled: 'bg-red-500/10 text-red-500 border-red-500/20',
            canceled: 'bg-red-500/10 text-red-500 border-red-500/20',
            failed_round: 'bg-red-500/10 text-red-500 border-red-500/20',
            expired: 'bg-zinc-800 text-zinc-500 border-zinc-700',
            pending: 'bg-yellow-500/10 text-yellow-500 border-yellow-500/20',
            confirmed: 'bg-yellow-500/10 text-yellow-500 border-yellow-500/20',
            eligible_to_pay: 'bg-blue-500/10 text-blue-400 border-blue-500/20',
            reserved: 'bg-yellow-500/10 text-yellow-500 border-yellow-500/20',
            active: 'bg-blue-500/10 text-blue-400 border-blue-500/20'
        };
        const defaultStyle = 'bg-zinc-800 text-zinc-400 border-zinc-700';
        return (
            <Badge variant="outline" className={styles[normalized] || defaultStyle}>
                {normalized.toUpperCase() || 'UNKNOWN'}
            </Badge>
        );
    };

    if (loading) {
        return (
            <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-12 flex flex-col items-center justify-center">
                <Loader2 className="h-8 w-8 animate-spin text-yellow-500 mb-4" />
                <p className="text-zinc-500">Loading orders...</p>
            </div>
        );
    }

    if (filteredOrders.length === 0) {
        return (
            <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-12 flex flex-col items-center justify-center text-center">
                <Calendar className="h-12 w-12 text-zinc-600 mb-4 opacity-50" />
                <h3 className="text-lg font-medium text-zinc-300 mb-1">No Orders Found</h3>
                <p className="text-zinc-500 text-sm max-w-sm">
                    No confirmed round orders match your current filters.
                </p>
            </div>
        );
    }

    return (
        <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
            {filteredOrders.map((order) => (
                <div 
                    key={order.order_id} 
                    className="bg-zinc-900 border border-zinc-800 rounded-xl p-5 hover:border-zinc-700 transition-colors cursor-pointer flex flex-col"
                    onClick={() => onViewDetail(order.order_id)}
                >
                    <div className="flex justify-between items-start mb-4">
                        <div>
                            <p className="text-sm font-medium text-white truncate max-w-[180px]">{order.customer_name || 'Unknown'}</p>
                            <p className="text-xs text-zinc-500 truncate max-w-[180px]">{order.customer_email}</p>
                        </div>
                        {getStatusBadge(order.status)}
                    </div>
                    
                    <div className="mb-4">
                        <p className="text-xs text-zinc-500 mb-1">Round</p>
                        <p className="text-sm text-zinc-300 truncate">{order.round_title || 'Unknown Round'}</p>
                    </div>

                    <div className="mt-auto grid grid-cols-2 gap-4 pt-4 border-t border-zinc-800/50">
                        <div>
                            <p className="text-xs text-zinc-500 mb-1">Total</p>
                            <p className="text-lg font-semibold text-yellow-500">${Number(order.total_amount || 0).toFixed(2)}</p>
                        </div>
                        <div className="text-right">
                            <p className="text-xs text-zinc-500 mb-1">Date</p>
                            <p className="text-sm text-zinc-400">{format(new Date(order.created_at), 'MMM dd, yyyy')}</p>
                            <p className="text-xs text-zinc-500">{order.items_count || 0} items</p>
                        </div>
                    </div>
                </div>
            ))}
        </div>
    );
}
