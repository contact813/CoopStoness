import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { 
  ChevronRight, 
  ChevronDown, 
  Trash2, 
  Image as ImageIcon,
  Check,
  Pencil
} from "lucide-react";
import { TableRow, TableCell } from "@/components/ui/table";
import { cn } from "@/lib/utils";
import { useToast } from "@/components/ui/use-toast";

export default function RoundProductRow({ 
  item, 
  isVariant, 
  isExpanded, 
  onToggleExpand, 
  onRemove, 
  onUpdatePricing, 
  onUpdateGoal,
  childVariants = []
}) {
  const [isEditingPrice, setIsEditingPrice] = useState(false);
  const [priceValue, setPriceValue] = useState(item.final_price || 0);
  
  const [isEditingGoal, setIsEditingGoal] = useState(false);
  const [goalValue, setGoalValue] = useState(item.goal_qty || 0);

  const { toast } = useToast();

  const handleSavePrice = async () => {
    try {
      await onUpdatePricing(item.product_id, item.variant_id, priceValue);
      setIsEditingPrice(false);
    } catch (error) {
      toast({ variant: "destructive", title: "Update failed", description: "Could not update price" });
    }
  };

  const handleSaveGoal = async () => {
    try {
      await onUpdateGoal(item.product_id, item.variant_id, goalValue);
      setIsEditingGoal(false);
    } catch (error) {
      toast({ variant: "destructive", title: "Update failed", description: "Could not update goal" });
    }
  };

  const imageUrl = item.final_images?.[0]?.url || null;

  // Calculate progress
  const progress = item.goal_qty > 0 
    ? Math.min(100, ((item.items_sold || 0) / item.goal_qty) * 100) 
    : 0;

  return (
    <>
      <TableRow className={cn(
        "border-zinc-800 hover:bg-zinc-900/50 transition-colors",
        isVariant ? "bg-zinc-900/30" : "bg-zinc-900/10"
      )}>
        {/* Expand/Collapse Toggle */}
        <TableCell className="w-[50px] p-2">
          {!isVariant && (
            <Button 
              variant="ghost" 
              size="sm" 
              onClick={() => onToggleExpand(item.product_id)}
              className="h-8 w-8 p-0 text-zinc-400 hover:text-white"
            >
              {isExpanded ? (
                <ChevronDown className="h-4 w-4" />
              ) : (
                <ChevronRight className="h-4 w-4" />
              )}
            </Button>
          )}
        </TableCell>

        {/* Image */}
        <TableCell className="w-[80px] p-2">
          <div className={cn(
            "h-10 w-10 rounded-md bg-zinc-900 flex items-center justify-center overflow-hidden border border-zinc-800",
            isVariant && "ml-4"
          )}>
            {imageUrl ? (
              <img src={imageUrl} alt="" className="h-full w-full object-cover" />
            ) : (
              <ImageIcon className="h-5 w-5 text-zinc-700" />
            )}
          </div>
        </TableCell>

        {/* Title & Info */}
        <TableCell className="p-2">
          <div className={cn("flex flex-col", isVariant && "ml-4")}>
             <span className="font-medium text-zinc-200">
               {isVariant ? item.variant_title : item.product_title}
             </span>
             {!isVariant && item.vendor && (
               <span className="text-xs text-zinc-500">{item.vendor}</span>
             )}
          </div>
        </TableCell>

        {/* SKU */}
        <TableCell className="text-zinc-400 font-mono text-xs p-2">
          {item.final_sku || '—'}
        </TableCell>

        {/* Pricing */}
        <TableCell className="p-2 w-[140px]">
          {isEditingPrice ? (
            <div className="flex items-center gap-1">
              <Input 
                type="number" 
                value={priceValue}
                onChange={(e) => setPriceValue(e.target.value)}
                className="h-8 w-20 px-2 bg-zinc-950 border-zinc-700 text-xs text-white"
              />
              <Button size="sm" variant="ghost" onClick={handleSavePrice} className="h-8 w-8 p-0 text-green-500 hover:text-green-400 hover:bg-green-950/20">
                <Check className="h-4 w-4" />
              </Button>
            </div>
          ) : (
            <div 
               className="flex items-center gap-2 cursor-pointer group"
               onClick={() => setIsEditingPrice(true)}
            >
               <span className={cn(
                  "font-medium", 
                  item.special_price ? "text-yellow-500" : "text-zinc-300"
               )}>
                 ${Number(item.final_price).toFixed(2)}
               </span>
               <Pencil className="w-3 h-3 text-zinc-600 opacity-0 group-hover:opacity-100 transition-opacity" />
            </div>
          )}
        </TableCell>

        {/* Goal */}
        <TableCell className="p-2 w-[140px]">
          {isEditingGoal ? (
            <div className="flex items-center gap-1">
              <Input 
                type="number" 
                value={goalValue}
                onChange={(e) => setGoalValue(e.target.value)}
                className="h-8 w-20 px-2 bg-zinc-950 border-zinc-700 text-xs text-white"
              />
              <Button size="sm" variant="ghost" onClick={handleSaveGoal} className="h-8 w-8 p-0 text-green-500 hover:text-green-400 hover:bg-green-950/20">
                <Check className="h-4 w-4" />
              </Button>
            </div>
          ) : (
            <div 
               className="flex items-center gap-2 cursor-pointer group"
               onClick={() => setIsEditingGoal(true)}
            >
               <span className="text-zinc-400 text-sm">
                 {item.goal_qty || 0} {item.goal_unit || 'un'}
               </span>
               <Pencil className="w-3 h-3 text-zinc-600 opacity-0 group-hover:opacity-100 transition-opacity" />
            </div>
          )}
        </TableCell>

        {/* Progress */}
        <TableCell className="p-2 w-[120px]">
           <div className="w-full h-1.5 bg-zinc-800 rounded-full overflow-hidden">
             <div 
               className="h-full bg-yellow-600 transition-all duration-500" 
               style={{ width: `${progress}%` }} 
             />
           </div>
           <div className="text-[10px] text-zinc-600 mt-1 text-right">{progress.toFixed(0)}%</div>
        </TableCell>

        {/* Actions */}
        <TableCell className="text-right p-2">
           <Button
             variant="ghost"
             size="sm"
             onClick={() => onRemove(item.product_id, item.variant_id)}
             className="text-red-400 hover:text-red-300 hover:bg-red-950/50 h-8 w-8 p-0"
           >
             <Trash2 className="h-4 w-4" />
           </Button>
        </TableCell>
      </TableRow>

      {/* Render children recursively if expanded */}
      {isExpanded && childVariants && childVariants.length > 0 && (
        <>
          {childVariants.map((variant) => (
             <RoundProductRow
                key={variant.variant_id}
                item={variant}
                isVariant={true}
                isExpanded={false} 
                onToggleExpand={() => {}} // Variants don't expand
                onRemove={onRemove}
                onUpdatePricing={onUpdatePricing}
                onUpdateGoal={onUpdateGoal}
             />
          ))}
        </>
      )}
    </>
  );
}