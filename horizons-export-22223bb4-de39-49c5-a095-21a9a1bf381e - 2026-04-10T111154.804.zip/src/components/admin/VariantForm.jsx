
import React, { useEffect, useState } from 'react';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import { AlertCircle, Check, UploadCloud, Loader2, CheckCircle2 } from 'lucide-react';
import { cn } from '@/lib/utils';
import { Textarea } from '@/components/ui/textarea';
import { formatVariantOptions, logVariantIssue } from '@/utils/variantUtils';
import { uploadVariantImage } from '@/lib/storageApi';
import { updateVariant } from '@/lib/adminVariantsApi';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Button } from '@/components/ui/button';

export default function VariantForm({ 
    formState, 
    onChange, 
    productImages = [],
    options = []
}) {
  const [imageUploading, setImageUploading] = useState(false);
  const [uploadSuccess, setUploadSuccess] = useState(false);
  const [uploadError, setUploadError] = useState(null);

  const safeOptions = Array.isArray(options) ? options : [];
  const safeImages = Array.isArray(productImages) ? productImages : [];
  const safeOptionValues = Array.isArray(formState?.optionValues) ? formState.optionValues : [];

  useEffect(() => {
    if (safeOptions.length > 0 && safeOptionValues.length === 0) {
      logVariantIssue('Variant has no optionValues assigned despite product having options.', formState);
    }
  }, [safeOptions.length, safeOptionValues.length, formState]);

  const handleChange = (field, value) => {
    onChange({ ...formState, [field]: value });
  };

  const handleVariantImageUpload = async (e) => {
      const file = e.target.files?.[0];
      if (!file) return;

      setImageUploading(true);
      setUploadError(null);
      setUploadSuccess(false);

      try {
          const variantId = formState.id && !formState.id.startsWith('temp-') ? formState.id : 'temp';
          
          console.log('[VariantForm] Uploading image:', file.name);
          const url = await uploadVariantImage(file, variantId);

          if (!url) {
              throw new Error('No URL returned from upload');
          }

          console.log('[VariantForm] Upload response:', url);
          console.log('[VariantForm] Image uploaded, updating form:', url);
          handleChange('image_url', url);

          // Auto-save if it's an existing variant
          if (variantId !== 'temp') {
              console.log('[VariantForm] Auto-saving image_url to variant');
              const { error: updateErr } = await updateVariant(variantId, { image_url: url });
              if (updateErr) throw updateErr;
          }

          setUploadSuccess(true);
          setTimeout(() => setUploadSuccess(false), 3000);
      } catch (err) {
          console.error("Variant image upload error:", err);
          setUploadError(err.message || "Failed to upload image.");
      } finally {
          setImageUploading(false);
          if (e.target) e.target.value = '';
      }
  };

  const formattedOptions = formatVariantOptions(safeOptionValues);

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 pb-24">
        {uploadError && (
            <div className="col-span-full">
                <Alert variant="destructive" className="bg-red-950/40 border-red-900 shadow-sm">
                    <AlertCircle className="h-4 w-4" />
                    <AlertTitle>Upload Error</AlertTitle>
                    <AlertDescription className="text-red-200 mt-1">{uploadError}</AlertDescription>
                </Alert>
            </div>
        )}

        <div className="lg:col-span-2 space-y-6">
            <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-6">
                <h3 className="text-lg font-semibold mb-6 flex items-center gap-2">
                     <div className="w-1.5 h-6 bg-yellow-500 rounded-full" />
                     Variant Options
                </h3>
                
                <div className="bg-zinc-950 border border-zinc-800 rounded-lg p-4">
                    {safeOptionValues.length > 0 ? (
                        <div className="text-white font-medium">
                            {formattedOptions}
                        </div>
                    ) : (
                        <div className="text-zinc-500 text-sm">
                            This product currently has no options configured for this variant.
                        </div>
                    )}
                </div>
            </div>

            <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-6">
                 <h3 className="text-lg font-semibold mb-6 flex items-center gap-2">
                     <div className="w-1.5 h-6 bg-purple-500 rounded-full" />
                     Variant Details
                 </h3>
                 
                 <div className="space-y-4">
                    <div>
                        <Label className="text-zinc-300">Title <span className="text-red-500">*</span></Label>
                        <Input 
                            className="bg-zinc-950 mt-1.5 border-zinc-800 text-white placeholder:text-zinc-600" 
                            value={formState.title || ''}
                            onChange={(e) => handleChange('title', e.target.value)}
                            required
                        />
                    </div>
                    <div>
                        <Label className="text-zinc-300">Custom Description</Label>
                        <Textarea 
                            className="bg-zinc-950 mt-1.5 border-zinc-800 text-white placeholder:text-zinc-600 min-h-[120px] resize-none" 
                            value={formState.custom_description || ''}
                            rows={3}
                            onChange={(e) => handleChange('custom_description', e.target.value)}
                        />
                    </div>
                 </div>
            </div>

            <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-6">
                <div className="flex justify-between items-center mb-6">
                    <h3 className="text-lg font-semibold flex items-center gap-2">
                        <div className="w-1.5 h-6 bg-blue-500 rounded-full" />
                        Pricing & Inventory
                    </h3>
                    <div className="flex items-center space-x-2">
                        <Checkbox 
                            id="is_active" 
                            checked={formState.is_active !== false}
                            onCheckedChange={(checked) => handleChange('is_active', !!checked)}
                            className="border-zinc-700 data-[state=checked]:bg-yellow-400 data-[state=checked]:border-yellow-400 data-[state=checked]:text-black"
                        />
                        <Label htmlFor="is_active" className="text-sm font-medium leading-none cursor-pointer">
                            Active Variant
                        </Label>
                    </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                    <div>
                        <Label>SKU <span className="text-red-500">*</span></Label>
                        <Input 
                            className="bg-zinc-950 mt-2 text-white" 
                            value={formState.sku || ''}
                            onChange={(e) => handleChange('sku', e.target.value)}
                            required
                        />
                    </div>
                    <div>
                        <Label>Price <span className="text-red-500">*</span></Label>
                        <div className="relative mt-2">
                            <span className="absolute left-3 top-1/2 -translate-y-1/2 text-zinc-500">$</span>
                            <Input 
                                type="number" 
                                className="bg-zinc-950 pl-8 text-white" 
                                value={formState.price ?? ''}
                                onChange={(e) => handleChange('price', parseFloat(e.target.value) || 0)}
                                step="0.01"
                                min="0.01"
                                required
                            />
                        </div>
                    </div>
                    <div>
                        <Label>Inventory Quantity <span className="text-red-500">*</span></Label>
                        <Input 
                            type="number" 
                            className="bg-zinc-950 mt-2 text-white" 
                            value={formState.inventory_qty ?? ''}
                            onChange={(e) => handleChange('inventory_qty', parseInt(e.target.value) || 0)}
                            min="0"
                            required
                        />
                    </div>
                </div>
            </div>
        </div>

        <div className="lg:col-span-1">
            <div className="sticky top-24 bg-zinc-900 border border-zinc-800 rounded-xl p-6 flex flex-col gap-4 max-h-[calc(100vh-120px)] overflow-y-auto no-scrollbar">
                
                <div className="flex justify-between items-center">
                    <h3 className="text-lg font-semibold flex items-center gap-2">
                        <div className="w-1.5 h-6 bg-green-500 rounded-full" />
                        Variant Image
                    </h3>
                </div>

                <div className="space-y-4 mb-4">
                    {imageUploading ? (
                        <div className="flex flex-col items-center justify-center p-6 border-2 border-dashed border-zinc-700 rounded-xl bg-zinc-900/50">
                            <Loader2 className="w-8 h-8 animate-spin text-yellow-500 mb-3" />
                            <p className="text-sm text-zinc-400 text-center">Uploading image...</p>
                        </div>
                    ) : formState.image_url && formState.image_url.trim() ? (
                        <div className="space-y-4">
                            <img 
                                src={formState.image_url} 
                                alt="Variant Preview" 
                                className="w-full aspect-square object-cover rounded-lg border border-zinc-800"
                            />
                            <div className="flex gap-2">
                                <Label 
                                    htmlFor="variant-image-upload" 
                                    className="flex-1 text-center bg-zinc-800 hover:bg-zinc-700 text-white px-4 py-2 rounded-lg cursor-pointer transition-colors border border-zinc-700 text-sm font-medium"
                                >
                                    Change Image
                                </Label>
                                <Button 
                                    variant="destructive" 
                                    size="sm"
                                    onClick={() => handleChange('image_url', '')}
                                >
                                    Remove
                                </Button>
                            </div>
                        </div>
                    ) : (
                        <Label 
                            htmlFor="variant-image-upload" 
                            className="flex flex-col items-center justify-center gap-2 border-2 border-dashed border-zinc-700 hover:border-zinc-500 bg-zinc-900/50 hover:bg-zinc-800/50 text-zinc-400 hover:text-white px-4 py-8 rounded-xl cursor-pointer transition-all"
                        >
                            <UploadCloud className="w-8 h-8 mb-2 text-zinc-500" />
                            <span className="font-medium">Upload Specific Image</span>
                            <span className="text-xs text-zinc-500">JPEG, PNG, WebP or GIF (max 5MB)</span>
                        </Label>
                    )}
                    
                    <Input 
                        id="variant-image-upload" 
                        type="file" 
                        accept="image/jpeg, image/png, image/webp, image/gif" 
                        onChange={handleVariantImageUpload} 
                        className="hidden" 
                        disabled={imageUploading}
                    />
                    
                    {uploadSuccess && (
                        <div className="text-xs text-green-500 font-medium flex items-center gap-1.5 justify-center mt-2">
                            <CheckCircle2 className="w-4 h-4" /> Image saved!
                        </div>
                    )}
                </div>

                {safeImages.length > 0 && (
                    <>
                        <div className="text-sm font-medium text-zinc-400 mt-4 mb-2">Or select from product images:</div>
                        <div className="grid grid-cols-2 gap-4 mt-2">
                            {safeImages.map((img, idx) => {
                                if (!img) return null;
                                const url = typeof img === 'string' ? img : img.url;
                                if (!url) return null;
                                
                                const isSelected = formState.image_url === url;
                                return (
                                    <div 
                                        key={`img-${idx}`} 
                                        onClick={() => handleChange('image_url', url)}
                                        className={cn(
                                            "relative aspect-square rounded-lg overflow-hidden border-2 cursor-pointer transition-all bg-zinc-950 group",
                                            isSelected 
                                                ? "border-blue-500 shadow-[0_0_12px_rgba(59,130,246,0.3)]" 
                                                : "border-zinc-800 hover:border-zinc-600"
                                        )}
                                    >
                                        <img src={url} alt={`Product view ${idx + 1}`} className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105" />
                                        {isSelected && (
                                            <div className="absolute top-2 right-2 bg-blue-500 text-white p-1 rounded-full shadow-lg z-10">
                                                <Check className="w-3 h-3" strokeWidth={3} />
                                            </div>
                                        )}
                                    </div>
                                )
                            })}
                        </div>
                    </>
                )}
            </div>
        </div>
    </div>
  );
}
