import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { cn } from '@/lib/utils';

export default function EditVariantModal({ isOpen, onClose, variant, onSave, productImages = [] }) {
  const [data, setData] = useState({
    sku: '',
    price: '',
    inventory_qty: '',
    barcode: '',
    image_url: ''
  });

  useEffect(() => {
    if (variant) {
      setData({
        sku: variant.sku || '',
        price: variant.price || 0,
        inventory_qty: variant.inventory_qty || 0,
        barcode: variant.barcode || '',
        image_url: variant.image_url || ''
      });
    }
  }, [variant]);

  const handleSave = () => {
    onSave({
      ...variant,
      ...data,
      price: parseFloat(data.price) || 0,
      inventory_qty: parseInt(data.inventory_qty) || 0
    });
    onClose();
  };

  if (!variant) return null;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="bg-zinc-900 border-zinc-800 text-white sm:max-w-lg">
        <DialogHeader>
          <DialogTitle className="flex flex-col gap-1">
             <span>Edit Variant</span>
             <span className="text-yellow-500 text-sm font-normal">{variant.title}</span>
          </DialogTitle>
        </DialogHeader>

        <div className="grid gap-6 py-4">
           {/* Option Values Read-only Display */}
           {variant.optionValues && variant.optionValues.length > 0 && (
             <div className="flex gap-2 flex-wrap">
                {variant.optionValues.map((ov, idx) => (
                    <span key={idx} className="px-2 py-1 rounded bg-zinc-800 text-xs text-zinc-300 border border-zinc-700">
                        {ov.optionName}: <span className="text-white font-medium">{ov.value}</span>
                    </span>
                ))}
             </div>
           )}

           {/* Image Selection */}
           <div className="space-y-2">
             <Label>Variant Image</Label>
             <div className="grid grid-cols-5 gap-2 max-h-[140px] overflow-y-auto p-2 bg-zinc-950 rounded border border-zinc-800">
                <div 
                   onClick={() => setData({...data, image_url: ''})}
                   className={cn(
                       "aspect-square rounded border cursor-pointer flex items-center justify-center text-xs text-zinc-500 hover:bg-zinc-900 transition-colors",
                       !data.image_url ? "border-yellow-500 bg-yellow-500/10 text-yellow-500 ring-1 ring-yellow-500" : "border-zinc-800"
                   )}
                >
                    None
                </div>
                {productImages.map((img, idx) => (
                    <div 
                        key={idx}
                        onClick={() => setData({...data, image_url: img.url})}
                        className={cn(
                            "aspect-square rounded border cursor-pointer overflow-hidden relative group",
                            data.image_url === img.url ? "border-yellow-500 ring-1 ring-yellow-500" : "border-zinc-800 hover:border-zinc-600"
                        )}
                    >
                        <img src={img.url} alt="Variant" className="w-full h-full object-cover" />
                        <div className={cn("absolute inset-0 bg-black/20 group-hover:bg-transparent transition-colors", data.image_url === img.url && "bg-transparent")} />
                    </div>
                ))}
             </div>
           </div>

           <div className="grid grid-cols-2 gap-4">
              <div>
                 <Label>Price</Label>
                 <Input 
                    type="number" 
                    step="0.01" 
                    value={data.price}
                    onChange={(e) => setData({...data, price: e.target.value})}
                    className="mt-1.5 bg-zinc-950 border-zinc-700 focus:border-yellow-500"
                 />
              </div>
              <div>
                 <Label>Inventory</Label>
                 <Input 
                    type="number" 
                    value={data.inventory_qty}
                    onChange={(e) => setData({...data, inventory_qty: e.target.value})}
                    className="mt-1.5 bg-zinc-950 border-zinc-700 focus:border-yellow-500"
                 />
              </div>
           </div>

           <div className="grid grid-cols-2 gap-4">
              <div>
                 <Label>SKU</Label>
                 <Input 
                    value={data.sku}
                    onChange={(e) => setData({...data, sku: e.target.value})}
                    className="mt-1.5 bg-zinc-950 border-zinc-700 focus:border-yellow-500"
                 />
              </div>
              <div>
                 <Label>Barcode</Label>
                 <Input 
                    value={data.barcode}
                    onChange={(e) => setData({...data, barcode: e.target.value})}
                    className="mt-1.5 bg-zinc-950 border-zinc-700 focus:border-yellow-500"
                 />
              </div>
           </div>
        </div>

        <DialogFooter className="gap-2 sm:gap-0">
          <Button variant="outline" onClick={onClose} className="border-zinc-700 hover:bg-zinc-800">Cancel</Button>
          <Button onClick={handleSave} className="bg-yellow-500 text-black hover:bg-yellow-400">Save Changes</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}