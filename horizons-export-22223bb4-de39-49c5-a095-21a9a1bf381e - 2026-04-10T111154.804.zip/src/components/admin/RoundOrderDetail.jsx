
import React, { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabaseClient';
import { Button } from '@/components/ui/button';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { ArrowLeft, Loader2, Package } from 'lucide-react';
import { format } from 'date-fns';

export default function RoundOrderDetail({ orderId, onBack }) {
    const [order, setOrder] = useState(null);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        let mounted = true;
        async function fetchDetail() {
            try {
                // Fetch order details
                const { data: orderData, error: orderError } = await supabase
                    .from('admin_round_orders')
                    .select('*')
                    .eq('order_id', orderId)
                    .single();
                
                if (orderError) throw orderError;

                // Fetch order items with nested product data via products join
                // Not joining product_variants to avoid relationship errors, variant_id is accessed directly as text
                const { data: itemsData, error: itemsError } = await supabase
                    .from('order_items')
                    .select('*, products(id, title, SKU)')
                    .eq('order_id', orderId);

                if (itemsError) throw itemsError;

                // Debug logging as requested
                console.log('Order Data:', orderData);
                console.log('Order Items:', itemsData);

                if (mounted) {
                    // Attach order items to the order object
                    if (orderData) {
                        orderData.order_items = itemsData || [];
                    }
                    setOrder(orderData);
                }
            } catch (error) {
                console.error('Error fetching order details:', error);
            } finally {
                if (mounted) setLoading(false);
            }
        }
        fetchDetail();
        return () => { mounted = false; };
    }, [orderId]);

    if (loading) return <div className="p-12 flex justify-center"><Loader2 className="w-8 h-8 animate-spin text-yellow-500" /></div>;
    if (!order) return <div className="p-12 text-center text-zinc-500">Order not found</div>;

    return (
        <div className="space-y-6">
            <Button variant="ghost" onClick={onBack} className="text-zinc-400 hover:text-white -ml-4 mb-4">
                <ArrowLeft className="w-4 h-4 mr-2" /> Back to Orders
            </Button>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-6 space-y-4">
                    <h3 className="text-lg font-medium text-white flex items-center gap-2">
                        Order Information
                    </h3>
                    <div className="space-y-2 text-sm">
                        <div className="flex justify-between border-b border-zinc-800 pb-2">
                            <span className="text-zinc-500">Order ID</span>
                            <span className="text-zinc-300 font-mono">{order.order_id}</span>
                        </div>
                        <div className="flex justify-between border-b border-zinc-800 pb-2">
                            <span className="text-zinc-500">Customer</span>
                            <span className="text-zinc-300">{order.customer_name} ({order.customer_email})</span>
                        </div>
                        <div className="flex justify-between border-b border-zinc-800 pb-2">
                            <span className="text-zinc-500">Round</span>
                            <span className="text-zinc-300">{order.round_title}</span>
                        </div>
                        <div className="flex justify-between border-b border-zinc-800 pb-2">
                            <span className="text-zinc-500">Date</span>
                            <span className="text-zinc-300">{order.created_at ? format(new Date(order.created_at), 'PPP pp') : '-'}</span>
                        </div>
                        <div className="flex justify-between pt-1">
                            <span className="text-zinc-500">Status</span>
                            <Badge variant="outline" className="bg-yellow-500/10 text-yellow-500 border-yellow-500/20">
                                {order.status?.toUpperCase() || 'UNKNOWN'}
                            </Badge>
                        </div>
                    </div>
                </div>

                <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-6 space-y-4">
                    <h3 className="text-lg font-medium text-white">Order Summary</h3>
                    {order.order_items && order.order_items.length > 0 ? (
                        <div className="flex flex-col items-center justify-center py-6 bg-zinc-950 rounded-lg border border-zinc-800">
                            <span className="text-4xl font-bold text-yellow-500">${Number(order.total_amount || 0).toFixed(2)}</span>
                            <span className="text-zinc-500 mt-2">{order.items_count || order.order_items.length} items total</span>
                        </div>
                    ) : (
                        <div className="flex flex-col items-center justify-center py-6 bg-zinc-950 rounded-lg border border-zinc-800">
                            <span className="text-zinc-500">No items available for total</span>
                        </div>
                    )}
                </div>
            </div>

            <div className="bg-zinc-900 border border-zinc-800 rounded-xl overflow-hidden">
                <div className="px-6 py-4 border-b border-zinc-800 flex items-center gap-2">
                    <Package className="w-5 h-5 text-zinc-400" />
                    <h3 className="font-medium text-white">Order Items</h3>
                </div>
                
                {order.order_items && order.order_items.length > 0 ? (
                    <Table>
                        <TableHeader className="bg-zinc-950">
                            <TableRow className="border-zinc-800">
                                <TableHead className="text-zinc-400">Product</TableHead>
                                <TableHead className="text-zinc-400">Variant ID</TableHead>
                                <TableHead className="text-zinc-400">SKU</TableHead>
                                <TableHead className="text-zinc-400 text-center">Qty</TableHead>
                                <TableHead className="text-zinc-400 text-right">Unit Price</TableHead>
                                <TableHead className="text-zinc-400 text-right">Subtotal</TableHead>
                            </TableRow>
                        </TableHeader>
                        <TableBody className="divide-y divide-zinc-800/50">
                            {order.order_items.map(item => {
                                // ✅ order_items usa APENAS quantity
                                const qty = Number(item.quantity ?? 0);
                                const unitPrice = Number(item.unit_price || 0);
                                const subtotal = qty * unitPrice;
                                
                                console.log('[RoundOrderDetail] Rendering order item:', {
                                  id: item.id,
                                  quantity: qty,
                                  unit_price: item.unit_price
                                });
                                
                                return (
                                    <TableRow key={item.id} className="border-none hover:bg-zinc-800/50">
                                        <TableCell className="text-zinc-300">
                                            {item.products?.title || item.product_title || 'Unknown Product'}
                                        </TableCell>
                                        <TableCell className="text-zinc-400 text-sm font-mono">
                                            {item.variant_id || '-'}
                                        </TableCell>
                                        <TableCell className="text-zinc-500 font-mono text-xs">
                                            {item.products?.SKU || '-'}
                                        </TableCell>
                                        <TableCell className="text-center text-zinc-300 font-medium">
                                            {qty}
                                        </TableCell>
                                        <TableCell className="text-right text-zinc-400">
                                            ${unitPrice.toFixed(2)}
                                        </TableCell>
                                        <TableCell className="text-right text-zinc-200 font-medium">
                                            ${subtotal.toFixed(2)}
                                        </TableCell>
                                    </TableRow>
                                );
                            })}
                        </TableBody>
                    </Table>
                ) : (
                    <div className="p-8 flex flex-col items-center justify-center text-center">
                        <Package className="w-12 h-12 text-zinc-700 mb-3" />
                        <p className="text-zinc-500 font-medium">No items in this order</p>
                    </div>
                )}
            </div>
        </div>
    );
}
