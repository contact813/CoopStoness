import React, { useState } from 'react';
import { Trash2, Image as ImageIcon } from 'lucide-react';
import { cn } from '@/lib/utils';

export default function ImageGalleryPreview({ imageUrl, title, onRemove }) {
    const [hasError, setHasError] = useState(false);

    if (!imageUrl || hasError) {
        return (
            <div className="w-full aspect-square rounded-lg border-2 border-dashed border-zinc-700 bg-zinc-950 flex flex-col items-center justify-center text-zinc-500 relative">
                <ImageIcon className="w-8 h-8 mb-2 opacity-50" />
                <p className="text-xs font-medium">Failed to load</p>
                {onRemove && (
                    <button 
                        type="button"
                        onClick={(e) => { e.preventDefault(); onRemove(); }} 
                        className="mt-3 text-xs text-red-500 hover:text-red-400 hover:underline px-3 py-1 bg-red-500/10 rounded-full transition-colors"
                    >
                        Remove
                    </button>
                )}
            </div>
        );
    }

    return (
        <div className="relative group w-full aspect-square rounded-lg overflow-hidden border border-zinc-800 bg-zinc-950 shadow-sm">
            <img 
                src={imageUrl} 
                alt={title || "Product preview"} 
                className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-[1.02]"
                onError={() => setHasError(true)}
                referrerPolicy="no-referrer"
            />
            
            {/* Hover overlay with action */}
            <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity duration-200 flex items-center justify-center backdrop-blur-[2px]">
                {onRemove && (
                    <button 
                        type="button"
                        onClick={(e) => { e.preventDefault(); onRemove(); }}
                        className="bg-red-500 hover:bg-red-600 text-white p-3 rounded-full transition-all duration-200 shadow-lg hover:scale-110"
                        title="Remove Image"
                    >
                        <Trash2 className="w-5 h-5" />
                    </button>
                )}
            </div>
        </div>
    );
}