import React from 'react';
import { Bell, Settings } from 'lucide-react';
import { Button } from "@/components/ui/button";

/**
 * FILENAME: src/components/admin/AdminHeader.jsx
 * PURPOSE: Top navigation for Admin Dashboard.
 * FIX: 
 * 1. High z-index (z-[60]) to ensure it's always on top of the sidebar (z-40) and page content.
 * 2. Solid, opaque background (bg-zinc-950) to prevent content from bleeding through.
 * 3. Shadow-lg for better separation.
 */
const AdminHeader = () => {
  return (
    <header className="fixed top-0 left-0 right-0 h-[72px] z-[60] bg-zinc-950 border-b border-zinc-800 flex items-center shadow-lg overflow-hidden">
      {/* Logo Section - Matches Sidebar Width */}
      <div className="w-64 h-full flex items-center px-6 border-r border-zinc-800 bg-zinc-950 shrink-0">
        <div className="flex items-center gap-2 font-bold text-lg text-white">
          <div className="flex items-center justify-center w-8 h-8 rounded bg-yellow-400 text-black font-bold text-xs">CS</div>
          <span className="bg-gradient-to-r from-yellow-200 to-yellow-500 bg-clip-text text-transparent">CoopStones</span>
        </div>
      </div>

      {/* Header Right Content */}
      <div className="flex-1 flex items-center justify-between px-8 bg-zinc-950 h-full">
        <div className="flex items-center">
          <h2 className="text-sm font-medium text-zinc-400 uppercase tracking-wider">
            Admin Panel
          </h2>
        </div>

        <div className="flex items-center gap-4">
          <Button 
            variant="ghost" 
            size="icon" 
            className="text-zinc-400 hover:text-zinc-200 hover:bg-zinc-800 rounded-full w-8 h-8"
          >
            <Bell className="w-4 h-4" />
          </Button>
          
          <Button 
            variant="ghost" 
            size="icon" 
            className="text-zinc-400 hover:text-zinc-200 hover:bg-zinc-800 rounded-full w-8 h-8"
          >
            <Settings className="w-4 h-4" />
          </Button>

          <div className="h-4 w-px bg-zinc-800 mx-1"></div>

          <Button 
            variant="ghost" 
            className="text-zinc-400 hover:text-zinc-200 hover:bg-zinc-800 pl-2 pr-3 h-9 rounded-full flex items-center gap-2"
          >
            <div className="w-6 h-6 rounded-full bg-gradient-to-tr from-yellow-400 to-yellow-600 flex items-center justify-center text-black font-bold text-xs shadow-lg">
              A
            </div>
            <span className="text-sm font-medium">Admin</span>
          </Button>
        </div>
      </div>
    </header>
  );
};

export default AdminHeader;