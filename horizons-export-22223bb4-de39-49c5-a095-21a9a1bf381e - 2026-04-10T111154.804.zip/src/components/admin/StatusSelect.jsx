import React, { useMemo } from 'react';
import { fetchStatusOptions } from '@/lib/adminProductsApi';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

export default function StatusSelect({ value, onChange, className }) {
  // Safe options handling with useMemo
  const options = useMemo(() => {
    try {
      const result = fetchStatusOptions();
      return Array.isArray(result) ? result : [];
    } catch (e) {
      console.error("Error loading status options:", e);
      return [];
    }
  }, []);

  return (
    <Select value={value || 'active'} onValueChange={onChange}>
      <SelectTrigger className={className}>
        <SelectValue placeholder="Select status" />
      </SelectTrigger>
      <SelectContent>
        {options.map((opt) => (
          <SelectItem key={opt.value} value={opt.value}>
            {opt.label}
          </SelectItem>
        ))}
      </SelectContent>
    </Select>
  );
}