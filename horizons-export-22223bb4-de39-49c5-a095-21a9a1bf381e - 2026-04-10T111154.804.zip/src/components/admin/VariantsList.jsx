import React, { useState } from 'react';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from '@/components/ui/badge';
import { Trash2, Edit, AlertCircle, Image as ImageIcon } from 'lucide-react';
import EditVariantModal from './EditVariantModal';
import { getVariantTitle } from '@/lib/variantHelpers';

export default function VariantsList({ variants = [], onChange, productImages = [] }) {
  const [editingVariant, setEditingVariant] = useState(null);

  const handleUpdate = (index, field, value) => {
    const newVars = [...variants];
    newVars[index] = { ...newVars[index], [field]: value };
    onChange(newVars);
  };

  const handleRemove = (index) => {
    if (confirm("Are you sure? This will remove this variant.")) {
        const newVars = [...variants];
        newVars.splice(index, 1);
        onChange(newVars);
    }
  };

  const handleSaveModal = (updatedVariant) => {
    const idx = variants.findIndex(v => v.id === updatedVariant.id);
    if (idx !== -1) {
        const newVars = [...variants];
        newVars[idx] = updatedVariant;
        onChange(newVars);
    }
  };

  return (
    <div className="space-y-4">
      <div className="rounded-md border border-zinc-800 overflow-hidden">
        <Table>
          <TableHeader className="bg-zinc-900">
            <TableRow className="border-zinc-800 hover:bg-zinc-900">
              <TableHead className="w-[60px]"></TableHead>
              <TableHead className="text-zinc-400">Variant</TableHead>
              <TableHead className="text-zinc-400">SKU</TableHead>
              <TableHead className="text-zinc-400 text-right">Price</TableHead>
              <TableHead className="text-zinc-400 text-right">Inventory</TableHead>
              <TableHead className="w-[100px] text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {variants.length === 0 && (
                <TableRow>
                    <TableCell colSpan={6} className="text-center text-zinc-500 py-8">
                        <div className="flex flex-col items-center gap-2">
                           <AlertCircle className="w-6 h-6 text-zinc-600" />
                           <p>No variants generated yet.</p>
                           <p className="text-xs">Add options above to generate variants.</p>
                        </div>
                    </TableCell>
                </TableRow>
            )}
            {variants.map((v, idx) => (
              <TableRow key={v.id} className="border-zinc-800 hover:bg-zinc-900/50">
                <TableCell>
                    {v.image_url ? (
                        <div className="w-10 h-10 rounded overflow-hidden border border-zinc-800 bg-zinc-950">
                            <img src={v.image_url} alt="v" className="w-full h-full object-cover" />
                        </div>
                    ) : (
                        <div className="w-10 h-10 rounded border border-zinc-800 bg-zinc-950 flex items-center justify-center text-zinc-700">
                            <ImageIcon size={16} />
                        </div>
                    )}
                </TableCell>
                <TableCell>
                    <span className="font-medium text-zinc-300">{getVariantTitle(v)}</span>
                </TableCell>
                <TableCell>
                    <Input 
                        value={v.sku || ''} 
                        onChange={e => handleUpdate(idx, 'sku', e.target.value)} 
                        className="h-8 w-full min-w-[100px] bg-transparent border-transparent hover:border-zinc-800 focus:bg-zinc-950 focus:border-zinc-800"
                        placeholder="SKU"
                    />
                </TableCell>
                <TableCell className="text-right">
                    <Input 
                        type="number"
                        value={v.price} 
                        onChange={e => handleUpdate(idx, 'price', e.target.value)} 
                        className="h-8 w-24 ml-auto text-right bg-transparent border-transparent hover:border-zinc-800 focus:bg-zinc-950 focus:border-zinc-800"
                    />
                </TableCell>
                <TableCell className="text-right">
                    <Input 
                        type="number"
                        value={v.inventory_qty} 
                        onChange={e => handleUpdate(idx, 'inventory_qty', e.target.value)} 
                        className="h-8 w-20 ml-auto text-right bg-transparent border-transparent hover:border-zinc-800 focus:bg-zinc-950 focus:border-zinc-800"
                    />
                </TableCell>
                <TableCell className="text-right">
                    <div className="flex items-center justify-end gap-1">
                        <Button variant="ghost" size="icon" onClick={() => setEditingVariant(v)} className="h-8 w-8 text-zinc-400 hover:text-white">
                            <Edit size={14} />
                        </Button>
                        <Button variant="ghost" size="icon" onClick={() => handleRemove(idx)} className="h-8 w-8 text-zinc-600 hover:text-red-500 hover:bg-red-950/20">
                            <Trash2 size={14} />
                        </Button>
                    </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>

      <EditVariantModal 
         isOpen={!!editingVariant}
         onClose={() => setEditingVariant(null)}
         variant={editingVariant}
         onSave={handleSaveModal}
         productImages={productImages}
      />
    </div>
  );
}