
import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Plus, X, Edit2, Check, AlertCircle, Trash2 } from 'lucide-react';
import { generateVariants } from '@/lib/generateVariants';

export default function MatrixVariantBuilder({ productId, options = [], onOptionsChange, variants = [], onVariantsChange }) {
  const safeOptions = Array.isArray(options) ? options : [];
  const safeVariants = Array.isArray(variants) ? variants : [];
  
  console.log('Rendering options defensively:', safeOptions);
  
  const [newOptionName, setNewOptionName] = useState('');
  const [newOptionValues, setNewOptionValues] = useState('');
  const [error, setError] = useState('');

  const [editingOptionId, setEditingOptionId] = useState(null);
  const [editingOptionName, setEditingOptionName] = useState(null);
  const [editName, setEditName] = useState('');
  const [editNewValue, setEditNewValue] = useState('');

  const updateVariantsAndOptions = (newOptions) => {
    if (typeof onOptionsChange === 'function') onOptionsChange(newOptions);
    const newVariants = generateVariants(newOptions, safeVariants);
    if (typeof onVariantsChange === 'function') onVariantsChange(newVariants);
  };

  const handleAddOption = () => {
    setError('');
    const name = newOptionName.trim();
    if (!name) {
      setError('Option name is required.');
      return;
    }
    if (safeOptions.some(o => o?.name && o.name.toLowerCase() === name.toLowerCase())) {
      setError('Option name already exists.');
      return;
    }

    const valuesArray = newOptionValues.split(',').map(v => v.trim()).filter(Boolean);
    if (valuesArray.length === 0) {
      setError('At least one value is required.');
      return;
    }

    const uniqueValues = [...new Set(valuesArray)];

    const newOption = {
      id: null,
      name: name,
      position: safeOptions.length,
      values: uniqueValues.map((val, idx) => ({
        id: null,
        value: val,
        position: idx
      }))
    };

    updateVariantsAndOptions([...safeOptions, newOption]);
    setNewOptionName('');
    setNewOptionValues('');
  };

  const handleRemoveOption = (optName) => {
    const newOptions = safeOptions.filter(o => o.name !== optName);
    updateVariantsAndOptions(newOptions);
  };

  const handleEditOption = (opt) => {
    if (!opt) return;
    setEditingOptionId(opt.id);
    setEditingOptionName(opt.name);
    setEditName(opt.name || '');
    setEditNewValue('');
    setError('');
  };

  const handleSaveOptionEdit = (opt) => {
    if (!opt) return;
    setError('');
    const name = editName.trim();
    if (!name) {
      setError('Option name is required.');
      return;
    }
    if (safeOptions.some(o => o.name !== opt.name && o.name.toLowerCase() === name.toLowerCase())) {
      setError('Option name already exists.');
      return;
    }
    
    const optValues = Array.isArray(opt.values) ? opt.values : [];
    if (optValues.length === 0) {
      setError('Option must have at least one value.');
      return;
    }

    const newOptions = safeOptions.map(o => o.name === opt.name ? { ...o, name } : o);
    updateVariantsAndOptions(newOptions);
    setEditingOptionId(null);
    setEditingOptionName(null);
  };

  const handleAddValue = (optName) => {
    setError('');
    const val = editNewValue.trim();
    if (!val) return;

    const newOptions = safeOptions.map(opt => {
      if (opt.name === optName) {
        const currentValues = Array.isArray(opt.values) ? opt.values : [];
        if (currentValues.some(v => v?.value && v.value.toLowerCase() === val.toLowerCase())) {
          setError('Value already exists in this option.');
          return opt;
        }
        return {
          ...opt,
          values: [...currentValues, { id: null, value: val, position: currentValues.length }]
        };
      }
      return opt;
    });

    if (!error) {
      updateVariantsAndOptions(newOptions);
      setEditNewValue('');
    }
  };

  const handleRemoveValue = (optName, valValue) => {
    const newOptions = safeOptions.map(opt => {
      if (opt.name === optName) {
        const currentValues = Array.isArray(opt.values) ? opt.values : [];
        return { ...opt, values: currentValues.filter(v => v.value !== valValue) };
      }
      return opt;
    });
    updateVariantsAndOptions(newOptions);
  };

  const cancelEdit = () => {
    setEditingOptionId(null);
    setEditingOptionName(null);
  };

  if (!safeOptions) return null;

  return (
    <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-6 mb-8">
      <h3 className="text-lg font-semibold mb-4">Matrix Options Builder</h3>
      
      {error && (
        <Alert variant="destructive" className="mb-4 bg-red-950/40 border-red-900 text-red-400">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      <div className="space-y-4 mb-6">
        {safeOptions.map((opt, optIndex) => {
          if (!opt) return null;
          const isEditing = editingOptionName === opt.name;
          const key = opt.id || opt.name || `opt-${optIndex}`;
          const safeValues = Array.isArray(opt.values) ? opt.values : [];
          
          if (isEditing) {
            return (
              <div key={key} className="p-4 bg-zinc-950 rounded-lg border border-zinc-700 space-y-4">
                <div className="flex items-end gap-4">
                  <div className="flex-1">
                    <Label className="mb-2 block">Option Name</Label>
                    <Input 
                      value={editName} 
                      onChange={e => setEditName(e.target.value)} 
                      className="bg-zinc-900"
                    />
                  </div>
                  <div className="flex gap-2">
                    <Button variant="outline" onClick={cancelEdit}>Cancel</Button>
                    <Button className="bg-emerald-600 hover:bg-emerald-500 text-white" onClick={() => handleSaveOptionEdit(opt)}>
                      <Check className="w-4 h-4 mr-2" /> Save
                    </Button>
                  </div>
                </div>

                <div>
                  <Label className="mb-2 block">Values</Label>
                  <div className="flex flex-wrap gap-2 mb-3">
                    {safeValues.map((v, vIndex) => {
                      if (!v) return null;
                      return (
                        <div key={v.id || v.value || `val-${vIndex}`} className="flex items-center gap-1 px-2 py-1 bg-zinc-800 rounded text-sm text-zinc-200">
                          <span>{v.value}</span>
                          <button type="button" onClick={() => handleRemoveValue(opt.name, v.value)} className="text-zinc-400 hover:text-red-400 ml-1">
                            <X className="w-3 h-3" />
                          </button>
                        </div>
                      );
                    })}
                  </div>
                  <div className="flex items-center gap-2 max-w-sm">
                    <Input 
                      value={editNewValue} 
                      onChange={e => setEditNewValue(e.target.value)} 
                      placeholder="Add new value..."
                      className="bg-zinc-900 h-9"
                      onKeyDown={e => e.key === 'Enter' && handleAddValue(opt.name)}
                    />
                    <Button type="button" size="sm" onClick={() => handleAddValue(opt.name)} className="bg-zinc-800 hover:bg-zinc-700">
                      <Plus className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </div>
            );
          }

          return (
            <div key={key} className="flex items-center justify-between p-3 bg-zinc-950 rounded-lg border border-zinc-800 group">
              <div className="flex items-center gap-4 flex-1">
                <div className="w-1/4 font-medium text-white">{opt.name}</div>
                <div className="flex-1 flex flex-wrap gap-2">
                  {safeValues.map((v, vIndex) => {
                    if (!v) return null;
                    return (
                      <span key={v.id || v.value || `val-${vIndex}`} className="px-2 py-1 bg-zinc-800 border border-zinc-700 rounded text-xs text-zinc-300">
                        {v.value}
                      </span>
                    );
                  })}
                </div>
              </div>
              <div className="flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                <Button variant="ghost" size="icon" onClick={() => handleEditOption(opt)} className="text-zinc-400 hover:text-white">
                  <Edit2 className="w-4 h-4" />
                </Button>
                <Button variant="ghost" size="icon" onClick={() => handleRemoveOption(opt.name)} className="text-red-400 hover:text-red-300">
                  <Trash2 className="w-4 h-4" />
                </Button>
              </div>
            </div>
          );
        })}
      </div>

      {!editingOptionName && (
        <div className="grid grid-cols-1 md:grid-cols-12 gap-4 items-end bg-zinc-950 p-4 rounded-lg border border-zinc-800">
          <div className="md:col-span-4">
            <Label className="mb-2 block">New Option Name</Label>
            <Input 
              value={newOptionName} 
              onChange={e => setNewOptionName(e.target.value)} 
              placeholder="e.g. Size, Color"
              className="bg-zinc-900 border-zinc-800"
            />
          </div>
          <div className="md:col-span-6">
            <Label className="mb-2 block">Values (comma-separated)</Label>
            <Input 
              value={newOptionValues} 
              onChange={e => setNewOptionValues(e.target.value)} 
              placeholder="e.g. Small, Medium, Large"
              className="bg-zinc-900 border-zinc-800"
              onKeyDown={e => e.key === 'Enter' && handleAddOption()}
            />
          </div>
          <div className="md:col-span-2">
            <Button type="button" onClick={handleAddOption} className="w-full bg-yellow-500 text-black hover:bg-yellow-400">
              <Plus className="w-4 h-4 mr-2" /> Add Option
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}
