import React from 'react';
import { Sparkles } from 'lucide-react';
import EmptyState from './EmptyState';

const InsightPill = ({ label, value, trend = 'neutral' }) => (
  <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-zinc-900 border border-zinc-800 text-sm">
    <Sparkles className="w-3 h-3 text-yellow-500" />
    <span className="text-zinc-400">{label}:</span>
    <span className="text-white font-medium">{value}</span>
  </div>
);

const Insights = ({ bestDay, topCategory, conversion }) => {
  const hasInsights = bestDay || topCategory || conversion;

  return (
    <div className="mb-6">
      {hasInsights ? (
        <div className="flex flex-wrap gap-3">
          {bestDay && <InsightPill label="Best Sales Day" value={bestDay} />}
          {topCategory && <InsightPill label="Top Category" value={topCategory} />}
          {conversion && <InsightPill label="Conversion Rate" value={conversion} />}
        </div>
      ) : (
        <div className="rounded-lg border border-zinc-800 bg-zinc-900/30">
           <EmptyState message="No insights available for this period." />
        </div>
      )}
    </div>
  );
};

export default Insights;