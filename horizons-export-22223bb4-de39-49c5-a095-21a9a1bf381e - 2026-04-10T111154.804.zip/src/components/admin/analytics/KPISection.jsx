import React from 'react';
import { ArrowUpRight, ArrowDownRight, DollarSign, ShoppingBag, Package, Users, UserCheck, AlertTriangle } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';
import { formatCurrency, formatNumber, calculateGrowth } from '@/lib/analyticsUtils';
import { cn } from '@/lib/utils';

const KPICard = ({ title, value, prevValue, icon: Icon, prefix = '', suffix = '', reverseColor = false, isLoading }) => {
  const growth = calculateGrowth(value, prevValue);
  const isPositive = growth >= 0;
  const isNeutral = prevValue === 0 && value === 0;
  
  // Standard: Green is up (good), Red is down (bad). 
  // Reverse: Green is down (good - e.g. abandoned carts), Red is up (bad).
  let colorClass = isPositive ? 'text-green-400' : 'text-red-400';
  if (reverseColor) {
    colorClass = isPositive ? 'text-red-400' : 'text-green-400';
  }
  if (isNeutral) colorClass = 'text-zinc-500';

  return (
    <Card className="bg-zinc-900/50 border-zinc-800">
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-sm font-medium text-zinc-400">{title}</CardTitle>
        <Icon className="h-4 w-4 text-yellow-500 opacity-70" />
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <div className="space-y-2">
            <Skeleton className="h-7 w-24" />
            <Skeleton className="h-4 w-16" />
          </div>
        ) : (
          <>
            <div className="text-2xl font-bold text-white">
              {prefix}{typeof value === 'number' ? (prefix === '$' ? formatCurrency(value).replace('$','') : formatNumber(value)) : value}{suffix}
            </div>
            <div className={cn("flex items-center text-xs mt-1", colorClass)}>
              {!isNeutral && (isPositive ? <ArrowUpRight className="h-3 w-3 mr-1" /> : <ArrowDownRight className="h-3 w-3 mr-1" />)}
              <span>{Math.abs(growth).toFixed(1)}%</span>
              <span className="text-zinc-500 ml-1">vs previous period</span>
            </div>
          </>
        )}
      </CardContent>
    </Card>
  );
};

const KPISection = ({ currentMetrics, prevMetrics, isLoading }) => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
      <KPICard 
        title="Total Revenue" 
        value={currentMetrics.revenue} 
        prevValue={prevMetrics.revenue} 
        icon={DollarSign} 
        prefix="$"
        isLoading={isLoading} 
      />
      <KPICard 
        title="Orders" 
        value={currentMetrics.orders} 
        prevValue={prevMetrics.orders} 
        icon={ShoppingBag} 
        isLoading={isLoading} 
      />
      <KPICard 
        title="Items Sold" 
        value={currentMetrics.items} 
        prevValue={prevMetrics.items} 
        icon={Package} 
        isLoading={isLoading} 
      />
       <KPICard 
        title="Member Savings" 
        value={currentMetrics.savings} 
        prevValue={prevMetrics.savings} 
        icon={DollarSign} 
        prefix="$"
        isLoading={isLoading} 
      />
      <KPICard 
        title="Avg. Ticket" 
        value={currentMetrics.avgTicket} 
        prevValue={prevMetrics.avgTicket} 
        icon={DollarSign} 
        prefix="$"
        isLoading={isLoading} 
      />
      <KPICard 
        title="Active Members" 
        value={currentMetrics.activeMembers} 
        prevValue={prevMetrics.activeMembers} 
        icon={Users} 
        isLoading={isLoading} 
      />
      <KPICard 
        title="Active Suppliers" 
        value={currentMetrics.activeSuppliers} 
        prevValue={prevMetrics.activeSuppliers} 
        icon={UserCheck} 
        isLoading={isLoading} 
      />
       <KPICard 
        title="Avg. Discount" 
        value={currentMetrics.avgDiscount} 
        prevValue={prevMetrics.avgDiscount} 
        icon={AlertTriangle} // Using alert as placeholder, percentage icon not standard in lucide set used
        suffix="%"
        isLoading={isLoading} 
      />
    </div>
  );
};

export default KPISection;