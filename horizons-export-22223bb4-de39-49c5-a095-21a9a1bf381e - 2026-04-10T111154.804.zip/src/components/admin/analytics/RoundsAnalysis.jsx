import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { formatCurrency, formatNumber } from '@/lib/analyticsUtils';
import { Badge } from 'lucide-react'; 
import EmptyState from './EmptyState';

const RoundsAnalysis = ({ roundsData, isLoading }) => {
  return (
    <Card className="bg-zinc-900/50 border-zinc-800 lg:col-span-2">
      <CardHeader>
        <CardTitle>Rounds Performance</CardTitle>
      </CardHeader>
      <CardContent>
        {isLoading ? (
            <div className="space-y-2">
                 {[...Array(5)].map((_, i) => (
                    <div key={i} className="h-10 bg-zinc-800/50 rounded animate-pulse" />
                 ))}
            </div>
        ) : roundsData && roundsData.length > 0 ? (
            <div className="overflow-auto max-h-[400px]">
              <Table>
                <TableHeader>
                  <TableRow className="border-zinc-800 hover:bg-transparent">
                    <TableHead className="text-zinc-400">Round Name</TableHead>
                    <TableHead className="text-zinc-400">Status</TableHead>
                    <TableHead className="text-right text-zinc-400">Orders</TableHead>
                    <TableHead className="text-right text-zinc-400">Revenue</TableHead>
                    <TableHead className="text-right text-zinc-400">Savings</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {roundsData.map((round) => (
                      <TableRow key={round.id} className="border-zinc-800 hover:bg-zinc-800/50">
                        <TableCell className="font-medium text-white">{round.title}</TableCell>
                        <TableCell>
                            <span className={`text-xs px-2 py-1 rounded-full border ${
                                round.status === 'active' 
                                ? 'bg-green-500/10 text-green-400 border-green-500/20' 
                                : 'bg-zinc-800 text-zinc-400 border-zinc-700'
                            }`}>
                                {round.status}
                            </span>
                        </TableCell>
                        <TableCell className="text-right">{formatNumber(round.orders)}</TableCell>
                        <TableCell className="text-right text-yellow-400">{formatCurrency(round.revenue)}</TableCell>
                        <TableCell className="text-right text-green-400">{formatCurrency(round.savings)}</TableCell>
                      </TableRow>
                    ))}
                </TableBody>
              </Table>
            </div>
        ) : (
            <EmptyState message="No active rounds in this period." />
        )}
      </CardContent>
    </Card>
  );
};

export default RoundsAnalysis;