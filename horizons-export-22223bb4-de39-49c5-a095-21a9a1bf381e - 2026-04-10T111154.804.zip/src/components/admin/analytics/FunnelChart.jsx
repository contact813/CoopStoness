import React from 'react';
import { FunnelChart, Funnel, LabelList, Tooltip, ResponsiveContainer, Cell } from 'recharts';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';
import EmptyState from './EmptyState';

const CHART_COLORS = ['#facc15', '#eab308', '#ca8a04', '#a16207'];

const SalesFunnel = ({ data, isLoading }) => {
  // Data shape expected: [{ name: 'Visits', value: 1000 }, { name: 'Add to Cart', value: 500 }, ...]
  
  // Filter out steps with 0 value to determine emptiness realistically
  const hasData = data && data.length > 0 && data.some(d => d.value > 0);

  return (
    <Card className="bg-zinc-900/50 border-zinc-800">
      <CardHeader>
        <CardTitle>Conversion Funnel</CardTitle>
      </CardHeader>
      <CardContent className="h-[300px]">
        {isLoading ? (
          <Skeleton className="w-full h-full" />
        ) : hasData ? (
          <ResponsiveContainer width="100%" height="100%">
            <FunnelChart>
              <Tooltip 
                contentStyle={{ backgroundColor: '#18181b', borderColor: '#3f3f46', color: '#fff' }}
                itemStyle={{ color: '#fff' }}
              />
              <Funnel
                dataKey="value"
                data={data}
                isAnimationActive
              >
                {data.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={CHART_COLORS[index % CHART_COLORS.length]} stroke="none" />
                ))}
                <LabelList position="right" fill="#a1a1aa" stroke="none" dataKey="name" />
              </Funnel>
            </FunnelChart>
          </ResponsiveContainer>
        ) : (
            <EmptyState message="No funnel data available for the selected period." />
        )}
      </CardContent>
    </Card>
  );
};

export default SalesFunnel;