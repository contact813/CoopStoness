import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { ShoppingBag } from 'lucide-react';
import { Link } from 'react-router-dom';
import { formatCurrency } from '@/lib/analyticsUtils';
import EmptyState from './EmptyState';

const RecentOrders = ({ orders, isLoading }) => {
  return (
    <Card className="bg-zinc-950 border-zinc-800">
      <CardHeader>
        <CardTitle className="text-white flex items-center gap-2">
          <ShoppingBag className="text-emerald-500" size={20} />
          Recent Orders
        </CardTitle>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <div className="space-y-3">
             {[...Array(5)].map((_, i) => (
                <div key={i} className="h-16 bg-zinc-900 rounded-lg animate-pulse" />
             ))}
          </div>
        ) : !orders || orders.length === 0 ? (
          <EmptyState message="No recent orders." />
        ) : (
          <div className="space-y-3">
            {orders.map((order) => (
              <Link
                key={order.id}
                to={`/admin/orders/${order.id}`}
                className="flex items-center justify-between p-3 rounded-lg bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 transition-colors group"
              >
                <div>
                  <div className="text-zinc-200 font-mono text-xs group-hover:text-yellow-400 transition-colors">#{order.id.slice(0, 8)}</div>
                  <div className="text-zinc-500 text-xs">{order.profiles?.email || 'Guest User'}</div>
                </div>
                <div className="text-right">
                  <div className="text-white font-bold text-sm">
                    {formatCurrency(order.total_amount)}
                  </div>
                  <div className={`text-[10px] uppercase font-medium ${
                    order.status === 'paid' ? 'text-emerald-500' : 'text-zinc-500'
                  }`}>
                    {order.status}
                  </div>
                </div>
              </Link>
            ))}
            <div className="pt-2 text-center">
              <Link to="/admin/orders" className="text-xs text-zinc-400 hover:text-yellow-400 transition-colors">
                View All Orders &rarr;
              </Link>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default RecentOrders;