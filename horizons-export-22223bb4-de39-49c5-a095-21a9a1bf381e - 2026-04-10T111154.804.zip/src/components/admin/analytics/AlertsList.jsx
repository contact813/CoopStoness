import React from 'react';
import { AlertTriangle, PackageX, TrendingDown } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import EmptyState from './EmptyState';

const AlertItem = ({ icon: Icon, title, message, type = 'warning' }) => (
  <div className="flex items-start gap-3 p-3 rounded-lg bg-zinc-950 border border-zinc-800/50 hover:border-zinc-700 transition-colors">
    <div className={`p-2 rounded-md ${type === 'critical' ? 'bg-red-500/10 text-red-400' : 'bg-yellow-500/10 text-yellow-400'}`}>
      <Icon size={16} />
    </div>
    <div>
      <h4 className="text-sm font-medium text-zinc-200">{title}</h4>
      <p className="text-xs text-zinc-500 mt-1">{message}</p>
    </div>
  </div>
);

const AlertsList = ({ lowStock, isLoading }) => {
  return (
    <Card className="bg-zinc-900/50 border-zinc-800 h-full">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <AlertTriangle className="h-5 w-5 text-red-400" />
          Risks & Alerts
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-3 max-h-[300px] overflow-y-auto">
        {isLoading ? (
           <div className="text-zinc-500 text-sm text-center py-4">Scanning system...</div>
        ) : (
            <>
                {lowStock && lowStock.length > 0 ? (
                    lowStock.map(item => (
                        <AlertItem 
                            key={item.id}
                            icon={PackageX}
                            title="Low Stock Alert"
                            message={`${item.title} (${item.vendor}) is down to ${item.inventory} units.`}
                            type="critical"
                        />
                    ))
                ) : (
                    <EmptyState message="No alerts detected." />
                )}
            </>
        )}
      </CardContent>
    </Card>
  );
};

export default AlertsList;