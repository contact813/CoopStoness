import React from 'react';
import { AlertCircle } from 'lucide-react';

const EmptyState = ({ message = "No data available" }) => {
  return (
    <div className="flex flex-col items-center justify-center py-12 text-gray-500 text-sm h-full w-full">
      <AlertCircle className="w-8 h-8 mb-3 opacity-50" />
      <p>{message}</p>
    </div>
  );
};

export default EmptyState;