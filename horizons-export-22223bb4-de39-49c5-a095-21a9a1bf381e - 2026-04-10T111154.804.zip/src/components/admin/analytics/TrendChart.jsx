import React, { useMemo, useState } from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { formatCurrency } from '@/lib/analyticsUtils';
import { Skeleton } from '@/components/ui/skeleton';
import EmptyState from './EmptyState';

const TrendChart = ({ currentData, prevData, isLoading }) => {
  const [metric, setMetric] = useState('revenue'); // revenue | orders

  const chartData = useMemo(() => {
    if (!currentData || !prevData) return [];
    
    // Align data points by index for comparison
    // Assuming aggregated data is sorted by date
    const length = Math.max(currentData.length, prevData.length);
    const result = [];

    for (let i = 0; i < length; i++) {
      const current = currentData[i] || {};
      const prev = prevData[i] || {};
      
      result.push({
        index: i,
        dayLabel: current.day ? current.day.slice(5) : `Day ${i+1}`,
        currentValue: current[metric] || 0,
        prevValue: prev[metric] || 0,
      });
    }
    return result;
  }, [currentData, prevData, metric]);

  const hasData = chartData && chartData.length > 0 && chartData.some(d => d.currentValue > 0 || d.prevValue > 0);

  return (
    <Card className="bg-zinc-900/50 border-zinc-800 col-span-1 lg:col-span-3">
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle className="text-lg font-semibold text-white">Performance Trends</CardTitle>
        <Tabs value={metric} onValueChange={setMetric} className="w-auto">
          <TabsList className="bg-zinc-800">
            <TabsTrigger value="revenue">Revenue</TabsTrigger>
            <TabsTrigger value="orders">Orders</TabsTrigger>
          </TabsList>
        </Tabs>
      </CardHeader>
      <CardContent className="h-[350px]">
        {isLoading ? (
          <Skeleton className="w-full h-full" />
        ) : !hasData ? (
          <EmptyState message="No sales data available for the selected period." />
        ) : (
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={chartData} margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.1)" />
              <XAxis 
                dataKey="dayLabel" 
                stroke="#71717a" 
                tick={{ fill: '#71717a' }} 
              />
              <YAxis 
                stroke="#71717a" 
                tick={{ fill: '#71717a' }}
                tickFormatter={metric === 'revenue' ? (val) => `$${val/1000}k` : (val) => val} 
              />
              <Tooltip 
                contentStyle={{ backgroundColor: '#18181b', borderColor: '#3f3f46', color: '#fff' }}
                formatter={(val) => metric === 'revenue' ? formatCurrency(val) : val}
              />
              <Legend />
              <Line 
                type="monotone" 
                dataKey="currentValue" 
                name="Current Period" 
                stroke="#facc15" 
                strokeWidth={2} 
                dot={false}
                activeDot={{ r: 6 }}
              />
              <Line 
                type="monotone" 
                dataKey="prevValue" 
                name="Previous Period" 
                stroke="#71717a" 
                strokeWidth={2} 
                strokeDasharray="5 5" 
                dot={false} 
              />
            </LineChart>
          </ResponsiveContainer>
        )}
      </CardContent>
    </Card>
  );
};

export default TrendChart;