import React from 'react';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip, Legend } from 'recharts';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { formatCurrency } from '@/lib/analyticsUtils';
import { Skeleton } from '@/components/ui/skeleton';
import EmptyState from './EmptyState';

const COLORS = ['#facc15', '#a16207', '#ca8a04', '#854d0e', '#fef08a', '#422006'];

const CategoryPies = ({ categoryData, vendorData, isLoading }) => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
      {/* By Category */}
      <Card className="bg-zinc-900/50 border-zinc-800">
        <CardHeader>
          <CardTitle className="text-base">Revenue by Category</CardTitle>
        </CardHeader>
        <CardContent className="h-[300px]">
            {isLoading ? <Skeleton className="w-full h-full"/> : (
                categoryData && categoryData.length > 0 ? (
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                        <Pie
                        data={categoryData}
                        cx="50%"
                        cy="50%"
                        innerRadius={60}
                        outerRadius={80}
                        paddingAngle={5}
                        dataKey="value"
                        >
                        {categoryData.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} stroke="rgba(0,0,0,0.5)" />
                        ))}
                        </Pie>
                        <Tooltip 
                            contentStyle={{ backgroundColor: '#18181b', borderColor: '#3f3f46', borderRadius: '8px' }}
                            formatter={(val) => formatCurrency(val)}
                        />
                        <Legend iconSize={8} wrapperStyle={{ fontSize: '12px' }} />
                    </PieChart>
                  </ResponsiveContainer>
                ) : (
                  <EmptyState message="No category revenue data available." />
                )
            )}
        </CardContent>
      </Card>

      {/* By Supplier */}
      <Card className="bg-zinc-900/50 border-zinc-800">
        <CardHeader>
          <CardTitle className="text-base">Revenue by Supplier</CardTitle>
        </CardHeader>
        <CardContent className="h-[300px]">
             {isLoading ? <Skeleton className="w-full h-full"/> : (
                vendorData && vendorData.length > 0 ? (
                  <ResponsiveContainer width="100%" height="100%">
                      <PieChart>
                      <Pie
                          data={vendorData}
                          cx="50%"
                          cy="50%"
                          innerRadius={60}
                          outerRadius={80}
                          paddingAngle={5}
                          dataKey="value"
                      >
                          {vendorData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} stroke="rgba(0,0,0,0.5)" />
                          ))}
                      </Pie>
                      <Tooltip 
                          contentStyle={{ backgroundColor: '#18181b', borderColor: '#3f3f46', borderRadius: '8px' }}
                          formatter={(val) => formatCurrency(val)}
                      />
                      <Legend iconSize={8} wrapperStyle={{ fontSize: '12px' }} />
                      </PieChart>
                  </ResponsiveContainer>
                ) : (
                  <EmptyState message="No supplier revenue data available." />
                )
             )}
        </CardContent>
      </Card>
    </div>
  );
};

export default CategoryPies;