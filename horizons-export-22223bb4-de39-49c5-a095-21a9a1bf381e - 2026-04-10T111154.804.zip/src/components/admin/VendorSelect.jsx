import React, { useEffect, useState } from 'react';
import { getUniqueVendors } from '@/lib/adminProductsApi';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Loader2 } from "lucide-react";

export default function VendorSelect({ value, onChange, className }) {
  const [vendors, setVendors] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    getUniqueVendors()
      .then(data => setVendors(data))
      .catch(err => console.error("Failed to load vendors", err))
      .finally(() => setLoading(false));
  }, []);

  if (loading) {
    return (
      <div className="flex items-center gap-2 h-10 w-full rounded-md border border-zinc-800 bg-zinc-950 px-3 text-sm text-zinc-500">
        <Loader2 className="h-4 w-4 animate-spin" />
        Loading vendors...
      </div>
    );
  }

  // Helper to handle custom input scenarios with Select components if needed
  // For now, if current value isn't in list, we add it to display properly
  const displayVendors = value && !vendors.includes(value) 
    ? [...vendors, value].sort() 
    : vendors;

  // We are using a combo of Select for existing + Input for creating new logic might be complex in one component without Combobox
  // Given constraints, if we want to allow "Creating new", simple Select won't work perfectly.
  // But request says "If no vendors available, fallback to text input".
  // Let's interpret: Use select if vendors exist.
  
  if (vendors.length === 0) {
     return (
        <Input 
           value={value || ''}
           onChange={(e) => onChange(e.target.value)}
           placeholder="Type vendor name"
           className={className}
        />
     );
  }

  return (
    <Select value={value || ''} onValueChange={onChange}>
      <SelectTrigger className={className}>
        <SelectValue placeholder="Select vendor" />
      </SelectTrigger>
      <SelectContent>
         {displayVendors.map((v) => (
           <SelectItem key={v} value={v}>{v}</SelectItem>
         ))}
      </SelectContent>
    </Select>
  );
}