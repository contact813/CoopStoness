import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Plus, X, Trash2, GripVertical } from 'lucide-react';
import { v4 as uuidv4 } from 'uuid';

export default function VariantsOptions({ options = [], onChange }) {
  const [newOptionName, setNewOptionName] = useState('');

  const addOption = () => {
    const newOp = {
      id: `new-opt-${uuidv4()}`,
      name: '',
      values: []
    };
    onChange([...options, newOp]);
  };

  const removeOption = (index) => {
    const newOps = [...options];
    newOps.splice(index, 1);
    onChange(newOps);
  };

  const updateOptionName = (index, name) => {
    const newOps = [...options];
    newOps[index].name = name;
    onChange(newOps);
  };

  const addValue = (index, valueText) => {
    if (!valueText.trim()) return;
    const newOps = [...options];
    const existing = newOps[index].values.find(v => v.value.toLowerCase() === valueText.trim().toLowerCase());
    if (existing) return;

    newOps[index].values.push({
      id: `new-val-${uuidv4()}`,
      value: valueText.trim()
    });
    onChange(newOps);
  };

  const removeValue = (optIndex, valIndex) => {
    const newOps = [...options];
    newOps[optIndex].values.splice(valIndex, 1);
    onChange(newOps);
  };

  return (
    <div className="space-y-6">
      {options.map((opt, idx) => (
        <div key={opt.id} className="bg-zinc-900/50 border border-zinc-800 rounded-lg p-4 relative group">
          <div className="flex items-start gap-4">
            <div className="mt-2 text-zinc-600 cursor-grab active:cursor-grabbing">
                <GripVertical size={16} />
            </div>
            
            <div className="flex-1 space-y-4">
               <div>
                  <Label className="text-xs text-zinc-500 mb-1 block">Option Name</Label>
                  <Input 
                    value={opt.name}
                    onChange={(e) => updateOptionName(idx, e.target.value)}
                    placeholder="e.g. Size, Color, Material"
                    className="max-w-md bg-zinc-950 border-zinc-800"
                  />
               </div>

               <div>
                  <Label className="text-xs text-zinc-500 mb-1 block">Option Values</Label>
                  <div className="flex flex-wrap gap-2 mb-2">
                     {opt.values.map((val, vIdx) => (
                       <Badge key={val.id} variant="secondary" className="bg-yellow-500/10 text-yellow-500 hover:bg-yellow-500/20 border-yellow-500/20 pr-1 gap-1">
                          {val.value}
                          <div 
                             role="button"
                             onClick={() => removeValue(idx, vIdx)}
                             className="hover:bg-yellow-500/20 rounded-full p-0.5 cursor-pointer"
                          >
                            <X size={12} />
                          </div>
                       </Badge>
                     ))}
                  </div>
                  <Input
                    placeholder="Add value (press Enter)"
                    className="max-w-md bg-zinc-950 border-zinc-800"
                    onKeyDown={(e) => {
                        if (e.key === 'Enter') {
                            e.preventDefault();
                            addValue(idx, e.currentTarget.value);
                            e.currentTarget.value = '';
                        }
                    }}
                  />
                  <p className="text-[10px] text-zinc-500 mt-1">Press Enter to add a value</p>
               </div>
            </div>

            <Button 
                variant="ghost" 
                size="icon" 
                onClick={() => removeOption(idx)}
                className="text-zinc-500 hover:text-red-500 hover:bg-red-950/20"
            >
                <Trash2 size={16} />
            </Button>
          </div>
        </div>
      ))}

      <Button onClick={addOption} variant="outline" className="w-full border-dashed border-zinc-700 text-zinc-400 hover:text-white hover:bg-zinc-800">
        <Plus className="mr-2 h-4 w-4" /> Add Option
      </Button>
    </div>
  );
}