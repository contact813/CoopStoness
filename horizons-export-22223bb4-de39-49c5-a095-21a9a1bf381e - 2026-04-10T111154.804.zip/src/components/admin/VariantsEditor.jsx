
import React, { useState, useEffect } from 'react';
import { getProductVariants, createVariant, updateVariant, deleteVariant } from '@/lib/adminVariantsApi';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useToast } from '@/components/ui/use-toast';
import { Loader2, Plus, Trash2, Edit2, Save } from 'lucide-react';
import { cn } from '@/lib/utils';

export default function VariantsEditor({ productId }) {
  const { toast } = useToast();
  const [variants, setVariants] = useState([]);
  const [loading, setLoading] = useState(true);
  const [activeVariantId, setActiveVariantId] = useState(null);
  
  const [form, setForm] = useState({
    title: '',
    sku: '',
    price: 0,
    compare_at_price: '',
    cost: '',
    inventory_qty: 0,
    image_url: '',
    custom_description: '',
    is_active: true
  });
  
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (productId && productId !== 'new') {
      fetchVariants();
    } else {
      setLoading(false);
    }
  }, [productId]);

  const fetchVariants = async () => {
    setLoading(true);
    console.log(`[VariantsEditor] Fetching variants for product: ${productId}`);
    try {
      const { data, error } = await getProductVariants(productId);
      if (error) throw error;
      setVariants(data || []);
      console.log(`[VariantsEditor] Successfully loaded ${data?.length || 0} variants`);
    } catch (error) {
      console.error("[VariantsEditor] Error loading variants:", error);
      toast({
        variant: "destructive",
        title: "Error loading variants",
        description: error.message
      });
    } finally {
      setLoading(false);
    }
  };

  const handleSelectVariant = (variant) => {
    setActiveVariantId(variant.id);
    setForm({
      title: variant.title || '',
      sku: variant.sku || '',
      price: variant.price || 0,
      compare_at_price: variant.compare_at_price || '',
      cost: variant.cost || '',
      inventory_qty: variant.inventory_qty || 0,
      image_url: variant.image_url || '',
      custom_description: variant.custom_description || '',
      is_active: variant.is_active !== false
    });
  };

  const handleAddVariant = () => {
    setActiveVariantId('new');
    setForm({
      title: 'New Variant',
      sku: '',
      price: 0,
      compare_at_price: '',
      cost: '',
      inventory_qty: 0,
      image_url: '',
      custom_description: '',
      is_active: true
    });
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setForm(prev => ({ ...prev, [name]: value }));
  };

  const handleSaveVariant = async (e) => {
    e.preventDefault();
    if (form.price === undefined || isNaN(form.price)) {
        toast({ variant: "destructive", title: "Validation Error", description: "Price is required." }); return;
    }
    if (form.inventory_qty === undefined || isNaN(form.inventory_qty)) {
        toast({ variant: "destructive", title: "Validation Error", description: "Inventory is required." }); return;
    }
    if (!form.sku) {
        toast({ variant: "destructive", title: "Validation Error", description: "SKU is required." }); return;
    }

    setSaving(true);
    console.log(`[VariantsEditor] Saving variant... Is new? ${activeVariantId === 'new'}`);
    
    try {
      const payload = {
        ...form,
        product_id: productId
      };

      if (activeVariantId === 'new') {
        const { error } = await createVariant(payload);
        if (error) throw error;
        console.log(`[VariantsEditor] Successfully created variant`);
      } else {
        const { error } = await updateVariant(activeVariantId, payload);
        if (error) throw error;
        console.log(`[VariantsEditor] Successfully updated variant: ${activeVariantId}`);
      }

      toast({ title: "Variant saved successfully" });
      await fetchVariants();
      
      if (activeVariantId === 'new') {
         setActiveVariantId(null);
      }
    } catch (error) {
      console.error("[VariantsEditor] Save error:", error);
      toast({
        variant: "destructive",
        title: "Failed to save variant",
        description: error.message
      });
    } finally {
      setSaving(false);
    }
  };

  const handleDeleteVariant = async (id) => {
    if (!window.confirm("Are you sure you want to delete this variant?")) return;
    
    console.log(`[VariantsEditor] Deleting variant: ${id}`);
    try {
      const { error } = await deleteVariant(id);
      if (error) throw error;
      
      console.log(`[VariantsEditor] Successfully deleted variant: ${id}`);
      toast({ title: "Variant deleted" });
      if (activeVariantId === id) setActiveVariantId(null);
      fetchVariants();
    } catch (error) {
      console.error("[VariantsEditor] Delete error:", error);
      toast({
        variant: "destructive",
        title: "Delete failed",
        description: error.message
      });
    }
  };

  if (loading) return <div className="p-4 flex items-center gap-2"><Loader2 className="animate-spin h-4 w-4" /> Loading variants...</div>;

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6 bg-zinc-900 border border-zinc-800 rounded-xl p-6 shadow-sm">
        <div className="md:col-span-3">
             <h2 className="text-xl font-semibold mb-2 text-zinc-100">Inline Variants Editor</h2>
        </div>

        <div className="md:col-span-1 border-r border-zinc-800 pr-0 md:pr-6 flex flex-col h-full min-h-[300px]">
             <div className="flex-1 space-y-2 overflow-y-auto max-h-[500px] mb-4">
                {variants.length === 0 && (
                    <div className="text-sm text-zinc-500 italic p-2 text-center border border-dashed border-zinc-800 rounded">
                        No variants yet.
                    </div>
                )}
                {variants.map(v => (
                    <div 
                        key={v.id} 
                        onClick={() => handleSelectVariant(v)}
                        className={cn(
                            "group p-3 rounded-lg border cursor-pointer transition-all hover:bg-zinc-800 flex justify-between items-start",
                            activeVariantId === v.id 
                                ? "bg-zinc-800 border-yellow-500/50" 
                                : "bg-zinc-950 border-zinc-800"
                        )}
                    >
                        <div>
                            <div className="font-semibold text-sm text-zinc-200">{v.title}</div>
                            <div className="text-xs text-zinc-500 mt-1">SKU: {v.sku}</div>
                            <div className="text-xs text-zinc-400 mt-0.5">Qty: {v.inventory_qty} | ${v.price}</div>
                        </div>
                        <button 
                            type="button"
                            onClick={(e) => {
                                e.stopPropagation();
                                handleDeleteVariant(v.id);
                            }}
                            className="text-zinc-600 hover:text-red-500 p-1 opacity-0 group-hover:opacity-100 transition-opacity"
                        >
                            <Trash2 size={14} />
                        </button>
                    </div>
                ))}
             </div>
             
             <Button onClick={handleAddVariant} variant="outline" className="w-full border-dashed border-zinc-700 hover:border-yellow-500 hover:text-yellow-500 text-zinc-400">
                <Plus className="mr-2 h-4 w-4" /> Add Variant
             </Button>
        </div>

        <div className="md:col-span-2 pl-0 md:pl-2">
            {!activeVariantId ? (
                <div className="h-full flex flex-col items-center justify-center text-zinc-500 min-h-[300px]">
                    <Edit2 className="mb-2 h-8 w-8 opacity-20" />
                    <p>Select a variant to edit inline.</p>
                </div>
            ) : (
                <form onSubmit={handleSaveVariant} className="space-y-4 animate-in fade-in slide-in-from-right-4 duration-300">
                    <div className="flex justify-between items-center mb-4">
                        <h3 className="font-semibold text-zinc-200">
                            {activeVariantId === 'new' ? 'Create New Variant' : 'Edit Variant'}
                        </h3>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                         <div className="space-y-2">
                             <Label className="text-zinc-300">Variant Title</Label>
                             <Input name="title" value={form.title} onChange={handleInputChange} className="bg-zinc-950 border-zinc-800"/>
                         </div>
                         <div className="space-y-2">
                             <Label className="text-zinc-300">SKU <span className="text-red-500">*</span></Label>
                             <Input name="sku" value={form.sku} onChange={handleInputChange} required className="bg-zinc-950 border-zinc-800"/>
                         </div>
                    </div>

                    <div className="grid grid-cols-3 gap-4">
                         <div className="space-y-2">
                             <Label className="text-zinc-300">Price <span className="text-red-500">*</span></Label>
                             <Input type="number" step="0.01" name="price" value={form.price} onChange={handleInputChange} required className="bg-zinc-950 border-zinc-800"/>
                         </div>
                         <div className="space-y-2">
                             <Label className="text-zinc-300">Compare at price</Label>
                             <Input type="number" step="0.01" name="compare_at_price" value={form.compare_at_price} onChange={handleInputChange} className="bg-zinc-950 border-zinc-800"/>
                         </div>
                         <div className="space-y-2">
                             <Label className="text-zinc-300">Cost (Admin)</Label>
                             <Input type="number" step="0.01" name="cost" value={form.cost} onChange={handleInputChange} className="bg-zinc-950 border-dashed border-zinc-700"/>
                         </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                         <div className="space-y-2">
                             <Label className="text-zinc-300">Inventory <span className="text-red-500">*</span></Label>
                             <Input type="number" name="inventory_qty" value={form.inventory_qty} onChange={handleInputChange} required className="bg-zinc-950 border-zinc-800"/>
                         </div>
                    </div>
                    
                    <div className="space-y-2 mt-4">
                         <Label className="text-zinc-300">Custom Description</Label>
                         <textarea 
                             name="custom_description" 
                             value={form.custom_description} 
                             onChange={handleInputChange} 
                             className="flex w-full rounded-md border border-zinc-800 bg-zinc-950 px-3 py-2 text-sm text-white placeholder:text-zinc-600 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-yellow-500 mt-1.5 min-h-[100px] resize-none"
                             placeholder="Leave empty to use product description"
                         />
                    </div>
                    
                    <div className="pt-4 flex justify-end gap-3">
                         <Button type="button" variant="ghost" onClick={() => setActiveVariantId(null)} className="text-zinc-400">
                            Cancel
                         </Button>
                         <Button type="submit" disabled={saving} className="bg-yellow-500 text-black hover:bg-yellow-400">
                            {saving ? <Loader2 className="animate-spin h-4 w-4 mr-2" /> : <Save className="h-4 w-4 mr-2" />} Save
                         </Button>
                    </div>
                </form>
            )}
        </div>
    </div>
  );
}
