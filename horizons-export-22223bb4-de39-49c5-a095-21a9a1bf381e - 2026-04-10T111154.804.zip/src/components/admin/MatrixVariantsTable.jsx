import React, { useState } from 'react';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Trash2, Edit, AlertCircle, Image as ImageIcon, Check, X } from 'lucide-react';
import { getVariantTitle } from '@/lib/variantHelpers';
import { useNavigate } from 'react-router-dom';
import { formatVariantOptions } from '@/utils/variantUtils';

export default function MatrixVariantsTable({ productId, variants = [], onVariantsChange }) {
  const safeVariants = Array.isArray(variants) ? variants : [];
  
  const navigate = useNavigate();
  const [editingKey, setEditingKey] = useState(null);
  const [editData, setEditData] = useState({});

  const getVariantKey = (variant, index) => {
    if (variant?.id && typeof variant.id === 'string' && !variant.id.startsWith('temp-')) {
      return variant.id;
    }
    return `var-${index}-${variant?.title || 'untitled'}`;
  };

  const handleRemove = (keyToRemove) => {
    if (window.confirm("Are you sure? This will remove this variant.")) {
        const newVars = safeVariants.filter((v, idx) => getVariantKey(v, idx) !== keyToRemove);
        if (typeof onVariantsChange === 'function') onVariantsChange(newVars);
    }
  };

  const handleEditVariant = (key, variant) => {
    if (!variant) return;
    const isExisting = variant.id && typeof variant.id === 'string' && !variant.id.startsWith('temp-');
    
    if (isExisting) {
      if (!productId || productId === 'new') {
        alert("Please save the product first before editing full variant details.");
        return;
      }
      navigate(`/admin/products/${productId}/variants/${variant.id}`);
    } else {
      setEditingKey(key);
      setEditData({ ...variant });
    }
  };

  const handleSaveEdit = (index) => {
    const newVars = [...safeVariants];
    newVars[index] = {
        ...(newVars[index] || {}),
        ...editData,
        price: parseFloat(editData.price) || 0,
        inventory_qty: parseInt(editData.inventory_qty) || 0,
        is_active: editData.is_active !== false
    };
    if (typeof onVariantsChange === 'function') onVariantsChange(newVars);
    setEditingKey(null);
    setEditData({});
  };

  const handleCancelEdit = () => {
    setEditingKey(null);
    setEditData({});
  };

  return (
    <div className="space-y-4 mt-8">
      <div className="p-4 border border-b-0 border-zinc-800 bg-zinc-950 rounded-t-xl">
        <h3 className="text-lg font-semibold">Matrix Variants List</h3>
      </div>
      <div className="rounded-b-xl border border-zinc-800 overflow-hidden bg-zinc-900">
        <Table>
          <TableHeader className="bg-zinc-900">
            <TableRow className="border-zinc-800 hover:bg-zinc-900">
              <TableHead className="w-[60px]"></TableHead>
              <TableHead className="text-zinc-400">Variant Title</TableHead>
              <TableHead className="text-zinc-400 hidden lg:table-cell">Options</TableHead>
              <TableHead className="text-zinc-400">SKU</TableHead>
              <TableHead className="text-zinc-400 text-right">Price</TableHead>
              <TableHead className="text-zinc-400 text-right">Inventory</TableHead>
              <TableHead className="text-zinc-400 text-center">Active</TableHead>
              <TableHead className="w-[100px] text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {safeVariants.length === 0 && (
                <TableRow>
                    <TableCell colSpan={8} className="text-center text-zinc-500 py-8">
                        <div className="flex flex-col items-center gap-2">
                           <AlertCircle className="w-6 h-6 text-zinc-600" />
                           <p>No variants yet.</p>
                           <p className="text-xs">Add options above to generate variants.</p>
                        </div>
                    </TableCell>
                </TableRow>
            )}
            {safeVariants.map((v, index) => {
              if (!v) return null;
              const key = getVariantKey(v, index);
              const isEditing = editingKey === key;
              
              const optionsDisplay = formatVariantOptions(v.optionValues);

              return (
                <TableRow key={key} className="border-zinc-800 hover:bg-zinc-900/50">
                  <TableCell>
                      {v.image_url ? (
                          <div className="w-10 h-10 rounded overflow-hidden border border-zinc-800 bg-zinc-950">
                              <img src={v.image_url} alt="v" className="w-full h-full object-cover" />
                          </div>
                      ) : (
                          <div className="w-10 h-10 rounded border border-zinc-800 bg-zinc-950 flex items-center justify-center text-zinc-700">
                              <ImageIcon size={16} />
                          </div>
                      )}
                  </TableCell>
                  
                  <TableCell>
                      <span className="font-medium text-zinc-300">{getVariantTitle(v) || v.title || 'Unnamed'}</span>
                  </TableCell>
                  
                  <TableCell className="hidden lg:table-cell">
                      <span className="text-zinc-400 text-xs">{optionsDisplay}</span>
                  </TableCell>
                  
                  <TableCell>
                      {isEditing ? (
                          <Input 
                              value={editData.sku || ''} 
                              onChange={e => setEditData({...editData, sku: e.target.value})} 
                              className="h-8 w-full min-w-[80px] bg-zinc-950 border-zinc-700 focus:border-yellow-500"
                              placeholder="SKU"
                          />
                      ) : (
                          <span className="text-zinc-400 font-mono text-xs">{v.sku || '-'}</span>
                      )}
                  </TableCell>
                  
                  <TableCell className="text-right">
                      {isEditing ? (
                          <Input 
                              type="number"
                              value={editData.price ?? 0} 
                              onChange={e => setEditData({...editData, price: e.target.value})} 
                              className="h-8 w-24 ml-auto text-right bg-zinc-950 border-zinc-700 focus:border-yellow-500"
                          />
                      ) : (
                          <span className="text-zinc-300 font-medium">R$ {parseFloat(v.price || 0).toFixed(2)}</span>
                      )}
                  </TableCell>
                  
                  <TableCell className="text-right">
                      {isEditing ? (
                          <Input 
                              type="number"
                              value={editData.inventory_qty ?? 0} 
                              onChange={e => setEditData({...editData, inventory_qty: e.target.value})} 
                              className="h-8 w-20 ml-auto text-right bg-zinc-950 border-zinc-700 focus:border-yellow-500"
                          />
                      ) : (
                          <span className="text-zinc-300">{parseInt(v.inventory_qty || 0)}</span>
                      )}
                  </TableCell>
                  
                  <TableCell className="text-center">
                      {isEditing ? (
                          <Checkbox 
                              checked={editData.is_active !== false}
                              onCheckedChange={(checked) => setEditData({...editData, is_active: !!checked})}
                              className="border-zinc-600 data-[state=checked]:bg-yellow-400 data-[state=checked]:text-black"
                          />
                      ) : (
                          <span className={`text-xs ${v.is_active !== false ? 'text-green-500' : 'text-red-500'}`}>
                              {v.is_active !== false ? 'Yes' : 'No'}
                          </span>
                      )}
                  </TableCell>
                  
                  <TableCell className="text-right">
                      {isEditing ? (
                          <div className="flex items-center justify-end gap-1">
                              <Button variant="ghost" size="icon" onClick={() => handleSaveEdit(index)} className="h-8 w-8 text-emerald-500 hover:text-emerald-400 hover:bg-emerald-950/20" title="Save">
                                  <Check size={16} />
                              </Button>
                              <Button variant="ghost" size="icon" onClick={handleCancelEdit} className="h-8 w-8 text-zinc-400 hover:text-white" title="Cancel">
                                  <X size={16} />
                              </Button>
                          </div>
                      ) : (
                          <div className="flex items-center justify-end gap-1">
                              <Button variant="ghost" size="icon" onClick={() => handleEditVariant(key, v)} className="h-8 w-8 text-zinc-400 hover:text-white" title="Edit Variant">
                                  <Edit size={14} />
                              </Button>
                              <Button variant="ghost" size="icon" onClick={() => handleRemove(key)} className="h-8 w-8 text-zinc-600 hover:text-red-500 hover:bg-red-950/20" title="Remove Variant">
                                  <Trash2 size={14} />
                              </Button>
                          </div>
                      )}
                  </TableCell>
                </TableRow>
              );
            })}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}