import React, { useState, useMemo, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  Trash2, ChevronDown, ChevronUp, Image as ImageIcon, 
  Edit2, Check, Loader2, Plus
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Checkbox } from '@/components/ui/checkbox';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from '@/components/ui/use-toast';
import { cn } from '@/lib/utils';
import { buildVariantGroups, hasMultipleOptions } from '@/lib/variants/buildVariantGroups';
import QuickVariantModal from '@/components/admin/QuickVariantModal';
import { 
    EditPriceModal, 
    EditInventoryModal, 
    EditSKUModal, 
    BulkDeleteVariantsModal 
} from '@/components/admin/BulkEditModals';
import { bulkEditPrice, bulkEditInventory, bulkEditSKU } from '@/lib/adminProductsApi';
import { v4 as uuidv4 } from 'uuid';

// --- Sub-components ---

function GroupPriceInput({ variants, onUpdate }) {
  const [isEditing, setIsEditing] = useState(false);
  const [inputValue, setInputValue] = useState('');
  
  const prices = useMemo(() => variants.map(v => parseFloat(v.price) || 0), [variants]);
  const min = Math.min(...prices);
  const max = Math.max(...prices);
  const allSame = min === max;
  const hasVariants = variants.length > 0;
  
  const displayValue = !hasVariants ? '-' : (allSame ? min.toFixed(2) : `${min.toFixed(2)} - ${max.toFixed(2)}`);

  useEffect(() => {
    if (!isEditing && hasVariants) {
        setInputValue(allSame ? min : '');
    }
  }, [min, allSame, isEditing, hasVariants]);

  const handleFocus = (e) => {
    e.stopPropagation();
    setIsEditing(true);
    setInputValue(allSame ? min : ''); 
  };

  const handleBlur = () => {
    setIsEditing(false);
    if (inputValue === '' || inputValue === null) return; 
    
    const val = parseFloat(inputValue);
    if (!isNaN(val) && val >= 0) {
      onUpdate(val);
    }
  };

  const handleKeyDown = (e) => {
    if (e.key === 'Enter') {
      e.target.blur();
    }
  };
  
  const handleChange = (e) => {
      setInputValue(e.target.value);
  }

  const handleClick = (e) => {
      e.stopPropagation();
  }

  return (
    <div className="relative group/price w-full" onClick={handleClick}>
       <div className={cn(
           "absolute left-2 top-1/2 -translate-y-1/2 text-xs pointer-events-none z-10",
           "text-yellow-500/70"
       )}>$</div>
       
       <Input
         type={isEditing ? "number" : "text"}
         value={isEditing ? inputValue : displayValue}
         onChange={handleChange}
         onFocus={handleFocus}
         onBlur={handleBlur}
         onKeyDown={handleKeyDown}
         onClick={handleClick}
         className={cn(
            "h-8 pl-5 bg-zinc-900 border-zinc-700 text-right text-sm font-medium transition-colors",
            "focus:border-yellow-500 focus:ring-1 focus:ring-yellow-500/50",
            "text-yellow-500",
            !isEditing && !allSame && "text-xs italic opacity-90"
         )}
         placeholder={!isEditing ? displayValue : "Set all"}
         step="0.01"
         min="0"
       />
       
       <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 px-2 py-1 bg-zinc-950 text-xs text-yellow-500 border border-yellow-500/20 rounded shadow-lg opacity-0 group-hover/price:opacity-100 pointer-events-none transition-opacity whitespace-nowrap z-50">
          Set price for all {variants.length} variants
       </div>
    </div>
  );
}

function VariantRow({ variant, productId, onUpdate, onDelete, isSelected, onToggleSelect, onOpenQuickEdit, isChild, variantMode }) {
  const navigate = useNavigate();
  const [localPrice, setLocalPrice] = useState(variant.price);
  const [localInventory, setLocalInventory] = useState(variant.inventory_qty);
  const [localDiscountValue, setLocalDiscountValue] = useState(variant.discount_value || 0);
  const [localDiscountType, setLocalDiscountType] = useState(variant.discount_type || 'percentage');
  const [isDirty, setIsDirty] = useState(false);
  
  useEffect(() => {
    setLocalPrice(variant.price);
    setLocalInventory(variant.inventory_qty);
    setLocalDiscountValue(variant.discount_value || 0);
    setLocalDiscountType(variant.discount_type || 'percentage');
    setIsDirty(false);
  }, [variant.price, variant.inventory_qty, variant.discount_value, variant.discount_type]);

  const handleChange = (field, value) => {
      if (field === 'price') setLocalPrice(value);
      if (field === 'inventory') setLocalInventory(value);
      if (field === 'discount_value') setLocalDiscountValue(value);
      if (field === 'discount_type') setLocalDiscountType(value);
      setIsDirty(true);
  };

  const handleSave = () => {
    if (!isDirty) return;
    
    const p = parseFloat(localPrice);
    const i = parseInt(localInventory);
    const d = parseFloat(localDiscountValue);

    if (isNaN(p) || isNaN(i) || isNaN(d)) return;

    onUpdate(variant.id, {
      price: p,
      inventory_qty: i,
      discount_value: d,
      discount_type: localDiscountType
    });
    setIsDirty(false);
  };

  const handleKeyDown = (e) => {
    if (e.key === 'Enter') {
        e.target.blur();
        handleSave();
    }
  };
  
  const handleEditClick = () => {
    if (variant.is_temp) {
        onOpenQuickEdit(variant);
    } else {
        navigate(`/admin/products/${productId}/variants/${variant.id}`);
    }
  };

  const displayTitle = variantMode === 'grouped' ? (variant.variant_label || variant.title || 'Unnamed Variant') : variant.title;

  return (
    <div className={cn(
      "grid grid-cols-[auto_50px_1fr_140px_120px_100px_40px] gap-4 items-center py-3 px-4 border-b border-white/5 hover:bg-white/5 transition-colors group/row",
      isSelected && "bg-blue-500/10 hover:bg-blue-500/20",
      isChild && "pl-12"
    )}>
      {/* 1. Checkbox */}
      <div className="flex items-center">
        <Checkbox 
            checked={isSelected} 
            onCheckedChange={onToggleSelect} 
            className="border-zinc-600 data-[state=checked]:bg-blue-600 data-[state=checked]:border-blue-600" 
        />
      </div>
      
      {/* 2. Image */}
      <div className="w-10 h-10 bg-zinc-800 rounded flex items-center justify-center overflow-hidden border border-white/10 relative cursor-pointer" onClick={handleEditClick}>
         {variant.image_url ? (
            <img src={variant.image_url} alt="" className="w-full h-full object-cover" />
         ) : (
            <ImageIcon className="w-5 h-5 text-zinc-600" />
         )}
      </div>

      {/* 3. Variant Title / SKU */}
      <div className="min-w-0 cursor-pointer" onClick={handleEditClick}>
        <div className="font-medium text-sm text-zinc-200 truncate hover:text-blue-400">
          {displayTitle}
          {variant.is_temp && <Badge variant="outline" className="ml-2 text-[10px] py-0 border-yellow-500 text-yellow-500">New</Badge>}
        </div>
        <div className="text-xs text-zinc-500 truncate flex items-center gap-2">
           {variant.sku ? <span>{variant.sku}</span> : <span className="italic opacity-50">No SKU</span>}
        </div>
      </div>

      {/* 4. Discount */}
      <div className="flex items-center gap-2">
          <Select 
            value={localDiscountType} 
            onValueChange={(val) => handleChange('discount_type', val)}
            onOpenChange={(open) => !open && handleSave()}
          >
             <SelectTrigger className="h-8 w-[60px] bg-zinc-900 border-zinc-700 text-xs px-2">
                 <SelectValue />
             </SelectTrigger>
             <SelectContent>
                 <SelectItem value="percentage">%</SelectItem>
                 <SelectItem value="fixed">$</SelectItem>
             </SelectContent>
          </Select>
          <Input 
             type="number"
             value={localDiscountValue}
             onChange={(e) => handleChange('discount_value', e.target.value)}
             onBlur={handleSave}
             onKeyDown={handleKeyDown}
             className="h-8 bg-zinc-900 border-zinc-700 text-right text-xs"
             min="0"
          />
      </div>

      {/* 5. Price Input */}
      <div className="relative">
        <div className="absolute left-2 top-1/2 -translate-y-1/2 text-zinc-500 text-xs">$</div>
        <Input 
          type="number"
          value={localPrice} 
          onChange={(e) => handleChange('price', e.target.value)}
          onBlur={handleSave} 
          onKeyDown={handleKeyDown}
          className="h-8 pl-5 bg-zinc-900 border-zinc-700 focus:border-blue-500 text-right text-sm"
          step="0.01"
          min="0"
        />
      </div>

      {/* 6. Available (Inventory) Input */}
      <div className="relative">
        <Input 
          type="number"
          value={localInventory} 
          onChange={(e) => handleChange('inventory', e.target.value)}
          onBlur={handleSave}
          onKeyDown={handleKeyDown}
          className="h-8 bg-zinc-900 border-zinc-700 focus:border-blue-500 text-right text-sm" 
        />
      </div>

      {/* 7. Actions */}
      <div className="flex justify-end opacity-0 group-hover/row:opacity-100 transition-opacity">
         {isDirty ? (
             <Button size="icon" variant="ghost" className="h-8 w-8 text-green-500 hover:text-white" onClick={handleSave}>
                 <Check className="w-4 h-4" />
             </Button>
         ) : (
             <div className="flex items-center">
                 <Button size="icon" variant="ghost" className="h-8 w-8 text-zinc-500 hover:text-white" onClick={handleEditClick}>
                     <Edit2 className="w-4 h-4" />
                 </Button>
                 <Button size="icon" variant="ghost" className="h-8 w-8 text-zinc-500 hover:text-red-500" onClick={() => onDelete(variant.id)}>
                     <Trash2 className="w-4 h-4" />
                 </Button>
             </div>
         )}
      </div>
    </div>
  );
}

// --- Main Component ---

export default function VariantsSection({ productId, options, variants, onVariantsChange, variantMode = 'matrix' }) {
  const { toast } = useToast();
  const navigate = useNavigate();
  const safeOptions = Array.isArray(options) ? options : [];
  const safeVariants = Array.isArray(variants) ? variants : [];
  
  const [groupBy, setGroupBy] = useState('none');
  const [expandedGroups, setExpandedGroups] = useState(new Set());
  const [selectedVariants, setSelectedVariants] = useState(new Set());
  const [editingVariant, setEditingVariant] = useState(null);

  const [showBulkPrice, setShowBulkPrice] = useState(false);
  const [showBulkQty, setShowBulkQty] = useState(false);
  const [showBulkSku, setShowBulkSku] = useState(false);
  const [showBulkDelete, setShowBulkDelete] = useState(false);
  const [bulkProcessing, setBulkProcessing] = useState(false);

  const selectedVariantObjects = useMemo(() => {
    return safeVariants.filter(v => selectedVariants.has(v.id));
  }, [safeVariants, selectedVariants]);

  useEffect(() => {
    if (variantMode === 'matrix') {
        if (groupBy !== 'none' && !safeOptions.find(o => o.name === groupBy)) {
        setGroupBy('none');
        } else if ((!groupBy || groupBy === 'none') && hasMultipleOptions(safeOptions)) {
        setGroupBy(safeOptions[0].name); 
        }
    } else {
        setGroupBy('variant_group'); // Force grouping by variant_group in grouped mode
    }
  }, [safeOptions, groupBy, variantMode]);

  const enrichedVariants = useMemo(() => {
    if (variantMode === 'grouped') return safeVariants;
    const optionIdToName = safeOptions.reduce((acc, opt) => {
        if (opt.id) acc[opt.id] = opt.name;
        return acc;
    }, {});

    return safeVariants.map(variant => {
        if (!variant.optionValues || !Array.isArray(variant.optionValues)) return variant;
        
        const hasStaleNames = variant.optionValues.some(ov => 
             ov.optionId && optionIdToName[ov.optionId] && ov.optionName !== optionIdToName[ov.optionId]
        );

        if (!hasStaleNames) return variant;

        const newOptionValues = variant.optionValues.map(ov => {
             if (ov.optionId && optionIdToName[ov.optionId]) {
                 return { ...ov, optionName: optionIdToName[ov.optionId] };
             }
             return ov;
        });

        return { ...variant, optionValues: newOptionValues };
    });
  }, [safeVariants, safeOptions, variantMode]);

  const groups = useMemo(() => {
    if (variantMode === 'grouped') {
        const groupMap = new Map();
        enrichedVariants.forEach(v => {
            const groupName = v.variant_group || 'Ungrouped';
            if (!groupMap.has(groupName)) {
                groupMap.set(groupName, { id: groupName, label: groupName, items: [], isFlat: false });
            }
            groupMap.get(groupName).items.push(v);
        });
        const result = Array.from(groupMap.values()).map(g => ({
            ...g,
            count: g.items.length,
            totalInventory: g.items.reduce((sum, v) => sum + (parseInt(v.inventory_qty) || 0), 0)
        }));
        // Sort grouped results if necessary or put 'Ungrouped' last
        return result.sort((a,b) => a.label === 'Ungrouped' ? 1 : b.label === 'Ungrouped' ? -1 : a.label.localeCompare(b.label));
    }
    return buildVariantGroups(enrichedVariants, groupBy, safeOptions);
  }, [enrichedVariants, groupBy, safeOptions, variantMode]);

  useEffect(() => {
    if (groups.length > 0 && expandedGroups.size === 0) {
       const allIds = groups.map(g => g.id);
       setExpandedGroups(new Set(allIds));
    }
  }, [groups.length]); 

  // --- Handlers ---

  const handleUpdateVariant = (id, updates) => {
    const newVariants = safeVariants.map(v => v.id === id ? { ...v, ...updates } : v);
    onVariantsChange(newVariants);
  };
  
  const handleGroupPriceUpdate = (groupItems, newPrice) => {
     const ids = new Set(groupItems.map(v => v.id));
     const newVariants = safeVariants.map(v => {
         if (ids.has(v.id)) {
             return { ...v, price: newPrice };
         }
         return v;
     });
     onVariantsChange(newVariants);
     toast({ title: `Updated price for ${groupItems.length} variants` });
  };
  
  const handleSaveQuickEdit = (id, updates) => {
      handleUpdateVariant(id, updates);
      setEditingVariant(null);
  };

  const handleDeleteVariant = (id) => {
    if(!confirm("Are you sure you want to delete this variant?")) return;
    const newVariants = safeVariants.filter(v => v.id !== id);
    onVariantsChange(newVariants);
    toast({ title: "Variant deleted" });
  };
  
  const toggleGroupExpand = (groupId) => {
    const next = new Set(expandedGroups);
    if (next.has(groupId)) next.delete(groupId);
    else next.add(groupId);
    setExpandedGroups(next);
  };

  const expandAll = () => setExpandedGroups(new Set(groups.map(g => g.id)));
  const collapseAll = () => setExpandedGroups(new Set());

  const toggleSelectVariant = (id) => {
    const next = new Set(selectedVariants);
    if (next.has(id)) next.delete(id);
    else next.add(id);
    setSelectedVariants(next);
  };

  const toggleSelectGroup = (groupId, groupItems) => {
    const next = new Set(selectedVariants);
    const allSelected = groupItems.every(v => next.has(v.id));
    
    groupItems.forEach(v => {
      if (allSelected) next.delete(v.id);
      else next.add(v.id);
    });
    setSelectedVariants(next);
  };

  const toggleSelectAll = (checked) => {
     if (checked) {
         setSelectedVariants(new Set(safeVariants.map(v => v.id)));
     } else {
         setSelectedVariants(new Set());
     }
  };

  const handleAddGroupedVariant = (groupName = '') => {
      const newVariant = {
          id: `temp-${uuidv4()}`,
          is_temp: true,
          title: 'New Variant',
          variant_label: 'New Variant',
          variant_group: groupName,
          price: 0,
          inventory_qty: 0,
          discount_type: 'percentage',
          discount_value: 0
      };
      onVariantsChange([...safeVariants, newVariant]);
      
      if (groupName) {
          const nextExpanded = new Set(expandedGroups);
          nextExpanded.add(groupName);
          setExpandedGroups(nextExpanded);
      }
      toast({ title: "Added new variant" });
  };

  const handleBulkEditPrices = async (pricesMap) => {
      try {
        setBulkProcessing(true);
        if (productId && productId !== 'new') {
            await bulkEditPrice(productId, pricesMap);
        }
        const newVariants = safeVariants.map(v => {
            if (pricesMap.hasOwnProperty(v.id)) {
                return { ...v, price: parseFloat(pricesMap[v.id]) || 0 };
            }
            return v;
        });
        onVariantsChange(newVariants);
        toast({ title: "Prices updated", description: `Updated ${Object.keys(pricesMap).length} variants.` });
        setSelectedVariants(new Set());
      } catch (error) {
          console.error("Bulk price edit failed:", error);
          toast({ variant: "destructive", title: "Update failed", description: error.message });
      } finally {
          setBulkProcessing(false);
      }
  };

  const handleBulkEditQuantities = async (qtyMap) => {
      try {
        setBulkProcessing(true);
        if (productId && productId !== 'new') {
            await bulkEditInventory(productId, qtyMap);
        }
        const newVariants = safeVariants.map(v => {
            if (qtyMap.hasOwnProperty(v.id)) {
                return { ...v, inventory_qty: parseInt(qtyMap[v.id]) || 0 };
            }
            return v;
        });
        onVariantsChange(newVariants);
        toast({ title: "Inventory updated", description: `Updated ${Object.keys(qtyMap).length} variants.` });
        setSelectedVariants(new Set());
      } catch (error) {
          console.error("Bulk inventory edit failed:", error);
          toast({ variant: "destructive", title: "Update failed", description: error.message });
      } finally {
          setBulkProcessing(false);
      }
  };

  const handleBulkEditSkus = async (skuMap) => {
      try {
        setBulkProcessing(true);
        if (productId && productId !== 'new') {
            await bulkEditSKU(productId, skuMap);
        }
        const newVariants = safeVariants.map(v => {
            if (skuMap.hasOwnProperty(v.id)) {
                return { ...v, sku: skuMap[v.id] };
            }
            return v;
        });
        onVariantsChange(newVariants);
        toast({ title: "SKUs updated", description: `Updated ${Object.keys(skuMap).length} variants.` });
        setSelectedVariants(new Set());
      } catch (error) {
          console.error("Bulk SKU edit failed:", error);
          toast({ variant: "destructive", title: "Update failed", description: error.message });
      } finally {
          setBulkProcessing(false);
      }
  };

  const handleBulkDeleteVariants = () => {
      const newVariants = safeVariants.filter(v => !selectedVariants.has(v.id));
      onVariantsChange(newVariants);
      toast({ title: "Variants deleted", description: `Deleted ${selectedVariants.size} variants.` });
      setSelectedVariants(new Set());
  };
  
  const totalInventory = safeVariants.reduce((sum, v) => sum + (parseInt(v.inventory_qty) || 0), 0);
  const allSelected = safeVariants.length > 0 && selectedVariants.size === safeVariants.length;

  return (
    <div className="space-y-4">
      <QuickVariantModal 
         open={!!editingVariant}
         onOpenChange={(open) => !open && setEditingVariant(null)}
         variant={editingVariant}
         onSave={handleSaveQuickEdit}
      />
      
      <EditPriceModal 
         open={showBulkPrice} 
         onOpenChange={setShowBulkPrice} 
         onConfirm={handleBulkEditPrices} 
         selectedVariants={selectedVariantObjects}
      />
      <EditInventoryModal 
         open={showBulkQty} 
         onOpenChange={setShowBulkQty} 
         onConfirm={handleBulkEditQuantities} 
         selectedVariants={selectedVariantObjects}
      />
      <EditSKUModal 
         open={showBulkSku} 
         onOpenChange={setShowBulkSku} 
         onConfirm={handleBulkEditSkus} 
         selectedVariants={selectedVariantObjects}
      />
      <BulkDeleteVariantsModal 
         open={showBulkDelete} 
         onOpenChange={setShowBulkDelete} 
         onConfirm={handleBulkDeleteVariants} 
         count={selectedVariants.size} 
      />

      <div className="flex items-center justify-between mb-2">
          {variantMode === 'matrix' ? (
             hasMultipleOptions(safeOptions) && (
                <div className="flex items-center gap-2">
                    <span className="text-sm text-zinc-400 whitespace-nowrap">Group by</span>
                    <Select value={groupBy} onValueChange={setGroupBy}>
                        <SelectTrigger className="w-[140px] h-8 bg-zinc-900 border-zinc-700">
                        <SelectValue placeholder="None" />
                        </SelectTrigger>
                        <SelectContent>
                        {safeOptions.map(o => o.name && <SelectItem key={o.id} value={o.name}>{o.name}</SelectItem>)}
                        </SelectContent>
                    </Select>
                </div>
             )
          ) : (
             <div className="flex items-center gap-2">
                 <Button onClick={() => handleAddGroupedVariant('')} size="sm" variant="outline" className="h-8 text-xs border-zinc-700 text-zinc-300">
                     <Plus className="w-3 h-3 mr-1" /> Add Variant
                 </Button>
             </div>
          )}

          <div className="flex items-center gap-2 ml-auto">
              <Button variant="ghost" size="sm" onClick={expandAll} className="h-8 text-xs">Expand All</Button>
              <Button variant="ghost" size="sm" onClick={collapseAll} className="h-8 text-xs">Collapse All</Button>
          </div>
      </div>

      <div className="bg-zinc-900 border border-zinc-800 rounded-xl overflow-hidden relative">
        {bulkProcessing && (
            <div className="absolute inset-0 bg-black/50 z-50 flex items-center justify-center backdrop-blur-sm">
                <div className="bg-zinc-900 border border-zinc-800 p-6 rounded-xl flex flex-col items-center gap-3">
                    <Loader2 className="w-8 h-8 animate-spin text-yellow-500" />
                    <p className="text-sm text-white">Updating variants...</p>
                </div>
            </div>
        )}
        
        {/* Table Header */}
        <div className="flex items-center justify-between px-4 py-3 bg-zinc-950 border-b border-zinc-800">
            <div className="flex items-center gap-4 w-full">
                 <Checkbox 
                    checked={allSelected} 
                    onCheckedChange={toggleSelectAll}
                    className="border-zinc-600 data-[state=checked]:bg-blue-600 data-[state=checked]:border-blue-600 flex-shrink-0"
                 />
                 {selectedVariants.size > 0 ? (
                     <div className="flex items-center gap-3 animate-in fade-in slide-in-from-left-2 duration-200">
                         <span className="text-sm font-medium text-white">{selectedVariants.size} selected</span>
                         <div className="h-4 w-px bg-zinc-800 mx-1" />
                         <Button size="sm" variant="ghost" onClick={() => setShowBulkPrice(true)} disabled={selectedVariants.size < 1} className="h-7 text-xs hover:text-yellow-500">Edit Price</Button>
                         <Button size="sm" variant="ghost" onClick={() => setShowBulkQty(true)} disabled={selectedVariants.size < 1} className="h-7 text-xs hover:text-yellow-500">Edit Inventory</Button>
                         <Button size="sm" variant="ghost" onClick={() => setShowBulkSku(true)} disabled={selectedVariants.size < 1} className="h-7 text-xs hover:text-yellow-500">Edit SKU</Button>
                         
                         <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                                <Button size="sm" variant="ghost" className="h-7 w-7 p-0 ml-1">
                                    <span className="sr-only">More</span>
                                    <svg width="15" height="3" viewBox="0 0 15 3" fill="none" xmlns="http://www.w3.org/2000/svg" className="fill-current text-zinc-400">
                                        <circle cx="1.5" cy="1.5" r="1.5"/>
                                        <circle cx="7.5" cy="1.5" r="1.5"/>
                                        <circle cx="13.5" cy="1.5" r="1.5"/>
                                    </svg>
                                </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="start" className="bg-zinc-900 border-zinc-800">
                                <DropdownMenuItem onClick={() => setShowBulkDelete(true)} className="text-red-500">Delete variants</DropdownMenuItem>
                            </DropdownMenuContent>
                         </DropdownMenu>
                     </div>
                 ) : (
                     <div className="grid grid-cols-[1fr_140px_120px_100px_40px] gap-4 w-full ml-4 text-xs font-semibold text-zinc-400 uppercase tracking-wider">
                         <div>Variant</div>
                         <div>Discount</div>
                         <div className="text-right">Price</div>
                         <div className="text-right">Available</div>
                         <div></div>
                     </div>
                 )}
            </div>
        </div>

        <div className="bg-zinc-900 min-h-[100px]">
           {safeVariants.length === 0 && (
             <div className="p-8 text-center text-zinc-500 flex flex-col items-center justify-center">
               <p className="mb-2">No variants yet.</p>
               <p className="text-xs">{variantMode === 'matrix' ? 'Add options above to automatically generate variants.' : 'Click "Add Variant" to create grouped variants.'}</p>
             </div>
           )}

           {groups.map((group) => {
             const isExpanded = group.isFlat ? true : expandedGroups.has(group.id);
             const isGroupSelected = group.items.length > 0 && group.items.every(v => selectedVariants.has(v.id));
             
             return (
               <div key={group.id} className={cn(!group.isFlat && "border-b border-zinc-800 last:border-0")}>
                 
                 {!group.isFlat && (
                   <div 
                     className={cn(
                       "grid grid-cols-[auto_50px_1fr_140px_120px_100px_40px] gap-4 items-center py-2 px-4 cursor-pointer hover:bg-zinc-800/50 transition-colors select-none",
                       isExpanded && "bg-zinc-800/20"
                     )}
                     onClick={() => toggleGroupExpand(group.id)}
                   >
                      <div className="flex items-center" onClick={(e) => e.stopPropagation()}>
                         <Checkbox 
                            checked={isGroupSelected} 
                            onCheckedChange={() => toggleSelectGroup(group.id, group.items)}
                            className="border-zinc-600 data-[state=checked]:bg-blue-600 data-[state=checked]:border-blue-600"
                         />
                      </div>

                      <div className="col-span-2 flex items-center gap-3">
                          <div className="w-10 h-10 flex items-center justify-center bg-zinc-800/50 rounded text-zinc-500 border border-white/5">
                             {group.items?.[0]?.image_url ? (
                                <img src={group.items[0].image_url} className="w-full h-full object-cover rounded" alt="" />
                             ) : (
                                <ImageIcon className="w-4 h-4" />
                             )}
                          </div>
                          <div>
                             <div className="font-semibold text-white flex items-center gap-2">
                                {group.label} 
                                {isExpanded ? <ChevronUp className="w-3 h-3 text-zinc-500" /> : <ChevronDown className="w-3 h-3 text-zinc-500" />}
                             </div>
                             <div className="text-xs text-zinc-500">{group.count} variants</div>
                          </div>
                      </div>

                      <div></div>

                      <div>
                         <GroupPriceInput 
                            variants={group.items} 
                            onUpdate={(newPrice) => handleGroupPriceUpdate(group.items, newPrice)} 
                         />
                      </div>
                      
                      <div className="text-right">
                         <Badge variant="secondary" className="bg-zinc-800 text-zinc-400 font-normal">
                           {group.totalInventory}
                         </Badge>
                      </div>

                      <div className="flex justify-end opacity-0 hover:opacity-100" onClick={(e) => e.stopPropagation()}>
                          {variantMode === 'grouped' && (
                              <Button size="icon" variant="ghost" className="h-8 w-8 text-zinc-400 hover:text-white" onClick={(e) => { e.stopPropagation(); handleAddGroupedVariant(group.id === 'Ungrouped' ? '' : group.id); }}>
                                  <Plus className="w-4 h-4" />
                              </Button>
                          )}
                      </div>
                   </div>
                 )}

                 {isExpanded && (
                   <div className={cn(!group.isFlat && "pl-0 border-t border-zinc-800/50")}>
                      {group.items.map(variant => (
                        <div key={variant.id}>
                            <VariantRow 
                                variant={variant} 
                                productId={productId}
                                onUpdate={handleUpdateVariant}
                                onDelete={handleDeleteVariant}
                                isSelected={selectedVariants.has(variant.id)}
                                onToggleSelect={() => toggleSelectVariant(variant.id)}
                                onOpenQuickEdit={setEditingVariant}
                                isChild={!group.isFlat}
                                variantMode={variantMode}
                            />
                        </div>
                      ))}
                   </div>
                 )}
               </div>
             );
           })}
        </div>

        <div className="bg-zinc-950/50 border-t border-zinc-800 p-3 text-center text-xs text-zinc-400">
             Total inventory: {totalInventory} available
        </div>
      </div>
    </div>
  );
}