import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Loader2, Check, X } from "lucide-react";
import { format } from 'date-fns';
import { useToast } from "@/components/ui/use-toast";
import MembershipNotesPanel from './MembershipNotesPanel';
import { membershipAutomation } from '@/lib/membershipAutomation';

export default function ApplicationDetailsModal({ isOpen, onClose, application, columns, onUpdated, authorName }) {
  const { toast } = useToast();
  const [isApproving, setIsApproving] = useState(false);
  const [showApproveDialog, setShowApproveDialog] = useState(false);
  const [showRejectDialog, setShowRejectDialog] = useState(false);
  const [rejectReason, setRejectReason] = useState("");

  if (!application) return null;

  const handleApprove = async () => {
    setIsApproving(true);
    try {
      const result = await membershipAutomation.handleApproveApplication(application.id);
      
      toast({ title: "Success", description: result.message });
      setShowApproveDialog(false);
      onUpdated();
      onClose();
    } catch (error) {
      toast({ variant: "destructive", title: "Approval Failed", description: error.message || "An unexpected error occurred." });
    } finally {
      setIsApproving(false);
    }
  };

  const handleReject = async () => {
    if (!rejectReason.trim()) {
      toast({ variant: "destructive", title: "Required", description: "Rejection reason is required." });
      return;
    }

    try {
      const result = await membershipAutomation.handleRejectApplication(application.id, rejectReason);

      toast({ title: "Application rejected", description: result.message });
      setShowRejectDialog(false);
      setRejectReason("");
      onUpdated();
      onClose();
    } catch (error) {
      toast({ variant: "destructive", title: "Error", description: error.message });
    }
  };

  const isApproved = application.status === 'APPROVED / CONTRACT SENT';

  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="bg-zinc-950 border-zinc-800 text-white max-w-3xl p-0 overflow-hidden flex flex-col max-h-[90vh]">
        <div className="p-6 border-b border-zinc-800 bg-zinc-900/50">
          <div className="flex justify-between items-start">
            <div>
                <DialogTitle className="text-2xl font-bold">{application.company_name}</DialogTitle>
                <DialogDescription className="text-zinc-400 mt-1">
                  {application.plan} Application • Submitted {format(new Date(application.created_at), "PPP")}
                </DialogDescription>
            </div>
            <Badge className={isApproved ? 'bg-green-500 hover:bg-green-600' : 'bg-zinc-700'}>
              {application.status}
            </Badge>
          </div>
        </div>

        <Tabs defaultValue="details" className="flex-1 flex flex-col h-full overflow-hidden">
          <div className="px-6 border-b border-zinc-800">
            <TabsList className="bg-transparent border-b-0 space-x-4">
              <TabsTrigger 
                value="details" 
                className="data-[state=active]:bg-zinc-800 data-[state=active]:text-white text-zinc-400 rounded-none border-b-2 border-transparent data-[state=active]:border-yellow-500 pb-2 px-1"
              >
                Details
              </TabsTrigger>
              <TabsTrigger 
                value="notes" 
                className="data-[state=active]:bg-zinc-800 data-[state=active]:text-white text-zinc-400 rounded-none border-b-2 border-transparent data-[state=active]:border-yellow-500 pb-2 px-1"
              >
                Notes
              </TabsTrigger>
            </TabsList>
          </div>

          <div className="flex-1 overflow-y-auto p-6">
            <TabsContent value="details" className="m-0 space-y-8 h-full focus:outline-none">
              
              <div className="grid md:grid-cols-2 gap-8">
                <div className="space-y-6">
                  <div>
                    <h4 className="text-xs font-bold uppercase tracking-wider text-zinc-500 mb-3 border-b border-zinc-800 pb-2">Applicant Details</h4>
                    <div className="space-y-3 text-sm">
                        <div className="grid grid-cols-3">
                          <span className="text-zinc-500 font-medium">Applicant:</span>
                          <span className="col-span-2 text-zinc-200">{application.applicant_name}</span>
                        </div>
                        <div className="grid grid-cols-3">
                          <span className="text-zinc-500 font-medium">Email:</span>
                          <span className="col-span-2 text-zinc-200">{application.email}</span>
                        </div>
                        <div className="grid grid-cols-3">
                          <span className="text-zinc-500 font-medium">Phone:</span>
                          <span className="col-span-2 text-zinc-200">{application.phone}</span>
                        </div>
                    </div>
                  </div>

                  <div>
                    <h4 className="text-xs font-bold uppercase tracking-wider text-zinc-500 mb-3 border-b border-zinc-800 pb-2">Location</h4>
                    <div className="space-y-3 text-sm">
                        <div className="grid grid-cols-3">
                          <span className="text-zinc-500 font-medium">Address:</span>
                          <span className="col-span-2 text-zinc-200">{application.street || "N/A"}</span>
                        </div>
                        <div className="grid grid-cols-3">
                          <span className="text-zinc-500 font-medium">City/State:</span>
                          <span className="col-span-2 text-zinc-200">
                            {application.city}, {application.state} {application.zip}
                          </span>
                        </div>
                    </div>
                  </div>
                </div>

                <div className="space-y-6">
                  <div>
                    <h4 className="text-xs font-bold uppercase tracking-wider text-zinc-500 mb-3 border-b border-zinc-800 pb-2">Application Message</h4>
                    <div className="bg-zinc-900/50 rounded-lg p-4 border border-zinc-800">
                      <p className="text-sm text-zinc-300 leading-relaxed min-h-[80px]">
                        {application.message || "No additional message provided."}
                      </p>
                    </div>
                  </div>

                  {application.rejected_reason && (
                    <div className="bg-red-950/20 rounded-lg p-4 border border-red-900/30">
                      <h4 className="text-xs font-bold uppercase tracking-wider text-red-400 mb-2">Rejection Reason</h4>
                      <p className="text-sm text-red-200">{application.rejected_reason}</p>
                    </div>
                  )}
                  
                  {application.contract_url && (
                    <div className="bg-green-950/20 rounded-lg p-4 border border-green-900/30">
                      <h4 className="text-xs font-bold uppercase tracking-wider text-green-400 mb-2">Contract Link</h4>
                      <a href={application.contract_url} target="_blank" rel="noopener noreferrer" className="text-sm text-blue-400 hover:text-blue-300 break-all">
                        {application.contract_url}
                      </a>
                    </div>
                  )}
                </div>
              </div>

              {/* Actions Section inside details */}
              {!isApproved && application.status !== 'REJECTED' && (
                <div className="pt-6 border-t border-zinc-800 mt-auto">
                    {showRejectDialog ? (
                      <div className="bg-zinc-900 border border-zinc-800 rounded-lg p-4 space-y-3">
                        <h4 className="text-sm font-semibold text-white">Reject Application</h4>
                        <Textarea 
                          value={rejectReason}
                          onChange={(e) => setRejectReason(e.target.value)}
                          placeholder="Provide a reason for rejection..."
                          className="bg-zinc-950 border-zinc-800 min-h-[80px] text-sm"
                        />
                        <div className="flex justify-end gap-2">
                          <Button variant="ghost" size="sm" onClick={() => setShowRejectDialog(false)}>Cancel</Button>
                          <Button variant="destructive" size="sm" onClick={handleReject} disabled={!rejectReason.trim()}>
                            Confirm Rejection
                          </Button>
                        </div>
                      </div>
                    ) : showApproveDialog ? (
                      <div className="bg-zinc-900 border border-zinc-800 rounded-lg p-4 space-y-3">
                        <h4 className="text-sm font-semibold text-white">Approve Application</h4>
                        <p className="text-xs text-zinc-500">Are you sure you want to approve this application? This will generate and send the contract automatically.</p>
                        <div className="flex justify-end gap-2">
                          <Button variant="ghost" size="sm" onClick={() => setShowApproveDialog(false)}>Cancel</Button>
                          <Button className="bg-green-600 hover:bg-green-500 text-white" size="sm" onClick={handleApprove} disabled={isApproving}>
                            {isApproving ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : null} Confirm Approval
                          </Button>
                        </div>
                      </div>
                    ) : (
                      <div className="flex gap-3 justify-end">
                        <Button variant="outline" className="border-red-900/50 text-red-500 hover:bg-red-500/10" onClick={() => setShowRejectDialog(true)} disabled={isApproving}>
                          <X className="w-4 h-4 mr-2" /> Reject Application
                        </Button>
                        <Button className="bg-green-600 hover:bg-green-500 text-white" onClick={() => setShowApproveDialog(true)} disabled={isApproving}>
                          <Check className="w-4 h-4 mr-2" /> Approve Application
                        </Button>
                      </div>
                    )}
                </div>
              )}

            </TabsContent>

            <TabsContent value="notes" className="m-0 h-full focus:outline-none">
                <MembershipNotesPanel applicationId={application.id} authorName={authorName} />
            </TabsContent>
          </div>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}