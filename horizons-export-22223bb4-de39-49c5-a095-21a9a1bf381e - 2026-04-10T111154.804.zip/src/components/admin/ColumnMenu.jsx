import React from 'react';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator
} from "@/components/ui/dropdown-menu";
import { Button } from "@/components/ui/button";
import { MoreVertical, Edit2, ChevronLeft, ChevronRight, Trash2 } from "lucide-react";
import { isDefaultColumn, canDeleteColumn } from "@/lib/membershipStatusUtils";

export default function ColumnMenu({ 
  column, 
  applications, 
  onRename, 
  onMoveLeft, 
  onMoveRight, 
  onDelete,
  isFirst,
  isLast
}) {
  const isDefault = isDefaultColumn(column.name);
  
  if (isDefault) return null; // Only non-default columns get the menu based on requirements

  const handleDelete = () => {
    if (!canDeleteColumn(column, applications)) {
      alert("Cannot delete column that contains applications. Please move them first.");
      return;
    }
    if (confirm(`Are you sure you want to delete the column "${column.name}"?`)) {
      onDelete(column);
    }
  };

  const handleRename = () => {
    const newName = prompt(`Enter new name for column "${column.name}":`, column.name);
    if (newName && newName.trim() && newName !== column.name) {
      onRename(column, newName.trim());
    }
  };

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="ghost" size="icon" className="h-6 w-6 hover:bg-zinc-800 text-zinc-400 shrink-0">
          <MoreVertical className="h-4 w-4" />
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="bg-zinc-950 border-zinc-800 text-zinc-200">
        <DropdownMenuItem onClick={handleRename} className="cursor-pointer hover:bg-zinc-800 focus:bg-zinc-800">
          <Edit2 className="w-4 h-4 mr-2" />
          Rename
        </DropdownMenuItem>
        
        {!isFirst && (
          <DropdownMenuItem onClick={() => onMoveLeft(column)} className="cursor-pointer hover:bg-zinc-800 focus:bg-zinc-800">
            <ChevronLeft className="w-4 h-4 mr-2" />
            Move Left
          </DropdownMenuItem>
        )}
        
        {!isLast && (
          <DropdownMenuItem onClick={() => onMoveRight(column)} className="cursor-pointer hover:bg-zinc-800 focus:bg-zinc-800">
            <ChevronRight className="w-4 h-4 mr-2" />
            Move Right
          </DropdownMenuItem>
        )}
        
        <DropdownMenuSeparator className="bg-zinc-800" />
        
        <DropdownMenuItem 
          onClick={handleDelete}
          className="cursor-pointer text-red-500 hover:text-red-400 hover:bg-red-500/10 focus:bg-red-500/10 focus:text-red-400"
        >
          <Trash2 className="w-4 h-4 mr-2" />
          Delete
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}