import React, { useState, useMemo, useEffect } from 'react';
import { Plus, Trash2, Edit, ChevronDown, ChevronRight, MoreHorizontal, Layers, Tag, GripVertical } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Label } from '@/components/ui/label';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { cn } from '@/lib/utils';
import EditVariantModal from './EditVariantModal';
import { generateVariantCombinations, mergeVariantsWithCombos, groupVariantsByOption } from '@/lib/variantManager';

export default function VariantsManager({ options, variants, onOptionsChange, onVariantsChange, productImages = [] }) {
  // State for Options management
  const [newOptionValue, setNewOptionValue] = useState({}); // { optionIndex: "value" }

  // State for Variants Table
  const [groupBy, setGroupBy] = useState('none');
  const [expandedGroups, setExpandedGroups] = useState({});
  const [editingVariant, setEditingVariant] = useState(null);

  // --- Options Logic ---

  const handleAddOption = () => {
    if (options.length >= 3) return;
    const newOpts = [...options, { id: `temp-${Date.now()}`, name: "", values: [] }];
    onOptionsChange(newOpts);
  };

  const handleRemoveOption = (index) => {
    const newOpts = options.filter((_, i) => i !== index);
    onOptionsChange(newOpts);
    // Trigger regeneration of variants
    regenerateVariants(newOpts);
  };

  const handleOptionNameChange = (index, name) => {
    const newOpts = [...options];
    newOpts[index].name = name;
    onOptionsChange(newOpts);
  };

  const handleAddValue = (index) => {
    const val = newOptionValue[index]?.trim();
    if (!val) return;
    
    const newOpts = [...options];
    // Check dupe
    if (newOpts[index].values.some(v => v.value === val)) {
        setNewOptionValue({ ...newOptionValue, [index]: "" });
        return;
    }

    newOpts[index].values.push({ id: `temp-val-${Date.now()}`, value: val });
    onOptionsChange(newOpts);
    setNewOptionValue({ ...newOptionValue, [index]: "" });
    
    // Auto-regenerate variants
    regenerateVariants(newOpts);
  };

  const handleRemoveValue = (optIndex, valIndex) => {
    const newOpts = [...options];
    newOpts[optIndex].values.splice(valIndex, 1);
    onOptionsChange(newOpts);
    regenerateVariants(newOpts);
  };

  const regenerateVariants = (currentOptions) => {
      const combos = generateVariantCombinations(currentOptions);
      const merged = mergeVariantsWithCombos(variants, combos);
      onVariantsChange(merged);
  };

  // --- Variants Table Logic ---

  const handleVariantUpdate = (id, field, value) => {
    const updated = variants.map(v => v.id === id ? { ...v, [field]: value } : v);
    onVariantsChange(updated);
  };

  const handleDeleteVariant = (id) => {
    if(confirm("Delete this variant?")) {
        onVariantsChange(variants.filter(v => v.id !== id));
    }
  };

  // Grouping
  const groupedVariants = useMemo(() => {
    if (groupBy === 'none') return null;
    return groupVariantsByOption(variants, groupBy);
  }, [variants, groupBy]);

  // Toggle group expansion
  const toggleGroup = (key) => {
    setExpandedGroups(prev => ({ ...prev, [key]: !prev[key] }));
  };
  
  // Initialize all groups as expanded when grouping changes
  useEffect(() => {
     if (groupedVariants) {
         const initial = {};
         Object.keys(groupedVariants).forEach(k => initial[k] = true);
         setExpandedGroups(initial);
     }
  }, [groupBy]);

  return (
    <div className="space-y-8">
      
      {/* --- SECTION 1: OPTIONS --- */}
      <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-6">
        <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold flex items-center gap-2">
                <Layers className="w-5 h-5 text-yellow-500" />
                Product Options
            </h3>
            {options.length < 3 && (
                <Button onClick={handleAddOption} variant="outline" size="sm" className="border-dashed border-zinc-700 hover:border-yellow-500 hover:text-yellow-500">
                    <Plus className="w-4 h-4 mr-2" /> Add Option
                </Button>
            )}
        </div>

        <div className="space-y-4">
            {options.length === 0 && (
                <div className="text-center py-8 text-zinc-500 text-sm border border-dashed border-zinc-800 rounded-lg">
                    No options added. Click "Add Option" to define Size, Color, etc.
                </div>
            )}

            {options.map((opt, idx) => (
                <div key={idx} className="bg-zinc-950 border border-zinc-800 rounded-lg p-4 relative group">
                    <div className="grid grid-cols-1 md:grid-cols-4 gap-4 items-start">
                        {/* Option Name */}
                        <div className="md:col-span-1">
                            <Label className="text-xs text-zinc-500 uppercase font-bold mb-1.5 block">Option Name</Label>
                            <Input 
                                placeholder="e.g. Size" 
                                value={opt.name}
                                onChange={(e) => handleOptionNameChange(idx, e.target.value)}
                                className="bg-zinc-900 border-zinc-700"
                            />
                        </div>
                        
                        {/* Option Values */}
                        <div className="md:col-span-3">
                            <Label className="text-xs text-zinc-500 uppercase font-bold mb-1.5 block">Option Values</Label>
                            <div className="flex flex-wrap gap-2 mb-2">
                                {opt.values.map((val, vIdx) => (
                                    <Badge key={vIdx} variant="secondary" className="bg-yellow-500/10 text-yellow-500 border-yellow-500/20 hover:bg-yellow-500/20 pl-2 pr-1 py-1 flex items-center gap-1">
                                        {val.value}
                                        <button onClick={() => handleRemoveValue(idx, vIdx)} className="hover:text-white rounded-full p-0.5">
                                            <Trash2 className="w-3 h-3" />
                                        </button>
                                    </Badge>
                                ))}
                            </div>
                            <div className="flex gap-2">
                                <Input 
                                    placeholder="Add value (e.g. Small)" 
                                    value={newOptionValue[idx] || ""}
                                    onChange={(e) => setNewOptionValue({ ...newOptionValue, [idx]: e.target.value })}
                                    onKeyDown={(e) => e.key === 'Enter' && (e.preventDefault(), handleAddValue(idx))}
                                    className="bg-zinc-900 border-zinc-700 max-w-xs"
                                />
                                <Button onClick={() => handleAddValue(idx)} size="icon" variant="secondary" className="bg-zinc-800 hover:bg-zinc-700">
                                    <Plus className="w-4 h-4" />
                                </Button>
                            </div>
                        </div>
                    </div>
                    
                    <Button 
                        onClick={() => handleRemoveOption(idx)} 
                        variant="ghost" 
                        size="icon" 
                        className="absolute top-2 right-2 text-zinc-600 hover:text-red-500 opacity-0 group-hover:opacity-100 transition-opacity"
                    >
                        <Trash2 className="w-4 h-4" />
                    </Button>
                </div>
            ))}
        </div>
      </div>

      {/* --- SECTION 2: VARIANTS TABLE --- */}
      {variants.length > 0 && (
          <div className="bg-zinc-900 border border-zinc-800 rounded-xl overflow-hidden">
             <div className="p-4 border-b border-zinc-800 flex items-center justify-between bg-zinc-900/50">
                <div className="flex items-center gap-4">
                    <h3 className="font-semibold">Variants ({variants.length})</h3>
                    {options.length > 0 && (
                        <div className="flex items-center gap-2">
                            <span className="text-xs text-zinc-500 uppercase font-bold">Group By:</span>
                            <Select value={groupBy} onValueChange={setGroupBy}>
                                <SelectTrigger className="h-8 w-[140px] bg-zinc-950 border-zinc-700 text-xs">
                                    <SelectValue placeholder="None" />
                                </SelectTrigger>
                                <SelectContent>
                                    <SelectItem value="none">None</SelectItem>
                                    {options.filter(o => o.name).map(o => (
                                        <SelectItem key={o.id} value={o.name}>{o.name}</SelectItem>
                                    ))}
                                </SelectContent>
                            </Select>
                        </div>
                    )}
                </div>
             </div>

             <div className="overflow-x-auto">
                 <Table>
                    <TableHeader className="bg-zinc-950">
                        <TableRow className="hover:bg-transparent border-zinc-800">
                            <TableHead className="w-[50px]"></TableHead>
                            <TableHead className="w-[60px]">Image</TableHead>
                            <TableHead>Variant</TableHead>
                            <TableHead className="w-[150px]">SKU</TableHead>
                            <TableHead className="w-[120px]">Price</TableHead>
                            <TableHead className="w-[120px]">Inventory</TableHead>
                            <TableHead className="w-[100px] text-right">Actions</TableHead>
                        </TableRow>
                    </TableHeader>
                    <TableBody>
                        {groupBy === 'none' ? (
                            variants.map(variant => (
                                <VariantRow 
                                    key={variant.id} 
                                    variant={variant} 
                                    onUpdate={handleVariantUpdate}
                                    onDelete={handleDeleteVariant}
                                    onEdit={() => setEditingVariant(variant)}
                                />
                            ))
                        ) : (
                            Object.entries(groupedVariants).map(([groupName, groupData]) => (
                                <React.Fragment key={groupName}>
                                    {/* Group Header Row */}
                                    <TableRow className="bg-zinc-950/50 hover:bg-zinc-950 border-zinc-800">
                                        <TableCell className="py-2">
                                            <button onClick={() => toggleGroup(groupName)} className="p-1 hover:bg-zinc-800 rounded">
                                                {expandedGroups[groupName] ? <ChevronDown className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
                                            </button>
                                        </TableCell>
                                        <TableCell colSpan={6} className="py-2 font-medium text-zinc-300">
                                            {groupBy}: <span className="text-white ml-1">{groupName}</span>
                                            <span className="ml-4 text-xs text-zinc-500 font-normal">
                                                {groupData.variants.length} variants • 
                                                ${groupData.minPrice} - ${groupData.maxPrice} • 
                                                {groupData.totalInventory} in stock
                                            </span>
                                        </TableCell>
                                    </TableRow>
                                    
                                    {/* Variant Rows */}
                                    {expandedGroups[groupName] && groupData.variants.map(variant => (
                                        <VariantRow 
                                            key={variant.id} 
                                            variant={variant} 
                                            isGrouped 
                                            onUpdate={handleVariantUpdate}
                                            onDelete={handleDeleteVariant}
                                            onEdit={() => setEditingVariant(variant)}
                                        />
                                    ))}
                                </React.Fragment>
                            ))
                        )}
                    </TableBody>
                 </Table>
             </div>
          </div>
      )}

      <EditVariantModal 
         isOpen={!!editingVariant}
         onClose={() => setEditingVariant(null)}
         variant={editingVariant}
         onSave={(updated) => {
             const newVariants = variants.map(v => v.id === updated.id ? updated : v);
             onVariantsChange(newVariants);
         }}
         productImages={productImages}
      />
    </div>
  );
}

function VariantRow({ variant, onUpdate, onDelete, onEdit, isGrouped }) {
    return (
        <TableRow className="border-zinc-800 hover:bg-zinc-900/50">
            <TableCell>
               {/* Spacer or Drag Handle could go here */}
               <GripVertical className="w-4 h-4 text-zinc-700" />
            </TableCell>
            <TableCell>
                <div className="w-10 h-10 rounded border border-zinc-800 bg-zinc-950 overflow-hidden flex items-center justify-center">
                    {variant.image_url ? (
                        <img src={variant.image_url} alt="" className="w-full h-full object-cover" />
                    ) : (
                        <Tag className="w-4 h-4 text-zinc-600" />
                    )}
                </div>
            </TableCell>
            <TableCell>
                <div className="font-medium text-sm">{variant.title}</div>
            </TableCell>
            <TableCell>
                <Input 
                    value={variant.sku || ''} 
                    onChange={(e) => onUpdate(variant.id, 'sku', e.target.value)}
                    className="h-8 bg-zinc-950 border-zinc-700 text-xs font-mono"
                    placeholder="SKU"
                />
            </TableCell>
            <TableCell>
                <div className="relative">
                    <span className="absolute left-2 top-1/2 -translate-y-1/2 text-zinc-500 text-xs">$</span>
                    <Input 
                        type="number"
                        value={variant.price}
                        onChange={(e) => onUpdate(variant.id, 'price', e.target.value)}
                        className="h-8 pl-5 bg-zinc-950 border-zinc-700 text-xs"
                    />
                </div>
            </TableCell>
            <TableCell>
                <Input 
                    type="number"
                    value={variant.inventory_qty}
                    onChange={(e) => onUpdate(variant.id, 'inventory_qty', e.target.value)}
                    className="h-8 bg-zinc-950 border-zinc-700 text-xs"
                />
            </TableCell>
            <TableCell className="text-right">
                <div className="flex items-center justify-end gap-1">
                    <Button onClick={onEdit} variant="ghost" size="icon" className="h-8 w-8 hover:bg-zinc-800 hover:text-yellow-500">
                        <Edit className="w-3.5 h-3.5" />
                    </Button>
                    <Button onClick={() => onDelete(variant.id)} variant="ghost" size="icon" className="h-8 w-8 hover:bg-zinc-800 hover:text-red-500">
                        <Trash2 className="w-3.5 h-3.5" />
                    </Button>
                </div>
            </TableCell>
        </TableRow>
    );
}