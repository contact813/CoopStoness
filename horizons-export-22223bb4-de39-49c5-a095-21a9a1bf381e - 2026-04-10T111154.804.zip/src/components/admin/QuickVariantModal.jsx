import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Loader2 } from "lucide-react";

export default function QuickVariantModal({ open, onOpenChange, variant, onSave, loading = false }) {
  const [formData, setFormData] = useState({
    sku: '',
    price: 0,
    inventory_qty: 0
  });

  useEffect(() => {
    if (variant && open) {
      setFormData({
        sku: variant.sku || '',
        price: variant.price || 0,
        inventory_qty: variant.inventory_qty || 0
      });
    }
  }, [variant, open]);

  const handleSubmit = (e) => {
    e.preventDefault();
    onSave(variant.id, {
        ...variant,
        ...formData,
        price: parseFloat(formData.price),
        inventory_qty: parseInt(formData.inventory_qty)
    });
  };

  if (!variant) return null;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="bg-zinc-950 border-zinc-800 text-white sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>Edit Variant</DialogTitle>
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="space-y-4 pt-4">
          <div className="space-y-2">
            <Label className="text-zinc-400 text-xs uppercase font-bold">Variant Title</Label>
            <div className="p-2 rounded bg-zinc-900 border border-zinc-800 text-sm font-medium">
                {variant.title}
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
                <Label htmlFor="sku">SKU</Label>
                <Input 
                    id="sku"
                    value={formData.sku}
                    onChange={(e) => setFormData(p => ({...p, sku: e.target.value}))}
                    className="bg-zinc-900 border-zinc-700"
                />
            </div>
             <div className="space-y-2">
                <Label htmlFor="inventory">Inventory</Label>
                <Input 
                    id="inventory"
                    type="number"
                    value={formData.inventory_qty}
                    onChange={(e) => setFormData(p => ({...p, inventory_qty: e.target.value}))}
                    className="bg-zinc-900 border-zinc-700"
                />
            </div>
          </div>

          <div className="space-y-2">
             <Label htmlFor="price">Price ($)</Label>
             <Input 
                id="price"
                type="number"
                step="0.01"
                value={formData.price}
                onChange={(e) => setFormData(p => ({...p, price: e.target.value}))}
                className="bg-zinc-900 border-zinc-700"
            />
          </div>

          <DialogFooter className="mt-6">
             <Button type="button" variant="ghost" onClick={() => onOpenChange(false)}>Cancel</Button>
             <Button type="submit" disabled={loading} className="bg-yellow-500 text-black hover:bg-yellow-400">
                {loading && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
                Save Variant
             </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}