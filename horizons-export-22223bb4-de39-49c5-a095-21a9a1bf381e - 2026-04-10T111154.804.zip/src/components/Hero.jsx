import React from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';

const Hero = () => {
  return (
    <section className="section-bg">
      <div className="min-h-[calc(100vh-64px)] flex items-center justify-center py-16"> {/* Adjusted height and added vertical padding */}
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <h1 className="text-4xl sm:text-5xl md:text-7xl font-bold text-white mb-6 tracking-tight">
              Stronger <span className="text-yellow-400">Together</span>
            </h1>
            <p className="text-base sm:text-lg md:text-xl text-gray-300 max-w-3xl mx-auto mb-10">
              Uniting stone professionals to leverage collective power, reduce costs,
              and grow stronger together.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link to="/membership"> {/* Changed link destination to /membership */}
                <Button 
                  size="lg"
                  className="bg-yellow-400 hover:bg-yellow-500 text-black font-bold px-8 py-6 text-lg shadow-lg shadow-yellow-400/20 transition-all duration-300 transform hover:scale-105"
                >
                  Apply Now
                </Button>
              </Link>
              <Link to="/about">
                <Button 
                  size="lg"
                  variant="outline"
                  className="border-2 border-white/50 text-white hover:bg-white hover:text-black font-bold px-8 py-6 text-lg transition-all duration-300 transform hover:scale-105"
                >
                  Learn More
                </Button>
              </Link>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default Hero;