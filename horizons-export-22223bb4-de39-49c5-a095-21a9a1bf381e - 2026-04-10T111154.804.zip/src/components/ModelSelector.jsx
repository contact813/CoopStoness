import React from 'react';

export default function ModelSelector({ options=[], value, onChange }) {
  const opts = options.length ? options : ["Default"];
  return (
    <div className="mt-4">
      <label className="block text-sm text-zinc-300 mb-1">Model</label>
      <select
        className="w-full bg-zinc-900 border border-zinc-800 rounded-xl px-3 py-2"
        value={value || opts[0]}
        onChange={(e)=>onChange?.(e.target.value)}
      >
        {opts.map(o => <option key={o} value={o}>{o}</option>)}
      </select>
    </div>
  );
}