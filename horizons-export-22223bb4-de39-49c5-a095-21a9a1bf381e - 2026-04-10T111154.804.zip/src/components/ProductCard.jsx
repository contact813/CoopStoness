
import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { PLACEHOLDER_IMAGE } from '@/lib/imageUtils';
import { Button } from '@/components/ui/button';
import { Minus, Plus, Loader2 } from 'lucide-react';
import { cn } from '@/lib/utils';

export default function ProductCard({ product, onAddToCart }) {
  const [quantity, setQuantity] = useState(1);
  const [isAdding, setIsAdding] = useState(false);
  const navigate = useNavigate();

  // Validate product has variants
  if (!product || !product.variants || product.variants.length === 0) {
    console.warn(`[ProductCard] Product ${product?.id} has no valid variants. Skipping render.`);
    return null;
  }

  const displayTitle = product.title || 'Untitled Product';
  const displayImage = product.thumbnail_url || product.images?.[0]?.url || PLACEHOLDER_IMAGE;
  const displayPrice = product.min_price || 0;
  const isOutOfStock = product.inventory <= 0;
  const hasMultipleVariants = product.variants_count > 1;

  const handleIncrement = (e) => { e.preventDefault(); e.stopPropagation(); setQuantity(q => q + 1); };
  const handleDecrement = (e) => { e.preventDefault(); e.stopPropagation(); if (quantity > 1) setQuantity(q => q - 1); };

  const handleAdd = async (e) => {
    e.preventDefault(); e.stopPropagation();
    if (hasMultipleVariants) return; 
    if (!onAddToCart) return;
    setIsAdding(true);
    await onAddToCart(product, quantity);
    setIsAdding(false);
    setQuantity(1);
  };

  const handleSelectOptions = (e) => {
    e.preventDefault(); e.stopPropagation();
    navigate(`/product/${product.id}`);
  };

  return (
    <div className="group flex flex-col h-full rounded-2xl border border-zinc-800 bg-zinc-950 overflow-hidden transition-all duration-300 hover:border-yellow-500 hover:shadow-lg hover:shadow-yellow-500/10">
       <Link to={`/product/${product.id}`} className="flex flex-col flex-1 relative z-0">
          <div className="relative aspect-square w-full overflow-hidden bg-white p-6">
              <img 
                 src={displayImage} 
                 alt={displayTitle} 
                 className="h-full w-full object-contain transition-transform duration-500 group-hover:scale-110"
                 onError={(e) => { e.currentTarget.onerror = null; e.currentTarget.src = PLACEHOLDER_IMAGE; }}
                 loading="lazy"
              />

              <div className="absolute top-3 left-3">
                  {isOutOfStock ? (
                      <span className="bg-red-500/90 text-white text-[10px] font-bold px-2 py-1 rounded shadow-sm uppercase tracking-wide">Out of Stock</span>
                  ) : (
                      <span className="bg-green-600/90 text-white text-[10px] font-bold px-2 py-1 rounded shadow-sm uppercase tracking-wide">In Stock</span>
                  )}
              </div>
          </div>

          <div className="flex flex-1 flex-col p-5">
              {product.vendor && (
                  <div className="text-[10px] font-bold uppercase tracking-widest text-zinc-500 mb-1">{product.vendor}</div>
              )}
              
              <h3 className="text-sm font-bold text-zinc-100 line-clamp-2 min-h-[2.5rem] mb-1 group-hover:text-yellow-500 transition-colors leading-tight">
                  {displayTitle}
              </h3>
              
              <div className="mt-auto flex flex-col items-start gap-1">
                  <div className="flex items-baseline gap-1">
                      {hasMultipleVariants && <span className="text-xs text-zinc-400 font-normal">From</span>}
                      <span className="text-lg font-bold tracking-tight text-yellow-500">
                          ${Number(displayPrice).toFixed(2)}
                      </span>
                  </div>
              </div>
          </div>
       </Link>

       <div className="p-5 pt-0 mt-auto grid grid-cols-[110px_1fr] gap-3 relative z-10">
           {!hasMultipleVariants && !isOutOfStock ? (
               <div className="flex items-center justify-between bg-zinc-900 rounded-lg border border-zinc-800 h-10 px-1">
                    <button onClick={handleDecrement} disabled={quantity <= 1 || isAdding} className="w-8 h-full flex items-center justify-center text-zinc-400 hover:text-white hover:bg-zinc-800 rounded transition-colors disabled:opacity-30" type="button"><Minus size={14} strokeWidth={3} /></button>
                    <div className="flex-1 text-center text-sm font-bold text-white select-none">{quantity}</div>
                    <button onClick={handleIncrement} disabled={isAdding} className="w-8 h-full flex items-center justify-center text-zinc-400 hover:text-white hover:bg-zinc-800 rounded transition-colors disabled:opacity-30" type="button"><Plus size={14} strokeWidth={3} /></button>
               </div>
           ) : (
               <div className="h-10 text-xs text-zinc-500 flex items-center">
                  {hasMultipleVariants ? `${product.variants_count} options` : ''}
               </div> 
           )}

           <Button
               onClick={hasMultipleVariants ? handleSelectOptions : handleAdd}
               className={cn(
                   "h-10 font-bold rounded-lg transition-colors w-full shadow-none",
                   hasMultipleVariants ? "bg-zinc-800 hover:bg-zinc-700 text-white col-span-2" : "bg-yellow-500 hover:bg-yellow-400 text-black",
                   isAdding && "opacity-90 cursor-wait",
                   isOutOfStock && "opacity-50 cursor-not-allowed"
               )}
               disabled={isAdding || (isOutOfStock && !hasMultipleVariants)}
           >
               {isAdding ? <><Loader2 className="mr-2 h-4 w-4 animate-spin" /> Adding...</> : (hasMultipleVariants ? "Select Options" : (isOutOfStock ? "Sold Out" : "Add to Cart"))}
           </Button>
       </div>
    </div>
  );
}
