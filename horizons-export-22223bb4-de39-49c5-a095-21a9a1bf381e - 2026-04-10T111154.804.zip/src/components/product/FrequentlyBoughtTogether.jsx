
import React, { useEffect, useState } from 'react';
import { getAllProducts } from '@/lib/productsApi';
import { Checkbox } from "@/components/ui/checkbox";
import { Button } from "@/components/ui/button";
import { Plus, AlertCircle } from 'lucide-react';
import { PLACEHOLDER_IMAGE } from '@/lib/imageUtils';
import { useCart } from '@/contexts/CartContext';
import { useToast } from "@/components/ui/use-toast";

export default function FrequentlyBoughtTogether({ currentProductId, currentProductPrice }) {
  const [related, setRelated] = useState([]);
  const [selectedIds, setSelectedIds] = useState([]);
  const [error, setError] = useState(null);
  const { addItem } = useCart();
  const { toast } = useToast();

  useEffect(() => {
    let mounted = true;
    
    async function load() {
       try {
         const { data, error: fetchError } = await getAllProducts(1000);
         if (fetchError) throw fetchError;
         
         if (mounted && data) {
           const filtered = data.filter(d => String(d.id) !== String(currentProductId)).slice(0, 2);
           if (filtered.length > 0) {
             setRelated(filtered);
             setSelectedIds(filtered.map(d => d.id));
           }
         }
       } catch (err) {
         console.error("FrequentlyBoughtTogether: Error loading products", err);
         if (mounted) setError("Could not load related products.");
       }
    }
    load();
    
    return () => { mounted = false; };
  }, [currentProductId]);

  const toggleItem = (id) => {
    if (selectedIds.includes(id)) {
      setSelectedIds(prev => prev.filter(i => i !== id));
    } else {
      setSelectedIds(prev => [...prev, id]);
    }
  };

  const handleAddBundle = () => {
     related.filter(r => selectedIds.includes(r.id)).forEach(item => {
        addItem(item);
     });
     toast({
       title: "Items Added",
       description: "Related items were successfully added to your cart.",
     });
  };

  if (error) {
     return (
       <div className="border border-zinc-800 rounded-xl p-6 bg-zinc-900/30 mt-8 flex items-center justify-center text-zinc-400 gap-2">
         <AlertCircle className="w-5 h-5 text-red-400" />
         <span>{error}</span>
       </div>
     );
  }

  if (related.length === 0) return null;

  const bundleTotal = Number(currentProductPrice || 0) + related
    .filter(r => selectedIds.includes(r.id))
    .reduce((sum, item) => sum + Number(item.min_price || item.price || 0), 0);

  return (
    <div className="border border-zinc-800 rounded-xl p-6 bg-zinc-900/30 mt-8">
      <h3 className="text-xl font-bold text-white mb-6">Frequently Bought Together</h3>
      
      <div className="flex flex-col md:flex-row gap-6 items-center">
        <div className="flex items-center gap-2">
            <div className="w-24 h-24 rounded-lg bg-zinc-900 p-2 border border-zinc-700 relative overflow-hidden">
               <img src={PLACEHOLDER_IMAGE} className="w-full h-full object-contain opacity-50" alt="Current" /> 
               <div className="absolute bottom-1 right-1 bg-zinc-800/80 rounded-sm px-1 text-[10px] text-zinc-400">Current</div>
            </div>
            {related.map(item => (
                <React.Fragment key={item.id}>
                    <Plus className="text-zinc-500" />
                    <div className="w-24 h-24 rounded-lg bg-zinc-900 p-2 border border-zinc-700 relative overflow-hidden">
                        <img 
                            src={item.thumbnail_url || item.images?.[0]?.url || item.image || PLACEHOLDER_IMAGE} 
                            className="w-full h-full object-cover" 
                            alt={item.title} 
                        />
                         {!selectedIds.includes(item.id) && (
                             <div className="absolute inset-0 bg-black/60" />
                         )}
                    </div>
                </React.Fragment>
            ))}
        </div>

        <div className="flex-1 space-y-3 w-full">
            {related.map(item => (
                <div key={item.id} className="flex items-center gap-3">
                    <Checkbox 
                        checked={selectedIds.includes(item.id)} 
                        onCheckedChange={() => toggleItem(item.id)}
                        className="border-zinc-600 data-[state=checked]:bg-yellow-500 data-[state=checked]:border-yellow-500 data-[state=checked]:text-black"
                    />
                    <span className={`text-sm flex-1 truncate ${selectedIds.includes(item.id) ? 'text-zinc-200' : 'text-zinc-500'}`}>{item.title}</span>
                    <span className={`text-sm font-bold ${selectedIds.includes(item.id) ? 'text-yellow-500' : 'text-zinc-500'}`}>${Number(item.min_price || item.price || 0).toFixed(2)}</span>
                </div>
            ))}
            
            <div className="pt-4 flex flex-col sm:flex-row items-center gap-4 border-t border-zinc-800 mt-4">
                <div className="text-zinc-200">
                    Total Price: <span className="text-2xl font-bold text-white ml-2">${bundleTotal.toFixed(2)}</span>
                </div>
                <Button onClick={handleAddBundle} disabled={selectedIds.length === 0} className="bg-yellow-500 text-black hover:bg-yellow-400 font-bold w-full sm:w-auto ml-auto">
                    Add Selected to Cart
                </Button>
            </div>
        </div>
      </div>
    </div>
  );
}
