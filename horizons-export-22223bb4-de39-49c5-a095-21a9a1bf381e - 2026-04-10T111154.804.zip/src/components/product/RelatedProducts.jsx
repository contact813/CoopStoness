
import React, { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabaseClient';
import ProductCard from '@/components/ProductCard';
import { Loader2 } from 'lucide-react';
import { PLACEHOLDER_IMAGE } from '@/lib/imageUtils';

export default function RelatedProducts({ productId, vendor, category, limit = 4 }) {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function load() {
      if (!productId) return;
      
      let query = supabase
        .from('v_products_public')
        .select('*')
        .neq('id', productId)
        .limit(limit);

      // Prioritize vendor match
      if (vendor) {
        query = query.eq('vendor', vendor);
      } else if (category) {
        query = query.eq('category', category);
      }

      const { data, error } = await query;
      
      if (error) {
        console.error("Error loading related products:", error);
      }
      
      // Map data to ensure fallback image logic is consistently applied
      const mappedProducts = (data || []).map(p => ({
          ...p,
          thumbnail_url: p.thumbnail_url || p.images?.[0]?.url || PLACEHOLDER_IMAGE
      }));

      setProducts(mappedProducts);
      setLoading(false);
    }
    load();
  }, [productId, vendor, category, limit]);

  if (loading) return <div className="py-8 text-center"><Loader2 className="animate-spin inline text-zinc-600" /></div>;
  if (products.length === 0) return null;

  return (
    <div className="space-y-6">
      <h3 className="text-2xl font-bold text-white">Related Products</h3>
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {products.map(p => (
           <ProductCard key={p.id} product={p} />
        ))}
      </div>
    </div>
  );
}
