import React, { useState, useEffect } from "react";
import { cn } from "@/lib/utils";
import { ZoomIn } from "lucide-react";
import { PLACEHOLDER_IMAGE } from "@/lib/imageUtils";

export default function ProductGallery({ images = [], selectedVariantImage }) {
  const [activeImage, setActiveImage] = useState(null);
  const [isZoomed, setIsZoomed] = useState(false);

  // Helper to normalize image input (string or object)
  const normalizeImg = (img) => (typeof img === "string" ? img : img?.url);
  
  // Helper for alt text
  const getAlt = (img) => (typeof img === "string" ? "Product Image" : img?.alt || "Product Image");

  // Get the first image safely
  const firstImage = images && images.length > 0 ? normalizeImg(images[0]) : PLACEHOLDER_IMAGE;

  // Initialize activeImage with firstImage when product loads or images change
  useEffect(() => {
    if (images && images.length > 0) {
      setActiveImage(normalizeImg(images[0]));
    }
  }, [images]);

  // Update activeImage when selectedVariant changes and has an image_url property
  useEffect(() => {
    if (selectedVariantImage) {
      setActiveImage(selectedVariantImage);
    }
  }, [selectedVariantImage]);

  // Determine which image to display
  const displayImage = activeImage || firstImage || PLACEHOLDER_IMAGE;

  return (
    <div className="flex flex-col-reverse md:flex-row gap-4 h-full">
      {/* Thumbnails - Left Vertical Strip on Desktop */}
      {images && images.length > 1 && (
        <div className="flex md:flex-col gap-3 overflow-x-auto md:overflow-y-auto md:w-24 md:max-h-[520px] scrollbar-none py-1 px-1">
          {images.map((img, idx) => {
            const url = normalizeImg(img);
            const alt = getAlt(img);
            const isActive = activeImage === url;

            return (
              <button
                key={idx}
                onClick={() => setActiveImage(url)}
                className={cn(
                  "relative flex-shrink-0 h-20 w-20 md:h-24 md:w-24 rounded-xl border-2 overflow-hidden transition-all duration-200",
                  isActive
                    ? "border-yellow-500 ring-2 ring-yellow-500/30"
                    : "border-white/10 hover:border-white/20 bg-white/5 hover:bg-white/10"
                )}
              >
                <img
                  src={url || PLACEHOLDER_IMAGE}
                  alt={alt}
                  className="w-full h-full object-cover"
                />
              </button>
            );
          })}
        </div>
      )}

      {/* Main Image */}
      <div
        className={cn(
          "relative flex-1 bg-zinc-900 rounded-xl border border-white/10 overflow-hidden group cursor-zoom-in",
          "h-[420px] md:h-[520px] w-full p-2 md:p-3"
        )}
        onMouseEnter={() => setIsZoomed(true)}
        onMouseLeave={() => setIsZoomed(false)}
      >
        <img
          src={displayImage}
          alt="Product active"
          className={cn(
            "w-full h-full object-contain transition-transform duration-500 ease-in-out",
            isZoomed ? "scale-150" : "scale-100"
          )}
          style={{ transformOrigin: "center center" }}
        />
        
        <div className="absolute top-4 right-4 bg-black/60 backdrop-blur-md p-2 rounded-full text-white opacity-0 group-hover:opacity-100 transition-all duration-300 pointer-events-none">
          <ZoomIn size={20} />
        </div>
      </div>
    </div>
  );
}