import React, { useMemo } from 'react';
import { cn } from '@/lib/utils';
import { Label } from '@/components/ui/label';

export default function GroupedVariantSelectorNew({ variants = [], selectedVariant, onSelectVariant }) {
  // Group variants by variant_group
  const groupedVariants = useMemo(() => {
    const groups = new Map();
    variants.forEach(v => {
      // Exclude inactive variants
      if (v.is_active === false) return;
      
      const groupName = v.variant_group || 'Options';
      if (!groups.has(groupName)) {
        groups.set(groupName, []);
      }
      groups.get(groupName).push(v);
    });
    return Array.from(groups.entries());
  }, [variants]);

  if (groupedVariants.length === 0) return null;

  return (
    <div className="space-y-6">
      {groupedVariants.map(([groupName, groupItems]) => (
        <div key={groupName} className="space-y-3">
          <Label className="text-zinc-400 text-xs uppercase tracking-wider font-bold block">
            {groupName}
          </Label>
          <div className="flex flex-wrap gap-2">
            {groupItems.map(variant => {
              const isSelected = selectedVariant?.id === variant.id;
              const isOutOfStock = variant.inventory_qty <= 0;
              
              return (
                <button
                  key={variant.id}
                  onClick={() => {
                    console.log("Selected grouped variant:", {
                      id: variant.id, 
                      group: variant.variant_group, 
                      label: variant.variant_label, 
                      price: variant.price, 
                      stock: variant.inventory_qty
                    });
                    onSelectVariant(variant);
                  }}
                  disabled={isOutOfStock}
                  className={cn(
                    "px-4 py-2 rounded-lg border text-sm font-medium transition-all relative overflow-hidden",
                    isSelected 
                      ? "border-yellow-500 bg-yellow-500/10 text-yellow-500 shadow-[0_0_10px_rgba(234,179,8,0.2)]" 
                      : "border-zinc-700 bg-zinc-900 text-zinc-300 hover:border-zinc-500",
                    isOutOfStock && "opacity-50 cursor-not-allowed bg-zinc-900/50 decoration-slate-500 line-through"
                  )}
                >
                  {variant.variant_label || variant.title || 'Option'}
                  {isOutOfStock && <span className="sr-only"> (Out of Stock)</span>}
                </button>
              );
            })}
          </div>
        </div>
      ))}
    </div>
  );
}