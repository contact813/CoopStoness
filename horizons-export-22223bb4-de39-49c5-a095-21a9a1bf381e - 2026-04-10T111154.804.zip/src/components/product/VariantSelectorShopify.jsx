import React from 'react';
import { cn } from '@/lib/utils';
import { Label } from '@/components/ui/label';

export default function VariantSelectorShopify({ variants = [], selectedVariant, onChange, options = [] }) {
  if (!variants || variants.length === 0) return null;

  // We rely on simple mapping since standard structured mapping is handled within page components.
  // This allows the simple fallback to handle products without defined `options` arrays.
  
  return (
    <div className="space-y-3">
      <Label className="text-zinc-300">Options</Label>
      <div className="flex flex-wrap gap-2">
        {variants.map((v) => {
          const isSelected = selectedVariant?.id === v.id;
          const isOutOfStock = v.inventory_qty <= 0;

          return (
            <button
              key={v.id}
              onClick={() => !isOutOfStock && onChange(v)}
              disabled={isOutOfStock}
              className={cn(
                "px-4 py-2 rounded-lg border text-sm font-medium transition-all relative overflow-hidden",
                isSelected 
                  ? "border-yellow-500 bg-yellow-500/10 text-yellow-500" 
                  : "border-zinc-700 bg-zinc-900 text-zinc-300 hover:border-zinc-500",
                isOutOfStock && "opacity-50 cursor-not-allowed bg-zinc-900/50 decoration-slate-500 line-through"
              )}
            >
              {v.title}
              {isOutOfStock && <span className="sr-only"> (Out of Stock)</span>}
            </button>
          );
        })}
      </div>
    </div>
  );
}