/**
 * FILENAME: src/components/MemberGate.jsx
 * PURPOSE: Route wrapper that enforces authentication. Redirects unauthenticated users to /login.
 * STATUS: Updated with logging verification. Logic preserved.
 */
import React, { useEffect } from 'react';
import { Navigate, Outlet, useLocation } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { Loader2 } from 'lucide-react';

const MemberGate = () => {
  const { user, profile, isAuthLoading } = useAuth();
  const location = useLocation();

  useEffect(() => {
     if (!isAuthLoading) {
         // Logic Check Logging as requested
         const isMemberCheck = (profile?.role === 'member' || profile?.is_member === true);
         console.log("MemberGate Verification:", {
             userExists: !!user,
             profileRole: profile?.role,
             profileIsMember: profile?.is_member,
             PASS_MEMBER_CHECK: isMemberCheck
         });
     }
  }, [user, profile, isAuthLoading]);

  // SECTION: Loading Check
  if (isAuthLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-black">
        <Loader2 className="h-8 w-8 animate-spin text-yellow-500" />
      </div>
    );
  }

  // SECTION: Auth Check
  // Keeping existing logic unchanged (checking only for user existence) as per instructions
  if (!user) {
    // Passes "from" state so user can be redirected back after login
    return <Navigate to="/login" state={{ from: location }} replace />;
  }

  // Render protected content
  return <Outlet />;
};

export default MemberGate;