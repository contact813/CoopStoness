
import React from 'react';

export function ProductSkeleton() {
  return (
    <div className="flex flex-col bg-zinc-900 border border-zinc-800 rounded-xl overflow-hidden h-full animate-pulse">
      {/* Image Block */}
      <div className="aspect-[4/3] bg-zinc-800 w-full" />
      
      {/* Content Block */}
      <div className="p-5 flex flex-col flex-grow space-y-4">
        <div className="space-y-2">
          <div className="h-3 bg-zinc-800 rounded w-1/3" />
          <div className="h-5 bg-zinc-700 rounded w-3/4" />
          <div className="h-5 bg-zinc-700 rounded w-1/2" />
        </div>
        
        <div className="flex flex-col mt-auto space-y-3">
          <div className="h-4 bg-zinc-800 rounded w-1/4" />
          <div className="h-2 bg-zinc-800 rounded w-full" />
        </div>
      </div>
    </div>
  );
}

export function ProductSkeletonGrid({ count = 4 }) {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
      {Array.from({ length: count }).map((_, i) => (
        <ProductSkeleton key={i} />
      ))}
    </div>
  );
}
