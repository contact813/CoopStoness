
import React, { createContext, useContext, useState, useCallback } from 'react';

const ProductsContext = createContext();

export const useProductsRefresh = () => useContext(ProductsContext);

export const ProductsProvider = ({ children }) => {
  const [refreshTrigger, setRefreshTrigger] = useState(0);

  const triggerRefresh = useCallback(() => {
    console.log('[ProductsContext] triggerRefresh called');
    setRefreshTrigger(prev => prev + 1);
  }, []);

  return (
    <ProductsContext.Provider value={{ refreshTrigger, triggerRefresh }}>
      {children}
    </ProductsContext.Provider>
  );
};
