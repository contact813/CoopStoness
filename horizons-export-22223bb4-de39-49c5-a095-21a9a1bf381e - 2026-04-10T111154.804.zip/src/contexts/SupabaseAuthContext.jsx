/**
 * FILENAME: src/contexts/SupabaseAuthContext.jsx
 * PURPOSE: Compatibility layer for AuthContext. Re-exports AuthContext functionality to ensure backward compatibility.
 * STATUS: Fixed. Now correctly re-exports AuthProvider and hooks instead of null.
 */
import AuthContext, { AuthProvider, useAuth } from './AuthContext';

// Re-export everything from the main AuthContext
export { AuthProvider, useAuth, AuthContext };

// Aliases for backward compatibility with older code
export const useSupabaseAuth = useAuth;
export const SupabaseAuthContext = AuthContext;
export const SupabaseAuthProvider = AuthProvider;

// Default export to match typical Provider usage (e.g. in main.jsx)
export default AuthProvider;