
/**
 * FILENAME: src/contexts/AuthContext.jsx
 * PURPOSE: Manages global authentication state. Non-blocking initialization.
 * NOTE: Products and Rounds are now members-only. Authentication is required.
 */
import React, { createContext, useContext, useEffect, useState } from "react";
import { supabase } from "@/lib/supabaseClient";

export const AuthContext = createContext(null);

async function retryOperation(operation, maxRetries = 3, delay = 1000) {
  for (let i = 0; i < maxRetries; i++) {
    try {
      return await operation();
    } catch (error) {
      const isNetworkError = error.message === 'Failed to fetch' || error.name === 'TypeError';
      if (i === maxRetries - 1 || !isNetworkError) throw error;
      
      console.warn(`[AuthContext] Operation failed, retrying (${i + 1}/${maxRetries})...`, error);
      await new Promise(resolve => setTimeout(resolve, delay * Math.pow(2, i)));
    }
  }
}

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [session, setSession] = useState(null);
  const [profile, setProfile] = useState(null);
  const [isAuthInitialized, setIsAuthInitialized] = useState(false);
  const [authError, setAuthError] = useState(null);

  const fetchProfile = async (userId) => {
    try {
      const { data, error } = await retryOperation(async () => {
        return await supabase
          .from('profiles')
          .select('*')
          .eq('id', userId)
          .single();
      });
      
      if (error) {
        if (error.code !== 'PGRST116') {
           setAuthError(error.message);
        }
      } else {
        setProfile(data);
        setAuthError(null);
      }
    } catch (err) {
      console.error('[AuthContext] Unexpected error fetching profile:', err);
      setAuthError("Failed to load user profile.");
    }
  };

  const handleAuthError = async (error) => {
    const msg = error?.message || "";
    const code = error?.code || "";
    
    if (
      msg.includes("Refresh Token") || 
      msg.includes("refresh_token_not_found") ||
      code === "refresh_token_not_found"
    ) {
      console.warn("[AuthContext] Stale session detected. Clearing local auth state.");
      await supabase.auth.signOut();
      setUser(null);
      setSession(null);
      setProfile(null);
    } else {
      console.error("[AuthContext] Auth initialization error:", error);
      setAuthError("Authentication service unavailable.");
    }
  };

  useEffect(() => {
    let isMounted = true;

    const initAuth = async () => {
      try {
        console.log("[AuthContext] Initializing auth state...");
        const { data: { session: currentSession }, error } = await retryOperation(async () => {
           return await supabase.auth.getSession();
        });
        
        if (error) throw error;

        if (isMounted) {
          setSession(currentSession);
          setUser(currentSession?.user ?? null);
          if (currentSession?.user) {
            await fetchProfile(currentSession.user.id);
          }
          console.log("[AuthContext] Auth initialized successfully.");
        }
      } catch (error) {
        await handleAuthError(error);
      } finally {
        if (isMounted) {
          setIsAuthInitialized(true);
        }
      }
    };

    initAuth();

    const { data: { subscription } } = supabase.auth.onAuthStateChange(async (event, currentSession) => {
      if (isMounted) {
        console.log(`[AuthContext] Auth state changed: ${event}`);
        if (event === 'RECOVERY' || event === 'PASSWORD_RECOVERY') {
          setSession(currentSession);
          setUser(currentSession?.user ?? null);
          setIsAuthInitialized(true);
          return;
        }

        setSession(currentSession);
        setUser(currentSession?.user ?? null);
        
        if (currentSession?.user) {
           await fetchProfile(currentSession.user.id);
        } else {
           setProfile(null);
        }
        
        setIsAuthInitialized(true);
      }
    });

    return () => {
      isMounted = false;
      subscription.unsubscribe();
    };
  }, []);

  const signOut = async () => {
    console.log("[AuthContext] signOut initiated...");
    try {
      const { error } = await supabase.auth.signOut();
      if (error) {
        // Ignore specific expected errors when session is already gone
        if (error.status === 401 || error.message.includes('session_not_found')) {
          console.warn("[AuthContext] Supabase session already expired or not found. Ignoring.", error.message);
        } else {
          console.error("[AuthContext] Supabase sign out error:", error.message);
        }
      }
    } catch (error) {
      console.error("[AuthContext] Unexpected error during sign out API call:", error);
    } finally {
      // ALWAYS clear local state to avoid inconsistent UI
      console.log("[AuthContext] Clearing local user state...");
      setUser(null);
      setSession(null);
      setProfile(null);
      setIsAuthInitialized(true);
      return { success: true };
    }
  };

  return (
    <AuthContext.Provider value={{ user, session, profile, isAuthInitialized, authError, signOut }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
};

export default AuthContext;
