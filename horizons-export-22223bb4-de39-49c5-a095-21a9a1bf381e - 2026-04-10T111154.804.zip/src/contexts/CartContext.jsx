
import React, { createContext, useContext, useState, useEffect, useCallback, useMemo } from 'react';
import { useToast } from "@/components/ui/use-toast";
import { supabase } from '@/lib/supabaseClient';
import { addToRoundCart as apiAddToRoundCart } from '@/lib/roundsApi';

const CartContext = createContext();

export const useCart = () => {
  const context = useContext(CartContext);
  if (!context) {
    console.error('[useCart] CartContext not found. Ensure component is wrapped in CartProvider.');
    throw new Error('useCart must be used within a CartProvider');
  }
  return context;
};

const normalizeCart = (input) => {
  console.log('[CartContext] normalizeCart input:', input, 'type:', typeof input);
  
  if (Array.isArray(input)) {
    return input;
  }
  if (input === null || input === undefined) {
    return [];
  }
  if (typeof input === 'string') {
    try {
      const parsed = JSON.parse(input);
      return normalizeCart(parsed);
    } catch (e) {
      console.error('[CartContext] Error parsing cart string:', e);
      return [];
    }
  }
  if (typeof input === 'object') {
    if (Array.isArray(input.items)) {
      return input.items;
    }
    return [];
  }
  
  return [];
};

export const CartProvider = ({ children }) => {
  const { toast } = useToast();

  const [cart, setCart] = useState(() => {
    try {
      console.log('[CartContext] Initializing cart from localStorage');
      const storedCart = localStorage.getItem('coop_cart');
      return normalizeCart(storedCart);
    } catch (error) {
      console.error('[CartContext] Failed to parse cart from localStorage during initialization', error);
      return [];
    }
  });

  const safeCart = useMemo(() => {
    const normalized = normalizeCart(cart);
    return normalized;
  }, [cart]);

  useEffect(() => {
    try {
      localStorage.setItem('coop_cart', JSON.stringify(safeCart));
    } catch (error) {
      console.error('[CartContext] Error saving cart to localStorage:', error);
    }
  }, [safeCart]);

  const generateItemKey = useCallback((item) => {
    const roundPart = item.round_id || 'none';
    const variantPart = item.variant_id || 'default';
    const productPart = item.product_id || item.id;
    return `${roundPart}_${productPart}_${variantPart}`;
  }, []);

  const addToCart = useCallback((item) => {
    console.log('[CartContext] addToCart called with item:', item);
    setCart(prev => {
      const normalizedPrev = normalizeCart(prev);
      const itemKey = generateItemKey(item);
      const existingIndex = normalizedPrev.findIndex(i => generateItemKey(i) === itemKey);

      if (existingIndex > -1) {
        const updated = [...normalizedPrev];
        updated[existingIndex] = {
          ...updated[existingIndex],
          quantity: (updated[existingIndex].quantity || 0) + (item.quantity || 1)
        };
        return updated;
      }
      const newItem = { ...item, key: itemKey, quantity: item.quantity || 1 };
      return [...normalizedPrev, newItem];
    });
  }, [generateItemKey]);

  const updateQuantity = useCallback((itemKey, quantity) => {
    console.log('[CartContext] updateQuantity called:', { itemKey, quantity });
    if (quantity <= 0) {
      removeFromCart(itemKey);
      return;
    }
    setCart(prev => {
      const normalizedPrev = normalizeCart(prev);
      return normalizedPrev.map(item => 
        (item.key === itemKey || generateItemKey(item) === itemKey) 
          ? { ...item, quantity } 
          : item
      );
    });
  }, [generateItemKey]);

  const removeFromCart = useCallback((itemKey) => {
    console.log('[CartContext] removeFromCart called for key:', itemKey);
    setCart(prev => {
      const normalizedPrev = normalizeCart(prev);
      return normalizedPrev.filter(item => item.key !== itemKey && generateItemKey(item) !== itemKey);
    });
  }, [generateItemKey]);

  const clearCart = useCallback(() => {
    console.log('[CartContext] clearCart called');
    setCart([]);
    try {
      localStorage.removeItem('coop_cart');
    } catch (e) {
      console.error('[CartContext] Error removing cart from localStorage', e);
    }
  }, []);

  const getRoundCart = async (userId, roundId) => {
    const { data: cartData } = await supabase
      .from('round_carts')
      .select('id, status')
      .eq('user_id', userId)
      .eq('round_id', roundId)
      .maybeSingle();
    return cartData;
  };

  const createRoundCart = async (userId, roundId) => {
    const { data: newCart, error } = await supabase
      .from('round_carts')
      .insert({
        user_id: userId,
        round_id: roundId,
        status: 'active'
      })
      .select()
      .single();
    if (error) throw error;
    return newCart;
  };

  const addToRoundCart = async ({ roundId, userId, variantId, quantity }) => {
    console.log('[CartContext] addToRoundCart start validation:', { roundId, userId, variantId, quantity });
    
    if (!roundId || !userId || !variantId) {
      throw new Error("Missing required inputs for addToRoundCart.");
    }
    
    if (!quantity || quantity < 1) {
      throw new Error("Quantity must be at least 1.");
    }

    try {
      console.log('[CartContext] Validated inputs, delegating strictly to roundsApi.');
      const result = await apiAddToRoundCart({ roundId, userId, variantId, quantity });
      console.log('[CartContext] addToRoundCart success response:', result);
      return result;
    } catch (error) {
      console.error('[CartContext] Error adding to DB round cart:', error);
      throw error; 
    }
  };

  let cartTotal = 0;
  let count = 0;

  if (Array.isArray(safeCart)) {
    cartTotal = safeCart.reduce((total, item) => total + ((item.price || 0) * (item.quantity || 0)), 0);
    count = safeCart.reduce((total, item) => total + (item.quantity || 0), 0);
  }

  const value = {
    addToRoundCart,
    
    // EXPLICITLY COMMENTED OUT LOCAL CART PROPERTIES AS REQUESTED IN TASK 2:
    // cart: safeCart,
    // setCart,
    // addToCart,
    // removeFromCart,
    // updateQuantity,
    // clearCart,
    // cartTotal,
    // count,
    // getRoundCart,
    // createRoundCart,
    // roundCart: safeCart,
    // updateRoundCartQuantity: (p, q, r, v) => updateQuantity(`${r || 'none'}_${p}_${v || 'default'}`, q),
    // removeFromRoundCart: (p, r, v) => removeFromCart(`${r || 'none'}_${p}_${v || 'default'}`),
    // getRoundItems: (r) => safeCart.filter(i => i.round_id === r),
    // removeRoundCartItemByDbId: (id) => { setCart(prev => normalizeCart(prev).filter(i => i.round_cart_item_id !== id)); },
    // updateRoundCartItem: (id, q) => { if(q<=0) { setCart(prev => normalizeCart(prev).filter(i => i.round_cart_item_id !== id)); } else { setCart(prev => normalizeCart(prev).map(i => i.round_cart_item_id === id ? { ...i, quantity: q } : i)); } }
  };

  return <CartContext.Provider value={value}>{children}</CartContext.Provider>;
};
