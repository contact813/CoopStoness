
# Coop Stones - Product & Variant Validation Checklist

## 1. Creating Products & Matrix Variants (ProductForm.jsx)
- **No `custom_title` Used**: The form only relies on `title`. No `custom_title` or `custom_description` inputs are shown or processed during matrix generation.
- **Validation**:
  - Requires Product Title and Description.
  - Enforces `matrixVariants.length` matching option permutations.
  - Ensures every variant has correctly linked option values. If any variant has missing options, it throws an error: `"Todas as variants devem ter opções selecionadas"`.
- **Database Operations**:
  - Purges old options and variants systematically.
  - Recreates `product_options`, `product_option_values`.
  - Recreates `product_variants` and maps `variant_option_values`.
  - Ensures valid `option_id` and `option_value_id` prior to insertion.

## 2. Editing Variants Inline (VariantsEditor.jsx)
- **No `custom_title` Used**: Completely removed `custom_title` from state, payloads, and rendering logic.
- **Fields Processed**: `title`, `sku`, `price`, `compare_at_price`, `cost`, `inventory_qty`, `is_active`, `image_url`, `custom_description`.
- **Validation**:
  - Enforces `price > 0`, `inventory_qty >= 0`, and non-empty `sku`.
- **Option Values**: Handled natively via the `getVariantById` joining logic to present valid associations without modifying them inline.

## 3. Comprehensive Variant Editor (VariantForm.jsx)
- **No `custom_title` Used**: Field is completely absent from the detailed admin panel form.
- **Option Values Display**: Read-only display of Option Values linked correctly by ID mapping (`id`, `variant_id`, `option_id`, `optionName`, `option_value_id`, `value`).

## 4. Product Retrieval (productsApi.js)
- **No `custom_title` dependencies**: `isValidVariant` handles standard validation ensuring active, priced, valid SKU variants.
- **Storefront Normalization**: `getProductById` ALWAYS provides a populated `product.validVariants` field.
- **Rule of Thumb**: Front-end storefront elements NEVER iterate through `product.variants`. They MUST iterate through `product.validVariants` to ensure orphaned or invalid elements are excluded.

## 5. Deleting Products and Variants (adminProductsApi.js)
- **Cascade Deletion**: Handles reverse dependency clearing:
  1. `variant_option_values`
  2. `product_variants`
  3. `product_option_values`
  4. `product_options`
  5. `products`
- **Integrity**: Assures no dangling options or variants are preserved when parent contexts are removed.

## 6. Table & Export Formatting
- **Admin Display**: `MatrixVariantsTable.jsx` maps standard Option Name: Values pairs directly instead of relying on manually keyed custom values.
- **Excel Export**: `exportProductsExcel.js` extracts values strictly from normalized `optionValues` elements. Completely ignores deprecated `custom_title` variables to ensure standardized exports.
