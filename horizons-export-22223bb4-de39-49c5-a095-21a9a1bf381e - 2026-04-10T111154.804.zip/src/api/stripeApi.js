
/**
 * FILENAME: src/api/stripeApi.js
 * PURPOSE: Communicates with Supabase Edge Functions for Stripe integration.
 * STATUS: LEGACY Marketplace checkout disabled. Only rounds and subscriptions active.
 */
import { supabase } from "@/lib/supabaseClient";

const delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

export async function getAuthHeaders(forceRefresh = false) {
  try {
    let { data: { session }, error: sessionError } = await supabase.auth.getSession();

    if (sessionError) console.error("Error fetching initial session:", sessionError);

    if (session?.expires_at) {
        const now = Math.floor(Date.now() / 1000);
        if (now >= session.expires_at - 60) forceRefresh = true;
    }

    if (forceRefresh || !session || !session.access_token) {
      const { data: refreshData, error: refreshError } = await supabase.auth.refreshSession();
      if (refreshError) throw new Error(`Session refresh failed: ${refreshError.message}`);
      session = refreshData.session;
    }

    if (!session?.access_token) {
      throw new Error("User not authenticated: Unable to retrieve valid access token.");
    }

    return { Authorization: `Bearer ${session.access_token}` };
  } catch (error) {
    console.error("Failed to generate auth headers:", error);
    throw error;
  }
}

export async function invokeSupabaseFunction(functionName, options = {}, maxRetries = 2) {
  let lastError;
  
  for (let attempt = 0; attempt <= maxRetries; attempt++) {
    try {
      const generatedHeaders = await getAuthHeaders(attempt > 0);
      const invokeOptions = {
        ...options,
        headers: { ...generatedHeaders, ...options.headers }
      };

      const { data, error } = await supabase.functions.invoke(functionName, invokeOptions);

      if (error) {
        if (error.context && typeof error.context.json === 'function') {
            try {
                const errorBody = await error.context.json();
                error.details = errorBody;
            } catch (jsonError) { }
        }
        if (error.status === 401) throw new Error("Unauthorized: Token may be expired");
        throw error; 
      }
      return data;
    } catch (error) {
      lastError = error;
      const isAuthError = error.message?.includes("Unauthorized") || error.message?.includes("token");
      const isNetworkError = error.message?.includes("Failed to fetch") || error.name === 'TypeError';
      
      if (attempt < maxRetries && (isAuthError || isNetworkError)) {
        await delay(1000 * Math.pow(2, attempt));
      } else {
         break; 
      }
    }
  }
  throw lastError;
}

export async function createMarketplaceCheckout(items) {
  // LEGACY: Marketplace checkout disabled
  throw new Error("Marketplace checkout is disabled. Use rounds instead.");
}

export async function createSubscriptionCheckout(priceId) {
  try {
    const data = await invokeSupabaseFunction("create-payment-intent", {
      body: { priceId, type: 'subscription' }
    });
    if (data?.url) window.location.href = data.url;
    return data;
  } catch (error) {
    throw error;
  }
}

export async function createRoundCheckout(roundId) {
  try {
    const { data: { session } } = await supabase.auth.getSession();
    if (!session) throw new Error("No active session");

    const data = await invokeSupabaseFunction("stripe-checkout-round", {
      body: { round_id: roundId, user_id: session.user.id }
    });

    if (data?.url) window.location.href = data.url;
    else throw new Error("No checkout URL returned from Edge Function");
    
    return data;
  } catch (error) {
    throw error;
  }
}

export async function getOrders() {
  try {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) throw new Error("Not authenticated");

    const { data, error } = await supabase
      .from('orders')
      .select('*')
      .eq('user_id', user.id) 
      .order('created_at', { ascending: false });

    if (error) throw error;
    return data;
  } catch (error) {
    throw error;
  }
}

export async function getAdminOrders({ page = 1, search = '' }) {
  try {
    const PAGE_SIZE = 20;
    const from = (page - 1) * PAGE_SIZE;
    const to = from + PAGE_SIZE - 1;

    let query = supabase.from('orders').select('*', { count: 'exact' }).order('created_at', { ascending: false }).range(from, to);
    if (search) query = query.ilike('id', `%${search}%`);

    const { data: orders, error: ordersError, count } = await query;
    if (ordersError) throw ordersError;
    if (!orders || orders.length === 0) return { orders: [], total: 0 };

    const userIds = [...new Set(orders.map(o => o.user_id).filter(Boolean))];
    let profilesMap = {};
    if (userIds.length > 0) {
      const { data: profiles } = await supabase.from('profiles').select('id, email').in('id', userIds);
      if (profiles) profilesMap = profiles.reduce((acc, p) => { acc[p.id] = p; return acc; }, {});
    }

    const enrichedOrders = orders.map(order => ({ ...order, profiles: profilesMap[order.user_id] || { email: 'Unknown' } }));
    return { orders: enrichedOrders, total: count };
  } catch (error) {
    throw error;
  }
}

export async function getAdminOrder(orderId) {
  try {
    const { data: order, error } = await supabase.from('orders').select('*').eq('id', orderId).single();
    if (error) throw error;
    if (order && order.user_id) {
       const { data: profile } = await supabase.from('profiles').select('email').eq('id', order.user_id).single();
       if (profile) order.profiles = profile;
    }
    const { data: items } = await supabase.from('order_items').select('*').eq('order_id', orderId);
    return { ...order, items: items || [] };
  } catch (error) {
    throw error;
  }
}
