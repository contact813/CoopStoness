import { supabase } from '@/lib/supabaseClient';

/**
 * Helper to validate that a user session exists before making admin requests.
 * This prevents sending requests with undefined UUIDs to Supabase.
 */
async function validateAdminSession() {
  const { data: { session }, error } = await supabase.auth.getSession();
  if (error || !session?.user) {
    throw new Error('Unauthorized: No active session found. Please log in.');
  }
  return session.user;
}

/**
 * Fetch all users (profiles) ordered by creation date.
 * Includes robust error handling for missing data.
 */
export async function adminGetAllUsers() {
  await validateAdminSession();

  const { data, error } = await supabase
    .from('profiles')
    .select('*')
    .order('created_at', { ascending: false });

  if (error) {
    console.error("Error fetching users:", error);
    throw new Error(error.message || "Failed to fetch users list");
  }

  // Return empty array if data is null/undefined, ensuring UI doesn't crash
  return data || [];
}

/**
 * Fetch user profile details and calculate financial stats from orders.
 */
export async function adminGetUserDetails(userId) {
  if (!userId) throw new Error("User ID is required");
  await validateAdminSession();

  // 1. Fetch Profile
  const { data: profile, error: profileError } = await supabase
    .from('profiles')
    .select('*')
    .eq('id', userId)
    .single();

  if (profileError) {
    if (profileError.code === 'PGRST116') {
      throw new Error("User profile not found");
    }
    throw profileError;
  }

  if (!profile) {
      throw new Error("User profile not found");
  }

  // 2. Fetch Orders & Items
  const { data: orders, error: ordersError } = await supabase
    .from('orders')
    .select(`
      *,
      order_items (
        discount_amount
      )
    `)
    .eq('user_id', userId)
    .order('created_at', { ascending: false });

  if (ordersError) {
      console.warn("Could not fetch orders for user:", ordersError);
      // Don't fail the whole request if orders fail, just return empty orders
  }

  const safeOrders = orders || [];

  // 3. Calculate Stats
  let total_spent = 0;
  let estimated_savings = 0;
  const total_orders_count = safeOrders.length;

  safeOrders.forEach(order => {
    // Assuming 'paid' status or similar indicates a completed transaction
    if (['paid', 'completed', 'shipped', 'delivered'].includes(order.status)) {
      total_spent += Number(order.total_amount || 0);
      
      if (order.order_items && order.order_items.length > 0) {
        order.order_items.forEach(item => {
          estimated_savings += Number(item.discount_amount || 0);
        });
      }
    }
  });

  return {
    profile,
    orders: safeOrders,
    stats: {
      total_spent,
      estimated_savings,
      total_orders_count
    }
  };
}

/**
 * Update user profile data.
 */
export async function adminUpdateUser(userId, updates) {
  if (!userId) throw new Error("User ID is required");
  await validateAdminSession();

  // Verify user exists first
  const { data: existing, error: checkError } = await supabase
      .from('profiles')
      .select('id')
      .eq('id', userId)
      .single();
      
  if (checkError || !existing) {
      throw new Error("Cannot update: User not found");
  }

  const { error } = await supabase
    .from('profiles')
    .update(updates)
    .eq('id', userId);

  if (error) throw error;
}

/**
 * Delete user using Edge Function with Fallback.
 * Attempts hard delete via Edge Function first.
 * If that fails, performs soft delete by updating profile status.
 */
export async function adminDeleteUser(userId) {
  if (!userId) throw new Error("User ID is required");
  await validateAdminSession();

  console.log(`Deleting user ${userId}...`);
  
  try {
    // 1. Try Edge Function (Hard Delete / Auth Delete)
    const { data, error } = await supabase.functions.invoke('admin-user-actions', {
      body: {
        action: 'delete_user',
        user_id: userId
      }
    });

    if (error) {
        // If edge function fails (e.g. network error), throw to trigger fallback
        throw error;
    }
    
    // Check application-level success flag from the function response
    if (data && data.error) {
        throw new Error(data.error);
    }
    
    if (!data || data.success !== true) {
      throw new Error(data?.message || 'Edge function reported failure');
    }

    return { success: true, method: 'hard-delete', ...data };

  } catch (err) {
    console.warn('Edge function delete failed, attempting soft delete fallback:', err);
    
    // 2. Fallback: Soft Delete (Update Profile)
    try {
        // Check if profile exists before trying to update
        const { data: profileCheck } = await supabase.from('profiles').select('id').eq('id', userId).single();
        
        if (!profileCheck) {
             throw new Error("User not found, cannot delete.");
        }

        const { error: updateError } = await supabase
            .from('profiles')
            .update({ 
                membership_status: 'inactive', 
                role: null,
                is_deleted: true 
            })
            .eq('id', userId);

        if (updateError) throw updateError;

        return { success: true, method: 'soft-delete', message: 'User soft-deleted successfully (fallback)' };
    } catch (fallbackError) {
        console.error('Soft delete also failed:', fallbackError);
        throw new Error(`Delete failed completely. Edge error: ${err.message}. DB error: ${fallbackError.message}`);
    }
  }
}

/**
 * Create a new user.
 * Uses Edge Function for Auth creation to bypass client-side restriction,
 * then updates the automatically created profile.
 */
export async function adminCreateUser(userData) {
  await validateAdminSession();

  // 1. Create Auth User via Edge Function
  // We use the 'admin-user-actions' function which is standard for this purpose.
  // Direct usage of supabase.auth.admin.createUser() is blocked in browser environments.
  const { data, error: authError } = await supabase.functions.invoke('admin-user-actions', {
    body: {
      action: 'create_user',
      email: userData.email,
      password: 'TempPassword123!', // Default temp password
      email_confirm: true,
      user_metadata: {
        full_name: userData.full_name
      }
    }
  });

  if (authError) throw authError;
  
  if (data && data.error) {
      throw new Error(data.error);
  }

  // If the function returns user data, grab the ID
  const newUserId = data?.user?.id || data?.id;

  if (!newUserId) {
      // Fallback: if the edge function didn't return the ID clearly but succeeded
      // We might need to fetch the profile by email to find the new ID
      const { data: existing } = await supabase.from('profiles').select('id').eq('email', userData.email).single();
      if (existing) return existing.id;
      throw new Error("User creation failed or ID not returned.");
  }

  // 2. Update the Profile (which is usually created by a database trigger on auth.users insert)
  const { error: updateError } = await supabase
    .from('profiles')
    .update({
      name: userData.full_name,
      full_name: userData.full_name, // Ensure both fields are set if schema varies
      phone: userData.phone,
      company_name: userData.company_name,
      address_street: userData.address_street,
      address_city: userData.address_city,
      address_state: userData.address_state,
      address_zip: userData.address_zip,
      membership_tier: userData.membership_tier,
      membership_status: userData.membership_status,
      role: userData.role
    })
    .eq('id', newUserId);

  if (updateError) throw updateError;

  return newUserId;
}