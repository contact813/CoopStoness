
import { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabaseClient';
import { searchProducts } from '@/lib/productsApi';

export function useProductSearch() {
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState([]);
  const [searching, setSearching] = useState(false);
  const [error, setError] = useState(null);

  useEffect(() => {
    const delayDebounceFn = setTimeout(async () => {
      if (!searchQuery || searchQuery.length < 2) {
        setSearchResults([]);
        return;
      }

      setSearching(true);
      setError(null);

      try {
        const results = await searchProducts(searchQuery, 20);
        setSearchResults(results);
      } catch (err) {
        console.error("Search error:", err);
        setError(err.message);
      } finally {
        setSearching(false);
      }
    }, 300);

    return () => clearTimeout(delayDebounceFn);
  }, [searchQuery]);

  return { searchQuery, setSearchQuery, searchResults, searching, error };
}
