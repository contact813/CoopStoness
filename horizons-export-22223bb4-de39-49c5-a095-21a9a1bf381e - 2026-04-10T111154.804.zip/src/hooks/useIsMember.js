import { useAuth } from "@/contexts/AuthContext";

export default function useIsMember() {
  const { profile, loading } = useAuth();
  return { isMember: !!profile?.is_member, loading };
}