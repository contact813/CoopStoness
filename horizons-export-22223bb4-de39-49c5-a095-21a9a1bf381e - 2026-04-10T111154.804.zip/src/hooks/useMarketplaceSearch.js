
/**
 * LEGACY: Marketplace functionality disabled. Use rounds instead.
 */
import { useMemo } from 'react';

export const useMarketplaceSearch = (products = [], searchQuery = '') => {
  return useMemo(() => {
    return [];
  }, [products, searchQuery]);
};
