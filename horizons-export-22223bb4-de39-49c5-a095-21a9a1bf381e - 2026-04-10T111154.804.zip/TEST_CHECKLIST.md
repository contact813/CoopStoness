# Custom Variant Display Testing Checklist

This checklist verifies the end-to-end functionality of the new `custom_title` and `custom_description` feature for product variants.

## 1. Database & Infrastructure
- [x] Verify migration ran successfully via Supabase dashboard (`product_variants` table contains `custom_title` and `custom_description` columns).
- [x] Verify column types are `text` and nullable.
- [x] Verify the index `idx_product_variants_custom_title` was created successfully.

## 2. Admin Interface
- [ ] Navigate to the Admin Panel -> Products.
- [ ] Select a product with variants (e.g., STINGER ANTIQUE BRUSHES).
- [ ] Navigate to the Variant Editor for one of the variants.
- [ ] Locate the new "Custom Display (Optional)" section at the bottom of the form.
- [ ] Fill in `Custom Title` and `Custom Description` fields with test data.
- [ ] Click "Save Variant" and observe the success toast.
- [ ] Refresh the page to verify that the custom fields persisted correctly.
- [ ] Clear the custom fields and save to verify that saving `null` (empty strings) works.

## 3. Marketplace & Public Product Page
- [ ] Go to the public Marketplace and find the product you edited.
- [ ] Navigate to the Product detail page.
- [ ] Without selecting the custom variant, verify that the default `product.title` and `product.description` are displayed.
- [ ] Select the variant that has custom fields.
  - [ ] **Verify Title Changes:** The `<h1>` title should instantly change to your `custom_title`.
  - [ ] **Verify Description Changes:** The description HTML below the fold should instantly change to your `custom_description`.
- [ ] Select a different variant that *does not* have custom fields.
  - [ ] **Verify Fallback:** The title and description should instantly revert to the standard `product.title` and `product.description`.
- [ ] Verify that option buttons (the square selectable buttons) only display the short option names (e.g., "120 Grit"), *not* the custom title.

## 4. Cart & Checkout Functionality
- [ ] With the custom variant selected, add it to the cart.
- [ ] Navigate to the Cart page.
- [ ] Verify that the item shows up with the custom title (or a combination like `Product Name - Custom Title`).
- [ ] Proceed to checkout.
- [ ] Verify that Stripe checkout succeeds and processes the correct `variant.id`.
- [ ] Verify that inventory quantity decrements successfully after purchase.

## 5. Backward Compatibility
- [ ] Open a product that was created before this update and has variants.
- [ ] Verify that it loads without errors.
- [ ] Verify that selecting variants on this old product correctly falls back to the main product title and description without issues.

## 6. Build & Logs
- [ ] Check browser console on Admin Variant Edit page - ensure no React warnings about missing props or controlled/uncontrolled inputs.
- [ ] Check browser console on Product page - ensure no errors.
- [ ] Run `npm run build` locally or in the environment to ensure all type-checks and imports resolve successfully.