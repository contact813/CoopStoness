# Variant Loading Diagnostic Report

## Purpose
This report provides the exact SQL queries needed to diagnose why product variants for specific products (like "CYCLONE S WITH REINFORCED SILENT CORE") might be failing to load, while working for others ("K BOND VIVID").

## Instructions
Run these queries in your Supabase SQL Editor.

### 1. Identify Product IDs
First, find the actual `id` (bigint) for the problematic product and the working product.