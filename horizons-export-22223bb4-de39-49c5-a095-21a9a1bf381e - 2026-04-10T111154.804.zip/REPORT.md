# Critical Update Report

## 1. Universal Image Handling Fix
Implemented a consistent image resolution strategy in `src/lib/image.js` via `getProductImage()`:
- **Primary Source**: `product.images[0].url` (if it exists and is not empty).
- **Secondary Source**: `product.thumbnail_url` (legacy support).
- **Fallback**: Fixed placeholder URL `https://cdn.coopstones.com/placeholders/product.png`.
- **Application**: Applied this logic to `ProductCard.jsx` (Marketplace), `ProductsList.jsx` (Admin), and `ProductEdit.jsx` (Preview).

## 2. SKU Display in Admin
- Updated `src/admin/ProductsList.jsx`.
- **Logic**: Added SKU display below the vendor name using `row.SKU || row.sku_raw || '—'`.
- **Styling**: Used a monospace font for SKU to distinguish it from the vendor name.

## 3. SKU in Product Edit
- Updated `src/admin/ProductEdit.jsx`.
- **Logic**: SKU field now correctly binds to `model.SKU` which initializes from `data.SKU` or `data.sku_raw`.
- **Persistence**: Save payload now explicitly includes `SKU`.

## 4. Price Formatting
- Updated `src/admin/ProductEdit.jsx`.
- **Implementation**: Added a visual `$` symbol absolutely positioned inside the price input container.
- **Data Integrity**: The underlying value remains numeric; only the visual presentation includes the symbol.

## 5. Filter & Data Integrity Verification
- **Marketplace**: Verified that `ProductCard` handles products with missing images gracefully by using the fallback, ensuring no products are hidden due to display errors.
- **Admin**: `ProductsList` iterates over all records returned by the API without client-side filtering based on image presence.
- **Fallback Safety**: The placeholder logic is robust against null, undefined, or empty string values in image fields.

All requested critical fixes have been applied.