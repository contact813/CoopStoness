# Debugging & Fix Report: Image Rendering Issues

## 1. The Bug
Products in the Admin list and Marketplace were displaying "broken image" icons or blank spaces, particularly for imported products like those from "CYCLONE". 
- **Symptom**: Images failed to load, showing browser default broken icons.
- **Root Cause**: The fallback placeholder URL `https://cdn.coopstones.com/placeholders/product.png` (provided in previous instructions) was unreachable or invalid. When the application attempted to fallback to this URL via `onError` handlers, the fallback itself failed, resulting in a persistent broken image state.

## 2. Analysis
- **Code Trace**: The `getProductImage` function was returning the placeholder for missing images, and `onError` handlers were setting `src` to the same placeholder for failed loads.
- **Data Integrity**: Imported products likely had inconsistent `images` JSON structures (e.g., varying keys like `src` vs `url`), causing `getProductImage` to miss valid URLs, forcing a fallback to the broken placeholder.
- **Network**: The browser failed to resolve the CDN placeholder URL.

## 3. The Fix
I have implemented a comprehensive fix across the application:
1.  **Reliable Local Fallback**: Switched from the external CDN to a local asset `'/images/placeholder-product.svg'`, which is verified to exist in the project.
2.  **Robust Data Handling**: Updated `src/lib/image.js` to handle multiple JSON structures for images. It now checks for `url`, `src`, and `image_url` properties within the `images` JSONB array, ensuring imported data works without modification.
3.  **Universal Application**: Updated `ProductsList.jsx`, `ProductCard.jsx`, `ProductEdit.jsx`, and `RoundDetail.jsx` to use the new `PLACEHOLDER_IMAGE` constant in their `onError` handlers.

## 4. Verification
- **Admin List**: Missing or broken images will now display the local placeholder SVG instead of a broken icon.
- **Marketplace**: Products with valid `src` keys in their JSON will now display correctly. Products with truly broken links will fallback gracefully.
- **Consistency**: All views now share the exact same logic and fallback assets.

All image display issues should now be resolved.